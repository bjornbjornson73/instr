from __future__ import annotations

from typing import List, Optional
import math
import random

from PySide6 import QtCore

from instrctl.core import (
    BaseInstrument,
    Capability,
    EventBus,
    feature,
    register_instrument,
    type as typehint,
)
from instrctl.gui.widgets import (
    UnitLineEdit,
    LabeledSlider,
    ToggleSwitch,
    SweepPlotWidget,
    EventPlotWidget,
    MultiTracePlotWidget,
    WaterfallWidget,
)


def _sine(n: int, phase: float, period: float = 64.0, amp: float = 20.0) -> List[float]:
    return [amp * math.sin(2 * math.pi * ((i / period) + phase)) for i in range(n)]


@register_instrument()
class RemoteDataRateDemo(BaseInstrument):
    """Demo instrument that exercises all plot types and exposes a data-rate gauge.

    - Connection type: DEMO
    - Plots: Sweep, Event, MultiTrace, Waterfall
    - Controls: Sweep size adjustable
    - Gauge: Data rate (bytes/sec) as an Event plot
    """

    __abstract__ = False

    def __init__(self, *, event_bus: Optional[EventBus] = None):
        super().__init__(event_bus=event_bus)
        self._connected = False
        self._sweep_n = 512
        self._phase = 0.0
        self._run_sweep = False
        self._run_events = False
        self._run_rate = False
        self._last_t_ms: Optional[int] = None
        self._bytes_since = 0
        self._last_rate_t_ms: Optional[int] = None

    # ---- Connection ----
    @classmethod
    def supported_connections(cls):
        return ["DEMO"]

    @classmethod
    def connection_placeholders(cls):
        return {"DEMO": "No address required"}

    def connect(self, **kwargs) -> None:
        self._state.connected = True

    def disconnect(self) -> None:
        self._state.connected = False

    # ---- Global start/stop toggle ----
    def stream_off(self) -> None:
        self._run_sweep = False
        self._run_events = False
        self._run_rate = False

    @feature(ui={"widget": ToggleSwitch, "label": "Streaming", "off_method": stream_off})
    def stream_on(self) -> None:
        # Start all streams so plots immediately show data when opened
        self.start_sweep()
        self.start_events()
        self.start_mt()
        self.start_wf()
        self.start_rate()

    # ---- Sweep size control ----
    def get_sweep_size(self) -> int:
        return int(self._sweep_n)

    @feature(capability=Capability.REQUIRED, ui={"widget": LabeledSlider, "label": "Sweep Size", "min": 64, "max": 4096, "value": 512, "step": 64, "readback": get_sweep_size})
    def set_sweep_size(self, n: int) -> None:
        n = int(n)
        if n < 64:
            n = 64
        if n > 4096:
            n = 4096
        print(f"[DEBUG] set_sweep_size: Setting _sweep_n from {self._sweep_n} to {n}")
        self._sweep_n = n
        print(f"[DEBUG] set_sweep_size: Confirmed _sweep_n is now {self._sweep_n}")

    # ---- Sweep stream (SweepPlotWidget) ----
    def start_sweep(self) -> None:
        self._run_sweep = True
        self._last_t_ms = int(QtCore.QDateTime.currentMSecsSinceEpoch())

    def stop_sweep(self) -> None:
        self._run_sweep = False

    @feature(ui={
        "widget": SweepPlotWidget,
        "label": "Sweep",
        "markers": True,
        "interval_ms": 150,
        "start": start_sweep,
        "stop": stop_sweep,
    })
    def get_sweep_points(self) -> List[float]:
        n = int(self._sweep_n)
        print(f"[DEBUG] get_sweep_points: Using n={n} (from _sweep_n={self._sweep_n})")
        now = int(QtCore.QDateTime.currentMSecsSinceEpoch())
        dt = 0
        if self._last_t_ms is not None:
            dt = max(0, now - self._last_t_ms)
        self._last_t_ms = now
        self._phase += (1.2 if self._run_sweep else 0.25) * max(0.0, dt / 1000.0)
        base = _sine(n, self._phase)
        # simple moving peak
        peak = [10.0 * math.exp(-0.5 * ((i - 0.55 * n) / 8) ** 2) for i in range(n)]
        ys = [float(b + p) for b, p in zip(base, peak)]
        # Account bytes sent (y-only schema assumed)
        self._bytes_since += len(ys) * 8
        return ys

    # ---- Event stream (EventPlotWidget) ----
    def start_events(self) -> None:
        self._run_events = True

    def stop_events(self) -> None:
        self._run_events = False

    @feature(ui={
        "widget": EventPlotWidget,
        "label": "Events",
        "max_points": 2000,
        "markers": True,
        "interval_ms": 120,
        "start": start_events,
        "stop": stop_events,
    })
    def get_event_points(self) -> List[float]:
        base = 1.5 + 0.7 * math.sin(self._phase)
        jitter = 0.25
        y = float(max(0.05, base + (random.uniform(-jitter, jitter) if self._run_events else 0.0)))
        self._bytes_since += 8
        return [y]

    # ---- MultiTrace (two sweeps) ----
    def start_mt(self) -> None:
        self._run_sweep = True

    def stop_mt(self) -> None:
        self._run_sweep = False

    def get_trace_a(self) -> List[float]:
        n = int(self._sweep_n)
        ys = _sine(n, self._phase + 0.2, period=52.0, amp=12.0)
        self._bytes_since += len(ys) * 8
        return [float(v) for v in ys]

    def get_trace_b(self) -> List[float]:
        n = int(self._sweep_n)
        ys = _sine(n, self._phase + 0.5, period=70.0, amp=8.0)
        self._bytes_since += len(ys) * 8
        return [float(v) for v in ys]

    @feature(ui={
        "widget": MultiTracePlotWidget,
        "label": "MultiTrace",
        "sources": [
            {"name": "A", "getter": get_trace_a, "mode": "sweep"},
            {"name": "B", "getter": get_trace_b, "mode": "sweep"},
        ],
        "interval_ms": 180,
        "start": start_mt,
        "stop": stop_mt,
    })
    def show_multitrace(self):
        return None

    # ---- Waterfall (rows from sweeps) ----
    def start_wf(self) -> None:
        self._run_sweep = True

    def stop_wf(self) -> None:
        self._run_sweep = False

    def get_wf_row(self) -> List[float]:
        # Reuse sweep generator
        ys = self.get_sweep_points()
        # bytes counted in sweep already
        return ys

    @feature(ui={
        "widget": WaterfallWidget,
        "label": "Waterfall",
        "getter": get_wf_row,
        "interval_ms": 150,
        "start": start_wf,
        "stop": stop_wf,
    })
    def show_waterfall(self):
        return None

    # ---- Data rate gauge (Event plot of B/s) ----
    def start_rate(self) -> None:
        self._run_rate = True
        self._bytes_since = 0
        self._last_rate_t_ms = int(QtCore.QDateTime.currentMSecsSinceEpoch())

    def stop_rate(self) -> None:
        self._run_rate = False

    @feature(ui={
        "widget": EventPlotWidget,
        "label": "Data Rate (B/s)",
        "max_points": 500,
        "interval_ms": 250,
        "markers": False,
        "start": start_rate,
        "stop": stop_rate,
    })
    @typehint(stream="event")
    def get_data_rate_bps(self) -> List[float]:
        now = int(QtCore.QDateTime.currentMSecsSinceEpoch())
        if self._last_rate_t_ms is None:
            self._last_rate_t_ms = now
            return [0.0]
        dt_ms = max(1, now - self._last_rate_t_ms)
        self._last_rate_t_ms = now
        rate = float(self._bytes_since) / (dt_ms / 1000.0)
        # decay counter but keep some carry to avoid zeroing between slow calls
        self._bytes_since = max(0, self._bytes_since - int(rate * 0.25))
        return [rate]
