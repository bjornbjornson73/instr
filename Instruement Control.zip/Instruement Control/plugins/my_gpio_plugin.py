from __future__ import annotations

# This file lives outside the installed instrctl package and demonstrates
# how to add a brand-new abstract instrument type AND a concrete implementation
# without modifying the core package. Just drop this file into:
#   - <project_root>\plugins           (development)
#   - %USERPROFILE%\.instrctl\plugins  (user-wide)
# Then start the app or click "Reload Plugins" in the toolbar.

from typing import Optional

from instrctl.core import BaseInstrument, Capability, EventBus, feature, register_instrument
from instrctl.gui.widgets import GPIOPanel


class MyGpioController(BaseInstrument):
    """A custom abstract GPIO controller defined entirely in a plugin.

    The @register_instrument decorator on a concrete subclass can infer the
    'kind' from this abstract base class name at runtime (no core edits).
    """

    __abstract__ = True

    @feature(capability=Capability.REQUIRED, ui={"widget": GPIOPanel})
    def pins_count(self) -> int:  # pragma: no cover - abstract
        raise NotImplementedError

    @feature(capability=Capability.REQUIRED)
    def set_pin_mode(self, pin: int, mode: str) -> None:  # pragma: no cover - abstract
        """Set pin mode: 'IN' or 'OUT'."""
        raise NotImplementedError

    @feature(capability=Capability.REQUIRED)
    def write_pin(self, pin: int, value: int) -> None:  # pragma: no cover - abstract
        """Write logical level 0/1 to a pin configured as OUT."""
        raise NotImplementedError

    @feature(capability=Capability.REQUIRED)
    def read_pin(self, pin: int) -> int:  # pragma: no cover - abstract
        """Read logical level 0/1 from a pin (works for IN and OUT)."""
        raise NotImplementedError


@register_instrument()  # infers kind = MyGpioController, model = MyDemoGPIO
class MyDemoGPIO(MyGpioController):
    __abstract__ = False

    def __init__(self, *, event_bus: Optional[EventBus] = None, pins: int = 8) -> None:
        super().__init__(event_bus=event_bus)
        self._pins = pins
        self._modes = ["IN"] * pins
        self._values = [0] * pins

    @classmethod
    def supported_connections(cls):
        return ["DEMO"]

    @classmethod
    def connection_placeholders(cls):
        return {"DEMO": "No address required"}

    # Connection lifecycle
    def connect(self, **kwargs) -> None:
        self._state.connected = True

    def disconnect(self) -> None:
        self._state.connected = False

    # Shared-connection hooks (demo)
    def get_connection(self, **kwargs):
        return dict(kwargs)

    def set_connection(self, connection) -> None:
        self._state.connected = True

    # GPIO API required by the abstract base
    def pins_count(self) -> int:
        return self._pins

    def set_pin_mode(self, pin: int, mode: str) -> None:
        mode = mode.upper()
        if mode not in ("IN", "OUT"):
            raise ValueError("mode must be 'IN' or 'OUT'")
        self._modes[pin] = mode
        # Publish a gpio event so UIs can update
        self.events.publish("gpio", pin=pin, mode=mode, value=self._values[pin])

    def write_pin(self, pin: int, value: int) -> None:
        if self._modes[pin] != "OUT":
            raise RuntimeError("Pin is not configured as OUT")
        v = 1 if value else 0
        self._values[pin] = v
        # Publish a gpio event so UIs can update
        self.events.publish("gpio", pin=pin, mode=self._modes[pin], value=v)

    def read_pin(self, pin: int) -> int:
        return int(self._values[pin])
