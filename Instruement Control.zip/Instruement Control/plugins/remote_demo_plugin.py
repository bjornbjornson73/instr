from __future__ import annotations

"""
Remote demo plugin: demonstrates REMOTE parity using a Sweep plot with
configurable sweep size, plus a data rate gauge.

Usage:
- Choose DEMO connection type (no address) and optionally enable REMOTE.
- Start the stream; the Sweep plot shows synthetic data. Adjust sweep size.
- The Data Rate gauge shows bytes/sec the demo produced.
"""

from typing import List, Optional, Deque
from collections import deque
import time
import math
import random

from instrctl.core import BaseInstrument, feature, register_instrument, type as typehint

try:  # GUI bits may be unavailable in headless CI
    from PySide6 import QtCore, QtWidgets
    import pyqtgraph as pg
except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:# pragma: no cover
    QtCore = None  # type: ignore
    QtWidgets = object  # type: ignore
    pg = None  # type: ignore


# ---------------- Simple fallback widget ----------------
if hasattr(QtWidgets, "QWidget"):
    class RemoteDemoWidget(QtWidgets.QWidget):  # type: ignore[misc]
        """Minimal plot widget used as a fallback when core widgets aren't available."""

        def __init__(self, parent=None):  # pragma: no cover - GUI only
            super().__init__(parent)
            layout = QtWidgets.QVBoxLayout(self)
            self._plot = pg.PlotWidget() if pg else QtWidgets.QLabel("plot unavailable")  # type: ignore
            self._curve = self._plot.plot(pen='y') if pg else None  # type: ignore
            layout.addWidget(self._plot)
            self._ys: Deque[float] = deque(maxlen=4096)

        def update_points(self, pts):  # pragma: no cover - GUI only
            if not pts:
                return
            if isinstance(pts, list) and pts and isinstance(pts[0], (tuple, list)):
                ys = [float(y) for _, y in pts]
            else:
                ys = [float(y) for y in pts]
            self._ys.extend(ys)
            if self._curve:
                self._curve.setData(list(self._ys))
else:
    class RemoteDemoWidget:  # type: ignore[misc]
        pass


# Prefer core widgets for built-in controls; fallback to simple/local types
try:  # pragma: no cover - best-effort
    from instrctl.gui.widgets import SweepPlotWidget as _SweepOrFallback
    from instrctl.gui.widgets import EventPlotWidget as _EventOrFallback
    from instrctl.gui.widgets import LabeledSlider as _SliderOrFallback
except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:# pragma: no cover - headless
    _SweepOrFallback = RemoteDemoWidget  # type: ignore[misc]
    _EventOrFallback = RemoteDemoWidget  # type: ignore[misc]
    _SliderOrFallback = object  # type: ignore[misc]


# ---------------- Instrument base ----------------
class RemoteDemo(BaseInstrument):
    __abstract__ = True

    def start(self) -> None:  # pragma: no cover
        raise NotImplementedError

    def stop(self) -> None:  # pragma: no cover
        raise NotImplementedError

    @feature(
        ui={
            "widget": _SweepOrFallback,
            "label": "REMOTE demo stream",
            "max_points": 5000,
            "start": start,
            "stop": stop,
            "interval_ms": 100,
        }
    )
    @typehint(stream="sweep")
    def get_points(self) -> List[float]:  # pragma: no cover
        """Return a single sweep (y-only). Subclasses must implement."""
        raise NotImplementedError


@register_instrument()
class RemoteDemoFull(RemoteDemo):
    __abstract__ = False

    def __init__(self, *, event_bus=None):
        super().__init__(event_bus=event_bus)
        self._run = False
        self._phi = 0.0
        self._sweep_n = 512
        self._bytes_since = 0
        self._run_rate = False
        self._last_rate_t_ms: Optional[int] = None

    # ---- Connection ----
    @classmethod
    def supported_connections(cls):
        return ["DEMO"]

    @classmethod
    def connection_placeholders(cls):
        return {"DEMO": "No address required"}

    def connect(self, **kwargs) -> None:
        self._state.connected = True

    def disconnect(self) -> None:
        self._state.connected = False

    # ---- Stream control ----
    def start(self) -> None:
        self._run = True

    def stop(self) -> None:
        self._run = False

    # ---- Sweep getter (y-only) ----
    def get_points(self) -> List[float]:
        n = int(self._sweep_n)
        self._phi += 0.3 if self._run else 0.05
        base = [math.sin(2 * math.pi * (i / 64.0 + self._phi)) for i in range(n)]
        noise = [random.uniform(-0.2, 0.2) for _ in range(n)]
        ys = [float(b + e) for b, e in zip(base, noise)]
        # Account bytes transferred for the data rate gauge (y-only schema)
        self._bytes_since += len(ys) * 8
        return ys

    # ---- Sweep size control ----
    def get_sweep_size(self) -> int:
        return int(self._sweep_n)

    @feature(ui={
        "widget": _SliderOrFallback,
        "label": "Sweep Size",
        "min": 64,
        "max": 4096,
        "value": 512,
        "step": 64,
        "readback": get_sweep_size,
    })
    def set_sweep_size(self, n: int) -> None:
        try:
            n = int(n)
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            n = 512
        n = max(64, min(4096, n))
        self._sweep_n = n

    # ---- Data rate gauge (Event plot of B/s) ----
    def start_rate(self) -> None:
        self._run_rate = True
        self._bytes_since = 0
        self._last_rate_t_ms = int(QtCore.QDateTime.currentMSecsSinceEpoch()) if QtCore else int(time.time() * 1000)

    def stop_rate(self) -> None:
        self._run_rate = False

    @feature(ui={
        "widget": _EventOrFallback,
        "label": "Data Rate (B/s)",
        "max_points": 500,
        "interval_ms": 250,
        "markers": False,
        "start": start_rate,
        "stop": stop_rate,
    })
    @typehint(stream="event")
    def get_data_rate_bps(self) -> List[float]:
        now = int(QtCore.QDateTime.currentMSecsSinceEpoch()) if QtCore else int(time.time() * 1000)
        if self._last_rate_t_ms is None:
            self._last_rate_t_ms = now
            return [0.0]
        dt_ms = max(1, now - self._last_rate_t_ms)
        self._last_rate_t_ms = now
        rate = float(self._bytes_since) / (dt_ms / 1000.0)
        # Decay counter but keep some carry to avoid zeroing between slow calls
        self._bytes_since = max(0, self._bytes_since - int(rate * 0.25))
        return [rate]


@register_instrument()
class RemoteDemoMinimal(RemoteDemo):
    __abstract__ = False

    def __init__(self, *, event_bus=None):
        super().__init__(event_bus=event_bus)
        self._run = False

    @classmethod
    def supported_connections(cls):
        return ["DEMO"]

    @classmethod
    def connection_placeholders(cls):
        return {"DEMO": "No address required"}

    def connect(self, **kwargs) -> None:
        self._state.connected = True

    def disconnect(self) -> None:
        self._state.connected = False

    def start(self) -> None:
        self._run = True

    def stop(self) -> None:
        self._run = False

    def get_points(self) -> List[float]:
        n = 128 if self._run else 16
        return [0.0] * n
