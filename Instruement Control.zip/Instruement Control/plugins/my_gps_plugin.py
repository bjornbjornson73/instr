from __future__ import annotations

"""
GPS Transmitter demo plugin that showcases a plugin-defined custom widget.

It provides a GpsMapWidget (QWidget) that renders a simple world map grid.
Clicking on the map selects latitude/longitude and calls the instrument's
set_coordinates(lat, lon). The widget also draws the current coordinate marker.
"""

from typing import Optional, Tuple

from PySide6 import QtCore, QtGui, QtWidgets

from instrctl.core import BaseInstrument, Capability, EventBus, feature, register_instrument


class GpsMapWidget(QtWidgets.QWidget):
    """Minimal world map-like picker.

    - X maps to longitude [-180, +180]
    - Y maps to latitude  [+90, -90] (top to bottom)
    - Draws graticule every 30 degrees
    - Draws a marker at current (lat, lon)

    Expects the instrument to implement:
      - set_coordinates(lat: float, lon: float) -> None
      - optionally get_coordinates() -> Tuple[float, float]
    """

    def __init__(self, instrument: BaseInstrument, parent: Optional[QtWidgets.QWidget] = None):
        super().__init__(parent)
        self._inst = instrument
        self.setMinimumSize(360, 180)
        self.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
        self._latlon: Tuple[float, float] = (0.0, 0.0)
        # Initialize from getter if available
        getter = getattr(instrument, "get_coordinates", None)
        if callable(getter):
            v = getter()
            if isinstance(v, (tuple, list)) and len(v) == 2:
                self._latlon = (float(v[0]), float(v[1]))

    def sizeHint(self) -> QtCore.QSize:  # type: ignore[override]
        return QtCore.QSize(600, 300)

    @staticmethod
    def _lon_to_x(w: int, lon: float) -> float:
        return (lon + 180.0) / 360.0 * w

    @staticmethod
    def _lat_to_y(h: int, lat: float) -> float:
        return (90.0 - lat) / 180.0 * h

    @staticmethod
    def _x_to_lon(w: int, x: float) -> float:
        return (x / max(w, 1)) * 360.0 - 180.0

    @staticmethod
    def _y_to_lat(h: int, y: float) -> float:
        return 90.0 - (y / max(h, 1)) * 180.0

    def paintEvent(self, event: QtGui.QPaintEvent):  # type: ignore[override]
        r = self.rect()
        if r.isEmpty() or r.width() <= 0 or r.height() <= 0:
            return
        p = QtGui.QPainter()
        if not p.begin(self):
            return
        try:
            p.fillRect(r, QtGui.QColor("#0b2239"))  # dark ocean
        # Graticule
            p.setPen(QtGui.QPen(QtGui.QColor("#335577")))
            for lon in range(-180, 181, 30):
                x = int(self._lon_to_x(r.width(), lon))
                p.drawLine(r.left() + x, r.top(), r.left() + x, r.bottom())
            for lat in range(-90, 91, 30):
                y = int(self._lat_to_y(r.height(), lat))
                p.drawLine(r.left(), r.top() + y, r.right(), r.top() + y)
        # Outline
            p.setPen(QtGui.QPen(QtGui.QColor("#88aacc")))
            p.drawRect(r.adjusted(0, 0, -1, -1))
        # Marker
            lat, lon = self._latlon
            mx = int(self._lon_to_x(r.width(), lon))
            my = int(self._lat_to_y(r.height(), lat))
            marker = QtCore.QRect(r.left() + mx - 4, r.top() + my - 4, 8, 8)
            p.setBrush(QtGui.QColor("#ffcc00"))
            p.setPen(QtGui.QPen(QtGui.QColor("#222")))
            p.drawEllipse(marker)
        # Text
            p.setPen(QtGui.QColor("#ddeeff"))
            p.drawText(r.adjusted(6, 6, -6, -6), QtCore.Qt.AlignLeft | QtCore.Qt.AlignTop, f"lat={lat:.4f}°, lon={lon:.4f}°")
        finally:
            p.end()

    def mousePressEvent(self, event: QtGui.QMouseEvent):  # type: ignore[override]
        r = self.rect()
        x = event.position().x() if hasattr(event, "position") else event.x()
        y = event.position().y() if hasattr(event, "position") else event.y()
        lon = float(self._x_to_lon(r.width(), x))
        lat = float(self._y_to_lat(r.height(), y))
        # Clamp
        lat = max(-90.0, min(90.0, lat))
        lon = max(-180.0, min(180.0, lon))
        # Call instrument setter
        setter = getattr(self._inst, "set_coordinates", None)
        if callable(setter):
            setter(lat, lon)
        self._latlon = (lat, lon)
        self.update()


class MyGpsTx(BaseInstrument):
    __abstract__ = True

    def get_coordinates(self) -> Tuple[float, float]:  # pragma: no cover - abstract
        raise NotImplementedError

    @feature(capability=Capability.REQUIRED, ui={"widget": GpsMapWidget, "label": "Coordinates", "readback": get_coordinates})
    def set_coordinates(self, lat: float, lon: float) -> None:  # pragma: no cover - abstract
        raise NotImplementedError


@register_instrument()
class MyGpsTxDemo(MyGpsTx):
    __abstract__ = False

    def __init__(self, *, event_bus: Optional[EventBus] = None):
        super().__init__(event_bus=event_bus)
        self._coords: Tuple[float, float] = (37.7749, -122.4194)  # San Francisco

    @classmethod
    def supported_connections(cls):
        return ["DEMO"]

    @classmethod
    def connection_placeholders(cls):
        return {"DEMO": "No address required"}

    def connect(self, **kwargs) -> None:
        self._state.connected = True

    def disconnect(self) -> None:
        self._state.connected = False

    # Shared-connection hooks (demo)
    def get_connection(self, **kwargs):
        return dict(kwargs)

    def set_connection(self, connection) -> None:
        self._state.connected = True

    def get_coordinates(self) -> Tuple[float, float]:
        return self._coords

    def set_coordinates(self, lat: float, lon: float) -> None:
        self._coords = (float(lat), float(lon))
