from __future__ import annotations

"""
Example multi-instrument plugin that defines TWO abstract kinds and TWO concrete
implementations, all outside the core package. No rebuild needed—drop this file
into a plugin folder and reload plugins in the app.

Provides:
- Kind: MySignalGenerator → Model: MyDemoSG
- Kind: MySpectrumAnalyzer → Model: MyDemoSA

Both publish events consumed by the default GUI:
- 'value' for a time-series (from a getter decorated with @observable_getter)
- 'sweep' for a frequency plot (from single_sweep)
"""

from typing import Optional
import math
import random
import time

from instrctl.core import (
    BaseInstrument,
    Capability,
    EventBus,
    feature,
    register_instrument,
    observable_getter,
)


# ---------- Abstract kinds (plugin-defined) ----------

class MySignalGenerator(BaseInstrument):
    __abstract__ = True

    @feature(capability=Capability.REQUIRED)
    def set_frequency(self, hz: float) -> None:  # pragma: no cover - abstract
        raise NotImplementedError

    @feature(capability=Capability.REQUIRED)
    def set_power(self, dbm: float) -> None:  # pragma: no cover - abstract
        raise NotImplementedError

    @feature()
    def output_on(self) -> None:  # pragma: no cover - abstract
        raise NotImplementedError

    @feature()
    def output_off(self) -> None:  # pragma: no cover - abstract
        raise NotImplementedError


class MySpectrumAnalyzer(BaseInstrument):
    __abstract__ = True

    @feature(capability=Capability.REQUIRED)
    def set_span(self, hz: float) -> None:  # pragma: no cover - abstract
        raise NotImplementedError

    @feature(capability=Capability.REQUIRED)
    def set_center(self, hz: float) -> None:  # pragma: no cover - abstract
        raise NotImplementedError

    @feature()
    def single_sweep(self) -> None:  # pragma: no cover - abstract
        raise NotImplementedError


# ---------- Concrete implementations ----------

@register_instrument()  # kind inferred: MySignalGenerator; model: MyDemoSG
class MyDemoSG(MySignalGenerator):
    __abstract__ = False

    def __init__(self, *, event_bus: Optional[EventBus] = None):
        super().__init__(event_bus=event_bus)
        self._t0 = time.perf_counter()
        self.freq = 1e6
        self.power = 0.0
        self.on = False

    def connect(self, **kwargs) -> None:
        self._state.connected = True

    def disconnect(self) -> None:
        self._state.connected = False

    def set_frequency(self, hz: float) -> None:
        self.freq = float(hz)

    def set_power(self, dbm: float) -> None:
        self.power = float(dbm)

    def output_on(self) -> None:
        self.on = True

    def output_off(self) -> None:
        self.on = False

    @observable_getter("value")
    def read_output_level(self) -> float:
        """Pseudo reading in volts; small sine + noise scaled by power."""
        t = time.perf_counter() - self._t0
        base = 0.5 * math.sin(2 * math.pi * 0.2 * t)
        noise = 0.02 * (random.random() - 0.5)
        scale = 10 ** (self.power / 20.0)
        return (base + noise) * scale


@register_instrument()  # kind inferred: MySpectrumAnalyzer; model: MyDemoSA
class MyDemoSA(MySpectrumAnalyzer):
    __abstract__ = False

    def __init__(self, *, event_bus: Optional[EventBus] = None):
        super().__init__(event_bus=event_bus)
        self.center = 1e6
        self.span = 1e5

    def connect(self, **kwargs) -> None:
        self._state.connected = True

    def disconnect(self) -> None:
        self._state.connected = False

    def set_span(self, hz: float) -> None:
        self.span = float(hz)

    def set_center(self, hz: float) -> None:
        self.center = float(hz)

    def single_sweep(self) -> None:
        # Gaussian-ish bump with noise
        n = 512
        mid = n / 2.0
        sigma = max(8.0, (self.span / max(self.center, 1.0)) * 60.0)
        y = [math.exp(-0.5 * ((i - mid) / sigma) ** 2) * 10 + (random.random() - 0.5) for i in range(n)]
        self.events.publish("sweep", y=y)
