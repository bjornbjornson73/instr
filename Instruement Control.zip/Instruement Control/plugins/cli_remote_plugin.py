from __future__ import annotations

"""
CLI Remote instrument plugin: SSH/Telnet command runner with a simple remote file browser (SSH).

- SSH mode (preferred):
  - Requires 'paramiko' (optional). If not installed, the UI shows a hint to install it.
  - Provides basic command execution (exec_command) and SFTP-based file browsing, download, and upload.
  - Saves downloads to ~/Downloads/instrctl/<host>/ by default and can open downloaded files with the OS.

- Telnet mode:
  - Uses Python's telnetlib for basic command execution.
  - Remote file browser is disabled (Telnet has no SFTP); UI shows a hint.

Notes:
- This is a pragmatic, demo-friendly tool. For long-running interactive shells or TTY features, a full PTY/terminal emulator would be required.
- Connection details are provided by the framework at instrument connect() time (address, username, password, port).
- No core changes required.
"""

from typing import Optional, List, Dict, Any, Tuple
import os
import sys
import socket
import telnetlib
from pathlib import Path
import os

from PySide6 import QtCore, QtWidgets, QtGui

# Optional ANSI/VT100 terminal emulator
try:
    import pyte  # type: ignore
    _HAS_PYTE = True
except ImportError:
    pyte = None  # type: ignore
    _HAS_PYTE = False

try:  # optional dependency
    import paramiko  # type: ignore
    _HAS_PARAMIKO = True
except ImportError:
    paramiko = None  # type: ignore
    _HAS_PARAMIKO = False

from instrctl.core import BaseInstrument, Capability, EventBus, feature, register_instrument

# Common exception groups for SSH/network operations
_SSH_EXC: tuple = (paramiko.SSHException,) if _HAS_PARAMIKO else tuple()  # type: ignore[attr-defined]
_AUTH_EXC: tuple = (paramiko.AuthenticationException,) if _HAS_PARAMIKO else tuple()  # type: ignore[attr-defined]
_NET_EXC: tuple = (OSError, socket.timeout) + _SSH_EXC
_AUTH_NET_EXC: tuple = _NET_EXC + _AUTH_EXC


class _SshConnection:
    def __init__(self, host: str, port: int, username: str, password: Optional[str] = None):
        if not _HAS_PARAMIKO:
            raise RuntimeError("paramiko not available for SSH")
        self.host = host
        self.port = port
        self.username = username
        self.password = password
        self.client: Optional[paramiko.SSHClient] = None  # type: ignore[name-defined]
        self.sftp = None
        self.cwd = None  # remote cwd (str)

    def connect(self):
        assert _HAS_PARAMIKO
        # Optional debug logging (set INSTRCTL_SSH_DEBUG=1 to enable)
        if os.environ.get("INSTRCTL_SSH_DEBUG", "0") == "1" and _HAS_PARAMIKO:
            log_dir = Path.home() / ".instrctl"
            log_dir.mkdir(parents=True, exist_ok=True)
            paramiko.util.log_to_file(str(log_dir / "paramiko.log"))  # type: ignore[attr-defined]
        cli = paramiko.SSHClient()  # type: ignore[name-defined]
        cli.set_missing_host_key_policy(paramiko.AutoAddPolicy())  # type: ignore[name-defined]
        # Avoid probing ssh-agent or local keys to prevent using up MaxAuthTries on the server
        # which can lead to 'transport shut down or saw EOF' before we can prompt for a password.
        try:
            cli.connect(
                self.host,
                port=self.port,
                username=self.username,
                password=self.password,
                timeout=10,
                banner_timeout=10,
                auth_timeout=10,
                allow_agent=False,
                look_for_keys=False,
            )
        except _AUTH_NET_EXC as e:  # type: ignore[misc]
            # Fallback to explicit keyboard-interactive if a password is present
            if self.password:
                try:
                    sock = socket.create_connection((self.host, int(self.port)), timeout=10)
                    t = paramiko.Transport(sock)  # type: ignore[name-defined]
                    t.start_client(timeout=10)
                    def _kbdint_handler(title, instructions, prompts):
                        return [self.password for _p, _echo in prompts]
                    t.auth_interactive(self.username, _kbdint_handler)  # type: ignore[arg-type]
                    if not t.is_authenticated():
                        t.close()
                        raise e
                    # Attach transport to SSHClient
                    cli._transport = t  # type: ignore[attr-defined]
                except _AUTH_NET_EXC:  # type: ignore[misc]
                    raise e
            else:
                raise
        self.client = cli
        try:
            self.sftp = cli.open_sftp()
            self.cwd = self.sftp.normalize(".")
        except (OSError, RuntimeError, AttributeError):
            self.sftp = None
            self.cwd = None

    def close(self):
        if self.sftp is not None:
            self.sftp.close()
        if self.client is not None:
            self.client.close()
        self.client = None
        self.sftp = None

    def exec(self, command: str, timeout: int = 30) -> Tuple[str, str, int]:
        if self.client is None:
            raise RuntimeError("SSH not connected")
        stdin, stdout, stderr = self.client.exec_command(command, timeout=timeout)
        out = stdout.read().decode("utf-8", errors="ignore")
        err = stderr.read().decode("utf-8", errors="ignore")
        rc = stdout.channel.recv_exit_status()  # type: ignore[attr-defined]
        return out, err, rc

    def open_shell(self, *, cols: int = 80, rows: int = 24):
        if self.client is None:
            raise RuntimeError("SSH not connected")
        # Open an interactive shell with a PTY of the given size
        try:
            chan = self.client.invoke_shell(term='xterm', width=cols, height=rows)
        except (OSError, AttributeError, TypeError, RuntimeError):
            chan = self.client.invoke_shell()
        return chan

    # SFTP helpers
    def listdir(self, path: str) -> List[Dict[str, Any]]:
        if self.sftp is None:
            raise RuntimeError("SFTP not available")
        items = []
        for a in self.sftp.listdir_attr(path):
            is_dir = bool((a.st_mode or 0) & 0o040000)
            items.append({"name": a.filename, "is_dir": is_dir, "size": int(getattr(a, "st_size", 0))})
        return items

    def join(self, base: str, name: str) -> str:
        if base.endswith("/"):
            return base + name
        return base + "/" + name

    def download(self, remote_path: str, local_path: str) -> str:
        if self.sftp is None:
            raise RuntimeError("SFTP not available")
        Path(local_path).parent.mkdir(parents=True, exist_ok=True)
        self.sftp.get(remote_path, local_path)
        return local_path

    def upload(self, local_path: str, remote_dir: str) -> str:
        if self.sftp is None:
            raise RuntimeError("SFTP not available")
        name = Path(local_path).name
        rp = self.join(remote_dir, name)
        self.sftp.put(local_path, rp)
        return rp


class _TelnetConnection:
    def __init__(self, host: str, port: int):
        self.host = host
        self.port = port
        self.tn: Optional[telnetlib.Telnet] = None

    def connect(self):
        self.tn = telnetlib.Telnet(self.host, self.port, timeout=10)

    def close(self):
        if self.tn is not None:
            self.tn.close()
        self.tn = None

    def exec(self, command: str, timeout: int = 10) -> Tuple[str, str, int]:
        # naive: write command and read with a short timeout; rc unknown in telnet -> -1
        if self.tn is None:
            raise RuntimeError("Telnet not connected")
        self.tn.write(command.encode("utf-8") + b"\r\n")
        try:
            data = self.tn.read_until(b"\n", timeout=timeout)
        except EOFError:
            data = b""
        out = data.decode("utf-8", errors="ignore")
        return out, "", -1


def _longest_common_prefix(strings: list[str]) -> str:
    if not strings:
        return ""
    s1 = min(strings)
    s2 = max(strings)
    i = 0
    for i, c in enumerate(s1):
        if i >= len(s2) or c != s2[i]:
            return s2[:i]
    return s1


class CliRemotePanel(QtWidgets.QWidget):
    def __init__(self, instrument: 'CliRemoteInstrument', parent: Optional[QtWidgets.QWidget] = None):
        super().__init__(parent)
        self._inst = instrument
        self._downloads_dir = Path.home() / "Downloads" / "instrctl"
        self._host_label = QtWidgets.QLabel("")
        self._mode_label = QtWidgets.QLabel("")

        # Left: remote file list (SSH only)
        self._path_label = QtWidgets.QLabel("/")
        self._up_btn = QtWidgets.QPushButton("Up")
        self._refresh_btn = QtWidgets.QPushButton("Refresh")
        self._download_btn = QtWidgets.QPushButton("Download")
        self._open_btn = QtWidgets.QPushButton("Open")
        self._upload_btn = QtWidgets.QPushButton("Upload…")
        self._list = QtWidgets.QListWidget()
        self._list.setSelectionMode(QtWidgets.QAbstractItemView.SingleSelection)

        # Right: interactive Terminal widgets
        self._term = _TerminalWidget()
        self._term_open_btn = QtWidgets.QPushButton("Open Terminal")
        self._term_close_btn = QtWidgets.QPushButton("Close Terminal")
        self._term_close_btn.setEnabled(False)
        term_btns = QtWidgets.QHBoxLayout()
        term_btns.addWidget(self._term_open_btn)
        term_btns.addWidget(self._term_close_btn)
        term_btns.addStretch(1)
        right_pane = QtWidgets.QWidget()
        term_lay = QtWidgets.QVBoxLayout(right_pane)
        term_lay.addLayout(term_btns)
        term_lay.addWidget(self._term, 1)

        # Layout
        top = QtWidgets.QHBoxLayout()
        top.addWidget(QtWidgets.QLabel("Remote:"))
        top.addWidget(self._host_label)
        top.addSpacing(10)
        top.addWidget(QtWidgets.QLabel("Mode:"))
        top.addWidget(self._mode_label)
        top.addStretch(1)

        fb = QtWidgets.QHBoxLayout()
        fb.addWidget(QtWidgets.QLabel("Path:"))
        fb.addWidget(self._path_label, 1)
        fb.addWidget(self._up_btn)
        fb.addWidget(self._refresh_btn)
        fb.addWidget(self._download_btn)
        fb.addWidget(self._open_btn)
        fb.addWidget(self._upload_btn)

        left = QtWidgets.QVBoxLayout()
        left.addLayout(fb)
        left.addWidget(self._list, 1)

        split = QtWidgets.QSplitter()
        lw = QtWidgets.QWidget(); lw.setLayout(left)
        split.addWidget(lw)
        split.addWidget(right_pane)
        split.setStretchFactor(0, 1)
        split.setStretchFactor(1, 2)

        root = QtWidgets.QVBoxLayout(self)
        root.addLayout(top)
        root.addWidget(split, 1)

        # Wire
        self._list.itemDoubleClicked.connect(self._on_item_double)
        self._up_btn.clicked.connect(self._on_up)
        self._refresh_btn.clicked.connect(self.refresh)
        self._download_btn.clicked.connect(self._on_download)
        self._open_btn.clicked.connect(self._on_open)
        self._upload_btn.clicked.connect(self._on_upload)
        self._term_open_btn.clicked.connect(self._on_open_terminal)
        self._term_close_btn.clicked.connect(self._on_close_terminal)
        self._term.sendBytes.connect(self._on_term_send)

        # Terminal runtime
        self._term_timer = QtCore.QTimer(self)
        self._term_timer.setInterval(30)
        self._term_timer.timeout.connect(self._on_term_poll)
        self._term_channel = None

        # Initialize state
        self._apply_connection_state()

    # --- helpers ---
    def _apply_connection_state(self):
        host = self._inst.get_host() or "?"
        mode = self._inst.get_mode()
        self._host_label.setText(host)
        self._mode_label.setText(mode)
        ssh_ok = (mode == "SSH") and self._inst.is_ssh_connected()
        self._list.setEnabled(ssh_ok)
        self._path_label.setEnabled(ssh_ok)
        self._up_btn.setEnabled(ssh_ok)
        self._refresh_btn.setEnabled(ssh_ok)
        self._download_btn.setEnabled(ssh_ok)
        self._open_btn.setEnabled(ssh_ok)
        self._upload_btn.setEnabled(ssh_ok)
        if mode == "SSH" and not _HAS_PARAMIKO:
            self._append_out("SSH file browser disabled: install 'paramiko' to enable (pip install paramiko)")
        self._term_open_btn.setEnabled(ssh_ok and _HAS_PARAMIKO and self._term_channel is None)
        self._term_close_btn.setEnabled(ssh_ok and _HAS_PARAMIKO and self._term_channel is not None)
        if ssh_ok:
            self.refresh()
            # Auto-open terminal on SSH connection
            if self._term_channel is None and _HAS_PARAMIKO:
                self._on_open_terminal()

    def _append_out(self, text: str):
        # Write helper: show messages in Terminal view
        self._term.append_text(text.rstrip("\n") + "\n")

    # --- file browser (SSH) ---
    def refresh(self):
        if self._inst.get_mode() != "SSH" or not self._inst.is_ssh_connected():
            return
        try:
            cwd = self._inst.get_cwd() or "/"
            items = self._inst.listdir(cwd)
            self._path_label.setText(cwd)
            self._list.clear()
            # Directories first
            for it in sorted([i for i in items if i["is_dir"]], key=lambda x: x["name"].lower()):
                self._list.addItem(f"[DIR] {it['name']}")
            for it in sorted([i for i in items if not i["is_dir"]], key=lambda x: x["name"].lower()):
                size = it.get("size", 0)
                self._list.addItem(f"{it['name']}  ({size} bytes)")
        except (OSError, RuntimeError) as e:
            self._append_out(f"refresh failed: {type(e).__name__}: {e}")

    def _selected_name(self) -> Optional[str]:
        it = self._list.currentItem()
        if not it:
            return None
        text = it.text()
        if text.startswith("[DIR] "):
            return text[6:].split("  ")[0]
        return text.split("  ")[0]

    def _on_item_double(self, item: QtWidgets.QListWidgetItem):  # type: ignore[name-defined]
        if self._inst.get_mode() != "SSH" or not self._inst.is_ssh_connected():
            return
        name = self._selected_name()
        if not name:
            return
        path = self._inst.join(self._inst.get_cwd() or "/", name)
        sub = self._inst.listdir(path)
        self._inst.set_cwd(path)
        self.refresh()
        return
        # It's a file: download to Downloads and attempt to open
        try:
            local = self._downloads_dir / (self._inst.get_host() or "host") / name
            got = self._inst.download(path, str(local))
            self._append_out(f"Downloaded: {got}")
            self._open_file(local)
        except (OSError, RuntimeError) as e:
            self._append_out(f"download failed: {type(e).__name__}: {e}")

    def _on_up(self):
        if self._inst.get_mode() != "SSH" or not self._inst.is_ssh_connected():
            return
        cwd = self._inst.get_cwd() or "/"
        if cwd in ("/", "\\"):
            return
        parent = str(Path(cwd).parent).replace("\\", "/")
        if not parent:
            parent = "/"
        self._inst.set_cwd(parent)
        self.refresh()

    def _on_download(self):
        if self._inst.get_mode() != "SSH" or not self._inst.is_ssh_connected():
            return
        name = self._selected_name()
        if not name:
            return
        path = self._inst.join(self._inst.get_cwd() or "/", name)
        local = self._downloads_dir / (self._inst.get_host() or "host") / name
        try:
            got = self._inst.download(path, str(local))
            self._append_out(f"Downloaded: {got}")
        except (OSError, RuntimeError) as e:
            self._append_out(f"download failed: {type(e).__name__}: {e}")

    def _on_open(self):
        name = self._selected_name()
        if not name:
            return
        local = self._downloads_dir / (self._inst.get_host() or "host") / name
        self._open_file(local)

    def _on_upload(self):
        if self._inst.get_mode() != "SSH" or not self._inst.is_ssh_connected():
            return
        fn, _ = QtWidgets.QFileDialog.getOpenFileName(self, "Select file to upload")
        if not fn:
            return
        try:
            rp = self._inst.upload(fn, self._inst.get_cwd() or "/")
            self._append_out(f"Uploaded to: {rp}")
            self.refresh()
        except (OSError, RuntimeError) as e:
            self._append_out(f"upload failed: {type(e).__name__}: {e}")

    def _open_file(self, path: Path):
        try:
            if sys.platform.startswith("win"):
                os.startfile(str(path))  # type: ignore[attr-defined]
            elif sys.platform == "darwin":
                import subprocess
                subprocess.Popen(["open", str(path)])
            else:
                import subprocess
                subprocess.Popen(["xdg-open", str(path)])
        except (OSError, RuntimeError) as e:
            self._append_out(f"open failed: {type(e).__name__}: {e}")

    # Console command entry removed; use Terminal for interactive commands

    # --- Interactive Terminal (SSH) ---
    def _on_open_terminal(self):
        if self._inst.get_mode() != "SSH" or not self._inst.is_ssh_connected():
            return
        if self._term_channel is not None:
            return
        cols, rows = self._term.terminal_size_chars()
        try:
            ch = self._inst.open_shell(cols=cols, rows=rows)
            self._term_channel = ch
            self._term_timer.start()
            self._term_open_btn.setEnabled(False)
            self._term_close_btn.setEnabled(True)
            # Hook resize -> pty resize
            self._term.terminalResized.connect(self._on_term_resize)
            self._term.setFocus()
        except (OSError, RuntimeError) as e:
            self._append_out(f"terminal failed: {type(e).__name__}: {e}")

    def _on_close_terminal(self):
        self._term_timer.stop()
        try:
            if self._term_channel is not None:
                self._term_channel.close()
        finally:
            self._term_channel = None
            self._term_open_btn.setEnabled(self._inst.get_mode() == "SSH" and self._inst.is_ssh_connected())
            self._term_close_btn.setEnabled(False)

    def _on_term_poll(self):
        ch = self._term_channel
        if ch is None:
            return
        try:
            while ch.recv_ready():
                data = ch.recv(4096)
                if not data:
                    break
                self._term.append_bytes(data)
            if ch.recv_stderr_ready():
                data = ch.recv_stderr(4096)
                if data:
                    self._term.append_bytes(data)
            if ch.exit_status_ready():
                self._term.append_text("\n[process exited]\n")
                self._on_close_terminal()
        except _NET_EXC as e:  # type: ignore[misc]
            self._term.append_text(f"\n[terminal error: {e}]\n")
            self._on_close_terminal()

    def _on_term_send(self, data: bytes):
        ch = self._term_channel
        if ch is None:
            return
        if data:
            ch.send(data)

    def _on_term_resize(self, cols: int, rows: int):
        ch = self._term_channel
        if ch is None:
            return
        ch.resize_pty(width=cols, height=rows)



class CliRemoteInstrument(BaseInstrument):
    __abstract__ = True

    @feature(capability=Capability.REQUIRED, ui={"widget": CliRemotePanel, "label": "CLI"})
    def show_cli(self) -> None:
        pass

    def __init__(self, *, event_bus: Optional[EventBus] = None):
        super().__init__(event_bus=event_bus)
        self.mode: str = "DEMO"  # SSH | TELNET | DEMO
        self.host: Optional[str] = None
        self.port: Optional[int] = None
        self.username: Optional[str] = None
        self.password: Optional[str] = None
        self._ssh: Optional[_SshConnection] = None
        self._telnet: Optional[_TelnetConnection] = None

    # --- public getters used by UI ---
    def get_host(self) -> Optional[str]:
        return self.host

    def get_mode(self) -> str:
        return self.mode

    # SSH-specific API (avoid exposing internal _ssh object to UI)
    def is_ssh_connected(self) -> bool:
        try:
            return bool(getattr(self, "_state", None) and getattr(self._state, "connected", False)) and self.mode == "SSH"
        except (AttributeError, TypeError):
            return self._ssh is not None

    def get_cwd(self) -> Optional[str]:
        if self._ssh is None:
            return None
        return self._ssh.cwd

    def set_cwd(self, path: str) -> None:
        if self._ssh is None:
            raise RuntimeError("SFTP not available")
        self._ssh.cwd = path

    # Convenience wrappers delegating to underlying _SshConnection
    def listdir(self, path: str) -> List[Dict[str, Any]]:
        if self._ssh is None:
            raise RuntimeError("SFTP not available")
        return self._ssh.listdir(path)

    def join(self, base: str, name: str) -> str:
        if self._ssh is None:
            # fallback generic join
            if base.endswith("/"):
                return base + name
            return base + "/" + name
        return self._ssh.join(base, name)

    def download(self, remote_path: str, local_path: str) -> str:
        if self._ssh is None:
            raise RuntimeError("SFTP not available")
        return self._ssh.download(remote_path, local_path)

    def upload(self, local_path: str, remote_dir: str) -> str:
        if self._ssh is None:
            raise RuntimeError("SFTP not available")
        return self._ssh.upload(local_path, remote_dir)

    def open_shell(self, *, cols: int = 80, rows: int = 24):
        if self._ssh is None:
            raise RuntimeError("SSH not connected")
        return self._ssh.open_shell(cols=cols, rows=rows)

    def is_connected(self) -> bool:
        # Prefer explicit state if available
        try:
            return bool(getattr(self, "_state", None) and getattr(self._state, "connected", False))
        except (AttributeError, TypeError):
            return self._ssh is not None

    @classmethod
    def supported_connections(cls):
        return ["SSH", "TELNET", "DEMO"]

    @classmethod
    def connection_placeholders(cls):
        return {
            # Keep Address minimal; Username and Port are provided as separate fields
            "SSH": "host",
            "TELNET": "host",
            "DEMO": "No address required",
        }

    @classmethod
    def connection_fields(cls):
        """Dynamic fields shown in the connection dialog below Timeout.

        Per user request, only show Username and Port (no Password field; prompt later).
        """
        return {
            "SSH": [
                {"name": "username", "label": "Username", "type": "text", "placeholder": "user", "default": ""},
                {"name": "port", "label": "Port", "type": "int", "default": 22},
            ],
            "TELNET": [
                {"name": "port", "label": "Port", "type": "int", "default": 23},
            ],
            "DEMO": [],
        }

    def connect(self, **kwargs) -> None:
        # Expect address like user@host:port (SSH) or host:port (TELNET), or kwargs with username/password/port
        addr = (kwargs.get("address") or "").strip()
        ctype = (kwargs.get("type") or kwargs.get("connection_type") or "").strip().upper() or "SSH"
        self.mode = ctype
        user = kwargs.get("username")
        pwd = kwargs.get("password")
        port = kwargs.get("port")
        host = None
        if addr:
            if "@" in addr:
                user_part, host_part = addr.split("@", 1)
                user = user or user_part
            else:
                host_part = addr
            if ":" in host_part:
                host_only, port_part = host_part.rsplit(":", 1)
                host = host_only
                port = int(port_part)
            else:
                host = host_part
        if ctype == "SSH":
            host = host or "localhost"
            user = user or os.getlogin()
            port = int(port or 22)
            self.host, self.username, self.port, self.password = host, user, port, pwd
            if not _HAS_PARAMIKO:
                # connect in degraded mode (no SSH client), only UI will show hint
                self._ssh = None
                self._state.connected = True
                return
            self._state.connected = False
            conn = _SshConnection(host, port, user, pwd)
            try:
                conn.connect()
            except _AUTH_NET_EXC as e:  # type: ignore[misc]
                    # If no password was provided, prompt interactively on common auth negotiation failures
                    auth_exc = getattr(paramiko, "AuthenticationException", None) if _HAS_PARAMIKO else None
                    ssh_exc = getattr(paramiko, "SSHException", None) if _HAS_PARAMIKO else None
                    partial_exc = getattr(paramiko, "PartialAuthentication", None) if _HAS_PARAMIKO else None
                    emsg = str(e) if e else ""
                    should_prompt = (pwd in (None, "")) and (
                        (auth_exc is not None and isinstance(e, auth_exc)) or
                        (ssh_exc is not None and isinstance(e, ssh_exc) and ("No authentication methods available" in emsg)) or
                        (partial_exc is not None and isinstance(e, partial_exc)) or
                        ("EOF" in emsg or "Authentication failed" in emsg or "Auth failed" in emsg)
                    )
                    if should_prompt:
                        # Prompt for password (UI only if QApplication exists)
                        pw = None
                        app = QtWidgets.QApplication.instance()
                        if app is not None:
                            pw_pair = QtWidgets.QInputDialog.getText(
                                None,
                                "SSH Password Required",
                                f"Enter password for {user}@{host}:{port}",
                                QtWidgets.QLineEdit.Password,
                            )
                            pw, ok = pw_pair[0], pw_pair[1]
                            if ok:
                                pw = pw.strip()
                            else:
                                pw = None
                        if pw:
                            # Retry once with provided password
                            conn = _SshConnection(host, port, user, pw)
                            conn.connect()
                            self.password = pw
                        else:
                            raise
                    else:
                        # Not an auth error or already had a password -> propagate
                        raise
            # Success
            self._ssh = conn
            self._telnet = None
            self._state.connected = True
        elif ctype == "TELNET":
            host = host or "localhost"
            port = int(port or 23)
            self.host, self.port = host, port
            self._state.connected = False
            t = _TelnetConnection(host, port)
            t.connect()
            self._telnet = t
            self._ssh = None
            self._state.connected = True
        else:  # DEMO
            self.host = "demo"
            self._ssh = None
            self._telnet = None
            self._state.connected = True

    def disconnect(self) -> None:
        if self._ssh is not None:
            self._ssh.close()
        if self._telnet is not None:
            self._telnet.close()
        self._ssh = None
        self._telnet = None
        self._state.connected = False

    # Shared-connection hooks (optional)
    def get_connection(self, **kwargs):
        return {
            "type": self.mode,
            "address": f"{(self.username + '@') if self.username else ''}{self.host or ''}:{self.port or ''}",
            "username": self.username,
            "password": self.password,
            "port": self.port,
        }

    def set_connection(self, connection) -> None:
        # Accept a dict like get_connection() and reconnect
        if not isinstance(connection, dict):
            return
        self.disconnect()
        self.connect(**connection)


class _TerminalWidget(QtWidgets.QPlainTextEdit):
    """Minimal terminal-like widget with key handling and resize signals.

    This does not implement full ANSI parsing; output is appended as-is.
    """
    sendBytes = QtCore.Signal(bytes)
    terminalResized = QtCore.Signal(int, int)  # cols, rows

    def __init__(self):
        super().__init__()
        self.setFont(QtGui.QFont("Consolas", 10))
        self.setUndoRedoEnabled(False)
        self.setLineWrapMode(QtWidgets.QPlainTextEdit.NoWrap)
        self.setWordWrapMode(QtGui.QTextOption.NoWrap)
        self.setTabChangesFocus(False)
        self._autoscroll = True
        self._max_chars = 200_000
        self.setFocusPolicy(QtCore.Qt.StrongFocus)
        self.document().setDefaultStyleSheet("")
        self.setReadOnly(False)
    # VT100 emulator (optional, improves correctness of backspace/arrows)
        self._use_emulator = _HAS_PYTE
        self._screen = None
        self._stream = None
        if self._use_emulator:
            try:
                cols, rows = self.terminal_size_chars()
                self._screen = pyte.Screen(cols, rows)  # type: ignore[name-defined]
                self._stream = pyte.Stream(self._screen)  # type: ignore[name-defined]
            except (RuntimeError, ValueError, AttributeError):
                self._use_emulator = False
    # local completion removed

    def append_text(self, text: str):
        if not text:
            return
        if self._use_emulator and self._stream is not None:
            try:
                self._stream.feed(text)
                self._render_from_emulator()
            except (RuntimeError, ValueError):
                # Fallback to raw append on error
                self._append_raw(text)
        else:
            self._append_raw(text)

    def append_bytes(self, data: bytes):
        text = data.decode("utf-8", errors="ignore")
        self.append_text(text)

    def _append_raw(self, text: str) -> None:
        self.moveCursor(QtGui.QTextCursor.End)
        self.insertPlainText(text)
        self._trim_backlog()
        if self._autoscroll:
            self.moveCursor(QtGui.QTextCursor.End)

    def _render_from_emulator(self) -> None:
        if not self._use_emulator or self._screen is None:
            return
        # Render current screen (visible area). pyte keeps history internally; we only show display.
        try:
            lines = list(getattr(self._screen, "display", []))
            text = "\n".join(lines)
        except AttributeError:
            return
        # Replace document with new text
        self.setPlainText(text)
        if self._autoscroll:
            self.moveCursor(QtGui.QTextCursor.End)

    def keyPressEvent(self, ev: QtGui.QKeyEvent):  # type: ignore[override]
        data: bytes | None = None
        key = ev.key()
        mod = ev.modifiers()
        # Tab goes to remote shell (no local completion)
        # Ctrl combinations
        if mod & QtCore.Qt.ControlModifier:
            ctrl_map = {
                QtCore.Qt.Key_C: b"\x03",  # ETX
                QtCore.Qt.Key_D: b"\x04",  # EOT
                QtCore.Qt.Key_Z: b"\x1a",  # SUB
                QtCore.Qt.Key_H: b"\x08",  # BS (Ctrl+H)
            }
            if key in ctrl_map:
                data = ctrl_map[key]
            # Ctrl + Arrow keys -> CSI 1;5{A/B/C/D}
            if data is None:
                ctrl_arrows = {
                    QtCore.Qt.Key_Left: b"\x1b[1;5D",
                    QtCore.Qt.Key_Right: b"\x1b[1;5C",
                    QtCore.Qt.Key_Up: b"\x1b[1;5A",
                    QtCore.Qt.Key_Down: b"\x1b[1;5B",
                }
                if key in ctrl_arrows:
                    data = ctrl_arrows[key]
        if data is None:
            special = {
                QtCore.Qt.Key_Return: b"\r",
                QtCore.Qt.Key_Enter: b"\r",
                QtCore.Qt.Key_Backspace: b"\x7f",
                QtCore.Qt.Key_Backtab: b"\x1b[Z",  # Shift+Tab
                QtCore.Qt.Key_Tab: b"\t",
                QtCore.Qt.Key_Escape: b"\x1b",
                QtCore.Qt.Key_Left: b"\x1b[D",
                QtCore.Qt.Key_Right: b"\x1b[C",
                QtCore.Qt.Key_Up: b"\x1b[A",
                QtCore.Qt.Key_Down: b"\x1b[B",
                QtCore.Qt.Key_Home: b"\x1b[H",
                QtCore.Qt.Key_End: b"\x1b[F",
                QtCore.Qt.Key_PageUp: b"\x1b[5~",
                QtCore.Qt.Key_PageDown: b"\x1b[6~",
                QtCore.Qt.Key_Delete: b"\x1b[3~",
            }
            if key in special:
                data = special[key]
        if data is None:
            txt = ev.text()
            if txt:
                data = txt.encode("utf-8", errors="ignore")
        if data:
            self.sendBytes.emit(data)
        # Do not insert locally; the remote PTY will echo
        ev.accept()

    def insertFromMimeData(self, source: QtGui.QMimeData):  # type: ignore[override]
        if source.hasText():
            text = source.text()
            if text:
                self.sendBytes.emit(text.encode("utf-8", errors="ignore"))

    def resizeEvent(self, e: QtGui.QResizeEvent):  # type: ignore[override]
        super().resizeEvent(e)
        cols, rows = self.terminal_size_chars()
        self.terminalResized.emit(cols, rows)
        # Resize emulator screen
        if self._use_emulator and self._screen is not None:
            # pyte uses (rows, cols)
            self._screen.resize(rows, cols)
            self._render_from_emulator()

    # Local completion support was removed; Tab is forwarded to remote shell

    def terminal_size_chars(self) -> tuple[int, int]:
        fm = self.fontMetrics()
        aw = max(1, fm.horizontalAdvance("M"))
        lh = max(1, fm.lineSpacing())
        cols = max(20, self.viewport().width() // aw)
        rows = max(5, self.viewport().height() // lh)
        return int(cols), int(rows)

    def _trim_backlog(self):
        doc = self.document()
        if doc.characterCount() > self._max_chars:
            cur = self.textCursor()
            cur.movePosition(QtGui.QTextCursor.Start)
            cur.movePosition(QtGui.QTextCursor.Right, QtGui.QTextCursor.KeepAnchor, max(0, doc.characterCount() - self._max_chars))
            cur.removeSelectedText()
            self.setTextCursor(cur)

    # Note: connection-sharing hooks live on the instrument, not the widget.


@register_instrument()
class CliRemoteDemo(CliRemoteInstrument):
    __abstract__ = False

    @classmethod
    def supported_connections(cls):
        return ["SSH", "TELNET", "DEMO"]

    @classmethod
    def connection_placeholders(cls):
        return {
            "SSH": "host",
            "TELNET": "host",
            "DEMO": "No address required",
        }
