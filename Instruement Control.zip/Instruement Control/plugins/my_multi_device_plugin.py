from __future__ import annotations

"""
Multi-instrument plugin example that aggregates two instruments and defines
exclusivity groups between their features. This demonstrates composing a device
that can act as both a signal generator and spectrum analyzer, but with
mutually exclusive operations.
"""

from typing import Optional
import logging

from instrctl.core import (
    BaseInstrument,
    Capability,
    EventBus,
    feature,
    register_instrument,
    MultiInstrument,
    ExclusivityError,
)
from instrctl.gui.widgets import (
    UnitLineEdit,
    LabeledSlider,
    ToggleSwitch,
    SweepPlotWidget,
    EventPlotWidget,
    MultiTracePlotWidget,
    WaterfallWidget,
)


# Define abstract kinds inside the plugin (plugin-first model)
class MySigGen(BaseInstrument):
    __abstract__ = True

    def get_frequency(self) -> float:  # pragma: no cover - abstract
        raise NotImplementedError

    @feature(capability=Capability.REQUIRED, ui={"widget": UnitLineEdit, "label": "Frequency", "readback": get_frequency, "unit": "Hz"})
    def set_frequency(self, hz: float) -> None:  # pragma: no cover - abstract
        raise NotImplementedError

    def get_power(self) -> float:  # pragma: no cover - abstract
        raise NotImplementedError

    @feature(capability=Capability.REQUIRED, ui={"widget": LabeledSlider, "label": "Power", "min": -50, "max": 20, "value": 0, "readback": get_power, "unit": "dBm"})
    def set_power(self, dbm: float) -> None:  # pragma: no cover - abstract
        raise NotImplementedError


    def output_off(self) -> None:  # pragma: no cover - abstract
        raise NotImplementedError


    @feature(ui={"widget": ToggleSwitch, "label": "Output", "off_method": output_off})
    def output_on(self) -> None:  # pragma: no cover - abstract
        raise NotImplementedError

    

class MySpecAn(BaseInstrument):
    __abstract__ = True

    def get_span(self) -> float:  # pragma: no cover - abstract
        raise NotImplementedError

    @feature(capability=Capability.REQUIRED, ui={"widget": UnitLineEdit, "label": "Span", "readback": get_span, "unit": "Hz"})
    def set_span(self, hz: float) -> None:  # pragma: no cover - abstract
        raise NotImplementedError

    def get_center(self) -> float:  # pragma: no cover - abstract
        raise NotImplementedError

    @feature(capability=Capability.REQUIRED, ui={"widget": UnitLineEdit, "label": "Center", "readback": get_center, "unit": "Hz"})
    def set_center(self, hz: float) -> None:  # pragma: no cover - abstract
        raise NotImplementedError

    # --- Sweep streaming for SweepPlotWidget ---
    def start_sweep(self) -> None:  # pragma: no cover - abstract
        raise NotImplementedError

    def stop_sweep(self) -> None:  # pragma: no cover - abstract
        raise NotImplementedError

    @feature(ui={
        "widget": SweepPlotWidget,
        "label": "Spectrum",
        # getter is the decorated function itself
        "start": start_sweep,
        "stop": stop_sweep,
        "interval_ms": 200,
        "markers": True,
    })
    def get_sweep_points(self):  # pragma: no cover - abstract
        """Return a full sweep (list of y values or [(x,y)])."""
        raise NotImplementedError

    # --- Current measure streaming for EventPlotWidget ---
    def start_current_measure(self) -> None:  # pragma: no cover - abstract
        raise NotImplementedError

    def stop_current_measure(self) -> None:  # pragma: no cover - abstract
        raise NotImplementedError

    @feature(ui={
        "widget": EventPlotWidget,
        "label": "Current Measure",
        # getter is the decorated function itself
        "start": start_current_measure,
        "stop": stop_current_measure,
        "interval_ms": 100,
        "max_points": 10000,
        "markers": True,
    })
    def get_current_measure_points(self):  # pragma: no cover - abstract
        """Return a list of new points to append for current measurement."""
        raise NotImplementedError

    # Optional spectrogram/waterfall using the sweep as input
    @feature(ui={
        "widget": WaterfallWidget,
        "label": "Spectrogram",
        "start": start_sweep,
        "stop": stop_sweep,
        "getter": get_sweep_points,
        "history": 200,
        "interval_ms": 80,
    })
    def show_spectrogram(self):
        """UI-only feature to expose a waterfall view based on the sweep getter."""
        pass

    # Plot features are now defined on the getter methods above.


# Provide simple concrete implementations we can embed
@register_instrument()
class MySigGenDemo(MySigGen):
    __abstract__ = False

    def __init__(self, *, event_bus: Optional[EventBus] = None):
        super().__init__(event_bus=event_bus)
        self.freq = 3e6
        self.power = 0.0
        self.on = False

    @classmethod
    def supported_connections(cls):
        return ["DEMO"]

    @classmethod
    def connection_placeholders(cls):
        return {"DEMO": "No address required"}

    def connect(self, **kwargs) -> None:
        self._state.connected = True

    def disconnect(self) -> None:
        self._state.connected = False

    # Shared-connection hooks (demo: use kwargs dict as the connection object)
    def get_connection(self, **kwargs):
        # For demo, the connection object is just the params dict
        return dict(kwargs)

    def set_connection(self, connection) -> None:
        # Attach to shared connection object (no real I/O)
        self._state.connected = True

    def set_frequency(self, hz: float) -> None:
        self.freq = float(hz)

    def get_frequency(self) -> float:
        # Simulate that device snaps to nearest Hz
        return float(round(self.freq))

    def set_power(self, dbm: float) -> None:
        self.power = float(dbm)

    def get_power(self) -> float:
        return float(self.power)

    def output_on(self) -> None:
        self.on = True

    def output_off(self) -> None:
        self.on = False


@register_instrument()
class MySpecAnDemo(MySpecAn):
    __abstract__ = False

    def __init__(self, *, event_bus: Optional[EventBus] = None):
        super().__init__(event_bus=event_bus)
        # Initialize demo state
        self.center = 1e6
        self.span = 1e5
        # Streaming state
        self._phase = 0.0
        self._meas_phase = 0.0
        self._sweep_on = False
        self._meas_on = False
        # Time-base for consistent phase regardless of poll rate
        self._last_sweep_t = None
        self._last_meas_t = None
    @classmethod
    def supported_connections(cls):
        return ["DEMO"]

    @classmethod
    def connection_placeholders(cls):
        return {"DEMO": "No address required"}

    def connect(self, **kwargs) -> None:
        self._state.connected = True

    def disconnect(self) -> None:
        self._state.connected = False

    # Shared-connection hooks (demo)
    def get_connection(self, **kwargs):
        return dict(kwargs)

    def set_connection(self, connection) -> None:
        self._state.connected = True

    def set_span(self, hz: float) -> None:
        self.span = float(hz)

    def set_center(self, hz: float) -> None:
        self.center = float(hz)

    def get_span(self) -> float:
        return float(self.span)

    def get_center(self) -> float:
        return float(self.center)

    def single_sweep(self) -> None:
        # Publish a fake sweep to the event bus
        try:
            import math
            xs = range(512)
            y = [20.0 * math.sin(2 * math.pi * (i / 64.0)) for i in xs]
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            import logging
            logging.getLogger(__name__).warning("single_sweep generation failed; publishing zeros", exc_info=True)
            y = [0.0] * 256
        self.events.publish("sweep", y=y)

    # No extra marker methods are needed; UI is derived from getter features.

    # --- Sweep streaming for SweepPlotWidget ---
    def start_sweep(self) -> None:
        # Start streaming (exclusivity enforced by GUI/backend wrappers)
        self._sweep_on = True
        try:
            import time
            self._last_sweep_t = time.perf_counter()
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            self._last_sweep_t = None

    def stop_sweep(self) -> None:
        self._sweep_on = False

    def get_sweep_points(self):
        import math, time
        # Exclusivity renewal handled by caller/proxy
        # Time-based phase evolution so visual is invariant to poll rate
        n = 512
        now = time.perf_counter()
        dt = 0.0
        if self._last_sweep_t is not None:
            dt = max(0.0, now - self._last_sweep_t)
        self._last_sweep_t = now
        # On -> ~1.0 rad/s, Off -> ~0.25 rad/s (similar to previous per-call deltas at ~5 Hz)
        omega = 1.0 if self._sweep_on else 0.25
        self._phase += omega * dt
        return [20.0 * math.sin(2 * math.pi * ((i / 64.0) + self._phase)) for i in range(n)]

    # --- Current measure streaming for EventPlotWidget ---
    def start_current_measure(self) -> None:
        self._meas_on = True
        try:
            import time
            self._last_meas_t = time.perf_counter()
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            self._last_meas_t = None

    def stop_current_measure(self) -> None:
        self._meas_on = False

    def get_current_measure_points(self):
        import math, random, time
        # Exclusivity renewal handled by caller/proxy
        # Time-based phase evolution so visual is invariant to poll rate
        now = time.perf_counter()
        dt = 0.0
        if self._last_meas_t is not None:
            dt = max(0.0, now - self._last_meas_t)
        self._last_meas_t = now
        # On -> ~1.5 rad/s, Off -> ~0.3 rad/s (similar to previous per-call deltas at ~10 Hz)
        omega = 1.5 if self._meas_on else 0.3
        self._meas_phase += omega * dt
        value = 0.5 * math.sin(self._meas_phase) + 0.05 * random.uniform(-1, 1)
        # Scale to dB-ish units
        return [float(10.0 * value)]

    # Multi-trace: combine sweep and current measure
    @feature(ui={
        "widget": MultiTracePlotWidget,
        "label": "Multi-Trace",
        "interval_ms": 150,
        "sources": [
            {"name": "Spectrum", "getter": get_sweep_points, "mode": "sweep"},
            {"name": "Measure", "getter": get_current_measure_points, "mode": "event"},
        ],
    })
    def show_multi_trace(self):
        """UI-only feature to expose MultiTracePlotWidget."""
        pass


# The multi-instrument that aggregates the two
@register_instrument()
class MyComboDevice(MultiInstrument):
    __abstract__ = False

    def __init__(self, *, event_bus: Optional[EventBus] = None):
        super().__init__(event_bus=event_bus)
        # Create child instances and add them under aliases
        self.add_child("sg", MySigGenDemo(event_bus=self.events))
        self.add_child("sa", MySpecAnDemo(event_bus=self.events))
        # Define exclusivity by aliases: sg and sa conflict in the same rf_path
        self.define_group("rf_path", ["sg", "sa"])

    @classmethod
    def supported_connections(cls):
        # Multi-instrument shares a single connection among children.
        # For the demo, both children support DEMO, so expose DEMO here.
        return ["DEMO"]

    @classmethod
    def connection_placeholders(cls):
        # DEMO requires no address; keep it simple for the combo.
        return {"DEMO": "No address required"}

    # Share connection lifecycle across all children
    def connect(self, **kwargs) -> None:
        # Build one shared connection using the first child that provides get_connection
        children = list(self.list_children().values())
        conn_obj = None
        for ch in children:
            mk = getattr(ch, "get_connection", None)
            if callable(mk):
                try:
                    conn_obj = mk(**kwargs)
                    break
                except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                    logging.warning("Child get_connection failed on %s: %s", type(ch).__name__, e, exc_info=True)
                    conn_obj = None
        # Fallback: use raw kwargs as the connection object
        if conn_obj is None:
            conn_obj = dict(kwargs)
        # Attach the same connection to all children
        for ch in children:
            attach = getattr(ch, "set_connection", None)
            if callable(attach):
                try:
                    attach(conn_obj)
                except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                    logging.warning("Child set_connection failed on %s: %s", type(ch).__name__, e, exc_info=True)
            else:
                # Backward-compat: fall back to individual connect
                try:
                    ch.connect(**kwargs)
                except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                    logging.warning("Child connect failed on %s: %s", type(ch).__name__, e, exc_info=True)
        self._state.connected = all(ch.is_connected() for ch in children)

    def disconnect(self) -> None:
        for child in self.list_children().values():
            try:
                child.disconnect()
            except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                logging.warning("Child disconnect failed on %s: %s", type(child).__name__, e, exc_info=True)
        self._state.connected = False


# New IQ Sampler device with spectrogram view
class MyIQSampler(BaseInstrument):
    __abstract__ = True

    # IQ streaming control
    def start_iq(self) -> None:  # pragma: no cover - abstract
        raise NotImplementedError

    def stop_iq(self) -> None:  # pragma: no cover - abstract
        raise NotImplementedError

    # Provide magnitude spectrum points per sweep
    @feature(ui={
        "widget": WaterfallWidget,
        "label": "Spectrogram",
        "start": start_iq,
        "stop": stop_iq,
        "history": 200,
        "interval_ms": 80,
    })
    def get_spectrum_points(self):  # pragma: no cover - abstract
        """Return a list of magnitudes for current FFT frame."""
        raise NotImplementedError


@register_instrument()
class MyIQSamplerDemo(MyIQSampler):
    __abstract__ = False

    def __init__(self, *, event_bus: Optional[EventBus] = None):
        super().__init__(event_bus=event_bus)
        self._on = False
        self._phase = 0.0

    @classmethod
    def supported_connections(cls):
        return ["DEMO"]

    @classmethod
    def connection_placeholders(cls):
        return {"DEMO": "No address required"}

    def connect(self, **kwargs) -> None:
        self._state.connected = True

    def disconnect(self) -> None:
        self._state.connected = False

    # Shared-connection hooks (demo)
    def get_connection(self, **kwargs):
        return dict(kwargs)

    def set_connection(self, connection) -> None:
        self._state.connected = True

    def start_iq(self) -> None:
        self._on = True

    def stop_iq(self) -> None:
        self._on = False

    def get_spectrum_points(self):
        # Fake FFT magnitudes that drift slowly
        import math, random
        n = 256
        self._phase += 0.18 if self._on else 0.04
        base = [0.7 * math.sin(2 * math.pi * ((i / 48.0) + self._phase)) for i in range(n)]
        # Add a couple of narrow peaks
        def peak(center, width, amp):
            return [amp * math.exp(-0.5 * ((i - center) / width) ** 2) for i in range(n)]
        y = [b + p1 + p2 + 0.05 * random.uniform(-1, 1) for b, p1, p2 in zip(base, peak(60, 6, 0.8), peak(170, 8, 0.6))]
        # Return magnitudes as floats
        return [float(val) for val in y]