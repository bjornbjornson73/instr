from __future__ import annotations

"""
Example instruments plugin bundle: provides demo implementations for multiple device types.
Each type has two concrete classes: a "Full" demo (richer behavior) and a "Minimal" demo (simpler),
so the GUI can be exercised thoroughly.

All instruments support the DEMO connection type and avoid real I/O.
Widgets are chosen from core GUI widgets when possible.
"""

from typing import Optional, List, Dict, Any
import math
import random

from instrctl.core import (
    BaseInstrument,
    Capability,
    EventBus,
    feature,
    register_instrument,
)
from instrctl.gui.widgets import (
    UnitLineEdit,
    LabeledSlider,
    ToggleSwitch,
    SweepPlotWidget,
    EventPlotWidget,
    MultiTracePlotWidget,
    WaterfallWidget,
)
import time


# ----------------------- Helpers -----------------------

def _adv_phase(phase: float, omega: float, dt_ms: int) -> float:
    return phase + omega * max(0.0, dt_ms / 1000.0)


def _sine_wave(n: int, phase: float, period: float = 64.0, amp: float = 20.0) -> List[float]:
    return [amp * math.sin(2 * math.pi * ((i / period) + phase)) for i in range(n)]


def _noisy(val: float, noise: float = 0.05) -> float:
    return float(val + noise * random.uniform(-1, 1))


# =====================================================================
# Spectrum Analyzer
# =====================================================================
class SpectrumAnalyzer(BaseInstrument):
    __abstract__ = True

    def get_span(self) -> float:  # pragma: no cover
        raise NotImplementedError

    @feature(capability=Capability.REQUIRED, ui={"widget": UnitLineEdit, "label": "Span", "unit": "Hz", "readback": get_span})
    def set_span(self, hz: float) -> None:  # pragma: no cover
        raise NotImplementedError

    def get_center(self) -> float:  # pragma: no cover
        raise NotImplementedError

    @feature(capability=Capability.REQUIRED, ui={"widget": UnitLineEdit, "label": "Center", "unit": "Hz", "readback": get_center})
    def set_center(self, hz: float) -> None:  # pragma: no cover
        raise NotImplementedError

    def start_sweep(self) -> None:  # pragma: no cover
        raise NotImplementedError

    def stop_sweep(self) -> None:  # pragma: no cover
        raise NotImplementedError

    @feature(
        ui={
            "widget": SweepPlotWidget,
            "label": "Spectrum",
            "markers": True,
            # restored: GUI drives polling; agent doesn't auto start/stop
            "start": start_sweep,
            "stop": stop_sweep,
            "interval_ms": 150,
        },
    )
    def get_sweep_points(self) -> List[float]:  # pragma: no cover
        raise NotImplementedError


@register_instrument()
class SpectrumAnalyzerFullDemo(SpectrumAnalyzer):
    __abstract__ = False

    def __init__(self, *, event_bus: Optional[EventBus] = None):
        super().__init__(event_bus=event_bus)
        self._center = 1.0e6
        self._span = 1.0e5
        self._phase = 0.0
        self._running = False
        self._last_t_ms: Optional[int] = None

    @classmethod
    def supported_connections(cls):
        return ["DEMO"]

    @classmethod
    def connection_placeholders(cls):
        return {"DEMO": "No address required"}

    def connect(self, **kwargs) -> None:
        self._state.connected = True

    def disconnect(self) -> None:
        self._state.connected = False

    def get_span(self) -> float:
        return float(self._span)

    def set_span(self, hz: float) -> None:
        self._span = float(hz)

    def get_center(self) -> float:
        return float(self._center)

    def set_center(self, hz: float) -> None:
        self._center = float(hz)

    def start_sweep(self) -> None:
        self._running = True
        self._last_t_ms = int(time.time_ns() / 1_000_000)

    def stop_sweep(self) -> None:
        self._running = False

    def get_state_object(self):
        """Return a state object for testing RPyC netref method calls."""
        class StateObject:
            def __init__(self, center, span, running):
                self.center = center
                self.span = span
                self.running = running
                self._call_count = 0
            
            def get_center(self):
                self._call_count += 1
                return self.center
            
            def get_span(self):
                self._call_count += 1
                return self.span
            
            def is_running(self):
                self._call_count += 1
                return self.running
            
            def get_call_count(self):
                return self._call_count
        
        return StateObject(self._center, self._span, self._running)

    def get_sweep_points(self) -> List[float]:
        n = 512
        now = int(time.time_ns() / 1_000_000)
        dt = 0
        if self._last_t_ms is not None:
            dt = max(0, now - self._last_t_ms)
        self._last_t_ms = now
        self._phase = _adv_phase(self._phase, 1.2 if self._running else 0.25, dt)
        base = _sine_wave(n, self._phase)
        # Add a couple of narrow peaks that wander slowly with center/span
        def gauss(center_i: float, width: float, amp: float) -> List[float]:
            return [amp * math.exp(-0.5 * ((i - center_i) / width) ** 2) for i in range(n)]
        p1 = gauss(0.25 * n + 0.1 * math.sin(self._center / 1e6), 7 + (self._span / 2e5), 18)
        p2 = gauss(0.70 * n + 0.1 * math.cos(self._center / 7e5), 9 + (self._span / 1.5e5), 14)
        return [float(b + x + y) for b, x, y in zip(base, p1, p2)]


@register_instrument()
class SpectrumAnalyzerMinimalDemo(SpectrumAnalyzer):
    __abstract__ = False

    def __init__(self, *, event_bus: Optional[EventBus] = None):
        super().__init__(event_bus=event_bus)
        self._center = 0.0
        self._span = 1.0e5
        self._running = False

    @classmethod
    def supported_connections(cls):
        return ["DEMO"]

    @classmethod
    def connection_placeholders(cls):
        return {"DEMO": "No address required"}

    def connect(self, **kwargs) -> None:
        self._state.connected = True

    def disconnect(self) -> None:
        self._state.connected = False

    def get_span(self) -> float:
        return float(self._span)

    def set_span(self, hz: float) -> None:
        self._span = float(hz)

    def get_center(self) -> float:
        return float(self._center)

    def set_center(self, hz: float) -> None:
        self._center = float(hz)

    def start_sweep(self) -> None:
        self._running = True

    def stop_sweep(self) -> None:
        self._running = False

    def get_sweep_points(self) -> List[float]:
        # Minimal: simple static sinusoid, low variance
        return _sine_wave(256, 0.0, period=32.0, amp=8.0)


# =====================================================================
# Signal Generator
# =====================================================================
class SignalGenerator(BaseInstrument):
    __abstract__ = True

    def get_frequency(self) -> float:  # pragma: no cover
        raise NotImplementedError

    @feature(capability=Capability.REQUIRED, ui={"widget": UnitLineEdit, "label": "Frequency", "unit": "Hz", "readback": get_frequency})
    def set_frequency(self, hz: float) -> None:  # pragma: no cover
        raise NotImplementedError

    def get_power(self) -> float:  # pragma: no cover
        raise NotImplementedError

    @feature(capability=Capability.REQUIRED, ui={"widget": LabeledSlider, "label": "Power", "min": -60, "max": 20, "value": 0, "unit": "dBm", "readback": get_power})
    def set_power(self, dbm: float) -> None:  # pragma: no cover
        raise NotImplementedError

    def output_off(self) -> None:  # pragma: no cover
        raise NotImplementedError

    @feature(ui={"widget": ToggleSwitch, "label": "RF Output", "off_method": output_off})
    def output_on(self) -> None:  # pragma: no cover
        raise NotImplementedError


@register_instrument()
class SignalGeneratorFullDemo(SignalGenerator):
    __abstract__ = False

    def __init__(self, *, event_bus: Optional[EventBus] = None):
        super().__init__(event_bus=event_bus)
        self._freq = 1e6
        self._power = 0.0
        self._on = False

    @classmethod
    def supported_connections(cls):
        return ["DEMO"]

    @classmethod
    def connection_placeholders(cls):
        return {"DEMO": "No address required"}

    def connect(self, **kwargs) -> None:
        self._state.connected = True

    def disconnect(self) -> None:
        self._state.connected = False

    def get_frequency(self) -> float:
        return float(round(self._freq))

    def set_frequency(self, hz: float) -> None:
        self._freq = float(hz)

    def get_power(self) -> float:
        return float(self._power)

    def set_power(self, dbm: float) -> None:
        self._power = float(dbm)

    def output_on(self) -> None:
        self._on = True

    def output_off(self) -> None:
        self._on = False


@register_instrument()
class SignalGeneratorMinimalDemo(SignalGenerator):
    __abstract__ = False

    def __init__(self, *, event_bus: Optional[EventBus] = None):
        super().__init__(event_bus=event_bus)
        self._freq = 10e3
        self._power = -10.0
        self._on = False

    @classmethod
    def supported_connections(cls):
        return ["DEMO"]

    @classmethod
    def connection_placeholders(cls):
        return {"DEMO": "No address required"}

    def connect(self, **kwargs) -> None:
        self._state.connected = True

    def disconnect(self) -> None:
        self._state.connected = False

    def get_frequency(self) -> float:
        return float(self._freq)

    def set_frequency(self, hz: float) -> None:
        self._freq = float(hz)

    def get_power(self) -> float:
        return float(self._power)

    def set_power(self, dbm: float) -> None:
        self._power = float(dbm)

    def output_on(self) -> None:
        self._on = True

    def output_off(self) -> None:
        self._on = False


# =====================================================================
# Vector Signal Generator (adds simple modulation)
# =====================================================================
class VectorSignalGenerator(BaseInstrument):
    __abstract__ = True

    def get_frequency(self) -> float:  # pragma: no cover
        raise NotImplementedError

    @feature(capability=Capability.REQUIRED, ui={"widget": UnitLineEdit, "label": "Frequency", "unit": "Hz", "readback": get_frequency})
    def set_frequency(self, hz: float) -> None:  # pragma: no cover
        raise NotImplementedError

    def get_power(self) -> float:  # pragma: no cover
        raise NotImplementedError

    @feature(capability=Capability.REQUIRED, ui={"widget": LabeledSlider, "label": "Power", "min": -60, "max": 20, "value": -10, "unit": "dBm", "readback": get_power})
    def set_power(self, dbm: float) -> None:  # pragma: no cover
        raise NotImplementedError

    def get_modulation(self) -> str:  # pragma: no cover
        raise NotImplementedError

    @feature(ui={"widget": UnitLineEdit, "label": "Modulation", "readback": get_modulation})
    def set_modulation(self, mod: str) -> None:  # pragma: no cover
        raise NotImplementedError

    def start_iq(self) -> None:  # pragma: no cover
        raise NotImplementedError

    def stop_iq(self) -> None:  # pragma: no cover
        raise NotImplementedError

    @feature(
        ui={
            "widget": EventPlotWidget,
            "label": "EVM (demo)",
            "max_points": 2000,
            "markers": True,
            # restored polling hints
            "start": start_iq,
            "stop": stop_iq,
            "interval_ms": 120,
        },
    )
    def get_evm_points(self) -> List[float]:  # pragma: no cover
        raise NotImplementedError


@register_instrument()
class VectorSignalGeneratorFullDemo(VectorSignalGenerator):
    __abstract__ = False

    def __init__(self, *, event_bus: Optional[EventBus] = None):
        super().__init__(event_bus=event_bus)
        self._freq = 2.45e9
        self._power = -5.0
        self._mod = "QAM16"
        self._running = False
        self._evm_phase = 0.0
        self._last_t_ms: Optional[int] = None

    @classmethod
    def supported_connections(cls):
        return ["DEMO"]

    @classmethod
    def connection_placeholders(cls):
        return {"DEMO": "No address required"}

    def connect(self, **kwargs) -> None:
        self._state.connected = True

    def disconnect(self) -> None:
        self._state.connected = False

    def get_frequency(self) -> float:
        return float(self._freq)

    def set_frequency(self, hz: float) -> None:
        self._freq = float(hz)

    def get_power(self) -> float:
        return float(self._power)

    def set_power(self, dbm: float) -> None:
        self._power = float(dbm)

    def get_modulation(self) -> str:
        return str(self._mod)

    def set_modulation(self, mod: str) -> None:
        self._mod = str(mod)

    def start_iq(self) -> None:
        self._running = True
        self._last_t_ms = int(time.time_ns() / 1_000_000)

    def stop_iq(self) -> None:
        self._running = False

    def get_evm_points(self) -> List[float]:
        now = int(time.time_ns() / 1_000_000)
        dt = 0
        if self._last_t_ms is not None:
            dt = max(0, now - self._last_t_ms)
        self._last_t_ms = now
        self._evm_phase = _adv_phase(self._evm_phase, 1.4 if self._running else 0.2, dt)
        base = 1.5 + 0.7 * math.sin(self._evm_phase)
        jitter = 0.3 if self._mod.upper().startswith("QAM") else 0.15
        return [float(max(0.1, base + random.uniform(-jitter, jitter)))]


@register_instrument()
class VectorSignalGeneratorMinimalDemo(VectorSignalGenerator):
    __abstract__ = False

    def __init__(self, *, event_bus: Optional[EventBus] = None):
        super().__init__(event_bus=event_bus)
        self._freq = 1e6
        self._power = -15.0
        self._mod = "OFF"

    @classmethod
    def supported_connections(cls):
        return ["DEMO"]

    @classmethod
    def connection_placeholders(cls):
        return {"DEMO": "No address required"}

    def connect(self, **kwargs) -> None:
        self._state.connected = True

    def disconnect(self) -> None:
        self._state.connected = False

    def get_frequency(self) -> float:
        return float(self._freq)

    def set_frequency(self, hz: float) -> None:
        self._freq = float(hz)

    def get_power(self) -> float:
        return float(self._power)

    def set_power(self, dbm: float) -> None:
        self._power = float(dbm)

    def get_modulation(self) -> str:
        return str(self._mod)

    def set_modulation(self, mod: str) -> None:
        self._mod = str(mod)

    def start_iq(self) -> None:
        pass

    def stop_iq(self) -> None:
        pass

    def get_evm_points(self) -> List[float]:
        return [0.5]


# =====================================================================
# GPIO Controller (demonstrates multiple toggles)
# =====================================================================
class GPIOController(BaseInstrument):
    __abstract__ = True

    # For demo, expose four pins as separate toggle features with readback labels
    def pin0_off(self) -> None:  # pragma: no cover
        raise NotImplementedError

    @feature(ui={"widget": ToggleSwitch, "label": "Pin 0", "off_method": pin0_off})
    def pin0_on(self) -> None:  # pragma: no cover
        raise NotImplementedError

    def pin1_off(self) -> None:  # pragma: no cover
        raise NotImplementedError

    @feature(ui={"widget": ToggleSwitch, "label": "Pin 1", "off_method": pin1_off})
    def pin1_on(self) -> None:  # pragma: no cover
        raise NotImplementedError

    def pin2_off(self) -> None:  # pragma: no cover
        raise NotImplementedError

    @feature(ui={"widget": ToggleSwitch, "label": "Pin 2", "off_method": pin2_off})
    def pin2_on(self) -> None:  # pragma: no cover
        raise NotImplementedError

    def pin3_off(self) -> None:  # pragma: no cover
        raise NotImplementedError

    @feature(ui={"widget": ToggleSwitch, "label": "Pin 3", "off_method": pin3_off})
    def pin3_on(self) -> None:  # pragma: no cover
        raise NotImplementedError


@register_instrument()
class GPIOControllerFullDemo(GPIOController):
    __abstract__ = False

    def __init__(self, *, event_bus: Optional[EventBus] = None):
        super().__init__(event_bus=event_bus)
        self._pins = [False, False, False, False]

    @classmethod
    def supported_connections(cls):
        return ["DEMO"]

    @classmethod
    def connection_placeholders(cls):
        return {"DEMO": "No address required"}

    def connect(self, **kwargs) -> None:
        self._state.connected = True

    def disconnect(self) -> None:
        self._state.connected = False

    def pin0_on(self) -> None: self._pins[0] = True
    def pin0_off(self) -> None: self._pins[0] = False
    def pin1_on(self) -> None: self._pins[1] = True
    def pin1_off(self) -> None: self._pins[1] = False
    def pin2_on(self) -> None: self._pins[2] = True
    def pin2_off(self) -> None: self._pins[2] = False
    def pin3_on(self) -> None: self._pins[3] = True
    def pin3_off(self) -> None: self._pins[3] = False


@register_instrument()
class GPIOControllerMinimalDemo(GPIOController):
    __abstract__ = False

    def __init__(self, *, event_bus: Optional[EventBus] = None):
        super().__init__(event_bus=event_bus)
        self._pins = [False, False, False, False]

    @classmethod
    def supported_connections(cls):
        return ["DEMO"]

    @classmethod
    def connection_placeholders(cls):
        return {"DEMO": "No address required"}

    def connect(self, **kwargs) -> None:
        self._state.connected = True

    def disconnect(self) -> None:
        self._state.connected = False

    def pin0_on(self) -> None: self._pins[0] = True
    def pin0_off(self) -> None: self._pins[0] = False
    def pin1_on(self) -> None: self._pins[1] = True
    def pin1_off(self) -> None: self._pins[1] = False
    def pin2_on(self) -> None: self._pins[2] = True
    def pin2_off(self) -> None: self._pins[2] = False
    def pin3_on(self) -> None: self._pins[3] = True
    def pin3_off(self) -> None: self._pins[3] = False


# =====================================================================
# Network Analyzer (MultiTrace: S11 and S21)
# =====================================================================
class NetworkAnalyzer(BaseInstrument):
    __abstract__ = True

    def start_sweep(self) -> None:  # pragma: no cover
        raise NotImplementedError

    def stop_sweep(self) -> None:  # pragma: no cover
        raise NotImplementedError

    def get_s11(self) -> List[float]:  # pragma: no cover
        raise NotImplementedError

    def get_s21(self) -> List[float]:  # pragma: no cover
        raise NotImplementedError

    @feature(
        ui={
            "widget": MultiTracePlotWidget,
            "label": "Network",
            "sources": [
                {"name": "S11", "getter": get_s11, "mode": "sweep"},
                {"name": "S21", "getter": get_s21, "mode": "sweep"},
            ],
            # restored polling hints
            "interval_ms": 180,
            "start": start_sweep,
            "stop": stop_sweep,
        },
    )
    def show_network(self):  # pragma: no cover
        return None


@register_instrument()
class NetworkAnalyzerFullDemo(NetworkAnalyzer):
    __abstract__ = False

    def __init__(self, *, event_bus: Optional[EventBus] = None):
        super().__init__(event_bus=event_bus)
        self._phase = 0.0
        self._running = False
        self._last_t_ms: Optional[int] = None

    @classmethod
    def supported_connections(cls):
        return ["DEMO"]

    @classmethod
    def connection_placeholders(cls):
        return {"DEMO": "No address required"}

    def connect(self, **kwargs) -> None:
        self._state.connected = True

    def disconnect(self) -> None:
        self._state.connected = False

    def start_sweep(self) -> None:
        self._running = True
        self._last_t_ms = int(time.time_ns() / 1_000_000)

    def stop_sweep(self) -> None:
        self._running = False

    def get_s11(self) -> List[float]:
        n = 256
        now = int(time.time_ns() / 1_000_000)
        dt = 0
        if self._last_t_ms is not None:
            dt = max(0, now - self._last_t_ms)
        self._last_t_ms = now
        self._phase = _adv_phase(self._phase, 1.0 if self._running else 0.2, dt)
        base = _sine_wave(n, self._phase, period=48.0, amp=10.0)
        notch = [-(8.0 * math.exp(-0.5 * ((i - 0.6 * n) / 6) ** 2)) for i in range(n)]
        return [float(b + x) for b, x in zip(base, notch)]

    def get_s21(self) -> List[float]:
        n = 256
        base = _sine_wave(n, self._phase + 0.3, period=64.0, amp=6.0)
        peak = [8.0 * math.exp(-0.5 * ((i - 0.3 * n) / 8) ** 2) for i in range(n)]
        return [float(b + x) for b, x in zip(base, peak)]


@register_instrument()
class NetworkAnalyzerMinimalDemo(NetworkAnalyzer):
    __abstract__ = False

    def __init__(self, *, event_bus: Optional[EventBus] = None):
        super().__init__(event_bus=event_bus)
        self._running = False

    @classmethod
    def supported_connections(cls):
        return ["DEMO"]

    @classmethod
    def connection_placeholders(cls):
        return {"DEMO": "No address required"}

    def connect(self, **kwargs) -> None:
        self._state.connected = True

    def disconnect(self) -> None:
        self._state.connected = False

    def start_sweep(self) -> None:
        self._running = True

    def stop_sweep(self) -> None:
        self._running = False

    def get_s11(self) -> List[float]:
        return _sine_wave(128, 0.0, period=32.0, amp=6.0)

    def get_s21(self) -> List[float]:
        return _sine_wave(128, 0.2, period=42.0, amp=4.0)


# =====================================================================
# RF Attenuator
# =====================================================================
class RFAttenuator(BaseInstrument):
    __abstract__ = True

    def get_atten(self) -> float:  # pragma: no cover
        raise NotImplementedError

    @feature(ui={"widget": LabeledSlider, "label": "Attenuation", "min": 0, "max": 60, "unit": "dB", "readback": get_atten})
    def set_atten(self, db: float) -> None:  # pragma: no cover
        raise NotImplementedError


@register_instrument()
class RFAttenuatorFullDemo(RFAttenuator):
    __abstract__ = False

    def __init__(self, *, event_bus: Optional[EventBus] = None):
        super().__init__(event_bus=event_bus)
        self._atten = 10.0

    @classmethod
    def supported_connections(cls):
        return ["DEMO"]

    @classmethod
    def connection_placeholders(cls):
        return {"DEMO": "No address required"}

    def connect(self, **kwargs) -> None:
        self._state.connected = True

    def disconnect(self) -> None:
        self._state.connected = False

    def get_atten(self) -> float:
        return float(self._atten)

    def set_atten(self, db: float) -> None:
        self._atten = float(db)


@register_instrument()
class RFAttenuatorMinimalDemo(RFAttenuator):
    __abstract__ = False

    def __init__(self, *, event_bus: Optional[EventBus] = None):
        super().__init__(event_bus=event_bus)
        self._atten = 0.0

    @classmethod
    def supported_connections(cls):
        return ["DEMO"]

    @classmethod
    def connection_placeholders(cls):
        return {"DEMO": "No address required"}

    def connect(self, **kwargs) -> None:
        self._state.connected = True

    def disconnect(self) -> None:
        self._state.connected = False

    def get_atten(self) -> float:
        return float(self._atten)

    def set_atten(self, db: float) -> None:
        self._atten = float(db)


# =====================================================================
# Oven (temperature controller)
# =====================================================================
class Oven(BaseInstrument):
    __abstract__ = True

    def get_target(self) -> float:  # pragma: no cover
        raise NotImplementedError

    @feature(ui={"widget": UnitLineEdit, "label": "Target", "unit": "°C", "readback": get_target})
    def set_target(self, celsius: float) -> None:  # pragma: no cover
        raise NotImplementedError

    def heater_off(self) -> None:  # pragma: no cover
        raise NotImplementedError

    @feature(ui={"widget": ToggleSwitch, "label": "Heater", "off_method": heater_off})
    def heater_on(self) -> None:  # pragma: no cover
        raise NotImplementedError

    def start_temp(self) -> None:  # pragma: no cover
        raise NotImplementedError

    def stop_temp(self) -> None:  # pragma: no cover
        raise NotImplementedError

    @feature(
        ui={
            "widget": EventPlotWidget,
            "label": "Temperature",
            "max_points": 2000,
            # restored polling hints
            "start": start_temp,
            "stop": stop_temp,
            "interval_ms": 250,
        },
    )
    def get_temperature_points(self) -> List[float]:  # pragma: no cover
        raise NotImplementedError


@register_instrument()
class OvenFullDemo(Oven):
    __abstract__ = False

    def __init__(self, *, event_bus: Optional[EventBus] = None):
        super().__init__(event_bus=event_bus)
        self._target = 50.0
        self._heater = False
        self._temp = 22.0
        self._run = False

    @classmethod
    def supported_connections(cls):
        return ["DEMO"]

    @classmethod
    def connection_placeholders(cls):
        return {"DEMO": "No address required"}

    def connect(self, **kwargs) -> None:
        self._state.connected = True

    def disconnect(self) -> None:
        self._state.connected = False

    def get_target(self) -> float:
        return float(self._target)

    def set_target(self, celsius: float) -> None:
        self._target = float(celsius)

    def heater_on(self) -> None:
        self._heater = True

    def heater_off(self) -> None:
        self._heater = False

    def start_temp(self) -> None:
        self._run = True

    def stop_temp(self) -> None:
        self._run = False

    def get_temperature_points(self) -> List[float]:
        # Drift toward target when heater on, drift down when off
        err = self._target - self._temp
        step = 0.3 if self._heater else -0.1
        self._temp = self._temp + 0.05 * err + step + random.uniform(-0.05, 0.05)
        return [float(self._temp)]


@register_instrument()
class OvenMinimalDemo(Oven):
    __abstract__ = False

    def __init__(self, *, event_bus: Optional[EventBus] = None):
        super().__init__(event_bus=event_bus)
        self._target = 30.0
        self._heater = False

    @classmethod
    def supported_connections(cls):
        return ["DEMO"]

    @classmethod
    def connection_placeholders(cls):
        return {"DEMO": "No address required"}

    def connect(self, **kwargs) -> None:
        self._state.connected = True

    def disconnect(self) -> None:
        self._state.connected = False

    def get_target(self) -> float:
        return float(self._target)

    def set_target(self, celsius: float) -> None:
        self._target = float(celsius)

    def heater_on(self) -> None:
        self._heater = True

    def heater_off(self) -> None:
        self._heater = False

    def start_temp(self) -> None:
        pass

    def stop_temp(self) -> None:
        pass

    def get_temperature_points(self) -> List[float]:
        return [self._target]


# =====================================================================
# DC Power Supply
# =====================================================================
class DCPowerSupply(BaseInstrument):
    __abstract__ = True

    def get_voltage(self) -> float:  # pragma: no cover
        raise NotImplementedError

    @feature(ui={"widget": UnitLineEdit, "label": "Voltage", "unit": "V", "readback": get_voltage})
    def set_voltage(self, v: float) -> None:  # pragma: no cover
        raise NotImplementedError

    def get_current_limit(self) -> float:  # pragma: no cover
        raise NotImplementedError

    @feature(ui={"widget": UnitLineEdit, "label": "Current Limit", "unit": "A", "readback": get_current_limit})
    def set_current_limit(self, a: float) -> None:  # pragma: no cover
        raise NotImplementedError

    def output_off(self) -> None:  # pragma: no cover
        raise NotImplementedError

    @feature(ui={"widget": ToggleSwitch, "label": "Output", "off_method": output_off})
    def output_on(self) -> None:  # pragma: no cover
        raise NotImplementedError

    def start_mon(self) -> None:  # pragma: no cover
        raise NotImplementedError

    def stop_mon(self) -> None:  # pragma: no cover
        raise NotImplementedError

    @feature(ui={
        "widget": EventPlotWidget,
        "label": "Current",
        "start": start_mon,
        "stop": stop_mon,
        "interval_ms": 120,
        "max_points": 3000,
    })
    def get_current_points(self) -> List[float]:  # pragma: no cover
        raise NotImplementedError


@register_instrument()
class DCPowerSupplyFullDemo(DCPowerSupply):
    __abstract__ = False

    def __init__(self, *, event_bus: Optional[EventBus] = None):
        super().__init__(event_bus=event_bus)
        self._v = 5.0
        self._ilim = 1.0
        self._on = False

    @classmethod
    def supported_connections(cls):
        return ["DEMO"]

    @classmethod
    def connection_placeholders(cls):
        return {"DEMO": "No address required"}

    def connect(self, **kwargs) -> None:
        self._state.connected = True

    def disconnect(self) -> None:
        self._state.connected = False

    def get_voltage(self) -> float:
        return float(self._v)

    def set_voltage(self, v: float) -> None:
        self._v = float(v)

    def get_current_limit(self) -> float:
        return float(self._ilim)

    def set_current_limit(self, a: float) -> None:
        self._ilim = float(a)

    def output_on(self) -> None:
        self._on = True

    def output_off(self) -> None:
        self._on = False

    def start_mon(self) -> None:
        pass

    def stop_mon(self) -> None:
        pass

    def get_current_points(self) -> List[float]:
        # Simple model: current ~ V / R with a bit of noise, clip by current limit
        r_load = 10.0 if self._on else 100.0
        current = min(self._ilim, max(0.0, self._v / r_load))
        return [_noisy(current, 0.02)]


@register_instrument()
class DCPowerSupplyMinimalDemo(DCPowerSupply):
    __abstract__ = False

    def __init__(self, *, event_bus: Optional[EventBus] = None):
        super().__init__(event_bus=event_bus)
        self._v = 3.3
        self._ilim = 0.5
        self._on = False

    @classmethod
    def supported_connections(cls):
        return ["DEMO"]

    @classmethod
    def connection_placeholders(cls):
        return {"DEMO": "No address required"}

    def connect(self, **kwargs) -> None:
        self._state.connected = True

    def disconnect(self) -> None:
        self._state.connected = False

    def get_voltage(self) -> float:
        return float(self._v)

    def set_voltage(self, v: float) -> None:
        self._v = float(v)

    def get_current_limit(self) -> float:
        return float(self._ilim)

    def set_current_limit(self, a: float) -> None:
        self._ilim = float(a)

    def output_on(self) -> None:
        self._on = True

    def output_off(self) -> None:
        self._on = False

    def start_mon(self) -> None:
        pass

    def stop_mon(self) -> None:
        pass

    def get_current_points(self) -> List[float]:
        return [0.1 if self._on else 0.0]


# =====================================================================
# Current Measure (standalone meter)
# =====================================================================
class CurrentMeter(BaseInstrument):
    __abstract__ = True

    def start(self) -> None:  # pragma: no cover
        raise NotImplementedError

    def stop(self) -> None:  # pragma: no cover
        raise NotImplementedError

    @feature(
        ui={
            "widget": EventPlotWidget,
            "label": "Current",
            "max_points": 5000,
            # restored polling hints
            "start": start,
            "stop": stop,
            "interval_ms": 100,
        },
    )
    def get_points(self) -> List[float]:  # pragma: no cover
        raise NotImplementedError


@register_instrument()
class CurrentMeterFullDemo(CurrentMeter):
    __abstract__ = False

    def __init__(self, *, event_bus: Optional[EventBus] = None):
        super().__init__(event_bus=event_bus)
        self._run = False
        self._phase = 0.0

    @classmethod
    def supported_connections(cls):
        return ["DEMO"]

    @classmethod
    def connection_placeholders(cls):
        return {"DEMO": "No address required"}

    def connect(self, **kwargs) -> None:
        self._state.connected = True

    def disconnect(self) -> None:
        self._state.connected = False

    def start(self) -> None:
        self._run = True

    def stop(self) -> None:
        self._run = False

    def get_points(self) -> List[float]:
        self._phase += 0.25 if self._run else 0.05
        return [0.5 + 0.3 * math.sin(self._phase) + 0.05 * random.uniform(-1, 1)]


@register_instrument()
class CurrentMeterMinimalDemo(CurrentMeter):
    __abstract__ = False

    def __init__(self, *, event_bus: Optional[EventBus] = None):
        super().__init__(event_bus=event_bus)
        self._run = False

    @classmethod
    def supported_connections(cls):
        return ["DEMO"]

    @classmethod
    def connection_placeholders(cls):
        return {"DEMO": "No address required"}

    def connect(self, **kwargs) -> None:
        self._state.connected = True

    def disconnect(self) -> None:
        self._state.connected = False

    def start(self) -> None:
        self._run = True

    def stop(self) -> None:
        self._run = False

    def get_points(self) -> List[float]:
        return [0.0]
