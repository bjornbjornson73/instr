from __future__ import annotations

"""
Web GUI instrument plugin: embeds a web page, can record basic user actions (click/input)
and replay them. Implemented entirely as a plugin; no core changes required.

Features:
- Widget: WebBrowserPanel (uses QtWebEngine if available; otherwise shows a helpful message)
- Recording: captures click and input events via injected JavaScript and streams them via
  console messages (prefixed with 'REC:'). Python side parses and accumulates events.
- Playback: replays recorded events by injecting JavaScript that finds targets by a
  generated CSS selector and synthesizes DOM events.

Notes:
- This is a demo-grade recorder; complex pages and asynchronous navigation may require
  more robust synchronization (e.g., waiting for specific DOM states) to replay reliably.
- Requires QtWebEngine modules (PySide6.QtWebEngineWidgets). If unavailable, the panel
  falls back to a placeholder with external-open button and disabled record/replay.
"""

from typing import Optional, List, Dict, Any
import importlib
import sys
import subprocess

from PySide6 import QtCore, QtWidgets

# Lazy-load QtWebEngine to avoid early GPU context issues at import time
WEB_ENGINE_AVAILABLE: Optional[bool] = None
WEB_ENGINE_REASON: str = ""
QWebEngineView = None  # type: ignore[assignment]

def _ensure_webengine_loaded() -> bool:
    global WEB_ENGINE_AVAILABLE, QWebEngineView, WEB_ENGINE_REASON
    if WEB_ENGINE_AVAILABLE is not None:
        return bool(WEB_ENGINE_AVAILABLE)
    import os
    # Interpret env var strictly: only 1/true/yes/on force external; 0/false/no/off/empty do not
    _raw_force = os.environ.get("INSTRCTL_FORCE_EXTERNAL_BROWSER", "")
    _val = _raw_force.strip().lower()
    _force = _val in ("1", "true", "yes", "on")
    if _force:
        WEB_ENGINE_AVAILABLE = False
        WEB_ENGINE_REASON = f"forced external by INSTRCTL_FORCE_EXTERNAL_BROWSER (value={_raw_force!r})"
        QWebEngineView = None  # type: ignore
        return False
    # Optional preflight: try launching a tiny helper that constructs QWebEngineView safely.
    # If it crashes or times out, we avoid importing/using WebEngine in-process and fall back.
    _skip_pf = os.environ.get("INSTRCTL_SKIP_WEBENGINE_PREFLIGHT", "").strip().lower() in ("1", "true", "yes", "on")
    if not _skip_pf:
        try:
            code = r"""
import os, sys
# Scenario-aware conservative flags; default to WARP, allow swiftshader/D3D11/desktop
scenario = os.environ.get("WEBENGINE_SCENARIO", "warp").strip().lower()
base = [
    "--disable-gpu",
    "--disable-gpu-compositing",
    "--in-process-gpu",
    "--disable-gpu-vsync",
    "--disable-features=UseSkiaRenderer",
]
if scenario == "warp":
    scen = ["--use-angle=warp"]
    os.environ.setdefault("QT_ANGLE_PLATFORM", "warp")
    os.environ.setdefault("QT_OPENGL", "angle")
elif scenario == "d3d11":
    scen = ["--use-angle=d3d11"]
    os.environ.setdefault("QT_OPENGL", "angle")
elif scenario == "desktop":
    scen = ["--use-gl=desktop"]
    os.environ.setdefault("QT_OPENGL", "desktop")
else:
    scen = ["--use-angle=swiftshader", "--use-gl=swiftshader"]
    os.environ.setdefault("QT_ANGLE_PLATFORM", "swiftshader")
    os.environ.setdefault("QT_OPENGL", "software")

existing = os.environ.get("QTWEBENGINE_CHROMIUM_FLAGS", "").strip()
# Remove any inherited --no-sandbox to avoid sandbox-disabled aborts during preflight
existing = " ".join(p for p in existing.split() if p != "--no-sandbox").strip()
has_use_angle = "use-angle=" in existing
has_use_gl = "use-gl=" in existing
scenario_flags = []
for f in scen:
    if f.startswith("--use-angle=") and has_use_angle:
        continue
    if f.startswith("--use-gl=") and has_use_gl:
        continue
    scenario_flags.append(f)
merged = existing
for f in base + scenario_flags:
    if f and f not in merged:
        merged = (merged + " " + f).strip()
os.environ["QTWEBENGINE_CHROMIUM_FLAGS"] = merged
# IMPORTANT: Ensure sandbox is enabled during preflight by unsetting the var entirely
os.environ.pop("QTWEBENGINE_DISABLE_SANDBOX", None)
# Sanitize inherited RHI/Quick backend values if misconfigured (Qt 6 valid RHI: opengl, d3d11, vulkan, metal, null)
_allowed = {"opengl", "d3d11", "vulkan", "metal", "null"}
_rhi = os.environ.get("QSG_RHI_BACKEND")
if _rhi and _rhi.strip().lower() not in _allowed:
    os.environ.pop("QSG_RHI_BACKEND", None)
if os.environ.get("QT_QUICK_BACKEND", "").strip().lower() == "software":
    os.environ.pop("QT_QUICK_BACKEND", None)
if importlib.util.find_spec("PySide6") is not None:
    # On Windows, help QtWebEngine find its resources and helper exe.
    import PySide6 as _p6
    from pathlib import Path as _P

    _base = _P(_p6.__file__).parent
    _res = _base / "resources"
    _loc = _res / "qtwebengine_locales"
    _proc = _base / "QtWebEngineProcess.exe"
    os.environ.setdefault("QTWEBENGINE_RESOURCES_PATH", str(_res))
    if _loc.exists():
        os.environ.setdefault("QTWEBENGINE_LOCALES_PATH", str(_loc))
    if _proc.exists():
        os.environ.setdefault("QTWEBENGINEPROCESS_PATH", str(_proc))
print("SCENARIO:", scenario)
print("FLAGS:", os.environ.get("QTWEBENGINE_CHROMIUM_FLAGS", ""))
print("RHI:", os.environ.get("QSG_RHI_BACKEND", "<unset>"))
print("SANDBOX_VAR:", os.environ.get("QTWEBENGINE_DISABLE_SANDBOX", "<unset>"))
from PySide6.QtCore import Qt
from PySide6.QtWidgets import QApplication
from PySide6.QtWebEngineWidgets import QWebEngineView
QApplication.setAttribute(Qt.AA_UseSoftwareOpenGL, True)
QApplication.setAttribute(Qt.AA_ShareOpenGLContexts, True)
app = QApplication([])
view = QWebEngineView()
# Try actual inline content load and run a short event loop
ok_flag = {"ok": False}
def on_loaded(ok: bool):
    ok_flag["ok"] = bool(ok)
    # Quit quickly after load callback
    from PySide6.QtCore import QTimer
    QTimer.singleShot(20, app.quit)
view.loadFinished.connect(on_loaded)
view.setHtml('''<!doctype html><html><body><div>preflight</div></body></html>''')
# Safety timeout: exit after ~2.5s regardless
from PySide6.QtCore import QTimer
QTimer.singleShot(2500, app.quit)
app.exec()
if ok_flag["ok"]:
    print("WEBENGINE_PREFLIGHT_OK")
    sys.exit(0)
else:
    print("WEBENGINE_PREFLIGHT_FAIL")
    sys.exit(3)
""".strip()
            proc = subprocess.run(
                [sys.executable, "-c", code],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=8,
                text=True,
            )
            if proc.returncode != 0 or "WEBENGINE_PREFLIGHT_OK" not in (proc.stdout or ""):
                WEB_ENGINE_AVAILABLE = False
                # Include a brief reason snippet (first line of stderr)
                first_err = (proc.stderr or "").strip().splitlines()[:1]
                WEB_ENGINE_REASON = f"preflight failed (rc={proc.returncode})" + (f": {first_err[0]}" if first_err else "")
                QWebEngineView = None  # type: ignore
                return False
        except subprocess.TimeoutExpired:
            WEB_ENGINE_AVAILABLE = False
            WEB_ENGINE_REASON = "preflight timeout"
            QWebEngineView = None  # type: ignore
            return False
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:# If preflight infra fails, continue to try importing in-process
            pass
    try:
        from PySide6 import QtGui  # noqa: F401
        from PySide6.QtWebEngineWidgets import QWebEngineView as _QWebEngineView  # type: ignore
        QWebEngineView = _QWebEngineView  # type: ignore
        try:
            from PySide6.QtWebEngineCore import QtWebEngine  # type: ignore
            try:
                QtWebEngine.initialize()  # type: ignore[attr-defined]
            except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:# Non-fatal; some builds don't expose initialize()
                WEB_ENGINE_REASON = "QtWebEngine.initialize() not available"
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:# QtWebEngineCore might not be present; continue with Widgets only
            WEB_ENGINE_REASON = "QtWebEngineCore not importable"
        WEB_ENGINE_AVAILABLE = True
        WEB_ENGINE_REASON = "loaded"
    except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
        QWebEngineView = None  # type: ignore
        WEB_ENGINE_AVAILABLE = False
        WEB_ENGINE_REASON = f"import failed: {type(e).__name__}: {e}"
    return bool(WEB_ENGINE_AVAILABLE)

from instrctl.core import BaseInstrument, Capability, EventBus, feature, register_instrument


# --------------------- Web panel widget ---------------------
class WebBrowserPanel(QtWidgets.QWidget):
    recordStatusChanged = QtCore.Signal(bool)

    def __init__(self, instrument: BaseInstrument, parent: Optional[QtWidgets.QWidget] = None):
        super().__init__(parent)
        self._inst = instrument
        self._events: List[Dict[str, Any]] = []
        self._recording = False
        self._record_t0_ms: Optional[int] = None
        self._current_url: Optional[str] = None
        # Playback state
        self._playback_active = False  # type: bool
        self._playback_index = 0       # type: int
        self._playback_plan = []       # type: List[Dict[str, Any]]  # each has keys: 'delay', 'ev'
        # Encourage splitter/layout and dock to give us maximum space
        self.setMinimumHeight(300)
        self.setMinimumWidth(900)
        self.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)

        top = QtWidgets.QHBoxLayout()
        self._rec_btn = QtWidgets.QPushButton("Start Rec")
        self._stop_btn = QtWidgets.QPushButton("Stop Rec")
        self._play_btn = QtWidgets.QPushButton("Play")
        self._stop_btn.setEnabled(False)
        self._play_btn.setEnabled(False)
        # URL entry and manual navigation controls removed; connection is handled at launch
        top.addStretch(1)
        top.addSpacing(12)
        top.addWidget(self._rec_btn)
        top.addWidget(self._stop_btn)
        top.addWidget(self._play_btn)
        top.addStretch(1)
        self._status_small = QtWidgets.QLabel("")
        self._status_small.setStyleSheet("color:#9ab; font: 11px 'Consolas','Courier New',monospace;")
        top.addWidget(self._status_small)

        self._status = QtWidgets.QLabel("")
        self._status.setStyleSheet("color:#aab; font: 11px 'Consolas','Courier New',monospace;")

        layout = QtWidgets.QVBoxLayout(self)
        layout.addLayout(top)

        if _ensure_webengine_loaded():
            self._view = QWebEngineView(self)  # type: ignore[arg-type]
            self._view.setMinimumHeight(220)
            self._view.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
            layout.addWidget(self._view, 1)
            _page = self._view.page()
            _sig = getattr(_page, "consoleMessageReceived", None)
            if hasattr(_sig, "connect"):
                _sig.connect(self._on_console)
            else:
                _sig2 = getattr(_page, "javaScriptConsoleMessage", None)
                if hasattr(_sig2, "connect"):
                    _sig2.connect(self._on_console)
            self._view.loadFinished.connect(self._on_load_finished)
            self._view.loadStarted.connect(lambda: self._set_status("Loading..."))
            self._view.loadProgress.connect(lambda p: self._set_status(f"Loading {p}%"))
            self._view.urlChanged.connect(self._on_url_changed)
        else:
            self._view = None
            placeholder = QtWidgets.QTextBrowser()
            placeholder.setMinimumHeight(220)
            # Show reason and guidance for troubleshooting
            import html
            why = WEB_ENGINE_REASON or "unknown"
            placeholder.setHtml(
                "<h3>QtWebEngine not available</h3>"
                f"<p><b>Reason</b>: {html.escape(why)}</p>"
                "<p>Tips:\n<ul>"
                "<li>On Windows, QtWebEngine requires QtWebEngineProcess.exe and resources under PySide6/resources.</li>"
                "<li>We set software rendering by default; GPU drivers can still interfere.</li>"
                "</ul></p>"
                "<p>Recording and playback are disabled without QtWebEngine.</p>"
            )
            layout.addWidget(placeholder, 1)
            self._rec_btn.setEnabled(False)
            self._stop_btn.setEnabled(False)
            self._play_btn.setEnabled(False)
        layout.addWidget(self._status)
        # Initial status message to make state obvious
        if _ensure_webengine_loaded():
            self._set_status("QtWebEngine: available")
        else:
            self._set_status(f"QtWebEngine: not available ({WEB_ENGINE_REASON or 'unknown'}) — using external browser")

        # Wire controls
        self._rec_btn.clicked.connect(self.start_recording)
        self._stop_btn.clicked.connect(self.stop_recording)
        self._play_btn.clicked.connect(self.playback)

        # Initialize URL from instrument if available
        init_url = None
        try:
            if hasattr(instrument, "get_url"):
                init_url = instrument.get_url()  # type: ignore[attr-defined]
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            init_url = None
        if not init_url:
            init_url = "https://example.com/"
        self._current_url = init_url
        if _ensure_webengine_loaded() and self._view is not None:
            self._load_url(init_url)

    def _on_url_changed(self, qurl: QtCore.QUrl):  # type: ignore[name-defined]
        self._current_url = qurl.toString()
        if self._recording:
            now_ms = int(QtCore.QDateTime.currentMSecsSinceEpoch())
            self._events.append({
                't': 'navigate',
                'url': self._current_url or '',
                'ts': now_ms,
            })
            self._update_status()

    def sizeHint(self):  # type: ignore[override]
        try:
            return QtCore.QSize(900, 600)
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            return super().sizeHint()

    # ---- Console bridge ----
    @QtCore.Slot(object, str, int, str)
    def _on_console(self, level, message: str, line: int, source: str):
        # Expect messages prefixed with REC:
        if not isinstance(message, str):
            return
        if not message.startswith("REC:"):
            return
        import json
        obj = json.loads(message[4:])
        self._events.append(obj)
        self._update_status()
        self._play_btn.setEnabled(bool(self._events))

    # ---- Load hook ----
    def _on_load_finished(self, ok: bool):
        if not ok:
            self._status.setText("Load failed")
            return
        # Inject recorder JS on every page load
        self._inject_recorder_js()
        self._status.setText("Loaded")

    def _inject_recorder_js(self):
        if self._view is None:
            return
        js = R"""
// Simple recorder: emits console messages with prefix 'REC:'
(function(){
  if (window.__instr_recorder_installed__) return;
  window.__instr_recorder_installed__ = true;
  window.__instr_rec_on__ = false;
  function cssPath(el){
    if (!(el instanceof Element)) return '';
    var path = [];
    while (el && el.nodeType === Node.ELEMENT_NODE) {
      var selector = el.nodeName.toLowerCase();
      if (el.id) { selector += '#' + el.id; path.unshift(selector); break; }
      var sib = el, nth = 1;
      while ((sib = sib.previousElementSibling)) { if (sib.nodeName.toLowerCase() === selector) nth++; }
      selector += ':nth-of-type(' + nth + ')';
      path.unshift(selector);
      el = el.parentElement;
    }
    return path.join(' > ');
  }
  function recEvent(obj){ try { console.log('REC:' + JSON.stringify(obj)); } catch(e){} }
  function onClick(ev){ if(!window.__instr_rec_on__) return; var sel=cssPath(ev.target); recEvent({t:'click', sel:sel, ts:Date.now()}); }
  function onInput(ev){ if(!window.__instr_rec_on__) return; var el=ev.target; if(!el) return; var sel=cssPath(el); var v=el.value; recEvent({t:'input', sel:sel, val:v, ts:Date.now()}); }
  document.addEventListener('click', onClick, true);
  document.addEventListener('input', onInput, true);
  window.addEventListener('hashchange', function(){ if(!window.__instr_rec_on__) return; recEvent({t:'navigate', url:window.location.href, ts:Date.now()}); }, true);
})();
        """
        self._view.page().runJavaScript(js)

    # ---- Controls ----
    def _open_external(self, url: str):
        import webbrowser
        webbrowser.open(url)

    def _load_url(self, url: str):
        self._set_status("Loading...")
        try:
            self._view.setUrl(QtCore.QUrl(url))  # type: ignore[union-attr]
            self._current_url = url
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:# Fallback: open externally
            self._open_external(url)

    # ---- Recording ----
    def start_recording(self):
        if self._view is None:
            return
        self._events.clear()
        self._recording = True
        self._record_t0_ms = int(QtCore.QDateTime.currentMSecsSinceEpoch())
        self._play_btn.setEnabled(False)
        self._stop_btn.setEnabled(True)
        self._rec_btn.setEnabled(False)
        self.recordStatusChanged.emit(True)
        self._update_status()
        self._view.page().runJavaScript("window.__instr_rec_on__ = true;")

    def stop_recording(self):
        if self._view is None:
            return
        self._recording = False
        self._view.page().runJavaScript("window.__instr_rec_on__ = false;")
        self._stop_btn.setEnabled(False)
        self._rec_btn.setEnabled(True)
        self._play_btn.setEnabled(bool(self._events))
        self.recordStatusChanged.emit(False)
        self._update_status()

    def _update_status(self):
        self._set_status(f"events: {len(self._events)} | rec={'on' if self._recording else 'off'}")

    # ---- Playback ----
    def playback(self):
        if self._view is None:
            return
        if not self._events:
            return
        if self._playback_active:
            return
        # Build a sequential plan with inter-event delays
        try:
            evs = [e for e in self._events if isinstance(e, dict)]
            evs.sort(key=lambda e: e.get('ts', 0))
            if not evs:
                return
            base = evs[0].get('ts', 0) or 0
            prev = base
            plan: List[Dict[str, Any]] = []
            for e in evs:
                ts = int(e.get('ts', 0) or 0)
                delay = max(0, ts - prev)
                prev = ts
                plan.append({'delay': delay, 'ev': e})
            self._playback_plan = plan
            self._playback_index = 0
            self._playback_active = True
            self._play_btn.setEnabled(False)
            self._rec_btn.setEnabled(False)
            self._stop_btn.setEnabled(False)
            self._set_status(f"Playback: {len(plan)} events")
            self._playback_step()
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            self._playback_active = False
            self._play_btn.setEnabled(True)
            self._rec_btn.setEnabled(True)

    def _replay_one(self, ev: Dict[str, Any]):
        if self._view is None:
            return
        t = ev.get('t')
        if t == 'navigate':
            url = ev.get('url') or (self._current_url or "")
            if url:
                self._view.setUrl(QtCore.QUrl(url))
            return
        sel = ev.get('sel')
        if not sel:
            return
        if t == 'click':
            js = f"(function(){{ var el = document.querySelector({sel!r}); if(!el) return; el.click(); }})();"
            self._view.page().runJavaScript(js)
        elif t == 'input':
            val = ev.get('val', '')
            js = (
                f"(function(){{ var el = document.querySelector({sel!r}); if(!el) return; el.focus(); el.value = {str(val)!r};"
                f" var ev=new Event('input',{{bubbles:true}}); el.dispatchEvent(ev); }})();"
            )
            self._view.page().runJavaScript(js)

    def _playback_step(self):
        if not self._playback_active:
            return
        if self._playback_index >= len(self._playback_plan):
            # Done
            self._playback_active = False
            self._play_btn.setEnabled(True)
            self._rec_btn.setEnabled(True)
            self._stop_btn.setEnabled(False)
            self._set_status("Playback: done")
            return
        item = self._playback_plan[self._playback_index]
        delay = int(item.get('delay', 0) or 0)
        ev = item.get('ev', {})
        # fire after delay
        QtCore.QTimer.singleShot(delay, lambda e=ev: self._perform_and_continue(e))

    def _perform_and_continue(self, ev: Dict[str, Any]):
        if not self._playback_active:
            return
        if ev.get('t') == 'navigate':
            # Perform navigate, then wait for loadFinished before continuing
            def _after_load(ok: bool):
                self._view.loadFinished.disconnect(_after_load)  # type: ignore[arg-type]
                # Small grace period
                QtCore.QTimer.singleShot(50, self._advance_playback)
            try:
                self._view.loadFinished.connect(_after_load)
            except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:# If cannot connect, just continue after a small delay
                QtCore.QTimer.singleShot(200, self._advance_playback)
            self._replay_one(ev)
        else:
            self._replay_one(ev)
            # proceed immediately to next step
            QtCore.QTimer.singleShot(0, self._advance_playback)

    def _advance_playback(self):
        if not self._playback_active:
            return
        self._playback_index += 1
        self._playback_step()

    # ---- Status helper ----
    def _set_status(self, text: str) -> None:
        self._status.setText(text)
        self._status_small.setText(text)


# --------------------- Instrument types ---------------------
class WebGuiInstrument(BaseInstrument):
    __abstract__ = True

    def __init__(self, *, event_bus: Optional[EventBus] = None):
        super().__init__(event_bus=event_bus)
        self._url = "https://example.com/"

    @feature(capability=Capability.REQUIRED, ui={"widget": WebBrowserPanel, "label": "Web"})
    def set_url(self, url: str) -> None:
        self._url = str(url)

    def get_url(self) -> str:
        return str(self._url)


@register_instrument()
class WebGuiDemo(WebGuiInstrument):
    __abstract__ = False

    @classmethod
    def supported_connections(cls):
        return ["WEB", "DEMO"]

    @classmethod
    def connection_placeholders(cls):
        return {"WEB": "http(s)://host/path", "DEMO": "No address required"}
    def connect(self, **kwargs) -> None:
        addr = kwargs.get("address")
        if addr:
            self._url = str(addr)
        self._state.connected = True

    def disconnect(self) -> None:
        self._state.connected = False
