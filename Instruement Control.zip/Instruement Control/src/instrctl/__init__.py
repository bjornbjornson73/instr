# Suppress noisy deprecation warnings emitted by paramiko about TripleDES from cryptography
# These do not affect functionality and clutter logs/GUI. Keep this narrowly scoped.
import warnings as _warnings
try:  # cryptography <-> paramiko deprecation category
    from cryptography.utils import CryptographyDeprecationWarning as _CryptoDepWarn  # type: ignore
except ImportError:  # Fallback if cryptography changes location
    class _CryptoDepWarn(Warning):
        pass

# Ignore only deprecations originating from paramiko modules
_warnings.filterwarnings(
    "ignore",
    category=_CryptoDepWarn,
    module=r"paramiko\..*",
)
# And specifically silence the TripleDES moved message if category changes upstream
_warnings.filterwarnings(
    "ignore",
    message=r".*TripleDES has been moved to cryptography\.hazmat\.decrepit.*",
    module=r"paramiko\..*",
)

from .core import (
    BaseInstrument,
    Capability,
    feature,
    InstrumentFactory,
    InstrumentRegistry,
    EventBus,
    Event,
    ConnectionInfo,
    ConnectionType,
)

__all__ = [
    "BaseInstrument",
    "Capability",
    "feature",
    "InstrumentFactory",
    "InstrumentRegistry",
    "EventBus",
    "Event",
    "ConnectionInfo",
    "ConnectionType",
]
