"""
Dual-plane transport for remote instruments

Control Plane: RPyC for method calls and complex object handling
Data Plane: Arrow Flight for high-bandwidth streaming
"""

from __future__ import annotations


from rpyc.utils.classic import obtain
import rpyc
from typing import Any, Optional, Iterator
import threading
import logging
from dataclasses import dataclass

logger = logging.getLogger(__name__)


@dataclass
class RemoteConfig:
    """Configuration for dual-plane remote connection"""
    host: str
    port_control: int = 18812  # RPyC control plane
    port_data: int = 8815      # Arrow Flight data plane
    use_ssh: bool = False
    ssh_user: Optional[str] = None
    ssh_password: Optional[str] = None
    ssh_keyfile: Optional[str] = None


class DualTransport:
    """
    Manages both control and data plane connections
    
    Control Plane (RPyC):
    - Method invocation with complex return types
    - Remote object references (netrefs)
    - Natural Python semantics
    
    Data Plane (Arrow Flight):
    - High-bandwidth streaming
    - Efficient binary serialization
    - Optimized for numpy arrays
    """
    
    def __init__(self, config: RemoteConfig):
        self.config = config
        self._rpyc_conn: Optional[rpyc.Connection] = None
        self._root = None  # RPyC root service
        self._flight_client = None
        self._connected = False
        self._log = logging.getLogger(f"instrctl.transport.{config.host}")
    
    def connect(self) -> None:
        """Establish both control and data plane connections"""
        
        # Normalize host: 0.0.0.0 should be localhost for client connections
        connect_host = self.config.host
        if connect_host in ("0.0.0.0", ""):
            connect_host = "localhost"
        
        # 1. Connect RPyC control plane
        try:
            self._rpyc_conn = rpyc.connect(
                connect_host,
                self.config.port_control,
                config={
                    "allow_public_attrs": True,
                    "allow_pickle": True,
                    "sync_request_timeout": 30,
                }
            )
            # Get root service
            self._root = self._rpyc_conn.root
            self._log.info(f"RPyC control plane connected to {connect_host}:{self.config.port_control}")
        except Exception as e:
            raise ConnectionError(f"Failed to connect RPyC control plane: {e}")
        
        # 2. Connect Arrow Flight data plane
        try:
            from pyarrow import flight
            
            location = flight.Location.for_grpc_tcp(
                connect_host,
                self.config.port_data
            )
            self._flight_client = flight.FlightClient(location)
            
            # Verify connection with ping
            try:
                list(self._flight_client.do_action(flight.Action("ping", b"")))
            except Exception as e:
                self._log.warning(f"Flight connection check failed: {e}")
            
            self._log.info(f"Flight data plane connected to {connect_host}:{self.config.port_data}")
        except Exception as e:
            self._log.warning(f"Flight data plane unavailable: {e}")
            self._flight_client = None
        
        self._connected = True
    
    def disconnect(self) -> None:
        """Close both connections"""
        if self._rpyc_conn:
            self._rpyc_conn.close()
            self._rpyc_conn = None
        
        self._flight_client = None
        self._connected = False
    
    # ---- Control Plane Methods ----
    
    def invoke(self, method: str, *args, **kwargs) -> Any:
        """
        Invoke method via RPyC (control plane) - simplified interface
        
        For tests, calls exposed_<method> on the root service.
        For real use, pass obj and method name: invoke_on(obj, method, ...)
        """
        if not self._rpyc_conn or not self._root:
            raise RuntimeError("Not connected")
        
        # Try to call exposed_<method> on root service
        exposed_name = f"exposed_{method}"
        if hasattr(self._root, exposed_name):
            remote_method = getattr(self._root, exposed_name)
            return remote_method(*args, **kwargs)
        else:
            raise AttributeError(f"Method {method} not found on remote service")
    
    def invoke_on(self, obj: Any, method: str, *args, **kwargs) -> Any:
        """
        Invoke method on specific object via RPyC (control plane)
        
        Returns complex objects naturally via netrefs
        
        Example:
            thread = transport.invoke_on(instrument, "start_logging", "data.csv")
            # thread is a netref - can call thread.join(), thread.is_alive(), etc.
        """
        if not self._rpyc_conn:
            raise RuntimeError("Not connected")
        
        # Get remote method
        remote_method = getattr(obj, method)
        
        # Call it - RPyC handles everything
        result = remote_method(*args, **kwargs)
        
        return result
    
    def get_remote_module(self, module_name: str):
        """Import and return remote module (for accessing classes, etc.)"""
        if not self._rpyc_conn:
            raise RuntimeError("Not connected")
        
        return self._rpyc_conn.modules[module_name]
    
    def obtain_local(self, netref: Any) -> Any:
        """
        Force a netref to transfer to local value
        
        Use sparingly - defeats purpose of netrefs, but sometimes needed
        """
        return obtain(netref)
    
    @property
    def rpyc_connection(self):
        """Access to underlying RPyC connection"""
        return self._rpyc_conn
    
    @property
    def flight_client(self):
        """Access to underlying Arrow Flight client for data streaming"""
        return self._flight_client
    
    # ---- Data Plane Methods ----
    
    def stream_data(self, stream_name: str, data: Any) -> None:
        """
        Send high-bandwidth data via Arrow Flight (do_put)
        
        Args:
            stream_name: Stream identifier
            data: NumPy array or similar data to send
        """
        if not self._flight_client:
            raise RuntimeError("Flight data plane not available")
        
        import json
        import pyarrow as pa
        from pyarrow import flight
        
        # Convert data to Arrow format
        if hasattr(data, 'shape') and len(data.shape) == 2:
            # 2D array - assume (N, 2) for (x, y) pairs
            schema = pa.schema([('x', pa.float64()), ('y', pa.float64())])
            batch = pa.record_batch([
                pa.array(data[:, 0], type=pa.float64()),
                pa.array(data[:, 1], type=pa.float64())
            ], schema=schema)
        elif hasattr(data, '__len__'):
            # 1D array
            schema = pa.schema([('y', pa.float64())])
            batch = pa.record_batch([pa.array(data, type=pa.float64())], schema=schema)
        else:
            raise ValueError(f"Unsupported data type: {type(data)}")
        
        # Create descriptor
        descriptor = flight.FlightDescriptor.for_path(stream_name)
        
        # Upload data
        try:
            writer, metadata_reader = self._flight_client.do_put(descriptor, schema)
            writer.write_batch(batch)
            writer.close()
            # No acknowledgment needed
                
        except Exception as e:
            self._log.error(f"Flight upload error: {e}")
            raise
    
    def get_stream(self, instrument_id: str, getter_name: str) -> Iterator[Any]:
        """
        Receive high-bandwidth data stream via Arrow Flight (do_get)
        
        Args:
            instrument_id: "kind:model"
            getter_name: Method name like "get_sweep_points"
            
        Yields:
            Data items (numpy arrays, tuples, etc.)
        """
        if not self._flight_client:
            raise RuntimeError("Flight data plane not available")
        
        import json
        from pyarrow import flight
        
        ticket = flight.Ticket(json.dumps({
            "instrument_id": instrument_id,
            "getter": getter_name
        }).encode())
        
        try:
            reader = self._flight_client.do_get(ticket)
            
            for chunk in reader:
                if chunk.data is None:
                    continue
                
                # Convert RecordBatch to Python objects
                rb = chunk.data
                
                if rb.num_columns >= 2:
                    # (x, y) pairs
                    xs = rb.column(0).to_pylist()
                    ys = rb.column(1).to_pylist()
                    yield list(zip(xs, ys))
                elif rb.num_columns == 1:
                    # Single column
                    yield rb.column(0).to_pylist()
                
        except Exception as e:
            self._log.error(f"Flight streaming error: {e}")
            raise
    
    @property
    def is_connected(self) -> bool:
        """Check if transport is connected"""
        return self._connected and self._rpyc_conn is not None
