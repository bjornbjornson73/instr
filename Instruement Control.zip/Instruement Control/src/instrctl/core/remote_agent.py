from __future__ import annotations

import json
import logging
import time
import traceback
from typing import Any, Dict, Optional

import pyarrow as pa  # type: ignore
from pyarrow import flight  # type: ignore

from .registry import InstrumentRegistry, InstrumentFactory
from .plugins import discover_all


log = logging.getLogger("instrctl.core.remote.agent")


class AgentServer(flight.FlightServerBase):
    def __init__(self, location: flight.Location, **kwargs: Any):
        super().__init__(location, **kwargs)
        self._instances: Dict[tuple[str, str, str], Any] = {}  # (kind, model, instance_id) -> instance
        log.info("AgentServer initialized at %s", getattr(location, "uri", location))

    # ---- Utilities ----
    def _get_or_create(self, kind: str, model: str, instance_id: str = "default"):
        key = (kind, model, instance_id)
        inst = self._instances.get(key)
        if inst is None:
            impl = InstrumentRegistry.get(kind, model)
            if impl is None:
                log.error("No instrument registered for %s:%s", kind, model)
                raise KeyError(f"No instrument registered for {kind}:{model}")
            log.info("Creating instrument instance: %s:%s (instance_id=%s)", kind, model, instance_id)
            inst = InstrumentFactory.create(kind, model)
            self._instances[key] = inst
        else:
            log.debug("Reusing cached instrument instance: %s:%s (instance_id=%s)", kind, model, instance_id)
        return inst

    # ---- Actions ----
    def list_actions(self, context):  # type: ignore[override]
        try:
            peer = getattr(context, "peer_identity", lambda: None)()  # type: ignore[attr-defined]
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            peer = None
        log.debug("list_actions requested by %s", peer)
        return [
            flight.ActionType("ping", "Ping the server"),
            flight.ActionType("invoke", "Invoke a method on an instrument"),
            flight.ActionType("info", "Return agent version and registry info"),
        ]

    def do_action(self, context, action):  # type: ignore[override]
        t = action.type
        if t == "ping":
            log.debug("ping action received")
            yield flight.Result(b"pong")
            return
        if t == "info":
            try:
                import importlib.metadata as im
                try:
                    version = im.version("instrctl")
                except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                    version = None
                kinds = {}
                try:
                    kinds = {k: list(v.keys()) for k, v in InstrumentRegistry.list_kinds().items()}
                except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                    kinds = {}
                log.info("info action served: version=%s kinds=%d", version, len(kinds))
                out = json.dumps({"version": version, "kinds": kinds}).encode("utf-8")
                yield flight.Result(out)
                return
            except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                log.exception("info action failed: %s", e)
                err = json.dumps({"error": str(e)}).encode("utf-8")
                yield flight.Result(err)
                return
        if t == "invoke":
            try:
                payload = json.loads(bytes(action.body).decode("utf-8"))
                kind = payload.get("kind")
                model = payload.get("model")
                method = payload.get("method")
                args = payload.get("args", [])
                kwargs = payload.get("kwargs", {})
                # Log call with trimmed args for readability
                def _trim(v):
                    s = repr(v)
                    return (s[:120] + "…") if len(s) > 120 else s
                log.debug("invoke: %s:%s.%s args=%s kwargs=%s", kind, model, method, _trim(args), _trim(kwargs))
                t0 = time.time()
                inst = self._get_or_create(kind, model)
                fn = getattr(inst, method, None)
                if not callable(fn):
                    log.error("invoke failed: method not found %s on %s:%s", method, kind, model)
                    raise AttributeError(f"Method not found: {method}")
                res = fn(*args, **kwargs)
                dt = (time.time() - t0) * 1000.0
                try:
                    rdesc = type(res).__name__
                except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                    rdesc = str(type(res))
                log.debug("invoke: %s:%s.%s completed in %.1f ms (result=%s)", kind, model, method, dt, rdesc)
                out = json.dumps(res).encode("utf-8")
                yield flight.Result(out)
                return
            except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                log.exception("invoke error: %s", e)
                err = json.dumps({"error": str(e)}).encode("utf-8")
                yield flight.Result(err)
                return
        # Unknown action
        log.warning("Unknown action: %s", t)
        yield flight.Result(b"")

    # ---- Streaming ----
    def do_get(self, context, ticket: flight.Ticket):  # type: ignore[override]
        # Ticket: {kind, model, instance_id, getter}
        try:
            spec = json.loads(bytes(ticket.ticket).decode("utf-8"))
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            spec = {}
        kind = spec.get("kind")
        model = spec.get("model")
        instance_id = spec.get("instance_id", "default")
        getter_name = spec.get("getter")
        log.debug("do_get subscribe: %s:%s.%s (instance=%s)", kind, model, getter_name, instance_id)
        inst = self._get_or_create(kind, model, instance_id)
        getter = getattr(inst, getter_name, None)
        if not callable(getter):
            raise KeyError(f"Getter not found: {getter_name}")
        # If the feature declares a start/stop in UI metadata, honor it
        feat_meta = None
        try:
            for m in inst.features().values():
                if m.get("attr") == getter_name:
                    feat_meta = m
                    break
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            feat_meta = None
        # Agent doesn't auto start/stop producers; client code decides when to call start/stop.

        # Quick probe to infer shape without long blocking
        first_pts = []
        try:
            pts = getter()
            if pts:
                first_pts = list(pts)
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            first_pts = []

        # Determine schema: [y] or [x,y]
        if first_pts and hasattr(first_pts[0], "__len__") and not isinstance(first_pts[0], (int, float)):
            schema = pa.schema([("x", pa.float64()), ("y", pa.float64())])
            def to_batch(data):
                xs = [float(p[0]) for p in data]
                ys = [float(p[1]) for p in data]
                return pa.record_batch([pa.array(xs), pa.array(ys)], schema=schema)
            empty_batch = pa.record_batch([pa.array([], type=pa.float64()), pa.array([], type=pa.float64())], schema=schema)
            log.debug("do_get schema inferred: (x,y) pairs")
        else:
            schema = pa.schema([("y", pa.float64())])
            def to_batch(data):
                ys = [float(p) for p in data]
                return pa.record_batch([pa.array(ys)], schema=schema)
            empty_batch = pa.record_batch([pa.array([], type=pa.float64())], schema=schema)
            log.debug("do_get schema inferred: y-only")

        def gen():
            # Yield an initial empty batch to establish schema promptly
            log.debug("do_get yield: initial empty batch")
            yield empty_batch
            # Yield the first non-empty batch if available from the quick probe
            if first_pts:
                log.debug("do_get initial probe batch: %d point(s)", len(first_pts))
                yield to_batch(first_pts)
            # Then poll continuously while client is connected
            try:
                last_log = 0.0
                cancelled = False
                while True:
                    # Check cancellation BEFORE polling to respond faster to client disconnect
                    if context.is_cancelled():  # type: ignore[attr-defined]
                        if not cancelled:
                            log.info("do_get cancelled by client: %s:%s.%s", kind, model, getter_name)
                            cancelled = True
                        break
                    
                    # ONLY call getter if client is still connected
                    # This prevents unnecessary work and logging when client has stopped
                    try:
                        pts = getter()
                    except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                        pts = []
                    
                    # Check cancellation again BEFORE processing/yielding data
                    if context.is_cancelled():  # type: ignore[attr-defined]
                        if not cancelled:
                            log.info("do_get cancelled by client (before yield): %s:%s.%s", kind, model, getter_name)
                            cancelled = True
                        break
                    
                    if pts:
                        try:
                            yield to_batch(pts)
                        except (GeneratorExit, StopIteration):
                            # Client closed the stream - stop immediately
                            log.info("do_get stream closed by client: %s:%s.%s", kind, model, getter_name)
                            break
                        except Exception as e:
                            # Any other exception during yield likely means disconnection
                            log.info("do_get stream error (client disconnected?): %s:%s.%s - %s", kind, model, getter_name, e)
                            break
                        now = time.time()
                        # Log at most every ~2s during streaming to avoid flooding
                        if now - last_log >= 2.0:
                            log.debug("do_get streamed batch: %d point(s)", len(pts))
                            last_log = now
                    
                    # Sleep with frequent cancellation checks for immediate stop response
                    # Instead of sleeping for 50ms straight, sleep in 10ms chunks and check cancellation
                    for _ in range(5):  # 5 * 10ms = 50ms total
                        if context.is_cancelled():  # type: ignore[attr-defined]
                            if not cancelled:
                                log.info("do_get cancelled during sleep: %s:%s.%s", kind, model, getter_name)
                                cancelled = True
                            break
                        time.sleep(0.01)  # 10ms chunks for responsive cancellation
                    
                    # If cancelled during sleep, exit immediately
                    if cancelled:
                        break
            except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                log.debug("do_get generator stopped:")
                log.debug("\n" + traceback.format_exc())

        return flight.GeneratorStream(schema, gen())


def main(argv: Optional[list[str]] = None) -> int:
    import argparse
    parser = argparse.ArgumentParser(description="instrctl remote agent (Arrow Flight)")
    parser.add_argument("--host", default="0.0.0.0", help="Bind host (default 0.0.0.0)")
    parser.add_argument("--port", type=int, default=8815, help="Port (default 8815)")
    parser.add_argument("--log-level", default="INFO", help="Logging level (DEBUG, INFO, WARNING, ERROR)")
    parser.add_argument("--log-file", default=None, help="Optional path to log file (adds a file handler)")
    args = parser.parse_args(argv)

    # Logging configuration
    lvl = getattr(logging, str(args.log_level).upper(), logging.INFO)
    logging.basicConfig(level=lvl, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
    if args.log_file:
        try:
            fh = logging.FileHandler(args.log_file, encoding="utf-8")
            fh.setLevel(lvl)
            fh.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(name)s: %(message)s"))
            logging.getLogger().addHandler(fh)
            log.info("File logging enabled: %s", args.log_file)
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            log.warning("Failed to enable file logging (%s): %s", args.log_file, e)
    logging.getLogger("instrctl.core.instrument").setLevel(logging.WARNING)

    # Load plugins
    try:
        discover_all()
        kinds = InstrumentRegistry.list_kinds()
        total_models = sum(len(models) for models in kinds.values())
        log.info("Discovered plugins: %d kinds, %d models", len(kinds), total_models)
        for k, models in sorted(kinds.items()):
            log.debug("  %s: %s", k, ", ".join(sorted(models.keys())))
    except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
        log.warning("Plugin discovery failed: %s", e)

    loc = flight.Location.for_grpc_tcp(args.host, int(args.port))
    server = AgentServer(loc)
    server_thread = server.serve()
    log.info("Agent listening on %s:%s (level=%s)", args.host, args.port, logging.getLevelName(lvl))
    try:
        server_thread.join()
    except KeyboardInterrupt:
        log.info("Shutting down agent")
        server.shutdown()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
