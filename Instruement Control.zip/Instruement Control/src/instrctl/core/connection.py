from __future__ import annotations

from dataclasses import dataclass
from enum import Enum, auto
from typing import Optional


class ConnectionType(Enum):
    SERIAL = auto()
    USB = auto()
    TCPIP = auto()
    WEB = auto()
    REMOTE = auto()


@dataclass
class ConnectionInfo:
    type: ConnectionType
    address: Optional[str] = None  # e.g., COM3, 192.168.0.2:5025, usb id, url
    timeout_s: float = 5.0
