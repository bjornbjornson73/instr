from __future__ import annotations

from collections import defaultdict, deque
from dataclasses import dataclass
from typing import Any, Callable, Deque, Dict, Optional, Type
import logging
import json
import threading
import time

from .base import BaseInstrument
from .registry import InstrumentFactory, InstrumentRegistry
from .bootstrap import SSHBootstrapper, BootstrapConfig
from .dual_transport import DualTransport, RemoteConfig as DualRemoteConfig


@dataclass
class RemoteConfig:
    host: str
    port: int = 18861  # Changed from 8815 to RPyC control port
    port_data: int = 8815  # Added data plane port for Arrow Flight
    use_ssh: bool = False
    ssh_user: Optional[str] = None
    ssh_password: Optional[str] = None
    ssh_keyfile: Optional[str] = None
    token: Optional[str] = None  # bearer token when using TLS
    use_dual_transport: bool = True  # Enable dual-plane by default


class RemoteInstrumentProxy(BaseInstrument):
    """Transparent proxy that mirrors a concrete instrument API over a remote agent.

    Notes:
    - This class exposes the same feature and method surface as the underlying
      implementation so existing GUI/widgets operate unchanged.
    - Control methods are forwarded to the agent; getters drain a local buffer
      populated by a background stream task (to be wired in a later step).
    - For now, this file holds the class shell so GUI can instantiate it when
      ConnectionType.REMOTE is selected; the transport is added subsequently.
    """

    __abstract__ = False

    # Reference to the concrete implementation class for introspection/UI
    _impl_cls: Type[BaseInstrument] | None = None

    def __init__(self, *, kind: str, model: str, config: RemoteConfig, event_bus=None):
        super().__init__(event_bus=event_bus)
        self.kind = kind
        self.model = model
        self._cfg = config
        self._log = logging.getLogger(f"instrctl.core.remote.{kind}.{model}")
        self._connected = False
        # Generate unique instance ID for multi-instrument support
        import uuid
        self._inst_id = str(uuid.uuid4())[:8]  # Short ID for logging
        self._log.info("Created proxy instance with ID: %s", self._inst_id)
        # feature attr -> deque buffer; filled by background consumer once transport added
        self._buffers: Dict[str, Deque] = defaultdict(deque)
        # attr -> stream kind: 'sweep' or 'event'. Used to control drain behavior
        self._stream_kinds: Dict[str, str] = {}
        # Optional per-getter sweep buffer caps: None = unlimited; 1 = latest-only; >1 = max batches
        self._sweep_caps: Dict[str, Optional[int]] = {}
        # Track first call per getter for initial wait
        self._first_call: Dict[str, bool] = {}
        # Track last getter access time to detect idle consumers
        self._last_access: Dict[str, float] = {}
        # Background consumers per feature attr
        self._consumers: Dict[str, threading.Thread] = {}
        self._stop_flags: Dict[str, threading.Event] = {}
        # Stream readers per feature attr (to allow stopping via close)
        self._stream_readers: Dict[str, Any] = {}
        # Dual transport: RPyC + Flight
        self._transport: Optional[DualTransport] = None
        # Legacy Flight clients for fallback (if use_dual_transport=False)
        self._ctl_client = None  # type: ignore[assignment]
        self._stream_client = None  # type: ignore[assignment]

    # ---- Low-level helpers ----
    def _encode_flight_invoke(self, method: str, args: tuple[Any, ...], kwargs: Dict[str, Any]) -> bytes:
        payload = {
            "kind": self.kind,
            "model": self.model,
            "method": method,
            "args": list(args),
            "kwargs": kwargs,
        }
        return json.dumps(payload).encode("utf-8")

    def _decode_flight_response(self, results) -> Any:
        out_local: Any = None
        for r in results:
            try:
                body = getattr(r, "body", None)
                if body is None:
                    continue
                raw = bytes(body)
                if not raw:
                    continue
                out_local = json.loads(raw.decode("utf-8"))
            except (AttributeError, RuntimeError, OSError, ValueError, TypeError):
                continue
        if isinstance(out_local, dict) and "error" in out_local:
            raise RuntimeError(out_local.get("error"))
        return out_local

    def _invoke_remote(self, method: str, *args, timeout_s: float = 3.0, **kwargs):
        # Use DualTransport if available, otherwise fallback to Flight-only
        if self._transport is not None:
            try:
                # Get instrument instance from remote side (with instance ID for multi-instrument)
                inst_key = f"{self.kind}:{self.model}:{self._inst_id}"
                # Ensure instrument exists
                self._transport.invoke("get_or_create_instrument", self.kind, self.model, self._inst_id)
                # Get the actual instance object (returns RPyC netref)
                inst_obj = self._transport.invoke("get_instance", inst_key)
                # Invoke method directly on the object
                result = getattr(inst_obj, method)(*args, **kwargs)
                return result
            except Exception as e:
                self._log.error("DualTransport invoke '%s' failed: %s", method, e)
                raise
        
        # Fallback to Flight-only (legacy)
        if self._ctl_client is None:
            raise NotImplementedError("Remote transport not available (no Flight client or DualTransport)")
        try:
            from pyarrow import flight  # type: ignore
            data = self._encode_flight_invoke(method, args, kwargs)
            out_box: Dict[str, Any] = {}
            err_box: Dict[str, Exception] = {}

            def worker():
                try:
                    results = self._ctl_client.do_action(flight.Action("invoke", data))
                    out_box["out"] = self._decode_flight_response(results)
                except Exception as exc:
                    err_box["err"] = exc

            th = threading.Thread(target=worker, daemon=True)
            th.start()
            th.join(timeout=timeout_s)
            if th.is_alive():
                self._log.warning("Remote invoke timeout for %s after %.1fs", method, float(timeout_s))
                raise TimeoutError(f"remote invoke timeout: {method}")
            if err_box:
                raise err_box["err"]
            return out_box.get("out")
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            self._log.error("Remote invoke '%s' failed: %s", method, e)
            raise

    @classmethod
    def features(cls) -> Dict[str, Dict[str, Any]]:  # type: ignore[override]
        # Delegate features to the real implementation for accurate UI metadata
        if cls._impl_cls is not None:
            return cls._impl_cls.features()  # type: ignore[return-value]
        return super().features()

    def connect(self, **kwargs) -> None:  # type: ignore[override]
        """Connect to remote agent and forward base connect() to the instrument on the agent.

        Accepts the same kwargs as a local instrument's connect(), plus an optional
        'remote' dict with host/port/ssh/token. When provided, updates this proxy's
        RemoteConfig accordingly. Then establishes DualTransport (RPyC + Flight) or
        legacy Flight-only connection.
        """
        remote = kwargs.get("remote")
        if isinstance(remote, dict):
            self._cfg.host = remote.get("host", self._cfg.host)
            self._cfg.port = int(remote.get("port", self._cfg.port))
            if "port_data" in remote:
                self._cfg.port_data = int(remote["port_data"])
            if "use_dual_transport" in remote:
                self._cfg.use_dual_transport = bool(remote["use_dual_transport"])

        # Try DualTransport first if enabled
        if self._cfg.use_dual_transport:
            try:
                dual_cfg = DualRemoteConfig(
                    host=self._cfg.host,
                    port_control=self._cfg.port,
                    port_data=self._cfg.port_data
                )
                self._transport = DualTransport(dual_cfg)
                self._transport.connect()
                self._log.info("Connected via DualTransport (RPyC + Flight) to %s:%d/%d", 
                              self._cfg.host, self._cfg.port, self._cfg.port_data)
                
                # Set stream client from DualTransport for streaming data
                self._stream_client = self._transport.flight_client
                self._log.info("Stream client initialized from DualTransport")
                
                self._connected = True
                self._state.connected = True
                
                # Forward base connect kwargs to remote instrument
                base_kwargs: Dict[str, Any] = {}
                for k, v in kwargs.items():
                    if k == "remote":
                        continue
                    if k == "type":
                        name = getattr(v, "name", None)
                        v = name if name is not None else str(v)
                    base_kwargs[k] = v
                
                # Invoke connect on remote instrument
                if base_kwargs:
                    try:
                        self._invoke_remote("connect", **base_kwargs)
                    except Exception as e:
                        self._log.warning("Remote instrument connect failed: %s", e)
                return
            except Exception as e:
                self._log.warning("DualTransport connection failed: %s, falling back to Flight-only", e)
                self._transport = None

        # Fallback to Flight-only (legacy)
        try:
            from pyarrow import flight  # type: ignore
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            self._log.warning("pyarrow.flight not available; REMOTE in degraded mode: %s", e)
            self._connected = True  # Allow UI to proceed; getters will be empty until agent exists
            self._state.connected = True
            return
        
        # Normalize host: 0.0.0.0 should be localhost for client connections
        connect_host = self._cfg.host
        if connect_host in ("0.0.0.0", ""):
            connect_host = "localhost"
        
        def _try_connect() -> tuple[Optional["flight.FlightClient"], Optional[str]]:
            try:
                location = flight.Location.for_grpc_tcp(connect_host, int(self._cfg.port_data))
                client = flight.FlightClient(location)
                # Prefer info action for readiness check
                e_info = None
                e_ping = None
                try:
                    for _ in client.do_action(flight.Action("info", b"")):
                        pass
                except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                    e_info = e
                    try:
                        for _ in client.do_action(flight.Action("ping", b"")):
                            pass
                    except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                        e_ping = e
                        return None, f"Flight ping failed: {e_ping} (after info error: {e_info})"
                return client, None
            except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                self._log.debug("Initial Flight connect failed: %s", e)
                return None, str(e)

        # Optional progress callback (callable(str)) supplied by GUI to surface phases
        progress_cb = kwargs.pop("progress", None)
        def _progress(msg: str) -> None:
            if callable(progress_cb):
                progress_cb(str(msg))
        client, initial_err = _try_connect()
        if client is None:
            # Attempt SSH bootstrap if creds provided
            remote_cfg = kwargs.get("remote") or {}
            # Accept either nested 'ssh' dict or top-level fields used by the GUI
            ssh_spec = None
            if isinstance(remote_cfg, dict):
                ssh_spec = remote_cfg.get("ssh")
                if not ssh_spec:
                    wants_ssh = bool(remote_cfg.get("use_ssh"))
                    # Consider creds presence as an intent to use SSH bootstrap as well
                    has_creds = any(bool(remote_cfg.get(k)) for k in ("ssh_user", "ssh_password", "ssh_keyfile", "user", "password", "keyfile"))
                    if wants_ssh or has_creds:
                        ssh_spec = {
                            "host": remote_cfg.get("host", self._cfg.host),
                            "user": remote_cfg.get("ssh_user") or remote_cfg.get("user"),
                            "password": remote_cfg.get("ssh_password") or remote_cfg.get("password"),
                            "keyfile": remote_cfg.get("ssh_keyfile") or remote_cfg.get("keyfile"),
                        }
            if ssh_spec:
                # ssh_spec: dict with a factory or basic (host,user,pass/key)
                def _ssh_factory():
                    # Prefer provided factory
                    fac = ssh_spec.get("factory")
                    if callable(fac):
                        return fac()
                    # Build a paramiko client lazily if available
                    import paramiko  # type: ignore
                    cli = paramiko.SSHClient()
                    cli.set_missing_host_key_policy(paramiko.AutoAddPolicy())
                    host = ssh_spec.get("host", self._cfg.host)
                    user = ssh_spec.get("user")
                    passwd = ssh_spec.get("password")
                    keyfile = ssh_spec.get("keyfile")
                    cli.connect(hostname=host, username=user, password=passwd, key_filename=keyfile, timeout=10.0)
                    return cli

                bcfg = BootstrapConfig(host=self._cfg.host, port=self._cfg.port, ssh_host=self._cfg.host, ssh_user=None)
                bs = SSHBootstrapper(bcfg)
                last_detail = None
                try:
                    res = bs.bootstrap(_ssh_factory, progress=_progress)
                    if not res.get("ok"):
                        last_detail = res.get("error") or "unknown bootstrap error"
                    else:
                        # Bootstrap succeeded; try connecting again
                        _progress("Connecting to agent…")
                        client, _ = _try_connect()
                except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:# Surface auth and connection errors clearly
                    last_detail = str(e)
                if client is None:
                    # Provide a richer error including bootstrap detail and initial failure
                    raise ConnectionError(
                        f"Failed to connect to Flight server {self._cfg.host}:{self._cfg.port}. "
                        f"Tried SSH bootstrap and it failed: {last_detail or 'no details'}. "
                        f"Initial connect error: {initial_err or 'n/a'}."
                    )
            else:
                # No SSH config and initial Flight connect failed; include detail
                raise ConnectionError(
                    f"Failed to connect to Flight server {self._cfg.host}:{self._cfg.port}. "
                    f"No SSH bootstrap configured. Error: {initial_err or 'n/a'}."
                )
        if client is None:
            raise ConnectionError(f"Failed to connect to Flight server {self._cfg.host}:{self._cfg.port}.")
        # Establish separate control and streaming clients (use two connections to avoid interference)
        self._ctl_client = client
        # Best-effort second connection for streaming; if it fails, fall back to control client
        try:
            stream_client, err2 = _try_connect()
            self._stream_client = stream_client if stream_client is not None else self._ctl_client
            if stream_client is None and err2:
                self._log.debug("Using control client for streaming (second connect failed): %s", err2)
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            self._stream_client = self._ctl_client
            self._log.debug("Using control client for streaming due to exception: %s", e)

        # Forward base connect kwargs (minus 'remote') to the agent's instrument
        base_kwargs: Dict[str, Any] = {}
        try:
            for k, v in kwargs.items():
                if k == "remote":
                    continue
                if k == "type":
                    # Convert ConnectionType Enum-like to a plain string
                    name = getattr(v, "name", None)
                    v = name if name is not None else str(v)
                base_kwargs[k] = v
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            base_kwargs = {}

        if self._ctl_client is not None:
            try:
                from pyarrow import flight  # type: ignore
                data = self._encode_flight_invoke("connect", tuple(), base_kwargs)
                results = self._ctl_client.do_action(flight.Action("invoke", data))
                # Drain results and surface server-side errors
                self._decode_flight_response(results)
            except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                self._log.error("Remote connect failed for %s:%s: %s", self.kind, self.model, e)
                raise

        self._connected = True
        self._state.connected = True

    def disconnect(self) -> None:  # type: ignore[override]
        for ev in list(self._stop_flags.values()):
            ev.set()
        self._stop_flags.clear()
        for t in list(self._consumers.values()):
            if t.is_alive():
                t.join(timeout=0.2)
        self._consumers.clear()
        if self._transport is not None:
            self._transport.disconnect()
            self._transport = None
        self._ctl_client = None
        self._stream_client = None
        self._connected = False
        self._state.connected = False
    
    def _stop_stream_consumer(self, attr: str) -> None:
        """Stop a specific stream consumer thread"""
        self._log.info("[STREAM] Stopping consumer for %s", attr)
        try:
            # Set stop flag
            if attr in self._stop_flags:
                self._stop_flags[attr].set()
                self._log.info("[STREAM] %s: Stop event set", attr)
            
            # Close the reader to interrupt blocking read_chunk() call
            if attr in self._stream_readers:
                reader = self._stream_readers[attr]
                try:
                    self._log.info("[STREAM] %s: Cancelling reader to interrupt blocking read", attr)
                    cancel = getattr(reader, "cancel", None)
                    if callable(cancel):
                        cancel()
                except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                    self._log.debug("[STREAM] %s: Reader cancel error (expected): %s", attr, e)
                try:
                    self._log.info("[STREAM] %s: Closing reader", attr)
                    reader.close()
                except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                    self._log.debug("[STREAM] %s: Reader close error (expected): %s", attr, e)
                del self._stream_readers[attr]
            
            # Wait for thread to finish
            if attr in self._consumers:
                t = self._consumers[attr]
                if t and t.is_alive():
                    self._log.info("[STREAM] %s: Waiting for consumer thread to finish", attr)
                    t.join(timeout=1.0)  # Increased timeout since we're closing reader
                    if t.is_alive():
                        self._log.warning("[STREAM] %s: Consumer thread still alive after stop", attr)
                del self._consumers[attr]
            
            if attr in self._stop_flags:
                del self._stop_flags[attr]
            
            # Clear buffer
            if attr in self._buffers:
                self._buffers[attr].clear()
                self._log.info("[STREAM] %s: Buffer cleared", attr)
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            self._log.warning("Failed to stop consumer for %s: %s", attr, e)

    def is_connected(self) -> bool:  # type: ignore[override]
        return bool(self._connected)

    # ---- MultiInstrument support methods ----
    def list_children(self) -> Dict[str, Any]:
        """Forward list_children to remote MultiInstrument (if applicable)"""
        try:
            result = self._invoke_remote("list_children", timeout_s=3.0)
            # Result should be a dict of {alias: child_inst}
            # We'll receive RPyC netrefs for remote children
            return result if isinstance(result, dict) else {}
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            self._log.debug("list_children not available or failed: %s", e)
            return {}
    
    def child(self, alias: str, *, ttl: float = 1.0, preempt: bool = False) -> Any:
        """Forward child() to remote MultiInstrument and return proxy wrapper"""
        try:
            # Get the child proxy from remote side
            result = self._invoke_remote("child", alias, ttl=ttl, preempt=preempt, timeout_s=3.0)
            # The result is an RPyC netref to the remote ChildProxy
            # We can use it directly as it supports attribute forwarding
            return result
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            self._log.warning("child(%r) failed: %s", alias, e)
            raise

    # Transparent attribute forwarding
    def __getattr__(self, name: str):
        # For getters, return a callable that drains buffered data (fed by remote stream)
        # Resolve real implementation metadata to detect getter names reliably
        feats: Dict[str, Dict[str, Any]] = {}
        try:
            impl = InstrumentRegistry.get(self.kind, self.model)
            if impl is not None and hasattr(impl, "features"):
                feats = dict(impl.features())  # type: ignore[assignment]
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:# Fallback to any class-level features if available
            try:
                feats = dict(type(self).features())
            except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                feats = {}
        for meta in feats.values():
            if meta.get("attr") == name and isinstance(name, str) and name.startswith("get_"):
                def _getter():
                    # Record getter access for idle detection
                    import time
                    self._last_access[name] = time.time()
                    
                    # Ensure background stream consumer is started once
                    try:
                        self._ensure_stream_consumer(name, meta)
                        self._log.debug("[GETTER] %s: Stream consumer ensured", name)
                    except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                        self._log.warning("[GETTER] %s: Failed to ensure stream consumer: %s", name, e)
                    buf = self._buffers[name]
                    self._log.debug("[GETTER] %s: Buffer size=%d", name, len(buf))
                    # Determine streaming via hints in priority order:
                    # 1) Explicit @type(stream=...) hint
                    # 2) Presence of remote transport hints (start/interval)
                    # 3) UI widget type indicating plotted streams (by class name to avoid GUI imports)
                    typehint = (meta.get("typehint") or {}) if isinstance(meta, dict) else {}
                    stream_kind = (typehint.get("stream") or "").lower() if isinstance(typehint, dict) else ""
                    # Any non-empty stream hint implies streaming
                    is_streaming = bool(stream_kind)
                    if not is_streaming and isinstance(meta, dict):
                        rmeta = (meta.get("remote") or {})
                        ui = (meta.get("ui") or {})
                        is_streaming = bool(rmeta.get("start") or rmeta.get("interval_ms"))
                        if not is_streaming:
                            w = ui.get("widget") if isinstance(ui, dict) else None
                            try:
                                wname = getattr(w, "__name__", None) or str(w)
                            except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                                wname = None
                            if isinstance(wname, str):
                                wn = wname.lower()
                                is_streaming = any(key in wn for key in ("plotwidget", "waterfall"))
                    # Classify stream mode for this getter ('sweep' or 'event')
                    mode = self._stream_kinds.get(name)
                    if not mode:
                        mode = ""
                        try:
                            ui = (meta.get("ui") or {}) if isinstance(meta, dict) else {}
                            w = ui.get("widget") if isinstance(ui, dict) else None
                            wname = (getattr(w, "__name__", None) or str(w) or "").lower()
                        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                            wname = ""
                        if isinstance(typehint, dict):
                            sk = str(typehint.get("stream") or "").lower()
                            if sk in ("sweep", "event"):
                                mode = sk
                        if not mode:
                            if "sweep" in wname or "multitrace" in wname or name.lower().startswith("get_sweep"):
                                mode = "sweep"
                        if not mode:
                            mode = "event" if is_streaming else ""
                        self._stream_kinds[name] = mode
                    
                    self._log.debug("[GETTER] %s: is_streaming=%s, mode=%s", name, is_streaming, mode)
                    
                    # PERFORMANCE FIX: Never block - return immediately if buffer empty
                    # Background streaming will fill buffer on next cycle
                    if not buf:
                        self._log.debug("[GETTER] %s: Buffer empty, returning []", name)
                        return []
                    
                    self._log.debug("[GETTER] %s: Draining buffer (mode=%s, buf_size=%d)", name, mode, len(buf))
                    
                    # Drain behavior: sweeps return exactly one batch; events drain all
                    try:
                        kind = self._stream_kinds.get(name, "")
                        if kind == "sweep":
                            try:
                                batch = buf.popleft()
                                self._log.debug("[GETTER] %s: Returning sweep batch with %d points", name, len(batch) if isinstance(batch, (list, tuple)) else 1)
                            except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                                self._log.warning("[GETTER] %s: Failed to pop sweep batch: %s", name, e)
                                return []
                            if isinstance(batch, (list, tuple)):
                                return list(batch)
                            # Fallback for legacy flattened buffers
                            return [batch]
                        else:
                            items = list(buf)
                            buf.clear()
                            self._log.debug("[GETTER] %s: Returning %d event items", name, len(items))
                            return items
                    except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                        self._log.warning("[GETTER] %s: Drain error: %s", name, e)
                        return []
                _getter.__name__ = name  # type: ignore[attr-defined]
                setattr(_getter, "_orig_attr", name)
                return _getter

        # Heuristic fallback: methods starting with 'get_' are treated as getters
        if isinstance(name, str) and name.startswith("get_"):
            meta: Dict[str, Any] = {"attr": name, "ui": {}}
            def _getter():
                import time as time_module
                t_start = time_module.perf_counter()
                
                # CRITICAL: Start background stream consumer to fill buffer
                try:
                    self._ensure_stream_consumer(name, meta)
                    self._log.debug("[FALLBACK_GETTER] %s: Stream consumer ensured", name)
                except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                    self._log.warning("[FALLBACK_GETTER] %s: Failed to ensure consumer: %s", name, e)
                
                t1 = time_module.perf_counter()
                self._log.debug("[PERF] %s: setup took %.3fms", name, (t1-t_start)*1000)
                
                buf = self._buffers[name]
                self._log.debug("[FALLBACK_GETTER] %s: Buffer size=%d", name, len(buf))
                
                t2 = time_module.perf_counter()
                self._log.debug("[PERF] %s: buffer access took %.3fms", name, (t2-t1)*1000)
                
                # Determine mode by name if possible
                mode = self._stream_kinds.get(name)
                if not mode:
                    mode = "sweep" if name.lower().startswith("get_sweep") else "event"
                    self._stream_kinds[name] = mode
                    
                t3 = time_module.perf_counter()
                self._log.debug("[PERF] %s: mode check took %.3fms", name, (t3-t2)*1000)
                
                # PERFORMANCE FIX: Return immediately if buffer empty
                # This prevents GUI freezing when polling remote instruments at high rates
                if not buf:
                    self._log.debug("[FALLBACK_GETTER] %s: Buffer empty, returning []", name)
                    return []
                
                self._log.debug("[FALLBACK_GETTER] %s: Draining buffer (mode=%s, buf_size=%d)", name, mode, len(buf))
                try:
                    if self._stream_kinds.get(name) == "sweep":
                        # Return exactly one batch
                        try:
                            batch = buf.popleft()
                            self._log.debug("[FALLBACK_GETTER] %s: Returning sweep batch with %d points", name, len(batch) if isinstance(batch, (list, tuple)) else 1)
                        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                            self._log.warning("[FALLBACK_GETTER] %s: Failed to pop sweep: %s", name, e)
                            return []
                        if isinstance(batch, (list, tuple)):
                            return list(batch)
                        return [batch]
                    else:
                        items = list(buf)
                        buf.clear()
                        self._log.debug("[FALLBACK_GETTER] %s: Returning %d events", name, len(items))
                        return items
                except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                    self._log.warning("[FALLBACK_GETTER] %s: Drain error: %s", name, e)
                    return []
            _getter.__name__ = name  # type: ignore[attr-defined]
            setattr(_getter, "_orig_attr", name)
            return _getter

        # For control methods, return a callable that will forward remotely later
        def _method(*args, **kwargs):
            # Use timeout-aware invoke helper; allow optional override via kwargs
            timeout = float(kwargs.pop("timeout_s", 4.0)) if isinstance(kwargs, dict) else 4.0
            result = self._invoke_remote(name, *args, timeout_s=timeout, **kwargs)
            
            # PERFORMANCE: After setters, flush buffers to immediately show new config
            # This eliminates latency from buffered old-size data
            if isinstance(name, str) and name.startswith("set_"):
                self._log.info("[METHOD] %s: Flushing buffers after setter", name)
                for attr in list(self._buffers.keys()):
                    self._buffers[attr].clear()
                    self._log.debug("[METHOD] Cleared buffer for %s", attr)
            
            return result
        _method.__name__ = name  # type: ignore[attr-defined]
        setattr(_method, "_orig_attr", name)
        return _method

    # ---- Internal helpers ----
    def _ensure_stream_consumer(self, attr: str, meta: Dict[str, Any]) -> None:
        if attr in self._consumers:
            t = self._consumers.get(attr)
            if t and t.is_alive():
                self._log.debug("[STREAM] %s: Consumer already running", attr)
                return
        if self._stream_client is None:
            # No remote; nothing to consume yet
            self._log.warning("[STREAM] %s: No stream client available", attr)
            return
        self._log.info("[STREAM] %s: Starting new consumer thread", attr)
        stop_evt = threading.Event()
        self._stop_flags[attr] = stop_evt
        t = threading.Thread(target=self._consume_stream, args=(attr, meta, stop_evt), name=f"remote-consumer-{attr}", daemon=True)
        self._consumers[attr] = t
        try:
            t.start()
            self._log.info("[STREAM] %s: Consumer thread started successfully", attr)
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            self._log.warning("Failed to start consumer for %s: %s", attr, e)

    def _consume_stream(self, attr: str, meta: Dict[str, Any], stop_evt: threading.Event) -> None:
        # Subscribe to a Flight stream for this feature and fill buffer
        self._log.info("[CONSUMER] %s: Starting stream consumer", attr)
        reader = None
        try:
            from pyarrow import flight  # type: ignore
            # Ticket structure: JSON with kind/model/instance_id/attr
            ticket = flight.Ticket(json.dumps({
                "kind": self.kind,
                "model": self.model,
                "instance_id": self._inst_id,
                "getter": attr,
            }).encode("utf-8"))
            self._log.info("[CONSUMER] %s: Connecting to do_get with ticket: kind=%s, model=%s, instance=%s, getter=%s", 
                          attr, self.kind, self.model, self._inst_id, attr)
            reader = self._stream_client.do_get(ticket)  # type: ignore[union-attr]
            
            # Store reader reference so it can be closed from _stop_stream_consumer
            self._stream_readers[attr] = reader
            
            self._log.info("[CONSUMER] %s: Connected to stream, starting read loop", attr)
            try:
                idle_cycles = 0
                while not stop_evt.is_set():
                    # Check if getter is still being accessed (active GUI polling)
                    last_access = self._last_access.get(attr, 0.0)
                    time_since_access = time.time() - last_access if last_access > 0 else 0.0
                    
                    # If getter hasn't been called in 2+ seconds, pause streaming to save resources
                    if time_since_access > 2.0 and last_access > 0:
                        self._log.debug("[CONSUMER] %s: Pausing (idle for %.1fs)", attr, time_since_access)
                        time.sleep(0.5)  # Sleep longer when idle
                        continue
                    
                    try:
                        chunk = reader.read_chunk()
                    except StopIteration:
                        self._log.info("[CONSUMER] %s: Stream ended (StopIteration)", attr)
                        break
                    except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                        # Check if this is due to stop request
                        if stop_evt.is_set():
                            self._log.info("[CONSUMER] %s: Stream stopped by user request", attr)
                        else:
                            self._log.debug("[CONSUMER] %s: Stream read error: %s", attr, e)
                        break
                    except Exception as e:  # Catch FlightCancelledError and other gRPC exceptions
                        if stop_evt.is_set():
                            self._log.info("[CONSUMER] %s: Stream cancelled after stop request", attr)
                        else:
                            # Best-effort detection for FlightCancelledError without hard dependency
                            name = type(e).__name__
                            if name == "FlightCancelledError":
                                self._log.info("[CONSUMER] %s: Flight stream cancelled", attr)
                            else:
                                self._log.debug("[CONSUMER] %s: Stream exception: %s", attr, e)
                        break
                    if chunk is None:
                        idle_cycles += 1
                        if idle_cycles > 200:  # ~20s with 0.1s sleep below
                            self._log.warning("Stream idle timeout for %s", attr)
                            break
                        time.sleep(0.1)
                        continue
                    # Flight returns FlightStreamChunk; .data -> RecordBatch
                    rb = getattr(chunk, "data", None)
                    if rb is None:
                        continue
                    # Schema/columns from RecordBatch
                    try:
                        names = list(rb.schema.names)
                    except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                        names = []
                    ncol = getattr(rb, "num_columns", 0)
                    # Common cases: event (y) -> 1 col; sweep (x,y) -> 2 cols
                    if ncol >= 2:
                        xs = rb.column(0).to_pylist()
                        ys = rb.column(1).to_pylist()
                        pts = list(zip(xs, ys))
                    elif ncol == 1:
                        ys = rb.column(0).to_pylist()
                        pts = ys
                    else:
                        pts = []
                    # Append to buffer with respect to stream kind
                    dq = self._buffers[attr]
                    # Skip empty batches entirely (e.g., initial schema batch)
                    if not pts:
                        self._log.debug("[CONSUMER] %s: Skipping empty batch", attr)
                        continue
                    
                    # Log at debug level during normal operation to reduce console spam
                    self._log.debug("[CONSUMER] %s: Received batch with %d points (ncol=%d)", attr, len(pts), ncol)
                    
                    # Determine/record mode if unknown yet, using schema as heuristic
                    mode = self._stream_kinds.get(attr)
                    if not mode:
                        if ncol >= 2:
                            mode = "sweep"
                        elif ncol == 1:
                            mode = "event"
                        else:
                            mode = "event"
                        self._stream_kinds[attr] = mode
                    if not mode:
                        mode = "sweep" if attr.lower().startswith("get_sweep") else "event"
                    # Determine per-getter sweep cap policy once from metadata if available
                    if mode == "sweep" and attr not in self._sweep_caps:
                        cap = None
                        try:
                            rmeta = (meta.get("remote") or {}) if isinstance(meta, dict) else {}
                            if isinstance(rmeta, dict):
                                if bool(rmeta.get("latest_only")):
                                    cap = 1
                                else:
                                    m = rmeta.get("sweep_buffer_max") or rmeta.get("sweep_max_batches") or rmeta.get("max_sweeps")
                                    if m is not None:
                                        cap = int(m)
                        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                            cap = None
                        self._sweep_caps[attr] = cap
                    if mode == "sweep":
                        cap = self._sweep_caps.get(attr)
                        # Preserve batch boundary: push as one item, with latest-only overwrite if cap==1
                        if cap == 1:
                            dq.clear()
                            dq.append(list(pts))
                            self._log.debug("[CONSUMER] %s: Appended sweep batch (latest-only), buffer_size=%d", attr, len(dq))
                        else:
                            dq.append(list(pts))
                            self._log.debug("[CONSUMER] %s: Appended sweep batch, buffer_size=%d", attr, len(dq))
                    else:
                        dq.extend(pts)
                        self._log.debug("[CONSUMER] %s: Extended events buffer, buffer_size=%d", attr, len(dq))
                    # Bound memory: apply configured cap for sweeps (if provided), default cap for events
                    if mode == "sweep":
                        cap = self._sweep_caps.get(attr)
                        if isinstance(cap, int) and cap >= 1:
                            while len(dq) > cap:
                                try:
                                    dq.popleft()
                                except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                                    break
                    else:
                        cap_pts = 10000
                        while len(dq) > cap_pts:
                            try:
                                dq.popleft()
                            except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                                break
                
                # Log reason for loop exit
                if stop_evt.is_set():
                    self._log.info("[CONSUMER] %s: Exiting consumer loop - stop requested", attr)
                else:
                    self._log.info("[CONSUMER] %s: Exiting consumer loop - stream ended", attr)
                    
            finally:
                if reader is not None:
                    reader.close()
                    self._log.debug("[CONSUMER] %s: Reader closed", attr)
                # Remove reader reference
                if attr in self._stream_readers:
                    del self._stream_readers[attr]
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            if stop_evt.is_set():
                self._log.info("[CONSUMER] %s: Consumer stopped (stop requested): %s", attr, e)
            else:
                self._log.warning("[CONSUMER] %s: Failed to consume remote stream: %s", attr, e)
