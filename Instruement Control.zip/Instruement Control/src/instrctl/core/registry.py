from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Dict, Optional, Tuple, Type, TypeVar

from .base import BaseInstrument

T = TypeVar("T", bound=BaseInstrument)


@dataclass(frozen=True)
class InstrumentKey:
    kind: str  # abstract type, e.g., "SignalGenerator"
    model: str  # implementation, e.g., "DemoSG"


class InstrumentRegistry:
    _registry: Dict[InstrumentKey, Type[BaseInstrument]] = {}

    @classmethod
    def register(cls, kind: str, model: str, impl: Type[T]) -> None:
        key = InstrumentKey(kind, model)
        impl.kind = kind  # type: ignore[attr-defined]
        impl.model = model  # type: ignore[attr-defined]
        cls._registry[key] = impl

    @classmethod
    def list_kinds(cls) -> Dict[str, Dict[str, Type[BaseInstrument]]]:
        out: Dict[str, Dict[str, Type[BaseInstrument]]] = {}
        for key, impl in cls._registry.items():
            out.setdefault(key.kind, {})[key.model] = impl
        return out

    @classmethod
    def get(cls, kind: str, model: str) -> Optional[Type[BaseInstrument]]:
        return cls._registry.get(InstrumentKey(kind, model))


def _infer_kind(impl: Type[T]) -> Optional[str]:
    # The first BaseInstrument subclass in MRO above impl is its abstract kind
    for base in impl.__mro__[1:]:
        if issubclass(base, BaseInstrument) and getattr(base, "__abstract__", False):
            return base.__name__
    return None


def register_instrument(kind: Optional[str] = None, model: Optional[str] = None) -> Callable[[Type[T]], Type[T]]:
    """Decorator to register a concrete instrument.

    - If kind is omitted, it is inferred from the first abstract BaseInstrument parent class name.
    - If model is omitted, it defaults to the concrete class name.
    """

    def deco(impl: Type[T]) -> Type[T]:
        k = kind or _infer_kind(impl)
        m = model or impl.__name__
        if not k:
            raise ValueError("Cannot infer instrument kind; specify kind= explicitly.")
        InstrumentRegistry.register(k, m, impl)
        return impl

    return deco


class InstrumentFactory:
    @staticmethod
    def create(kind: str, model: str, **kwargs: Any) -> BaseInstrument:
        impl = InstrumentRegistry.get(kind, model)
        if not impl:
            raise KeyError(f"No instrument registered for {kind}:{model}")
        return impl(**kwargs)
