"""
Dual-plane remote agent supporting both RPyC (control) and Arrow Flight (data).

This agent extends the existing Flight-based AgentServer with RPyC support
for more efficient control plane operations and complex object handling.
"""

from __future__ import annotations

import json
import logging
import os
import threading
import time
import traceback
from typing import Any, Dict, Optional

import rpyc  # type: ignore
import pyarrow as pa  # type: ignore
from pyarrow import flight  # type: ignore

from .registry import InstrumentRegistry, InstrumentFactory
from .plugins import discover_all
from .remote_agent import AgentServer  # Inherit from existing AgentServer


log = logging.getLogger("instrctl.core.dual_agent")


class DualAgentRPyCService(rpyc.Service):
    """RPyC service for control plane operations."""
    
    def __init__(self):
        super().__init__()
        self._instances: Dict[str, Any] = {}  # key format: "kind:model"
        log.info("DualAgentRPyCService initialized")
    
    def exposed_get_or_create_instrument(self, kind: str, model: str, instance_id: str = "default"):
        """Get or create an instrument instance (with instance ID for multi-instrument support)."""
        key = f"{kind}:{model}:{instance_id}"
        inst = self._instances.get(key)
        
        if inst is None:
            impl = InstrumentRegistry.get(kind, model)
            if impl is None:
                log.error("No instrument registered for %s:%s", kind, model)
                raise KeyError(f"No instrument registered for {kind}:{model}")
            
            log.debug("Creating instrument instance: %s:%s (instance_id=%s)", kind, model, instance_id)
            inst = InstrumentFactory.create(kind, model)
            self._instances[key] = inst
        else:
            log.debug("Reusing cached instrument instance: %s:%s (instance_id=%s)", kind, model, instance_id)
        
        return key
    
    def exposed_invoke(self, method: str, *args, **kwargs):
        """Invoke a standalone method."""
        log.debug("Invoking standalone method: %s", method)
        # This would be for utility methods not tied to a specific instrument
        raise NotImplementedError(f"Standalone method not implemented: {method}")
    
    def exposed_invoke_on(self, inst_key: str, method: str, *args, **kwargs):
        """Invoke a method on a specific instrument instance."""
        inst = self._instances.get(inst_key)
        if inst is None:
            raise KeyError(f"Instrument not found: {inst_key}")
        
        # Log call with trimmed args for readability
        def _trim(v):
            s = repr(v)
            return (s[:120] + "…") if len(s) > 120 else s
        
        log.debug("invoke_on: %s.%s args=%s kwargs=%s", inst_key, method, _trim(args), _trim(kwargs))
        
        t0 = time.time()
        fn = getattr(inst, method, None)
        if not callable(fn):
            log.error("Method not found: %s on %s", method, inst_key)
            raise AttributeError(f"Method not found: {method}")
        
        try:
            result = fn(*args, **kwargs)
            dt = (time.time() - t0) * 1000.0
            log.debug("invoke_on: %s.%s completed in %.1f ms", inst_key, method, dt)
            return result
        except Exception as e:
            log.exception("invoke_on error: %s.%s - %s", inst_key, method, e)
            raise
    
    def exposed_get_instance(self, inst_key: str):
        """Get an instrument instance (returns netref for remote access)."""
        inst = self._instances.get(inst_key)
        if inst is None:
            raise KeyError(f"Instrument not found: {inst_key}")
        return inst
    
    def exposed_list_instruments(self):
        """List all cached instrument instances."""
        return list(self._instances.keys())


class DualAgentServer:
    """
    Combined agent server with RPyC (control plane) and Arrow Flight (data plane).
    
    This runs both servers in the same process, sharing instrument instances.
    """
    
    def __init__(self, host: str = "0.0.0.0", port_control: int = 18861, port_data: int = 8815):
        self.host = host
        self.port_control = port_control
        self.port_data = port_data
        
        # Shared service instances
        self.rpyc_service = DualAgentRPyCService()
        self.flight_server = AgentServer(
            flight.Location.for_grpc_tcp(host, port_data)
        )
        
        # Share instrument instances between RPyC and Flight
        # Flight server already has _instances dict, link it to RPyC service
        self.rpyc_service._instances = self._make_shared_instances()
        
        self._rpyc_thread: Optional[threading.Thread] = None
        self._flight_thread: Optional[threading.Thread] = None
        self._rpyc_server = None
        self._stop_event = threading.Event()
        
        log.info("DualAgentServer initialized: RPyC=%s:%d Flight=%s:%d",
                 host, port_control, host, port_data)
    
    def _make_shared_instances(self) -> Dict[str, Any]:
        """
        Create a shared instrument instances dict that both services can use.
        Flight server uses (kind, model, instance_id) tuples as keys, RPyC uses "kind:model:instance_id" strings.
        This ensures BOTH services access THE SAME instrument instance.
        """
        class SharedInstances(dict):
            """Dict that accepts both tuple and string keys, mapping to same instances."""
            def __init__(self):
                super().__init__()
                self._instances = {}  # Unified storage: "kind:model:instance_id" -> instance
            
            def _normalize_key(self, key):
                """Convert any key format to canonical 'kind:model:instance_id' string."""
                if isinstance(key, tuple):
                    if len(key) == 2:
                        # Legacy (kind, model) -> add default instance_id
                        return f"{key[0]}:{key[1]}:default"
                    elif len(key) == 3:
                        return f"{key[0]}:{key[1]}:{key[2]}"
                    else:
                        return str(key)
                elif isinstance(key, str):
                    # Ensure format is kind:model:instance_id
                    parts = key.split(":")
                    if len(parts) == 2:
                        # Legacy "kind:model" -> add default instance_id
                        return f"{key}:default"
                    return key
                return str(key)
            
            def __getitem__(self, key):
                normalized = self._normalize_key(key)
                return self._instances.get(normalized)
            
            def __setitem__(self, key, value):
                normalized = self._normalize_key(key)
                self._instances[normalized] = value
            
            def get(self, key, default=None):
                normalized = self._normalize_key(key)
                return self._instances.get(normalized, default)
            
            def keys(self):
                return list(self._instances.keys())
            
            def __contains__(self, key):
                normalized = self._normalize_key(key)
                return normalized in self._instances
        
        shared = SharedInstances()
        # Make Flight server use the same shared dict (it will use tuple keys)
        self.flight_server._instances = shared
        return shared
    
    def start(self):
        """Start both RPyC and Flight servers in background threads."""
        # Discover plugins before starting
        discover_all()
        
        # Start RPyC server
        def rpyc_worker():
            from rpyc.utils.server import ThreadedServer
            log.info("Starting RPyC server on %s:%d", self.host, self.port_control)
            self._rpyc_server = ThreadedServer(
                self.rpyc_service,
                hostname=self.host,
                port=self.port_control,
                protocol_config={"allow_public_attrs": True, "allow_all_attrs": True}
            )
            self._rpyc_server.start()
        
        self._rpyc_thread = threading.Thread(target=rpyc_worker, daemon=True)
        self._rpyc_thread.start()
        
        # Start Flight server unless explicitly disabled (useful on platforms where
        # Arrow Flight is unavailable or unstable, e.g. Windows without the native
        # gRPC transport libraries). This keeps the control plane available so tests
        # can still exercise remote proxies.
        disable_flight = os.environ.get("INSTRCTL_DISABLE_FLIGHT", "").lower() in {"1", "true", "yes"}
        if disable_flight:
            log.warning("Skipping Flight server startup due to INSTRCTL_DISABLE_FLIGHT")
        else:
            def flight_worker():
                try:
                    log.info("Starting Flight server on %s:%d", self.host, self.port_data)
                    self.flight_server.serve()
                except Exception as exc:
                    log.exception("Flight server crashed: %s", exc)

            self._flight_thread = threading.Thread(target=flight_worker, daemon=True, name="DualAgentFlightServer")
            self._flight_thread.start()
        
        log.info("DualAgentServer started successfully")
        time.sleep(0.5)  # Give servers time to start
    
    def wait(self):
        """Block until servers are stopped."""
        try:
            while not self._stop_event.is_set():
                time.sleep(1.0)
        except KeyboardInterrupt:
            log.info("Received interrupt signal")
            self.stop()
    
    def stop(self):
        """Stop both servers."""
        log.info("Stopping DualAgentServer")
        self._stop_event.set()
        
        if self._rpyc_server:
            try:
                self._rpyc_server.close()
            except Exception as e:
                log.warning("Error stopping RPyC server: %s", e)
        
        try:
            if hasattr(self, "flight_server"):
                self.flight_server.shutdown()
                if self._flight_thread is not None:
                    self._flight_thread.join(timeout=2.0)
        except Exception as e:
            log.warning("Error stopping Flight server: %s", e)


def run_dual_agent(host: str = "0.0.0.0", port_control: int = 18861, port_data: int = 8815):
    """Convenience function to run a dual-plane agent server."""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s [%(levelname)s] %(name)s: %(message)s'
    )
    
    agent = DualAgentServer(host, port_control, port_data)
    agent.start()
    
    log.info("=" * 60)
    log.info("Dual-plane agent running:")
    log.info("  RPyC (control):  %s:%d", host, port_control)
    log.info("  Flight (data):   %s:%d", host, port_data)
    log.info("=" * 60)
    
    try:
        agent.wait()
    except KeyboardInterrupt:
        log.info("Shutting down...")
        agent.stop()


if __name__ == "__main__":
    run_dual_agent()
