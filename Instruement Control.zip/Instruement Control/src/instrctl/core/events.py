from __future__ import annotations

from dataclasses import dataclass
import logging
from typing import Any, Callable, DefaultDict, Dict, List
from collections import defaultdict


@dataclass(frozen=True)
class Event:
    type: str
    data: Dict[str, Any]


class EventBus:
    """Simple in-process pub/sub bus."""

    def __init__(self) -> None:
        self._subs: DefaultDict[str, List[Callable[[Event], None]]] = defaultdict(list)

    def subscribe(self, event_type: str, callback: Callable[[Event], None]) -> None:
        if callback not in self._subs[event_type]:
            self._subs[event_type].append(callback)

    def unsubscribe(self, event_type: str, callback: Callable[[Event], None]) -> None:
        self._subs[event_type].remove(callback)

    def publish(self, event_type: str, **data: Any) -> None:
        evt = Event(event_type, data)
        for cb in list(self._subs.get(event_type, [])):
            try:
                cb(evt)
            except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:# Avoid crashing the bus due to subscriber error, but log it
                logging.getLogger(__name__).exception("Event subscriber error for '%s'", event_type)
