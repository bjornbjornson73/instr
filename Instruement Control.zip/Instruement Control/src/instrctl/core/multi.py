from __future__ import annotations

import threading
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, Iterator, List, Optional

from .base import BaseInstrument
from .base import ExclusivityError


@dataclass
class ExclusivityGroup:
    name: str
    members: List[str] = field(default_factory=list)  # child aliases in this group
    owner: Optional[str] = None  # active alias owning the group


class MultiInstrument(BaseInstrument):
    """Base class for multi-instruments that aggregate other instruments.

    - Holds child instruments with aliases
    - Provides metadata for exclusivity groups (conflicting features)
    - Does not hard-enforce exclusivity; GUI or concrete implementations can use
      this metadata to prevent conflicting operations.
    """

    __abstract__ = True

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._children: Dict[str, BaseInstrument] = {}
        self._groups: Dict[str, ExclusivityGroup] = {}
        # Backend lease state per group: name -> {owner, expires_at, lock}
        self._leases: Dict[str, Dict[str, object]] = {}
        # Active flags per child to let children detect preemption cooperatively
        self._child_active: Dict[str, bool] = {}
        # Policy: stop the losing child automatically when ownership transfers
        # Default enabled; callers can flip off if they prefer manual control
        self._auto_stop_on_preempt: bool = True

    # ---- Children management ----
    def add_child(self, alias: str, inst: BaseInstrument) -> None:
        self._children[alias] = inst
        setattr(inst, "_parent_multi", self)
        setattr(inst, "_parent_alias", alias)
        self._child_active[alias] = False

    def list_children(self) -> Dict[str, BaseInstrument]:
        return dict(self._children)

    # ---- Exclusivity groups ----
    def define_group(self, name: str, members: List[str]) -> None:
        """Define an exclusivity group by child alias membership."""
        self._groups[name] = ExclusivityGroup(name=name, members=list(members), owner=None)
        self._leases[name] = {"owner": None, "expires_at": 0.0, "lock": threading.Lock()}

    def groups(self) -> Dict[str, ExclusivityGroup]:
        return dict(self._groups)

    def set_group_owner(self, name: str, owner: Optional[str]) -> None:
        if name in self._groups:
            self._groups[name].owner = owner

    # ---- Backend exclusivity enforcement ----
    def get_group_of_child(self, child_alias: str) -> Optional[str]:
        for g, grp in self._groups.items():
            if child_alias in grp.members:
                return g
        return None

    def ensure_access(self, child_alias: str, *, ttl: float = 1.0, preempt: bool = False) -> None:
        """Acquire/renew exclusive access for the child's group for ttl seconds.

        - If the group is free or expired, becomes owner.
        - If already owner, renews.
        - If owned by another alias: raises ExclusivityError unless preempt=True, in which case ownership transfers.
        """
        group = self.get_group_of_child(child_alias)
        # No exclusivity group for this child: allow
        if group is None:
            self._child_active[child_alias] = True
            return
        lease = self._leases[group]
        lock: threading.Lock = lease["lock"]  # type: ignore[assignment]
        now = time.monotonic()
        prev_owner_to_stop: Optional[str] = None
        acquired = False
        error_owner: Optional[str] = None
        with lock:
            owner: Optional[str] = lease["owner"]  # type: ignore[assignment]
            exp: float = float(lease["expires_at"])  # type: ignore[assignment]
            if owner is None or now >= exp or owner == child_alias or preempt:
                # If we're replacing a different current owner, remember to stop it after releasing the lock
                if owner and owner != child_alias and (preempt or now >= exp):
                    prev_owner_to_stop = owner
                lease["owner"] = child_alias
                lease["expires_at"] = now + float(ttl)
                # keep metadata in sync for UI if used
                self.set_group_owner(group, child_alias)
                self._child_active[child_alias] = True
                # Deactivate other children in the group
                for alias in self._groups[group].members:
                    if alias != child_alias:
                        self._child_active[alias] = False
                acquired = True
            else:
                error_owner = owner
        if acquired:
            # Perform best-effort stop of the losing child outside the lock to avoid blocking lease operations
            if self._auto_stop_on_preempt and prev_owner_to_stop:
                self._stop_child_best_effort(prev_owner_to_stop)
            return
        # Not acquired: raise with details captured inside the lock
        raise ExclusivityError(
            f"Group '{group}' is owned by '{error_owner}', '{child_alias}' cannot acquire without preempt",
            group=group,
            owner=error_owner,
        )

    def release_access(self, child_alias: str) -> None:
        group = self.get_group_of_child(child_alias)
        self._child_active[child_alias] = False
        if group is None:
            return
        lease = self._leases[group]
        lock: threading.Lock = lease["lock"]  # type: ignore[assignment]
        with lock:
            owner: Optional[str] = lease["owner"]  # type: ignore[assignment]
            if owner == child_alias:
                lease["owner"] = None
                lease["expires_at"] = 0.0
                # update metadata for UI
                self.set_group_owner(group, None)

    def start_all(self) -> None:
        # Hook for concrete classes; we just reset activity flags
        for alias in list(self._child_active.keys()):
            self._child_active[alias] = False

    def stop_all(self) -> None:
        # Clear all leases and activity flags
        for alias in list(self._child_active.keys()):
            self._child_active[alias] = False
        for g, lease in self._leases.items():
            lock: threading.Lock = lease["lock"]  # type: ignore[assignment]
            with lock:
                lease["owner"] = None
                lease["expires_at"] = 0.0
            self.set_group_owner(g, None)

    def is_active(self, child_alias: str) -> bool:
        """Whether the child should continue based on last ensure_access call."""
        return bool(self._child_active.get(child_alias, True))

    # ---- Policy configuration & helpers ----
    def set_auto_stop_on_preempt(self, enabled: bool) -> None:
        """Enable/disable auto-stopping the losing child when ownership changes.

        Enabled by default. When True, on an ownership transfer (preempt or expired),
        the previous owner's declared streaming "stop" handlers (as exposed in feature
        UI metadata) are invoked best-effort.
        """
        self._auto_stop_on_preempt = bool(enabled)

    def _stop_child_best_effort(self, alias: str) -> None:
        """Attempt to stop any declared streaming features on the child.

        This inspects the child's feature metadata for UI entries containing a
        "stop" handler and calls the corresponding bound method if present.
        Failures are ignored to keep this best-effort.
        """
        child = self._children.get(alias)
        if not child:
            return
        try:
            feats = getattr(child.__class__, "features", None)
            feature_map = feats() if callable(feats) else {}
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            feature_map = {}
        for meta in feature_map.values():
            ui = meta.get("ui", {}) if isinstance(meta, dict) else {}
            stop_fn = ui.get("stop") if isinstance(ui, dict) else None
            if not stop_fn:
                continue
            stop_name = getattr(stop_fn, "__name__", None)
            if not stop_name:
                continue
            method = getattr(child, stop_name, None)
            if callable(method):
                method()

    # ---- Convenience accessors / wrappers ----
    class _ChildProxy:
        """Lightweight proxy for a child instrument that enforces exclusivity.

        - Before any callable attribute is invoked, calls multi.ensure_access(alias).
        - Non-callable attribute access is forwarded directly.

        Parameters
        ----------
        multi: MultiInstrument
            The parent multi instrument handling leases.
        alias: str
            Alias of the child instrument within this MultiInstrument.
        child: BaseInstrument
            The actual child instance to proxy.
        ttl: float
            Lease time-to-live (seconds) to renew on each call.
        preempt: bool
            Whether proxy calls can preempt an existing owner.
        """

        def __init__(self, multi: "MultiInstrument", alias: str, child: BaseInstrument, *, ttl: float = 1.0, preempt: bool = False):
            object.__setattr__(self, "_multi", multi)
            object.__setattr__(self, "_alias", alias)
            object.__setattr__(self, "_child", child)
            object.__setattr__(self, "_ttl", float(ttl))
            object.__setattr__(self, "_preempt", bool(preempt))

        def __getattr__(self, name: str) -> Any:
            target = getattr(self._child, name)
            # Introspection/metadata methods should not enforce exclusivity
            NO_ENSURE = {"features", "is_connected", "last_error"}
            if name in NO_ENSURE:
                return target
            if callable(target):
                def wrapped(*args: Any, **kwargs: Any):
                    # Acquire/renew access before invoking the child method
                    self._multi.ensure_access(self._alias, ttl=self._ttl, preempt=self._preempt)
                    return target(*args, **kwargs)
                wrapped.__name__ = getattr(target, "__name__", name)
                wrapped.__doc__ = getattr(target, "__doc__", None)
                return wrapped
            return target

        def __repr__(self) -> str:  # pragma: no cover - trivial
            return f"<ChildProxy alias={self._alias!r} of {self._multi!r}>"

        def __setattr__(self, name: str, value: Any) -> None:
            # Forward attribute writes to the child, guarding access
            if name in {"_multi", "_alias", "_child", "_ttl", "_preempt"}:
                object.__setattr__(self, name, value)
                return
            self._multi.ensure_access(self._alias, ttl=self._ttl, preempt=self._preempt)
            setattr(self._child, name, value)

        def __delattr__(self, name: str) -> None:
            if name in {"_multi", "_alias", "_child", "_ttl", "_preempt"}:
                raise AttributeError(f"Cannot delete internal attribute {name}")
            self._multi.ensure_access(self._alias, ttl=self._ttl, preempt=self._preempt)
            delattr(self._child, name)

    def child(self, alias: str, *, ttl: float = 1.0, preempt: bool = False) -> "MultiInstrument._ChildProxy":
        """Return a proxy for the child that auto-enforces exclusivity on calls.

        Example
        -------
        >>> sa = combo.child("sa", ttl=1.0)
        >>> sa.start_sweep()   # will ensure_access("sa") before calling
        >>> pts = sa.get_sweep_points()
        """
        child = self._children.get(alias)
        if child is None:
            raise KeyError(f"Unknown child alias: {alias!r}")
        return MultiInstrument._ChildProxy(self, alias, child, ttl=ttl, preempt=preempt)

    class _AccessContext:
        """Context manager to acquire/release access around a block.

        with multi.with_access("sa", ttl=2.0, preempt=True) as sa:
            sa.start_sweep()
            ...
        # releases on exit
        """

        def __init__(self, multi: "MultiInstrument", alias: str, *, ttl: float = 1.0, preempt: bool = False, proxy: bool = True):
            self._multi = multi
            self._alias = alias
            self._ttl = float(ttl)
            self._preempt = bool(preempt)
            self._proxy = bool(proxy)

        def __enter__(self) -> Any:
            self._multi.ensure_access(self._alias, ttl=self._ttl, preempt=self._preempt)
            child = self._multi._children.get(self._alias)
            if child is None:
                raise KeyError(f"Unknown child alias: {self._alias!r}")
            if self._proxy:
                return MultiInstrument._ChildProxy(self._multi, self._alias, child, ttl=self._ttl, preempt=self._preempt)
            return child

        def __exit__(self, exc_type, exc, tb) -> Optional[bool]:  # type: ignore[override]
            try:
                self._multi.release_access(self._alias)
            finally:
                return None

    def with_access(self, alias: str, *, ttl: float = 1.0, preempt: bool = False, proxy: bool = True) -> "MultiInstrument._AccessContext":
        """Acquire access on enter and release on exit; returns child or proxy.

        Parameters
        ----------
        alias: str
            Child alias to control.
        ttl: float
            Initial TTL to acquire; if `proxy=True`, calls renew per method.
        preempt: bool
            If True, will transfer ownership if held by another alias.
        proxy: bool
            If True (default), returns a ChildProxy renewing access per call.
            If False, returns the raw child instance.
        """
        return MultiInstrument._AccessContext(self, alias, ttl=ttl, preempt=preempt, proxy=proxy)
