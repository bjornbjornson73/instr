from __future__ import annotations

import importlib
import importlib.util
from importlib import metadata
from pathlib import Path
from types import ModuleType
from typing import Iterable, List, Optional
import logging


def load_entry_point_plugins(group: str = "instrctl.instruments") -> List[str]:
    """Load instrument plugins registered via Python entry points.

    Each entry point should reference a module (recommended) or a callable. Loading
    the module should trigger instrument registration via decorators.
    Returns a list of successfully loaded entry point names.
    """
    loaded: List[str] = []
    try:
        eps = metadata.entry_points()
        # Python 3.10+ provides select
        try:
            selected = eps.select(group=group)  # type: ignore[attr-defined]
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            logging.debug("entry_points.select not available; falling back: %s", e, exc_info=True)
            selected = [ep for ep in eps if getattr(ep, "group", None) == group]
        for ep in selected:
            try:
                obj = ep.load()
                # If callable, invoke once (it may register instruments)
                if callable(obj):
                    try:
                        obj()
                    except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                        logging.warning("Plugin entry point callable failed: %s (%s)", ep.name, e, exc_info=True)
                loaded.append(ep.name)
            except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:# ignore failures to keep app running but log context
                logging.warning("Failed to load entry point '%s': %s", getattr(ep, 'name', '<unknown>'), e, exc_info=True)
                continue
    except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
        logging.warning("Enumerating entry points failed: %s", e, exc_info=True)
    return loaded


def load_folder_plugins(paths: Optional[Iterable[Path]] = None) -> List[str]:
    """Load .py modules from specified plugin folders.

    Default paths: ~/.instrctl/plugins and ./plugins
    Modules are imported by file location; importing should trigger registration.
    Returns module names (synthetic) that were loaded.
    """
    if paths is None:
        paths = [Path.home() / ".instrctl" / "plugins", Path.cwd() / "plugins"]
    loaded: List[str] = []
    for base in paths:
        try:
            if not base.exists():
                continue
            for py in sorted(base.glob("*.py")):
                try:
                    name = f"instrctl_user_plugins_{py.stem}"
                    spec = importlib.util.spec_from_file_location(name, py)
                    if spec and spec.loader:
                        mod = importlib.util.module_from_spec(spec)
                        spec.loader.exec_module(mod)  # type: ignore[arg-type]
                        loaded.append(name)
                except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                    logging.warning("Failed to load plugin module %s: %s", py, e, exc_info=True)
                    continue
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            logging.warning("Error scanning plugin directory %s: %s", base, e, exc_info=True)
            continue
    return loaded


def discover_all() -> None:
    """Discover and import plugins from entry points and default folders."""
    load_entry_point_plugins()
    load_folder_plugins()
