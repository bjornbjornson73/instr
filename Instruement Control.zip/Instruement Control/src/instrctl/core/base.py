from __future__ import annotations

from dataclasses import dataclass, field
import logging
import functools
from enum import Enum, auto
from typing import Any, Callable, ClassVar, Dict, List, Optional, Protocol, Tuple, Union
import builtins

from .events import EventBus


class ConnectionError(Exception):
    pass


class ExclusivityError(Exception):
    """Raised when an operation requires an exclusive resource owned by another alias."""
    def __init__(self, message: str, *, group: str | None = None, owner: str | None = None):
        super().__init__(message)
        self.group = group
        self.owner = owner


class Capability(Enum):
    REQUIRED = auto()
    OPTIONAL = auto()


def feature(
    name: Optional[str] = None,
    capability: Capability = Capability.OPTIONAL,
    ui: Optional[Dict[str, Any]] = None,
    *,
    remote: Optional[Dict[str, Any]] = None,
):
    """Decorator to mark a method/property as a user-facing feature for GUI.

    Parameters
    - name: Optional display name; defaults to function name
    - capability: Whether this feature is required or optional for an abstract type
    """

    def wrapper(fn: Callable):
        setattr(fn, "__instr_feature__", {
            "name": name or fn.__name__,
            "capability": capability,
            "ui": ui or {},
            # Keep remote transport hints separate from UI metadata
            "remote": remote or {},
        })
        return fn

    return wrapper


def type(stream: Optional[str] = None, *, dtype: Optional[str] = None, layout: Optional[Union[List[str], Dict[str, Any]]] = None):
    """Decorator to provide explicit stream/schema hints for a feature.

    This is optional. When absent, downstream consumers may "sniff" the first
    payload(s) to infer schema and layout.

    Parameters
    - stream: "event" | "sweep" | "multitrace" (or other agreed kinds)
    - dtype:  "f32" | "f64" | "i16" | "bytes" (applies to primary numeric column)
    - layout: For multitrace, names/order or a mapping of name -> dtype
    """

    def wrapper(fn: Callable):
        # Store as a separate attribute so this decorator can be stacked with @feature in any order
        meta: Dict[str, Any] = {}
        if stream is not None:
            meta["stream"] = stream
        if dtype is not None:
            meta["dtype"] = dtype
        if layout is not None:
            meta["layout"] = layout
        setattr(fn, "__instr_type__", meta)
        return fn

    return wrapper


class InstrumentMeta(builtins.type):
    """Metaclass to collect features and support auto-registration via registry.

    Subclasses can define __abstract__ = True to avoid registration.
    """

    def __new__(mcls, name, bases, namespace, **kwargs):  # type: ignore[override]
        cls = super().__new__(mcls, name, bases, dict(namespace))
        # Collect features from bases and this class
        features: Dict[str, Dict[str, Any]] = {}
        for base in reversed(cls.__mro__):
            for attr_name, attr_val in base.__dict__.items():
                meta = getattr(attr_val, "__instr_feature__", None)
                if meta:
                    # Copy to avoid mutating decorator-shared dict
                    m = dict(meta)
                    m.setdefault("attr", attr_name)
                    # Merge optional explicit type/schema hints if present
                    tmeta = getattr(attr_val, "__instr_type__", None)
                    if isinstance(tmeta, dict) and tmeta:
                        # Keep under a dedicated key to avoid collisions with UI metadata
                        m["typehint"] = dict(tmeta)
                    features[m["name"]] = m
        setattr(cls, "__features__", features)

        # Wrap feature methods to log calls/results/exceptions for tracing
        # Use a consistent logger hierarchy for filtering: instrctl.core.instrument.<ClassName>
        logger = logging.getLogger(f"instrctl.core.instrument.{name}")
        for meta in features.values():
            attr = meta.get("attr")
            if not attr:
                continue
            fn = getattr(cls, attr, None)
            if not callable(fn):
                continue
            # Avoid double wrapping
            if getattr(fn, "__instr_logged__", False):
                continue

            def _summarize(val: Any) -> str:
                try:
                    # Common large types: lists/tuples/dicts/ndarrays-like
                    if isinstance(val, (list, tuple)):
                        n = len(val)
                        if n > 32:
                            return f"<{type(val).__name__} len={n}>"
                    if isinstance(val, dict):
                        n = len(val)
                        if n > 20:
                            return f"<dict {n} keys>"
                    # NumPy/arrow-like objects with shape/size
                    shp = getattr(val, "shape", None)
                    if shp is not None:
                        return f"<{type(val).__name__} shape={shp}>"
                    s = repr(val)
                    if len(s) > 512:
                        return s[:256] + "...(truncated)"
                    return s
                except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                    return f"<{type(val).__name__}>"

            @functools.wraps(fn)
            def _wrapped(self, *args, __fn=fn, __attr=attr, **kwargs):
                try:
                    logger.debug("CALL %s(%s%s)", __attr, 
                                ", ".join(repr(a) for a in args),
                                (", " + ", ".join(f"{k}={v!r}" for k, v in kwargs.items())) if kwargs else "")
                except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                    logging.getLogger(__name__).debug("Instrument logger call formatting failed for %s.%s", name, __attr, exc_info=True)
                try:
                    result = __fn(self, *args, **kwargs)
                except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                    try:
                        logger.exception("EXC  %s: %s", __attr, e)
                    except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                        logging.getLogger(__name__).debug("Instrument logger exception formatting failed for %s.%s", name, __attr, exc_info=True)
                    raise
                else:
                    try:
                        logger.debug("RET  %s -> %s", __attr, _summarize(result))
                    except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                        logging.getLogger(__name__).debug("Instrument logger return formatting failed for %s.%s", name, __attr, exc_info=True)
                    return result

            # Preserve feature metadata on wrapper
            setattr(_wrapped, "__instr_feature__", getattr(fn, "__instr_feature__", None))
            setattr(_wrapped, "__instr_logged__", True)
            try:
                setattr(cls, attr, _wrapped)
            except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:# If setattr fails (e.g., read-only descriptors), skip wrapping but record it
                logging.getLogger(__name__).warning("Failed to wrap feature method '%s' on %s", attr, name, exc_info=True)
        return cls


@dataclass
class InstrumentState:
    connected: bool = False
    info: Dict[str, Any] = field(default_factory=dict)


class BaseInstrument(metaclass=InstrumentMeta):
    """Minimal base instrument interface.

    Concrete instruments should override connection methods.
    """

    # If True, not register as a concrete implementation of an abstract type.
    __abstract__: ClassVar[bool] = True

    # Assigned by registry when constructed
    kind: ClassVar[str]
    model: ClassVar[str]

    def __init__(self, *, event_bus: Optional[EventBus] = None) -> None:
        self._state = InstrumentState()
        self.events = event_bus or EventBus()

    # ---- Connection management ----
    def connect(self, **kwargs) -> None:  # pragma: no cover - abstract default
        raise NotImplementedError("connect must be implemented by concrete instrument")

    def disconnect(self) -> None:  # pragma: no cover - abstract default
        raise NotImplementedError("disconnect must be implemented by concrete instrument")

    def is_connected(self) -> bool:
        return self._state.connected

    # ---- Shared connection hooks (optional) ----
    def get_connection(self, **kwargs):  # pragma: no cover - optional hook
        """Create and return a connection handle/object from GUI params.

        Default behavior: return the kwargs dict. Override to return a reusable
        object (e.g., VISA session, socket, serial) without dialing multiple times.
        """
        return dict(kwargs)

    def set_connection(self, connection) -> None:  # pragma: no cover - optional hook
        """Attach to a pre-built connection handle/object.

        Default behavior: if a dict is provided, call connect(**dict), otherwise
        call connect() with no arguments. Override to store/use the connection
        object without re-establishing it.
        """
        try:
            if isinstance(connection, dict):
                self.connect(**connection)
            else:
                self.connect()
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:# Leave connected state unchanged on failure by default, but log it
            logging.getLogger(__name__).warning("set_connection failed on %s: %s", type(self).__name__, e, exc_info=True)

    # Back-compat aliases
    def make_connection(self, **kwargs):  # pragma: no cover - alias
        return self.get_connection(**kwargs)

    def connect_with(self, connection) -> None:  # pragma: no cover - alias
        self.set_connection(connection)

    # ---- Error interfaces ----
    def last_error(self) -> Optional[str]:
        return None

    # ---- Introspection ----
    @classmethod
    def features(cls) -> Dict[str, Dict[str, Any]]:
        return getattr(cls, "__features__", {})

    # ---- Connection capabilities (GUI hints) ----
    @classmethod
    def supported_connections(cls):  # type: ignore[override]
        """Return a list of supported ConnectionType for this implementation.

        Implementations can override to narrow the list; default is TCP/IP and SERIAL.
        """
        try:
            from .connection import ConnectionType  # local import to avoid cycles
            return [ConnectionType.TCPIP, ConnectionType.SERIAL]
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            return []

    @classmethod
    def connection_placeholders(cls) -> Dict[str, str]:
        """Optional placeholders for address field per connection type name.

        Keys are ConnectionType names; values are placeholder strings.
        """
        return {
            "TCPIP": "host:port (e.g. 192.168.0.2:5025)",
            "SERIAL": "COMx (e.g. COM3)",
            "USB": "USB resource (e.g. USB0::0xAAAA::0xBBBB::INSTR)",
            "WEB": "URL (e.g. http://device/api)",
            "REMOTE": "host[:port] (e.g. 10.0.0.12 or 10.0.0.12:8815)",
        }

    # Helper to publish observable values (used by observable_getter)
    def _publish(self, event: str, **data: Any) -> None:
        self.events.publish(event, **data)


def observable_getter(event_name: str):
    """Decorator for getter methods whose return values should be observed.

    When the getter is called anywhere, it publishes the value on the event bus
    without requiring a second call.
    """

    def deco(fn: Callable[[Any], Any]):
        def wrapped(self: BaseInstrument, *args: Any, **kwargs: Any):
            val = fn(self, *args, **kwargs)
            try:
                self._publish(event_name, value=val)
            except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                logging.getLogger(__name__).exception("Failed to publish observable '%s'", event_name)
            return val

        wrapped.__name__ = fn.__name__
        wrapped.__doc__ = fn.__doc__
        return wrapped

    return deco
