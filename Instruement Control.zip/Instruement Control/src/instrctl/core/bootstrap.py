from __future__ import annotations

"""SSH bootstrapper for starting the instrctl remote agent on an edge host.

This module provides SSHBootstrapper, which can:
- Probe if an Arrow Flight agent is already running
- SSH into a host to ensure Python and required packages exist (instrctl, pyarrow)
- Install/upgrade as needed and launch the agent (POSIX and Windows)

Design notes:
- No hard dependency on paramiko at import; callers pass an SSH client with exec_command().
- POSIX uses nohup & background; Windows writes a .cmd launcher and uses 'start' to detach.
"""

from dataclasses import dataclass
from typing import Optional, Dict, Any, Tuple, Callable
import time
import shlex
import base64
import os

try:
    from pyarrow import flight  # type: ignore
except ImportError:  # pragma: no cover - used at runtime
    flight = None  # type: ignore


@dataclass
class BootstrapConfig:
    host: str
    port: int = 8815
    # SSH connection details
    ssh_host: Optional[str] = None
    ssh_port: int = 22
    ssh_user: Optional[str] = None
    ssh_password: Optional[str] = None
    ssh_key: Optional[str] = None
    # Agent startup
    start_timeout_s: float = 35.0
    python_cmd: Optional[str] = None
    pip_cmd: Optional[str] = None
    agent_port: Optional[int] = None  # defaults to port if None
    env: Optional[Dict[str, str]] = None


class SSHBootstrapper:
    def __init__(self, cfg: BootstrapConfig) -> None:
        self.cfg = cfg
        if self.cfg.agent_port is None:
            self.cfg.agent_port = self.cfg.port

    # --------------------------- SSH helpers ---------------------------
    def _ssh_exec(self, ssh, cmd: str, timeout: float = 30.0) -> Tuple[int, str, str]:
        """Run a command via SSH client, return (exit, stdout, stderr)."""
        stdin, stdout, stderr = ssh.exec_command(cmd, timeout=timeout)
        out_s = stdout.read().decode(errors="ignore") if hasattr(stdout, "read") else ""
        err_s = stderr.read().decode(errors="ignore") if hasattr(stderr, "read") else ""
        rc = stdout.channel.recv_exit_status() if hasattr(stdout, "channel") else 0
        return rc, out_s, err_s

    def _detect_platform(self, ssh) -> str:
        """Return 'posix' or 'windows' for the remote host."""
        rc, out, _ = self._ssh_exec(ssh, "uname -s")
        if rc == 0 and out.strip():
            return "posix"
        return "windows"

    # ------------------------- Flight probing -------------------------
    def _probe_flight(self) -> Dict[str, Any]:
        if flight is None:
            return {"error": "pyarrow.flight not available"}
        try:
            loc = flight.Location.for_grpc_tcp(self.cfg.host, self.cfg.port)
            client = flight.FlightClient(loc)
            # Try 'info' first, then 'ping'; treat failures as not ready
            try:
                list(client.do_action(flight.Action("info", b"")))
                return {"ok": True}
            except flight.FlightError as e1:  # type: ignore[attr-defined]
                try:
                    list(client.do_action(flight.Action("ping", b"")))
                    return {"ok": True}
                except flight.FlightError as e2:  # type: ignore[attr-defined]
                    return {"error": str(e2) or str(e1)}
        except (RuntimeError, OSError, ValueError) as e:
            return {"error": str(e)}

    # ---------------------- Python/package ensure ---------------------
    def _pick_python(self, ssh) -> Tuple[str, str]:
        plat = self._detect_platform(ssh)
        if plat == "windows":
            # Prefer the launcher with specific versions
            for ver in ("-3.10", "-3.12", "-3.11", "-3"):
                py = f"py {ver}"
                rc, out, _ = self._ssh_exec(ssh, f"{py} -V")
                if rc == 0 and (out and out.strip().lower().startswith("python")):
                    # Resolve absolute interpreter path
                    rcp, outp, _ = self._ssh_exec(ssh, f"{py} -c \"import sys; print(sys.executable)\"")
                    exe_path = (outp.splitlines()[0].strip() if (rcp == 0 and outp) else None)
                    if exe_path:
                        return f'"{exe_path}"', f'"{exe_path}" -m pip'
                    # Fallback to py launcher if resolution failed
                    return py, f"{py} -m pip"
            rc, out, _ = self._ssh_exec(ssh, "py -V")
            if rc == 0 and (out and out.strip().lower().startswith("python")):
                rcp, outp, _ = self._ssh_exec(ssh, "py -c \"import sys; print(sys.executable)\"")
                exe_path = (outp.splitlines()[0].strip() if (rcp == 0 and outp) else None)
                if exe_path:
                    return f'"{exe_path}"', f'"{exe_path}" -m pip'
                return "py", "py -m pip"
            rc, out, _ = self._ssh_exec(ssh, "where python")
            if rc == 0 and out:
                path = out.splitlines()[0].strip()
                if path:
                    rc2, out2, _ = self._ssh_exec(ssh, f'"{path}" -V')
                    if rc2 == 0 and (out2 and out2.strip().lower().startswith("python")):
                        return f'"{path}"', f'"{path}" -m pip'
        else:
            candidates = ["python", "python3"]
            for py in candidates:
                rc, out, _ = self._ssh_exec(ssh, f"{py} -V")
                if rc == 0 and (out and out.strip().lower().startswith("python")):
                    return py, f"{py} -m pip"
        raise RuntimeError("Python not available on remote host")

    def _ensure_python(self, ssh) -> None:
        py, pip = self._pick_python(ssh)
        self.cfg.python_cmd = py
        self.cfg.pip_cmd = pip

    def _ensure_packages(self, ssh) -> None:
        # Best effort ensurepip and pip upgrade
        self._ssh_exec(ssh, f"{self.cfg.python_cmd} -m ensurepip --upgrade")
        # Keep pip upgrade optional to avoid long runs during tests
        # self._ssh_exec(ssh, f"{self.cfg.pip_cmd} install --upgrade pip")
        # Install required packages
        # 1) Ensure pyarrow only if missing to save time
        rc_pa, _, _ = self._ssh_exec(ssh, f"{self.cfg.python_cmd} -c \"import importlib.util, sys; sys.exit(0 if importlib.util.find_spec('pyarrow.flight') else 1)\"")
        if rc_pa != 0:
            self._ssh_exec(ssh, f"{self.cfg.pip_cmd} install -q --disable-pip-version-check --no-input pyarrow")
        # 2) Install instrctl: prefer local path if provided for dev/test
        local_path = os.getenv("INSTRCTL_BOOTSTRAP_LOCAL_PATH")
        if local_path:
            # If instrctl is already imported from this path, skip reinstall
            check_cmd = (
                f"{self.cfg.python_cmd} -c \"import os,sys,instrctl;"
                f"target=os.path.abspath(r'{local_path}');"
                f"mod=os.path.abspath(instrctl.__file__);"
                f"sys.exit(0 if mod.lower().startswith(os.path.join(target,'src','instrctl').lower()) else 1)\""
            )
            rc_installed, _, _ = self._ssh_exec(ssh, check_cmd)
            if rc_installed == 0:
                # Already using local path; nothing to do
                return
            # Editable install is fast and updates between runs; avoid build isolation for speed
            cmd = f"{self.cfg.pip_cmd} install -q --disable-pip-version-check --no-input --no-build-isolation --no-deps -e \"{local_path}\""
        else:
            cmd = f"{self.cfg.pip_cmd} install -q --disable-pip-version-check --no-input --upgrade instrctl"
        _, out, err = self._ssh_exec(ssh, cmd)
        # Verify importability
        rc2, _out2, err2 = self._ssh_exec(
            ssh,
            f"{self.cfg.python_cmd} -c \"import importlib.util, sys;"
            "sys.exit(0 if importlib.util.find_spec('instrctl.core.remote_agent') and importlib.util.find_spec('pyarrow.flight') else 1)\"",
            timeout=20.0,
        )
        if rc2 != 0:
            details = err2 or err or out
            raise RuntimeError(
                "instrctl and/or pyarrow not importable on remote after installation. "
                f"Python: {self.cfg.python_cmd}. pip output: {details[:300]}"
            )

    # ------------------------- Agent launching ------------------------
    def _launch_agent(self, ssh) -> None:
        plat = self._detect_platform(ssh)
        port = int(self.cfg.agent_port or self.cfg.port)
        # Prefer localhost binding when targeting localhost to reduce firewall friction
        target_is_local = str(self.cfg.host) in {"127.0.0.1", "localhost"} or str(self.cfg.ssh_host or "").lower() in {"127.0.0.1", "localhost"}
        bind_host = "127.0.0.1" if target_is_local else "0.0.0.0"
        if plat == "posix":
            cmd = (
                f"nohup {self.cfg.python_cmd} -m instrctl.core.remote_agent --host {bind_host} --port {port} "
                ">> instrctl_agent.log 2>&1 & echo $!"
            )
            self._ssh_exec(ssh, cmd)
        else:
            # Windows: Create a launcher .cmd in %TEMP% and start it via 'cmd /c start'.
            # This satisfies test expectations and works reliably under OpenSSH job objects.
            try:
                parts = shlex.split(self.cfg.python_cmd or "py", posix=False)
            except ValueError:
                parts = (self.cfg.python_cmd or "py").split()
            exe = parts[0] if parts else "py"
            pre_args = parts[1:] if len(parts) > 1 else []
            run_args = pre_args + [
                "-m", "instrctl.core.remote_agent",
                "--host", bind_host,
                "--port", str(port),
            ]
            args_q = " ".join(a if " " not in a else f'"{a}"' for a in run_args)
            exe_clean = exe[1:-1] if exe.startswith('"') and exe.endswith('"') else exe

            # PowerShell: write launch_agent.cmd under %TEMP%\instrctl
            ps_mk_cmd = r"""
$dir = Join-Path $env:TEMP 'instrctl';
New-Item -ItemType Directory -Force -Path $dir | Out-Null;
$cmdf = Join-Path $dir 'launch_agent.cmd';
$log = Join-Path $dir 'instrctl_agent.out.log';
$err = Join-Path $dir 'instrctl_agent.err.log';
$lines = @(
    '@echo off',
    'setlocal',
    'cd /d "%~dp0"',
    'set LOGDIR=%TEMP%\\instrctl',
    'if not exist "%LOGDIR%" mkdir "%LOGDIR%"',
    'set OUT="%LOGDIR%\\instrctl_agent.out.log"',
    'set ERR="%LOGDIR%\\instrctl_agent.err.log"',
    'echo starting > "%OUT%"',
    '"__EXE__" __ARGS__ >> "%OUT%" 2>> "%ERR%"'
);
Set-Content -Path $cmdf -Encoding ascii -Value ($lines -join "`r`n");
"""
            ps_script = (
                ps_mk_cmd
                .replace('__EXE__', exe_clean.replace("'", "''"))
                .replace('__ARGS__', args_q.replace("'", "''"))
            )
            enc = base64.b64encode(ps_script.encode('utf-16le')).decode('ascii')
            self._ssh_exec(ssh, f"powershell -NoProfile -EncodedCommand {enc}")
            # Now start the launcher via cmd; tests capture this invocation
            self._ssh_exec(ssh, 'cmd /c set "CMDF=%TEMP%\\instrctl\\launch_agent.cmd" & start "" "%CMDF%"')

    # ----------------------------- Public -----------------------------
    def bootstrap(self, ssh_factory, progress: Optional[Callable[[str], None]] = None) -> Dict[str, Any]:
        """Ensure a Flight agent is running that matches expectations.

        ssh_factory: callable that returns a connected SSH client with exec_command().
        Returns a dict with keys: ok, started (bool), info (dict) or error (str).
        """
        def _progress(msg: str) -> None:
            if callable(progress):
                progress(str(msg))

        # 1) Probe Flight first (maybe already running)
        _progress(f"Probing Flight at {self.cfg.host}:{self.cfg.port}…")
        info = self._probe_flight()
        if not info.get("error"):
            return {"ok": True, "started": False, "info": info}

        # 2) Connect over SSH and try to launch
        _progress(f"Connecting via SSH to {self.cfg.ssh_host or self.cfg.host}…")
        ssh = ssh_factory()
        try:
            _progress("Ensuring Python is available…")
            self._ensure_python(ssh)
            _progress(f"Using Python: {self.cfg.python_cmd}")
            _progress("Ensuring packages (pyarrow, instrctl)…")
            self._ensure_packages(ssh)
            _progress("Launching agent…")
            self._launch_agent(ssh)
        finally:
            ssh.close()

        # 3) Wait for the Flight server to respond
        _progress("Waiting for agent to become ready…")
        deadline = time.time() + float(self.cfg.start_timeout_s)
        last_err = None
        while time.time() < deadline:
            info = self._probe_flight()
            if not info.get("error"):
                _progress("Agent is ready.")
                return {"ok": True, "started": True, "info": info}
            last_err = info.get("error")
            time.sleep(0.5)
        _progress(f"Agent failed to start: {last_err}")
        return {
            "ok": False,
            "error": (
                f"Agent failed to start: {last_err}. "
                "Check 'instrctl_agent.err.log' and 'instrctl_agent.out.log' on the remote host for details."
            ),
        }
