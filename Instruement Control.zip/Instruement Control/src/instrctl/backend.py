from __future__ import annotations

import importlib
from dataclasses import dataclass
from typing import Dict, Iterable, Optional, Tuple, Type, Union

from .core import BaseInstrument, InstrumentFactory, InstrumentRegistry
from .core.plugins import discover_all


@dataclass(frozen=True)
class _Identifier:
    kind: str
    model: str


class InstrumentBackend:
    """Convenience facade for registering and instantiating instruments.

    This wrapper keeps backwards compatibility with the public API used by
    the example suites while reusing the modern core registry/factory
    primitives.
    """

    def __init__(self, *, event_bus: Optional[object] = None, auto_discover: bool = False):
        self._event_bus = event_bus
        self._instances: Dict[Tuple[str, str], BaseInstrument] = {}
        if auto_discover:
            self.load_plugins()

    # ---- Discovery helpers -------------------------------------------------
    def load_plugins(self) -> None:
        """Discover built-in and user plugins via the shared discover_all helper."""

        discover_all()

    def discover_and_register(self, dotted_path: str) -> Type[BaseInstrument]:
        """Import the given class and register it with the core registry.

        Args:
            dotted_path: Fully qualified class path (``module.Class``).
        Returns:
            The imported instrument class.
        Raises:
            ImportError: If the module or attribute cannot be imported.
            TypeError: If the imported attribute is not a subclass of BaseInstrument.
        """

        cls = self._import_class(dotted_path)
        return self.register_class(cls)

    def register_class(self, cls: Type[BaseInstrument]) -> Type[BaseInstrument]:
        """Register the provided instrument class with the shared registry."""

        if not isinstance(cls, type) or not issubclass(cls, BaseInstrument):
            raise TypeError(f"{cls!r} is not a BaseInstrument subclass")

        kind = getattr(cls, "KIND", None) or getattr(cls, "kind", None)
        model = getattr(cls, "MODEL", None) or getattr(cls, "model", None)
        if not kind:
            kind = cls.__name__
        if not model:
            model = cls.__name__

        InstrumentRegistry.register(str(kind), str(model), cls)
        return cls

    # ---- Query helpers -----------------------------------------------------
    def list_registered_classes(self) -> Iterable[str]:
        """Return dotted paths of all registered instrument implementations."""

        kinds = InstrumentRegistry.list_kinds()
        items = []
        for models in kinds.values():
            for impl in models.values():
                items.append(f"{impl.__module__}.{impl.__name__}")
        return sorted(set(items))

    def get_registered_instance(
        self,
        identifier: Union[str, Tuple[str, str]],
        *,
        force_new: bool = False,
        **kwargs,
    ) -> BaseInstrument:
        """Return an instrument instance for the given identifier.

        Args:
            identifier: Either ``"kind:model"``, ``("kind", "model")``,
                or a dotted class path.
            force_new: When True, skip the cache and always create a new instance.
            **kwargs: Forwarded to the instrument constructor.
        """

        resolved = self._resolve_identifier(identifier)
        cache_key = (resolved.kind, resolved.model)

        if not force_new and cache_key in self._instances:
            return self._instances[cache_key]

        params = dict(kwargs)
        if "event_bus" not in params and self._event_bus is not None:
            params["event_bus"] = self._event_bus

        inst = InstrumentFactory.create(resolved.kind, resolved.model, **params)
        if not force_new:
            self._instances[cache_key] = inst
        return inst

    # ---- Internal helpers --------------------------------------------------
    def _import_class(self, dotted_path: str) -> Type[BaseInstrument]:
        module_name, _, attr = dotted_path.rpartition(".")
        if not module_name or not attr:
            raise ImportError(f"Invalid instrument path: {dotted_path!r}")
        module = importlib.import_module(module_name)
        cls = getattr(module, attr)
        if not isinstance(cls, type) or not issubclass(cls, BaseInstrument):
            raise TypeError(f"{dotted_path!r} is not a BaseInstrument subclass")
        return cls

    def _resolve_identifier(self, identifier: Union[str, Tuple[str, str]]) -> _Identifier:
        if isinstance(identifier, tuple):
            if len(identifier) != 2:
                raise ValueError("Tuple identifier must be (kind, model)")
            kind, model = identifier
            return _Identifier(str(kind), str(model))

        if not isinstance(identifier, str):
            raise TypeError("Identifier must be a string or (kind, model) tuple")

        if ":" in identifier:
            kind, model = identifier.split(":", 1)
            if not model:
                raise ValueError("Model component cannot be empty")
            return _Identifier(kind, model)

        cls = self._import_class(identifier)
        kind = getattr(cls, "KIND", None) or getattr(cls, "kind", None)
        model = getattr(cls, "MODEL", None) or getattr(cls, "model", None)
        if not kind or not model:
            # Ensure the class is registered to derive kind/model consistently
            self.register_class(cls)
            kind = getattr(cls, "KIND", None) or getattr(cls, "kind", None) or cls.__name__
            model = getattr(cls, "MODEL", None) or getattr(cls, "model", None) or cls.__name__
        if InstrumentRegistry.get(str(kind), str(model)) is None:
            self.register_class(cls)
        return _Identifier(str(kind), str(model))

    def clear_cache(self) -> None:
        """Forget any cached instrument instances."""

        self._instances.clear()
