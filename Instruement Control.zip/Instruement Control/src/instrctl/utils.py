"""Utility helpers for working with InstrCtl instruments.

The helpers in this module intentionally avoid any GUI-specific machinery so
that they behave the same way for both local instruments and remote proxies.
"""

from __future__ import annotations

import time
from collections.abc import Callable, Iterable, Iterator, Sequence
from typing import Any, List, Optional, Tuple


__all__ = [
    "resolve_getter",
    "collect_stream_seconds",
    "collect_stream_minutes",
]


def resolve_getter(instrument: Any, getter: Any) -> Callable[[], Any]:
    """Resolve a getter specification against *instrument*.

    The *getter* may be a string attribute name or a callable.  When a free
    function is provided it is bound to the instrument automatically so the
    helper works with remote proxies just like local instances.
    """

    if isinstance(getter, str):
        attr = getattr(instrument, getter, None)
        if attr is None:
            raise AttributeError(f"Instrument has no attribute '{getter}'")
        if not callable(attr):
            raise TypeError(f"Attribute '{getter}' is not callable")
        return attr  # already bound method (works for remote proxies)

    if callable(getter):
        # If it's already a bound method for this instrument, use it directly
        owner = getattr(getter, "__self__", None)
        if owner is instrument or owner is getattr(instrument, "_inst", None):
            return getter  # type: ignore[return-value]

        def _wrapped() -> Any:
            return getter(instrument)

        return _wrapped

    raise TypeError("getter must be a callable or attribute name")


def collect_stream_minutes(
    instrument: Any,
    getter: Any,
    minutes: float,
    *,
    poll_interval_s: float = 0.5,
    include_timestamps: bool = False,
    clock: Optional[Callable[[], float]] = None,
    sleep_fn: Optional[Callable[[float], None]] = None,
) -> List[Any]:
    """Collect data samples from *instrument* for ``minutes`` minutes.

    Parameters
    ----------
    instrument:
        Local instrument instance or remote proxy.
    getter:
        Callable or attribute name to invoke each poll.  The callable should
        return an iterable of samples, a tuple of two iterables (X/Y), a single
        value, or ``None``.  All results are normalised into a flat list.
    minutes:
        Duration to poll for.  A value of ``0`` collects a single sample.
    poll_interval_s:
        Seconds to wait between polls.  Set to ``0`` to poll as fast as the
        event loop allows.
    include_timestamps:
        When ``True`` the result list contains ``(timestamp, sample)`` tuples.
    clock, sleep_fn:
        Optional injectables for testing.  Defaults to ``time.monotonic`` and
        ``time.sleep``.
    """

    seconds = max(float(minutes), 0.0) * 60.0
    getter_fn = resolve_getter(instrument, getter)
    clock = clock or time.monotonic
    sleep_fn = sleep_fn or time.sleep

    if seconds == 0.0:
        payload = getter_fn()
        return _normalise_payload(payload, include_timestamps, clock())

    collected: List[Any] = []
    deadline = clock() + seconds
    while True:
        now = clock()
        if now >= deadline:
            break
        payload = getter_fn()
        collected.extend(_normalise_payload(payload, include_timestamps, now))
        if poll_interval_s > 0:
            sleep_fn(poll_interval_s)
        else:
            # Avoid a tight busy loop; still yield control briefly
            sleep_fn(0.0)
    return collected


def collect_stream_seconds(
    instrument: Any,
    getter: Any,
    seconds: float,
    **kwargs: Any,
) -> List[Any]:
    """Shorthand wrapper around :func:`collect_stream_minutes` using seconds."""

    minutes = float(seconds) / 60.0
    return collect_stream_minutes(instrument, getter, minutes, **kwargs)


def _normalise_payload(
    payload: Any,
    include_timestamps: bool,
    timestamp: float,
) -> List[Any]:
    """Convert arbitrary getter payloads into a flat list of samples."""

    samples: List[Any] = []
    if payload is None:
        return samples

    if include_timestamps:
        def _with_ts(item: Any) -> Tuple[float, Any]:
            return (timestamp, item)
    else:
        def _with_ts(item: Any) -> Any:
            return item

    if isinstance(payload, dict):
        samples.append(_with_ts(payload))
        return samples

    if isinstance(payload, (str, bytes)):
        samples.append(_with_ts(payload))
        return samples

    if isinstance(payload, tuple) and len(payload) == 2:
        left, right = payload
        if _is_iterable(left) and _is_iterable(right):
            zipped = list(zip(left, right))
            samples.extend(_with_ts(item) for item in zipped)
            return samples

    if _is_iterable(payload):
        # If payload is an iterator make sure we exhaust it only once
        if isinstance(payload, (list, tuple, set)):
            iterable = payload
        else:
            iterable = list(payload)
        samples.extend(_with_ts(item) for item in iterable)
        return samples

    samples.append(_with_ts(payload))
    return samples


def _is_iterable(value: Any) -> bool:
    if isinstance(value, (str, bytes)):
        return False
    try:
        iter(value)
        return True
    except TypeError:
        return False
