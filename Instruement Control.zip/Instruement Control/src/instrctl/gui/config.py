from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any, Dict

_CFG_DIR = Path.home() / ".instrctl"
_CFG_FILE = _CFG_DIR / "settings.json"


def _load() -> Dict[str, Any]:
    try:
        return json.loads(_CFG_FILE.read_text(encoding="utf-8"))
    except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
        logging.debug("Failed to load GUI config %s: %s", _CFG_FILE, e, exc_info=True)
        return {}


def _save(cfg: Dict[str, Any]) -> None:
    try:
        _CFG_DIR.mkdir(parents=True, exist_ok=True)
        _CFG_FILE.write_text(json.dumps(cfg, indent=2), encoding="utf-8")
    except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:# Best-effort; but log so issues are visible during development
        logging.warning("Failed to save GUI config %s: %s", _CFG_FILE, e, exc_info=True)


def get_use_opengl() -> bool:
    cfg = _load()
    # Default False for stability
    return bool(cfg.get("useOpenGL", False))


def set_use_opengl(enabled: bool) -> None:
    cfg = _load()
    cfg["useOpenGL"] = bool(enabled)
    _save(cfg)


# WebEngine scenario: one of "warp", "swiftshader", "d3d11", "desktop"
def get_webengine_scenario(default: str | None = None) -> str | None:
    cfg = _load()
    val = cfg.get("webengineScenario")
    if val in ("warp", "swiftshader", "d3d11", "desktop"):
        return val
    return default


def set_webengine_scenario(scenario: str) -> None:
    scenario = str(scenario).strip().lower()
    if scenario not in ("warp", "swiftshader", "d3d11", "desktop"):
        return
    cfg = _load()
    cfg["webengineScenario"] = scenario
    _save(cfg)


def get_force_external_browser() -> bool:
    cfg = _load()
    return bool(cfg.get("forceExternalBrowser", False))


def set_force_external_browser(enabled: bool) -> None:
    cfg = _load()
    cfg["forceExternalBrowser"] = bool(enabled)
    _save(cfg)
