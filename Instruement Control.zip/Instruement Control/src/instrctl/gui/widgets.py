from __future__ import annotations

import logging
import math
from typing import List, Optional, Tuple, Any, Dict
import inspect
import time
import numbers

from PySide6 import QtCore, QtWidgets, QtGui
import pyqtgraph as pg
# Disable antialiasing globally for performance; OpenGL attempted in app.py
pg.setConfigOptions(antialias=False, useOpenGL=False, background='k', foreground='w')

# Optional numpy for advanced widgets (e.g., Waterfall)
try:
    import numpy as np  # type: ignore[import-not-found]
except ImportError:  # pragma: no cover - optional dep
    np = None  # type: ignore[assignment]

from ..core import BaseInstrument, EventBus, InstrumentFactory, InstrumentRegistry, MultiInstrument
from pathlib import Path
from typing import Dict
from ..core.plugins import discover_all
import traceback

# Optional import: Remote remoting types may not be available or imported in all code paths.
try:  # Keep names private to avoid shadowing inline imports
    from ..core.remote import RemoteInstrumentProxy as _RemoteInstrumentProxy, RemoteConfig as _RemoteConfig
except ImportError:  # pragma: no cover - optional
    _RemoteInstrumentProxy = None  # type: ignore[assignment]
    _RemoteConfig = None  # type: ignore[assignment]


# ---- Shared helpers -------------------------------------------------------
def _resolve_on_instrument(inst: BaseInstrument, spec):
    """Resolve a UI getter/start/stop spec to a bound method on the instrument.

    Accepts a callable or a string. If a callable's __name__ exists on the
    instrument, the bound method will be returned to ensure consistent keys for
    the shared feed manager. Returns None when resolution fails.
    """
    if callable(spec):
        name = getattr(spec, "__name__", None)
        if name:
            bound = getattr(inst, name, None)
            if callable(bound):
                return bound
        # Fallback: attempt to bind free function to instance (best-effort)
        try:
            import types
            return types.MethodType(spec, inst)  # type: ignore[arg-type]
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            return None
    if isinstance(spec, str):
        return getattr(inst, spec, None)
    return None


def _normalize_plot_points(pts, *, start_index: int = 0) -> tuple[list[float], list[float], str]:
    """Normalize an incoming sequence of samples into explicit ``x``/``y`` arrays."""

    try:
        items = list(pts) if pts is not None else []
    except TypeError:
        return [], [], "index"

    if not items:
        return [], [], "index"

    first = items[0]
    is_pair = hasattr(first, "__len__") and not isinstance(first, (int, float)) and len(first) >= 2  # type: ignore[arg-type]

    if is_pair:
        xs: list[float] = []
        ys: list[float] = []
        for entry in items:
            try:
                x_val = float(entry[0])
                y_val = float(entry[1])
            except (TypeError, ValueError, IndexError):
                continue
            if not math.isfinite(x_val) or not math.isfinite(y_val):
                continue
            xs.append(x_val)
            ys.append(y_val)
        if not xs:
            return [], [], "explicit"
        return xs, ys, "explicit"

    ys: list[float] = []
    for entry in items:
        try:
            y_val = float(entry)
        except (TypeError, ValueError):
            continue
        if not math.isfinite(y_val):
            continue
        ys.append(y_val)

    if not ys:
        return [], [], "index"

    base = int(start_index)
    xs = [base + i for i in range(len(ys))]
    return xs, ys, "index"



def _select_follow_window(xs, ys, follow_pts: Optional[int]):
    """Return the trailing window of ``xs``/``ys`` based on ``follow_pts``.

    When ``follow_pts`` is positive, the last ``follow_pts`` samples are
    returned; otherwise the original sequences are returned unchanged.
    """

    try:
        n = len(xs)
        m = len(ys)
    except TypeError:
        # Fall back to materializing when objects do not expose ``len``
        xs = list(xs)
        ys = list(ys)
        n = len(xs)
        m = len(ys)

    if n != m:
        raise ValueError("X/Y length mismatch")

    try:
        limit = int(follow_pts) if follow_pts is not None else 0
    except (TypeError, ValueError):
        limit = 0

    if limit <= 0 or n <= limit:
        return xs, ys

    return xs[-limit:], ys[-limit:]


def _compute_plot_bounds(xs, ys) -> tuple[float, float, float, float]:
    """Compute padded axis bounds for the provided samples.

    Raises ``ValueError`` when the input sequences are empty or mismatched in
    length. Degenerate axes are expanded slightly so plots remain visible.
    """

    xs_seq = xs
    ys_seq = ys

    try:
        n = len(xs_seq)
    except TypeError:
        xs_seq = list(xs_seq)
        n = len(xs_seq)
    try:
        m = len(ys_seq)
    except TypeError:
        ys_seq = list(ys_seq)
        m = len(ys_seq)

    if n == 0 or m == 0:
        raise ValueError("Plot data is empty")
    if n != m:
        raise ValueError("X/Y length mismatch")

    xmin = xmax = ymin = ymax = None
    if np is not None:
        try:
            xs_arr = np.asarray(xs_seq, dtype=np.float64)
            ys_arr = np.asarray(ys_seq, dtype=np.float64)
            if xs_arr.size == 0 or ys_arr.size == 0:
                raise ValueError("Plot data is empty")
            xmin = float(np.min(xs_arr))
            xmax = float(np.max(xs_arr))
            ymin = float(np.min(ys_arr))
            ymax = float(np.max(ys_arr))
        except (TypeError, ValueError, AttributeError):
            xmin = xmax = ymin = ymax = None

    if xmin is None:
        xmin = float(min(xs_seq))
        xmax = float(max(xs_seq))
        ymin = float(min(ys_seq))
        ymax = float(max(ys_seq))

    if xmax == xmin:
        xmin -= 0.5
        xmax += 0.5
    if ymax == ymin:
        ymin -= 0.5
        ymax += 0.5

    return xmin, xmax, ymin, ymax


def _qt_object_is_alive(obj) -> bool:
    """Return True when ``obj`` is a valid, non-destroyed Qt object."""

    if obj is None:
        return False
    try:
        obj.metaObject()
    except (AttributeError, RuntimeError, OSError, ValueError, TypeError):
        return False
    return True


def _remote_stream_attr(getter: Any) -> Optional[str]:
    """Best-effort resolution of the remote getter name for stream consumers."""

    current = getter
    seen_ids: set[int] = set()
    while current is not None:
        ident = id(current)
        if ident in seen_ids:
            break
        seen_ids.add(ident)
        name = getattr(current, "_orig_attr", None)
        if isinstance(name, str) and name:
            return name
        name = getattr(current, "__name__", None)
        if isinstance(name, str) and name:
            return name
        fallback = getattr(current, "func", None)
        if fallback is None:
            fallback = getattr(current, "__wrapped__", None)
        current = fallback
    return None


# Shared UI clock (single QTimer) used to coalesce plot repaints
# For high-frequency data streaming, a slower update rate prevents GUI freezing
class _UiClock(QtCore.QObject):
    tick = QtCore.Signal()

    def __init__(self, interval_ms: int = 50):  # Changed from 33ms to 50ms (20 Hz instead of 30 Hz)
        super().__init__()
        self._timer = QtCore.QTimer(self)
        self._timer.setTimerType(QtCore.Qt.CoarseTimer)
        self._timer.timeout.connect(lambda: self.tick.emit())
        self._interval_ms = max(1, int(interval_ms))
        self._started = False

    def ensure_started(self) -> None:
        """Start the shared timer once a Q(Core)Application exists."""
        if self._started:
            return
        # Defer start until after QApplication is created
        if QtCore.QCoreApplication.instance() is None:
            return
        self._timer.start(self._interval_ms)
        self._started = True

# Global singleton clock (created on first import)
_ui_clock = _UiClock()


class PlotWidgetBase(QtWidgets.QWidget):
    """Common lifecycle management for plot widgets.

    Ensures timers are stopped, UI clock slots are disconnected, shared feeds
    are unsubscribed, and open files are closed when the widget is closed.
    Prevents lingering callbacks after the widget is gone, avoiding crashes and
    UI slowdowns without swallowing exceptions.
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._disposed = False
        self._owned_timers: list[QtCore.QTimer] = []
        self._ui_clock_slots: list = []

    def _register_timer(self, t: QtCore.QTimer) -> None:
        if isinstance(t, QtCore.QTimer):
            self._owned_timers.append(t)

    def _register_ui_clock_slot(self, slot) -> None:
        try:
            _ui_clock.tick.connect(slot)
            self._ui_clock_slots.append(slot)
        except (TypeError, RuntimeError):
            logging.getLogger(__name__).debug("Failed to connect UI clock slot", exc_info=True)

    def closeEvent(self, event):  # type: ignore[override]
        # Mark disposed and stop timers proactively
        self._disposed = True
        for t in list(self._owned_timers):
            try:
                t.stop()
            except RuntimeError:
                logging.getLogger(__name__).debug(
                    "PlotWidgetBase.closeEvent: failed to stop owned timer", exc_info=True
                )
        # Disconnect UI clock slots
        for slot in list(self._ui_clock_slots):
            try:
                _ui_clock.tick.disconnect(slot)
            except (TypeError, RuntimeError):
                logging.getLogger(__name__).debug(
                    "PlotWidgetBase.closeEvent: failed to disconnect UI clock slot", exc_info=True
                )
        self._ui_clock_slots.clear()
        # Unsubscribe shared feeds if present
        if getattr(self, "_feed_handle", None) is not None:
            try:
                _feed_mgr.stop(self._feed_handle)
                _feed_mgr.unsubscribe(self._feed_handle)
            except (RuntimeError, AttributeError):
                logging.getLogger(__name__).debug(
                    "PlotWidgetBase.closeEvent: failed to stop/unsubscribe _feed_handle",
                    exc_info=True,
                )
        if getattr(self, "_feed_handles", None):
            for _name, handle in list(self._feed_handles.items()):
                try:
                    _feed_mgr.stop(handle)
                    _feed_mgr.unsubscribe(handle)
                except (RuntimeError, AttributeError):
                    logging.getLogger(__name__).debug(
                        "PlotWidgetBase.closeEvent: failed to stop/unsubscribe handle %s",
                        _name,
                        exc_info=True,
                    )
            try:
                self._feed_handles.clear()
            except AttributeError:
                logging.getLogger(__name__).debug(
                    "PlotWidgetBase.closeEvent: failed to clear _feed_handles", exc_info=True
                )
        # Close open file handles if any
        try:
            f = getattr(self, "_file", None)
            if f:
                f.close()
        except OSError:
            logging.getLogger(__name__).debug(
                "PlotWidgetBase.closeEvent: failed to close file handle", exc_info=True
            )
        super().closeEvent(event)


# Frontend-only shared feed manager to prevent multiple widgets from consuming
# the same instrument getter independently. Polls each (instrument, method_name)
# at most once per minimal requested interval and fans out data to subscribers
# with per-subscriber throttling to respect their configured intervals.
class _SharedGetterFeedManager(QtCore.QObject):
    class _Feed(QtCore.QObject):
        def __init__(self, instrument: BaseInstrument, method_name: str):
            super().__init__()
            self._inst = instrument
            self._method_name = method_name
            self._timer = QtCore.QTimer(self)
            self._timer.setTimerType(QtCore.Qt.PreciseTimer)
            self._timer.timeout.connect(self._on_timeout)
            # sub_id -> {interval:int, cb:callable, active:bool, tmr:QElapsedTimer, acc:bool, cursor:int}
            self._subs = {}
            self._next_id = 1
            # Journal of polled batches for accumulating subscribers
            self._journal = []  # list of batches (each batch is normalized list)
            # Last time we polled the getter (epoch seconds)
            self._last_polled_at: Optional[float] = None

        def add_sub(self, interval_ms: int, cb, accumulate: bool = True) -> int:
            sid = self._next_id
            self._next_id += 1
            t = QtCore.QElapsedTimer()
            t.start()
            self._subs[sid] = {"interval": int(max(1, interval_ms)), "cb": cb, "active": False, "tmr": t, "acc": bool(accumulate), "cursor": 0}
            return sid

        def remove_sub(self, sid: int) -> None:
            self._subs.pop(sid, None)
            self._update_timer()

        def start(self, sid: int) -> None:
            sub = self._subs.get(sid)
            if not sub:
                return
            sub["active"] = True
            # reset throttle so delivery occurs promptly
            try:
                sub["tmr"].restart()
            except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                logging.getLogger(__name__).debug("Failed to restart elapsed timer for subscriber %s", sid, exc_info=True)
            self._update_timer()

        def stop(self, sid: int) -> None:
            sub = self._subs.get(sid)
            if not sub:
                return
            sub["active"] = False
            self._update_timer()

        def update_interval(self, sid: int, interval_ms: int) -> None:
            sub = self._subs.get(sid)
            if not sub:
                return
            sub["interval"] = int(max(1, interval_ms))
            self._update_timer()

        def _min_active_interval(self) -> Optional[int]:
            mins = [sub["interval"] for sub in self._subs.values() if sub.get("active")]
            return min(mins) if mins else None

        def _update_timer(self) -> None:
            min_int = self._min_active_interval()
            if min_int is None:
                try:
                    self._timer.stop()
                except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                    logging.getLogger(__name__).debug("Failed to stop feed timer for %s.%s", self._inst.__class__.__name__, self._method_name, exc_info=True)
                return
            try:
                if self._timer.isActive() and self._timer.interval() == int(min_int):
                    return
            except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                logging.getLogger(__name__).debug("Feed timer state check failed for %s.%s", self._inst.__class__.__name__, self._method_name, exc_info=True)
            try:
                self._timer.start(int(min_int))
            except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                logging.getLogger(__name__).warning("Failed to start feed timer for %s.%s", self._inst.__class__.__name__, self._method_name, exc_info=True)

        def _on_timeout(self) -> None:
            # Poll getter exactly once and fan out to subscribers with per-sub throttling
            getter = getattr(self._inst, self._method_name, None)
            if not callable(getter):
                return
            try:
                pts = getter()
            except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                logging.getLogger(__name__).warning("Feed getter error for %s.%s: %s", self._inst.__class__.__name__, self._method_name, e)
                pts = None
            try:
                if isinstance(pts, (list, tuple)):
                    pts = list(pts)
                else:
                    pts = []
            except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                pts = []
            # Track last poll time regardless of points
            try:
                self._last_polled_at = time.time()
            except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                self._last_polled_at = None
            # Append this batch to the journal for accumulating subscribers
            if pts:
                self._journal.append(pts)
            # Fan-out
            for sid, sub in list(self._subs.items()):
                if not sub.get("active"):
                    continue
                tmr: QtCore.QElapsedTimer = sub.get("tmr")  # type: ignore[assignment]
                try:
                    elapsed = tmr.elapsed()
                except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                    elapsed = sub.get("interval", 0)
                if elapsed >= sub.get("interval", 0):
                    cb = sub.get("cb")
                    if callable(cb):
                        try:
                            if sub.get("acc", True):
                                # Deliver all batches since last cursor
                                cur = int(sub.get("cursor", 0))
                                if cur < 0: cur = 0
                                batches = self._journal[cur:]
                                merged = []
                                for b in batches:
                                    try:
                                        if isinstance(b, (list, tuple)):
                                            merged.extend(b)
                                    except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                                        logging.getLogger(__name__).debug("Failed to merge batch for subscriber %s", sid, exc_info=True)
                                cb(merged)
                                sub["cursor"] = len(self._journal)
                            else:
                                # Non-accumulating: deliver only latest batch
                                cb(pts)
                        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                            logging.getLogger(__name__).warning("Subscriber callback error: %s", e)
                    try:
                        tmr.restart()
                    except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                        logging.getLogger(__name__).debug("Failed to restart per-subscriber timer %s", sid, exc_info=True)
            # Prune journal up to minimum cursor across accumulating subscribers to bound memory
            try:
                cursors = [int(sub.get("cursor", 0)) for sub in self._subs.values() if sub.get("acc", True)]
                if cursors:
                    min_cur = min(cursors)
                    if min_cur > 0:
                        # drop first min_cur batches
                        self._journal = self._journal[min_cur:]
                        for sub in self._subs.values():
                            if sub.get("acc", True):
                                sub["cursor"] = max(0, int(sub.get("cursor", 0)) - min_cur)
            except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                logging.getLogger(__name__).debug("Failed to prune feed journal for %s.%s", self._inst.__class__.__name__, self._method_name, exc_info=True)

    def __init__(self):
        super().__init__()
        self._feeds = {}  # key -> _Feed

    def _key_for(self, instrument: BaseInstrument, getter) -> Optional[tuple]:
        name = getattr(getter, "__name__", None)
        if name is None:
            return None
        return (id(instrument), name)

    def subscribe(self, instrument: BaseInstrument, getter, interval_ms: int, callback, accumulate: bool = True):
        key = self._key_for(instrument, getter)
        if key is None:
            return None
        feed = self._feeds.get(key)
        if feed is None:
            feed = self._Feed(instrument, key[1])
            self._feeds[key] = feed
        sid = feed.add_sub(int(interval_ms), callback, accumulate=accumulate)
        return (key, sid)

    def unsubscribe(self, handle) -> None:
        if not handle:
            return
        key, sid = handle
        feed = self._feeds.get(key)
        if not feed:
            return
        feed.remove_sub(sid)
        # Drop feed if no subscribers remain
        if not feed._subs:
            try:
                inst = getattr(feed, "_inst", None)
                meth = getattr(feed, "_method_name", None)
                stop_stream = getattr(inst, "_stop_stream_consumer", None) if inst is not None else None
                if callable(stop_stream) and isinstance(meth, str):
                    try:
                        stop_stream(meth)
                    except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                        logging.getLogger(__name__).warning("Failed to stop remote stream for %s.%s: %s", inst.__class__.__name__ if inst is not None else "?", meth, e)
            except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                logging.getLogger(__name__).debug("Remote stream shutdown hook failed", exc_info=True)
            feed._timer.stop()
            self._feeds.pop(key, None)

    def start(self, handle) -> None:
        if not handle:
            return
        key, sid = handle
        feed = self._feeds.get(key)
        if feed:
            feed.start(sid)

    def stop(self, handle) -> None:
        if not handle:
            return
        key, sid = handle
        feed = self._feeds.get(key)
        if feed:
            feed.stop(sid)

    def update_interval(self, handle, interval_ms: int) -> None:
        if not handle:
            return
        key, sid = handle
        feed = self._feeds.get(key)
        if feed:
            feed.update_interval(sid, int(interval_ms))

    def snapshot(self) -> List[Dict[str, Any]]:
        """Return a summary of active feeds for diagnostics UI.

        Each item contains: instrument, class, getter, subscribers, active,
        accumulating, min_interval_ms, last_polled_at.
        """
        items: List[Dict[str, Any]] = []
        for (inst_id, getter_name), feed in self._feeds.items():
            inst = getattr(feed, "_inst", None)
            # Instrument label
            try:
                label = f"{getattr(inst, 'kind', inst.__class__.__name__)}:{getattr(inst, 'model', '')}".rstrip(":")
            except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                label = str(inst)
            # Subscriber stats
            subs = getattr(feed, "_subs", {}) or {}
            total = len(subs)
            active = sum(1 for s in subs.values() if s.get("active"))
            acc = sum(1 for s in subs.values() if s.get("acc", True))
            # Min interval among active subs
            try:
                mins = [int(s.get("interval", 0)) for s in subs.values() if s.get("active")]
                min_interval = min(mins) if mins else None
            except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                min_interval = None
            items.append({
                "instrument": label,
                "class": inst.__class__.__name__ if inst is not None else "",
                "getter": getter_name,
                "subscribers": total,
                "active": active,
                "accumulating": acc,
                "min_interval_ms": min_interval,
                "last_polled_at": getattr(feed, "_last_polled_at", None),
            })
        return items


_feed_mgr = _SharedGetterFeedManager()


class AddInstrumentDialog(QtWidgets.QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Add Instrument")
        self.kind_combo = QtWidgets.QComboBox()
        self.model_combo = QtWidgets.QComboBox()
        self._conn_placeholders: Dict[str, str] = {}
        self._conn_fields_schema: Dict[str, list] = {}
        self._conn_extra_editors: Dict[str, QtWidgets.QWidget] = {}
        kinds = InstrumentRegistry.list_kinds()
        self.kind_combo.addItems(sorted(kinds.keys()))
        self.kind_combo.currentTextChanged.connect(self._refresh_models)
        self._kinds = kinds

        form = QtWidgets.QFormLayout()
        form.addRow("Type", self.kind_combo)
        form.addRow("Model", self.model_combo)

        # Connection section (populated after model selection)
        self.conn_group = QtWidgets.QGroupBox("Connection")
        conn_lay = QtWidgets.QFormLayout(self.conn_group)
        self._conn_form = conn_lay
        self.conn_type_combo = QtWidgets.QComboBox()
        self.conn_addr_edit = QtWidgets.QLineEdit()
        self.conn_timeout = QtWidgets.QDoubleSpinBox()
        self.conn_timeout.setRange(0.1, 120.0)
        self.conn_timeout.setSingleStep(0.5)
        self.conn_timeout.setValue(5.0)
        conn_lay.addRow("Type", self.conn_type_combo)
        conn_lay.addRow("Address", self.conn_addr_edit)
        conn_lay.addRow("Timeout (s)", self.conn_timeout)
        # Remote agent toggle + fields
        self.conn_remote_chk = QtWidgets.QCheckBox("Use remote agent")
        self.conn_remote_chk.setChecked(False)
        conn_lay.addRow(self.conn_remote_chk)
        # Remote extras container
        self._remote_group = QtWidgets.QGroupBox("Remote Agent")
        self._remote_group.setVisible(False)
        remote_form = QtWidgets.QFormLayout(self._remote_group)
        self._remote_host = QtWidgets.QLineEdit()
        self._remote_host.setPlaceholderText("localhost or 127.0.0.1")
        self._remote_host.setText("localhost")  # Set default value
        self._remote_port = QtWidgets.QSpinBox()
        self._remote_port.setRange(1, 65535)
        self._remote_port.setValue(18861)  # RPyC control port
        self._remote_port_data = QtWidgets.QSpinBox()
        self._remote_port_data.setRange(1, 65535)
        self._remote_port_data.setValue(8815)  # Arrow Flight data port
        self._remote_use_ssh = QtWidgets.QCheckBox("Use SSH tunnel")
        self._remote_ssh_user = QtWidgets.QLineEdit()
        self._remote_ssh_user.setPlaceholderText("SSH user")
        self._remote_ssh_password = QtWidgets.QLineEdit()
        self._remote_ssh_password.setEchoMode(QtWidgets.QLineEdit.Password)
        self._remote_ssh_password.setPlaceholderText("SSH password (optional)")
        self._remote_ssh_keyfile = QtWidgets.QLineEdit()
        self._remote_ssh_keyfile.setPlaceholderText("SSH key file (optional)")
        self._remote_token = QtWidgets.QLineEdit()
        self._remote_token.setPlaceholderText("Auth token (optional)")
        remote_form.addRow("Host", self._remote_host)
        remote_form.addRow("Control Port", self._remote_port)
        remote_form.addRow("Data Port", self._remote_port_data)
        remote_form.addRow(self._remote_use_ssh)
        remote_form.addRow("SSH user", self._remote_ssh_user)
        remote_form.addRow("SSH password", self._remote_ssh_password)
        remote_form.addRow("SSH key file", self._remote_ssh_keyfile)
        remote_form.addRow("Auth token", self._remote_token)
        conn_lay.addRow(self._remote_group)
        self.conn_remote_chk.toggled.connect(self._remote_group.setVisible)
        # Update connection options whenever model changes
        self.model_combo.currentTextChanged.connect(self._refresh_connection_options)
        # Handle connection-type changes once; behavior driven by _conn_placeholders
        self.conn_type_combo.currentIndexChanged.connect(self._on_conn_type_change)

        btn_box = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Ok | QtWidgets.QDialogButtonBox.Cancel)
        btn_box.accepted.connect(self.accept)
        btn_box.rejected.connect(self.reject)

        layout = QtWidgets.QVBoxLayout(self)
        layout.addLayout(form)
        layout.addWidget(self.conn_group)
        layout.addWidget(btn_box)

        # Populate initial models and connection options now that widgets exist
        self._refresh_models(self.kind_combo.currentText())

    def _refresh_models(self, kind: str) -> None:
        self.model_combo.clear()
        models = sorted(self._kinds.get(kind, {}).keys())
        self.model_combo.addItems(models)
        # Also refresh connection options for the first model
        if models:
            self._refresh_connection_options(models[0])

    def _refresh_connection_options(self, model: str) -> None:
        # Determine selected kind+model impl and query supported connections
        kind = self.kind_combo.currentText()
        impl = self._kinds.get(kind, {}).get(model)
        self.conn_type_combo.clear()
        self.conn_addr_edit.clear()
        if impl is None:
            self.conn_group.setEnabled(False)
            return
        self.conn_group.setEnabled(True)
        types = list(getattr(impl, "supported_connections")())
        from ..core.connection import ConnectionType
        if not types:
            types = [ConnectionType.TCPIP, ConnectionType.SERIAL]
        # Populate combo with names and keep actual enum in itemData
        for t in types:
            name = getattr(t, "name", str(t))
            self.conn_type_combo.addItem(name, t)
        # Placeholders
        try:
            ph = dict(getattr(impl, "connection_placeholders")())
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            ph = {}
        # Store placeholders for use in the common handler
        self._conn_placeholders = ph
        # Optional dynamic fields per connection type (schema provided by implementation)
        schema_map = {}
        try:
            fields_fn = getattr(impl, "connection_fields", None)
            if callable(fields_fn):
                # Expect: dict { type_name -> [ {name,label,type,placeholder,default,required} ] }
                maybe_schema = fields_fn()
                if isinstance(maybe_schema, dict):
                    schema_map = maybe_schema
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            schema_map = {}
        schema_map = dict(schema_map)
        remote_fields = list(schema_map.get("REMOTE", []))
        # Only add if not already present
        existing_names = {str(f.get("name")) for f in remote_fields}
        builtin = [
            {"name": "use_ssh", "label": "Use SSH tunnel", "type": "bool", "default": False},
            {"name": "ssh_user", "label": "SSH user", "type": "text", "placeholder": "pi"},
            {"name": "ssh_password", "label": "SSH password", "type": "password", "placeholder": "optional"},
            {"name": "ssh_keyfile", "label": "SSH key file", "type": "text", "placeholder": "~/.ssh/id_rsa"},
            {"name": "token", "label": "Auth token", "type": "text", "placeholder": "optional"},
        ]
        for f in builtin:
            if f["name"] not in existing_names:
                remote_fields.append(f)
        schema_map["REMOTE"] = remote_fields
        self._conn_fields_schema = schema_map
        # Trigger once to set placeholder and address enablement
        self._on_conn_type_change(self.conn_type_combo.currentIndex())

    def _on_conn_type_change(self, _idx: int) -> None:
        cur = self.conn_type_combo.currentData()
        # Support both Enum-like (with .name) and plain string types from plugins
        name = getattr(cur, "name", None)
        if not name and cur is not None:
            try:
                name = str(cur)
            except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                name = None
        ph = getattr(self, "_conn_placeholders", {}) or {}
        self.conn_addr_edit.setPlaceholderText(ph.get(name, ""))
        if isinstance(name, str) and name.upper() == "DEMO":
            self.conn_addr_edit.clear()
            self.conn_addr_edit.setEnabled(False)
        else:
            self.conn_addr_edit.setEnabled(True)
        # Remove previously added dynamic remote rows (if any)
        for key in list(getattr(self, "_conn_extra_editors", {}).keys()):
            pass  # cleared below by rebuild
        self._remove_form_row_widget(self.conn_timeout)
        # Remove existing dynamic rows
        for key, w in list(self._conn_extra_editors.items()):
            # Find and remove the corresponding row from the form
            self._remove_form_row_widget(w)
        self._conn_extra_editors.clear()
        schema_map = getattr(self, "_conn_fields_schema", {}) or {}
        fields = schema_map.get(name, []) if isinstance(schema_map, dict) else []
        for field in fields:
            fname = str(field.get("name", ""))
            flabel = str(field.get("label", fname or "Field"))
            ftype = str(field.get("type", "text")).lower()
            placeholder = str(field.get("placeholder", ""))
            default = field.get("default", "")
            editor: QtWidgets.QWidget
            if ftype in ("int", "integer", "number"):
                spin = QtWidgets.QSpinBox()
                spin.setRange(0, 65535)
                if isinstance(default, int):
                    spin.setValue(int(default))
                editor = spin
            elif ftype in ("bool", "boolean"):
                chk = QtWidgets.QCheckBox()
                chk.setChecked(bool(default))
                editor = chk
            else:
                line = QtWidgets.QLineEdit()
                if placeholder:
                    line.setPlaceholderText(placeholder)
                if default not in (None, ""):
                    line.setText(str(default))
                if ftype in ("password", "secret"):
                    line.setEchoMode(QtWidgets.QLineEdit.Password)
                editor = line
            self._conn_form.addRow(flabel, editor)
            if fname:
                self._conn_extra_editors[fname] = editor
        self._conn_form.addRow("Timeout (s)", self.conn_timeout)

    def _remove_form_row_widget(self, w: QtWidgets.QWidget) -> None:
        form: QtWidgets.QFormLayout = self._conn_form  # type: ignore[assignment]
        for i in range(form.rowCount() - 1, -1, -1):
            item = form.itemAt(i, QtWidgets.QFormLayout.FieldRole)
            if item and item.widget() is w:
                # Remove both label and field
                lab_item = form.itemAt(i, QtWidgets.QFormLayout.LabelRole)
                if lab_item and lab_item.widget():
                    lab = lab_item.widget()
                    form.removeWidget(lab)
                    lab.setParent(None)
                    lab.deleteLater()
                field = item.widget()
                form.removeWidget(field)
                field.setParent(None)
                field.deleteLater()
                break

    def selected(self) -> Optional[tuple[str, str]]:
        if self.result() == QtWidgets.QDialog.Accepted:
            return self.kind_combo.currentText(), self.model_combo.currentText()
        return None

    def connection_params(self):
        # Return kwargs dict for connect(), including extra fields if present.
        t = self.conn_type_combo.currentData()
        if t is None:
            return None
        params: Dict[str, Any] = {"type": t}
        try:
            addr = self.conn_addr_edit.text().strip() or None
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            addr = None
        params["address"] = addr
        params["timeout_s"] = float(self.conn_timeout.value())
        # Remote block
        if self.conn_remote_chk.isChecked():
            remote: Dict[str, Any] = {}
            host = self._remote_host.text().strip()
            if host:
                remote["host"] = host
            remote["port"] = int(self._remote_port.value())
            remote["use_ssh"] = bool(self._remote_use_ssh.isChecked())
            u = self._remote_ssh_user.text().strip()
            if u:
                remote["ssh_user"] = u
            p = self._remote_ssh_password.text().strip()
            if p:
                remote["ssh_password"] = p
            k = self._remote_ssh_keyfile.text().strip()
            if k:
                remote["ssh_keyfile"] = k
            tok = self._remote_token.text().strip()
            if tok:
                remote["token"] = tok
            params["remote"] = remote
        # Add extra fields
        for name, editor in (self._conn_extra_editors or {}).items():
            val: Any = None
            if isinstance(editor, QtWidgets.QLineEdit):
                val = editor.text().strip()
            elif isinstance(editor, QtWidgets.QSpinBox):
                val = int(editor.value())
            elif isinstance(editor, QtWidgets.QCheckBox):
                val = bool(editor.isChecked())
            else:
                # Fallback for other widgets
                try:
                    val = editor.text()  # type: ignore[attr-defined]
                except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                    val = None
            if val in ("", None):
                continue
            params[name] = val
        return params


class LogViewer(QtWidgets.QPlainTextEdit):
    def __init__(self):
        super().__init__()
        self.setReadOnly(True)

    @QtCore.Slot(str)
    def append_log(self, msg: str) -> None:
        self.appendPlainText(msg)


class DiagnosticsPanel(QtWidgets.QWidget):
    def __init__(self):
        super().__init__()
        self._table = QtWidgets.QTableWidget(0, 7)
        self._table.setHorizontalHeaderLabels([
            "Instrument", "Getter", "Subs", "Active", "Accum", "Min Int (ms)", "Last Poll"
        ])
        self._table.horizontalHeader().setStretchLastSection(True)
        self._table.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
        self._refresh_btn = QtWidgets.QPushButton("Refresh")
        self._refresh_btn.clicked.connect(self.refresh)
        layout = QtWidgets.QVBoxLayout(self)
        layout.addWidget(self._table)
        layout.addWidget(self._refresh_btn)

    def refresh(self) -> None:
        data = _feed_mgr.snapshot()
        self._table.setRowCount(len(data))
        for r, item in enumerate(data):
            instr = str(item.get("instrument", ""))
            getter = str(item.get("getter", ""))
            subs = str(item.get("subscribers", 0))
            active = str(item.get("active", 0))
            accum = str(item.get("accumulating", 0))
            mint = item.get("min_interval_ms")
            mintxt = str(mint) if mint is not None else ""
            last = item.get("last_polled_at")
            if isinstance(last, (int, float)):
                try:
                    ago = max(0.0, time.time() - float(last))
                    lasttxt = f"{ago:.2f}s ago"
                except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                    lasttxt = ""
            else:
                lasttxt = ""
            for c, txt in enumerate([instr, getter, subs, active, accum, mintxt, lasttxt]):
                self._table.setItem(r, c, QtWidgets.QTableWidgetItem(txt))


class UnitLineEdit(QtWidgets.QLineEdit):
    """Line edit that parses engineering suffixes like k, M, G, m, u/µ, n.

    Emits 'committed' when the value should be applied:
      - Return/Enter pressed
            - Focus leaves the editor
    """

    committed = QtCore.Signal()

    MULTS = {
        "k": 1e3,
        "K": 1e3,
        "M": 1e6,
        "G": 1e9,
        "m": 1e-3,
        "u": 1e-6,
        "µ": 1e-6,
        "n": 1e-9,
    }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Unify commit events
        try:
            self.returnPressed.connect(self._emit_committed)
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            logging.getLogger(__name__).debug("UnitLineEdit: returnPressed connection failed", exc_info=True)
        self.editingFinished.connect(self._emit_committed)

    # Commit is intentionally not triggered on mouse-leave to avoid
    # overly eager application of partial edits. Focus-out and Enter
    # are sufficient and predictable for users.

    def _emit_committed(self) -> None:
        self.committed.emit()

    def value(self) -> Optional[float]:
        text = self.text().strip()
        if not text:
            return None
        return float(text)
        try:
            num = "".join(ch for ch in text if (ch.isdigit() or ch in ".-+eE"))
            suf = text[len(num) :].strip()[:1]
            base = float(num)
            mult = self.MULTS.get(suf, 1.0)
            return base * mult
        except (ValueError, TypeError):
            return None


def _format_engineering(value: float, unit: Optional[str] = None) -> str:
    try:
        v = float(value)
    except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
        return str(value)
    # Choose a suffix based on magnitude
    suffixes = [
        (1e9, "G"),
        (1e6, "M"),
        (1e3, "k"),
        (1.0, ""),
        (1e-3, "m"),
        (1e-6, "µ"),
        (1e-9, "n"),
    ]
    abs_v = abs(v)
    mult, suf = next(((m, s) for m, s in suffixes if abs_v >= m), (1.0, ""))
    disp = v / mult
    txt = f"{disp:.6g}{suf}"
    return f"{txt} {unit}".strip() if unit else txt


class LabeledSlider(QtWidgets.QWidget):
    valueChanged = QtCore.Signal(int)
    released = QtCore.Signal(int)

    def __init__(self, minimum: int, maximum: int, value: int = 0):
        super().__init__()
        self.slider = QtWidgets.QSlider(QtCore.Qt.Horizontal)
        self.slider.setRange(minimum, maximum)
        self.slider.setValue(value)
        self.label = QtWidgets.QLabel(str(value))
        layout = QtWidgets.QHBoxLayout(self)
        layout.addWidget(self.slider)
        layout.addWidget(self.label)
        self.slider.valueChanged.connect(self._on_change)
        self.slider.sliderReleased.connect(lambda: self.released.emit(self.slider.value()))

    def _on_change(self, v: int):
        self.label.setText(str(v))
        self.valueChanged.emit(v)

    def value(self) -> int:
        return self.slider.value()


class ToggleSwitch(QtWidgets.QCheckBox):
    def __init__(self):
        super().__init__("On/Off")
        self.setTristate(False)


class GPIOPanel(QtWidgets.QGroupBox):
    """Simple GPIO panel for a GpioController-like instrument."""

    def __init__(self, instrument: BaseInstrument):
        super().__init__("GPIO")
        self.instrument = instrument
        layout = QtWidgets.QGridLayout(self)
        try:
            n = int(instrument.pins_count()) if hasattr(instrument, "pins_count") else 0
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            n = 0
        self._mode_boxes: list[QtWidgets.QComboBox] = []
        self._value_checks: list[QtWidgets.QCheckBox] = []
        for i in range(n):
            layout.addWidget(QtWidgets.QLabel(f"Pin {i}"), i, 0)
            mode = QtWidgets.QComboBox()
            mode.addItems(["IN", "OUT"])
            layout.addWidget(mode, i, 1)
            val = QtWidgets.QCheckBox("High")
            layout.addWidget(val, i, 2)
            self._mode_boxes.append(mode)
            self._value_checks.append(val)

            def make_mode_handler(pin: int):
                def handler(text: str):
                    try:
                        instrument.set_pin_mode(pin, text)
                    except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                        QtWidgets.QMessageBox.critical(self, "GPIO", str(e))
                return handler

            def make_value_handler(pin: int):
                def handler(checked: bool):
                    try:
                        instrument.write_pin(pin, 1 if checked else 0)
                    except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                        QtWidgets.QMessageBox.critical(self, "GPIO", str(e))
                return handler

            mode.currentTextChanged.connect(make_mode_handler(i))
            val.toggled.connect(make_value_handler(i))

        # Subscribe to gpio events for UI updates
        if hasattr(instrument, "events"):
            instrument.events.subscribe("gpio", self._on_gpio_event)

    def _on_gpio_event(self, e):
        pin = int(e.data.get("pin", -1))
        mode = e.data.get("mode")
        value = int(e.data.get("value", 0))
        if 0 <= pin < len(self._mode_boxes):
            try:
                self._mode_boxes[pin].blockSignals(True)
                if mode in ("IN", "OUT"):
                    self._mode_boxes[pin].setCurrentText(mode)
            finally:
                self._mode_boxes[pin].blockSignals(False)
        if 0 <= pin < len(self._value_checks):
            try:
                self._value_checks[pin].blockSignals(True)
                self._value_checks[pin].setChecked(bool(value))
            finally:
                self._value_checks[pin].blockSignals(False)


class FrequencyPlotWidget(QtWidgets.QWidget):
    def __init__(self, max_points: int = 1024, instrument: Optional[BaseInstrument] = None):
        super().__init__()
        self.max_points = max_points
        self.plot = pg.PlotWidget()
        self.curve = self.plot.plot([])
        self.plot.setAntialiasing(False)
        # Allow resizing comfortably inside splitters/docks
        self.setMinimumHeight(150)
        self.setSizePolicy(QtWidgets.QSizePolicy.Preferred, QtWidgets.QSizePolicy.Expanding)
        layout = QtWidgets.QVBoxLayout(self)
        layout.addWidget(self.plot)
        # Optional event subscription so this widget can be added standalone via UI
        if instrument is not None and hasattr(instrument, "events"):
            instrument.events.subscribe("sweep", lambda e: self.update_sweep(e.data.get("y", [])))

    def update_sweep(self, y: List[float]):
        if not y:
            return
        if len(y) > self.max_points:
            y = y[: self.max_points]
        self.curve.setData(list(range(len(y))), y)


class TimeSeriesPlotWidget(QtWidgets.QWidget):
    """Multi-series time plot hidden until data is appended.

    - Multiple named series share one graph
    - Different series lengths allowed
    - Continuous CSV recording with start/stop
    """

    def __init__(self, max_points: int = 1000, autosave_path: Optional[str] = None):
        super().__init__()
        self.max_points = max_points
        self.plot = pg.PlotWidget()
        self.setMinimumHeight(150)
        self.setSizePolicy(QtWidgets.QSizePolicy.Preferred, QtWidgets.QSizePolicy.Expanding)
        self.plot.setAntialiasing(False)
        self.plot.addLegend()
        self._series_data: dict[str, List[Tuple[float, float]]] = {}
        self._curves: dict[str, object] = {}
        self._timer = QtCore.QElapsedTimer()
        self._timer.start()
        self._file = open(autosave_path, "a") if autosave_path else None
        layout = QtWidgets.QVBoxLayout(self)
        layout.addWidget(self.plot)

    def append_value(self, name: str, v: float) -> None:
        t = self._timer.elapsed() / 1000.0
        series = self._series_data.setdefault(name, [])
        series.append((t, v))
        if len(series) > self.max_points:
            self._series_data[name] = series[-self.max_points :]
            series = self._series_data[name]
        if name not in self._curves:
            self._curves[name] = self.plot.plot(name=name)
        if self._file:
            self._file.write(f"{t},{name},{v}\n")
            self._file.flush()
        if series:
            xs, ys = zip(*series)
            self._curves[name].setData(xs, ys)  # type: ignore[union-attr]

    def set_autosave_path(self, path: str) -> None:
        # Back-compat for existing code paths; now same as start_recording
        self.start_recording(path)

    def start_recording(self, path: str) -> None:
        if self._file:
            self._file.close()
        try:
            self._file = open(path, "a")
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            QtWidgets.QMessageBox.critical(self, "Error", str(e))

    def stop_recording(self) -> None:
        if self._file:
            self._file.close()
        self._file = None

    def closeEvent(self, event):  # type: ignore[override]
        try:
            if self._file:
                self._file.close()
        finally:
            super().closeEvent(event)


# legacy helper removed (features now in MarkerSupportMixin)

# Back-compat and explicit name for spectrum plotting
class MarkerSupportMixin:
    """Reusable marker feature mixin for plot widgets.

    Expects subclasses to define:
      - self._plot: pg.PlotWidget
      - self._markers_enabled: bool

    Provides multi-marker support with heads, labels, context menu, and readout.

    Data source: by default uses attributes `_last_xs/_last_ys` (sweep-style)
    or `_buf_x/_buf_y` (event-style). Subclasses can override `_marker_series()`
    to return custom x/y sequences for nearest-point logic.
    """

    def _marker_series(self):
        if hasattr(self, '_last_xs') and hasattr(self, '_last_ys'):
            return getattr(self, '_last_xs'), getattr(self, '_last_ys')
        try:
            return getattr(self, '_buf_x'), getattr(self, '_buf_y')
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            return [], []

    def _build_controls_container(
        self,
        controls_layout: QtWidgets.QBoxLayout,
        *,
        min_height_markers: int = 104,
        min_height_plain: int = 36,
    ) -> tuple[QtWidgets.QWidget, Optional[QtWidgets.QVBoxLayout]]:
        """Wrap a controls layout in a widget, optionally stacking marker UI."""

        controls_widget = QtWidgets.QWidget()
        ctrl_container: Optional[QtWidgets.QVBoxLayout] = None
        if getattr(self, "_markers_enabled", False):
            ctrl_container = QtWidgets.QVBoxLayout(controls_widget)
            ctrl_container.setContentsMargins(6, 6, 6, 6)
            ctrl_container.setSpacing(6)
            ctrl_container.addLayout(controls_layout)
            controls_widget.setMinimumHeight(min_height_markers)
        else:
            controls_widget.setLayout(controls_layout)
            controls_widget.setMinimumHeight(min_height_plain)
        controls_widget.setSizePolicy(QtWidgets.QSizePolicy.Preferred, QtWidgets.QSizePolicy.Fixed)
        return controls_widget, ctrl_container

    def markers_init(self, status_layout: QtWidgets.QVBoxLayout, plot: 'pg.PlotWidget') -> None:
        if not getattr(self, '_markers_enabled', False):
            return
        # State
        if not hasattr(self, '_markers'):
            self._markers = []
        self._marker_seq = getattr(self, '_marker_seq', 0)
        self._mouse_pos_vb = None
        if not hasattr(self, '_marker_chip_area'):
            self._marker_chip_area = QtWidgets.QScrollArea()
            self._marker_chip_area.setWidgetResizable(True)
            self._marker_chip_area.setVerticalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff)
            self._marker_chip_area.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarAsNeeded)
            self._marker_chip_area.setFrameShape(QtWidgets.QFrame.NoFrame)
            self._marker_chip_area.setMinimumHeight(28)
            self._marker_chip_area.setMaximumHeight(34)
            content = QtWidgets.QWidget()
            lay = QtWidgets.QHBoxLayout(content)
            lay.setContentsMargins(0, 0, 0, 0)
            lay.setSpacing(6)
            lay.addStretch(1)
            self._marker_chip_area.setWidget(content)
            status_layout.addWidget(self._marker_chip_area)
            self._marker_chip_content = content
            self._marker_chip_layout = lay
            self._marker_chip_widgets = {}
        if not hasattr(self, '_marker_delta_area'):
            self._marker_delta_area = QtWidgets.QScrollArea()
            self._marker_delta_area.setWidgetResizable(True)
            self._marker_delta_area.setVerticalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff)
            self._marker_delta_area.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarAsNeeded)
            self._marker_delta_area.setFrameShape(QtWidgets.QFrame.NoFrame)
            self._marker_delta_area.setMinimumHeight(26)
            self._marker_delta_area.setMaximumHeight(32)
            dcontent = QtWidgets.QWidget()
            dlay = QtWidgets.QHBoxLayout(dcontent)
            dlay.setContentsMargins(0, 0, 0, 0)
            dlay.setSpacing(6)
            dlay.addStretch(1)
            self._marker_delta_area.setWidget(dcontent)
            status_layout.addWidget(self._marker_delta_area)
            self._marker_delta_content = dcontent
            self._marker_delta_layout = dlay
            self._marker_delta_widgets = {}
        scene = plot.scene()
        scene.sigMouseMoved.connect(self._on_mouse_moved)
        scene.sigMouseClicked.connect(self._on_mouse_clicked)
        vb = plot.getPlotItem().getViewBox()
        if hasattr(vb, 'sigRangeChanged'):
            vb.sigRangeChanged.connect(lambda *_: self._update_marker_heads())
        self._install_context_menu_hook()
        self._ensure_overlay()
        # Marker drag deferral state
        self._marker_dragging = False
        plot.installEventFilter(self)

    def eventFilter(self, obj, event):  # type: ignore[override]
        if obj is getattr(self, '_plot', None) or obj is getattr(self, '_overlay_parent', None):
            et = int(event.type())
            # 12: Resize, 17: Show, 14: LayoutRequest, 75: PolishRequest (constants vary across Qt bindings)
            if et in (12, 17, 14, 75):
                # Defer a tick to ensure geometry is final
                QtCore.QTimer.singleShot(0, lambda: getattr(self, '_update_marker_heads')())
                # No explicit geometry sync needed when parenting labels to the viewport
        try:
            return QtWidgets.QWidget.eventFilter(self, obj, event)  # type: ignore[misc]
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            return False

    # ---- Overlay helpers ----
    def _ensure_overlay(self) -> None:
        """Ensure we have a valid parent for overlay labels.

        Instead of a separate overlay widget, we parent labels directly to the
        QGraphicsView viewport so they are always visible and not clipped by axes.
        """
        vb = self._plot.getPlotItem().getViewBox()
        scene = vb.scene()
        views = scene.views() if hasattr(scene, 'views') else []
        view = views[0] if views else None
        if view is None:
            return
        new_parent = view.viewport()
        # If parent changed (e.g., viewport replaced), reparent existing labels
        old_parent = getattr(self, '_overlay_parent', None)
        if old_parent is not new_parent:
            for lbl in list(getattr(self, '_overlay_labels', {}).values()):
                lbl.setParent(new_parent)
                lbl.show()
            self._overlay_parent = new_parent
            new_parent.installEventFilter(self)
        if not hasattr(self, '_overlay_labels'):
            self._overlay_labels = {}

    def _overlay_label_html(self, name: str, color) -> str:
        try:
            qcol = pg.mkColor(color)
            r, g, b = qcol.red(), qcol.green(), qcol.blue()
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            r, g, b = 255, 255, 0
        return (
            "<div style='background-color: rgba(0,0,0,0.45); color: rgb(%d,%d,%d); padding:1px 3px; border-radius:3px; font: 12px/1.2 Consolas, Courier New, monospace;'>%s</div>"
            % (r, g, b, name)
        )

    def _get_view_and_offset(self):
        try:
            vb = self._plot.getPlotItem().getViewBox()
            scene = vb.scene()
            views = scene.views() if hasattr(scene, 'views') else []
            view = views[0] if views else None
            if view is None:
                return None, QtCore.QPoint(0, 0)
            # When parenting to viewport, use viewport coordinates directly (no extra offset)
            return view, QtCore.QPoint(0, 0)
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            return None, QtCore.QPoint(0, 0)

    def _update_overlay_label_for_marker(self, mk, x: float, y_label: float) -> None:
        # Ensure overlay parent (viewport) exists
        self._ensure_overlay()
        view, top_left = self._get_view_and_offset()
        if view is None:
            return
        vb = self._plot.getPlotItem().getViewBox()
        p_scene = vb.mapViewToScene(QtCore.QPointF(x, y_label))
        p_view = view.mapFromScene(p_scene)
        key = id(mk)
        lbl = getattr(self, '_overlay_labels', {}).get(key)
        if lbl is None:
            # Parent directly to the QGraphicsView viewport
            parent = getattr(self, '_overlay_parent', None)
            if parent is None:
                return
            lbl = QtWidgets.QLabel(parent)
            lbl.setAttribute(QtCore.Qt.WA_TransparentForMouseEvents, True)
            lbl.setTextFormat(QtCore.Qt.RichText)
            lbl.setStyleSheet("background: transparent;")
            lbl.show()
            self._overlay_labels[key] = lbl
        lbl.setText(self._overlay_label_html(mk.get('name', 'M'), mk.get('color')))
        lbl.adjustSize()
        pos_x = int(top_left.x() + p_view.x() - lbl.width() // 2)
        pos_y = int(top_left.y() + p_view.y() - lbl.height())
        vp = view.viewport()
        margin = 2
        pos_x = max(margin, min(pos_x, max(0, vp.width() - lbl.width() - margin)))
        pos_y = max(margin, min(pos_y, max(0, vp.height() - lbl.height() - margin)))
        lbl.move(pos_x, pos_y)
        lbl.raise_()

    def _remove_overlay_label(self, mk) -> None:
        key = id(mk)
        d = getattr(self, '_overlay_labels', None)
        if not d:
            return
        lbl = d.pop(key, None)
        if lbl is not None:
            lbl.deleteLater()

    # ---- Marker helpers ----
    def _marker_color(self, idx: int):
        try:
            return pg.mkColor(pg.intColor(idx, hues=12))
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            return pg.mkColor((255, 255, 0))

    def _on_mouse_moved(self, pos):
        vb = self._plot.getPlotItem().getViewBox()
        if vb is None:
            return
        self._mouse_pos_vb = vb.mapSceneToView(pos)

    def _nearest_point(self, x: float) -> Optional[tuple[float, float]]:
        try:
            xs, ys = self._marker_series()
            if not xs:
                return None
            best_i = min(range(len(xs)), key=lambda i: abs(xs[i] - x))
            return (xs[best_i], ys[best_i])
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            return None

    def _on_mouse_clicked(self, ev):
        if not getattr(self, '_markers_enabled', False):
            return
        pos = ev.scenePos()
        try:
            vb = self._plot.getPlotItem().getViewBox()
            if vb is None:
                return
            p = vb.mapSceneToView(pos)
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            return
        x = float(p.x())
        if ev.button() == QtCore.Qt.LeftButton and getattr(ev, 'double', lambda: False)():
            self._add_marker_at_x(x)
        elif ev.button() == QtCore.Qt.RightButton:
            self._context_click_x = x
            try:
                vb.raiseContextMenu(ev)
            except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                mk = self._nearest_marker_at_x(x)
                self._show_marker_menu(mk, global_pos=QtGui.QCursor.pos(), click_x=x)

    def _add_marker_at_x(self, x: float) -> None:
        pt = self._nearest_point(x)
        if not pt:
            return
        idx = getattr(self, '_marker_seq', 0)
        self._marker_seq = idx + 1
        name = f"M{idx}"
        color = self._marker_color(idx)
        line = pg.InfiniteLine(angle=90, movable=True, pen=pg.mkPen(color, width=1))
        line.setValue(pt[0])
        try:
            self._plot.addItem(line, ignoreBounds=True)
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            self._plot.addItem(line)
        line.sigPositionChanged.connect(lambda _: self._on_marker_line_moved(line))
        arrow, label = self._create_marker_head(pt[0], color, name)
        mk = {"idx": idx, "name": name, "color": color, "line": line, "pt": pt, "arrow": arrow, "label": label}
        self._bind_marker_head_handlers(arrow, label, mk)
        self._markers.append(mk)
        self._update_marker_readout()
        self._update_marker_heads()

    def _on_marker_line_moved(self, line) -> None:
        x = float(line.value())
        pt = self._nearest_point(x)
        if not pt:
            return
        for mk in self._markers:
            if mk["line"] is line:
                mk["pt"] = pt
                break
        self._update_marker_readout()
        self._update_marker_heads()

    def _nearest_marker_at_x(self, x: float):
        if not self._markers:
            return None
        try:
            vb = self._plot.getPlotItem().getViewBox()
            xr = vb.viewRange()[0]
            tol = (xr[1] - xr[0]) * 0.01
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            tol = 0.0
        best = None
        best_d = float('inf')
        for mk in self._markers:
            d = abs(float(mk["line"].value()) - x)
            if d < best_d:
                best = mk
                best_d = d
        return best if best_d <= tol else None

    def _show_marker_menu(self, marker, global_pos=None, click_x=None) -> None:
        menu = QtWidgets.QMenu(self)
        if marker is not None:
            remove_act = menu.addAction("Remove marker")
            def do_remove():
                self._plot.removeItem(marker["line"])
                if marker.get("arrow"):
                    self._plot.removeItem(marker["arrow"])  # type: ignore[arg-type]
                if marker.get("label"):
                    self._plot.removeItem(marker["label"])  # type: ignore[arg-type]
                self._markers.remove(marker)
                self._remove_overlay_label(marker)
                self._remove_marker_chip(marker)
                self._update_marker_readout()
                self._update_marker_heads()
            remove_act.triggered.connect(do_remove)
        else:
            add_act = menu.addAction("Add marker here")
            add_act.triggered.connect(lambda: self._add_marker_at_x(float(click_x)))
        menu.exec(global_pos or QtGui.QCursor.pos())

    def _update_marker_readout(self) -> None:
        if not getattr(self, '_markers_enabled', False):
            return
        ms = sorted(self._markers, key=lambda m: m.get("idx", 0))
        self._sync_marker_chips()
        self._sync_marker_deltas()

    def _sync_marker_chips(self) -> None:
        if not hasattr(self, '_marker_chip_layout'):
            return
        ms = sorted(self._markers, key=lambda m: m.get('idx', 0))
        existing = dict(getattr(self, '_marker_chip_widgets', {}))
        # Create/update chips
        for mk in ms:
            key = id(mk)
            btn = existing.pop(key, None)
            if btn is None:
                btn = QtWidgets.QToolButton(self._marker_chip_content)
                btn.setAutoRaise(True)
                btn.setCheckable(False)
                btn.clicked.connect(lambda _v=False, m=mk: self._on_chip_clicked(m))
                self._marker_chip_layout.insertWidget(self._marker_chip_layout.count() - 1, btn)
                self._marker_chip_widgets[key] = btn
            name = mk.get('name', 'M')
            color = mk.get('color')
            try:
                qcol = pg.mkColor(color)
                r, g, b = qcol.red(), qcol.green(), qcol.blue()
            except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                r, g, b = 255, 255, 0
            try:
                x, y = mk['pt']
                btn.setText(f"{name}")
            except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                btn.setText(name)
            style = (
                f"QToolButton {{ background-color: rgba({r},{g},{b},40%); color: rgb({r},{g},{b});"
                f" border: 1px solid rgba({r},{g},{b},80%); border-radius: 3px; padding: 2px 8px;"
                f" font: 11px 'Consolas','Courier New',monospace; min-height: 22px; }}"
            )
            btn.setStyleSheet(style)
            x, y = mk['pt']
            btn.setToolTip(f"{name}: x={x:.6g}, y={y:.6g}")
        # Remove leftover chips
        for key, btn in existing.items():
            btn.setParent(None)
            btn.deleteLater()
            self._marker_chip_widgets.pop(key, None)

    def _on_chip_clicked(self, mk) -> None:
        try:
            x = float(mk['line'].value())
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            x = mk.get('pt', (None, None))[0]
        if x is None:
            return
        vb = self._plot.getPlotItem().getViewBox()
        xr, yr = vb.viewRange()
        w = (xr[1] - xr[0])
        # Center on marker x (keep width), only if finite
        if w > 0:
            cx = x
            vb.setXRange(cx - 0.5 * w, cx + 0.5 * w, padding=0.05)

    def _on_add_marker_btn(self) -> None:
        # Add a marker at the X center of the current view (snapped to nearest data point)
        try:
            vb = self._plot.getPlotItem().getViewBox()
            xr, _ = vb.viewRange()
            cx = 0.5 * (float(xr[0]) + float(xr[1]))
            self._add_marker_at_x(cx)
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:# Fallback: if ranges unavailable, try last known mouse position
            if getattr(self, '_mouse_pos_vb', None) is not None:
                self._add_marker_at_x(float(self._mouse_pos_vb.x()))

    def _remove_marker_chip(self, mk) -> None:
        key = id(mk)
        btn = getattr(self, '_marker_chip_widgets', {}).pop(key, None)
        if btn is not None:
            btn.setParent(None)
            btn.deleteLater()

    def _sync_marker_deltas(self) -> None:
        if not hasattr(self, '_marker_delta_layout'):
            return
        # Build desired deltas between consecutive markers, sorted by idx
        ms = sorted(self._markers, key=lambda m: m.get('idx', 0))
        pairs = []
        for i in range(len(ms) - 1):
            for j in range(i + 1, len(ms)):
                a, b = ms[i], ms[j]
                pairs.append((a, b))
        # Reuse widgets keyed by (ida,idb)
        existing = dict(getattr(self, '_marker_delta_widgets', {}))
        for a, b in pairs:
            key = (id(a), id(b))
            btn = existing.pop(key, None)
            if btn is None:
                btn = QtWidgets.QToolButton(self._marker_delta_content)
                btn.setAutoRaise(True)
                btn.setCheckable(False)
                self._marker_delta_layout.insertWidget(self._marker_delta_layout.count() - 1, btn)
                self._marker_delta_widgets[key] = btn
            # Styling blends colors or uses the first
            try:
                ca = pg.mkColor(a.get('color'))
                cb = pg.mkColor(b.get('color'))
                r = (ca.red() + cb.red()) // 2
                g = (ca.green() + cb.green()) // 2
                bcol = (ca.blue() + cb.blue()) // 2
            except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                r, g, bcol = 200, 200, 200
            try:
                dx = float(b['pt'][0] - a['pt'][0])
                dy = float(b['pt'][1] - a['pt'][1])
            except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                dx = 0.0; dy = 0.0
            name = f"Δ({a.get('name','M')}→{b.get('name','M')})"
            btn.setText(name)
            style = (
                f"QToolButton {{ background-color: rgba({r},{g},{bcol},32%); color: rgb({r},{g},{bcol});"
                f" border: 1px solid rgba({r},{g},{bcol},80%); border-radius: 3px; padding: 2px 8px;"
                f" font: 11px 'Consolas','Courier New',monospace; min-height: 22px; }}"
            )
            btn.setStyleSheet(style)
            btn.setToolTip(f"{name}: dx={dx:.6g}, dy={dy:.6g}")
        # Remove leftover delta widgets
        for key, btn in existing.items():
            btn.setParent(None)
            btn.deleteLater()
            self._marker_delta_widgets.pop(key, None)

    def _create_marker_head(self, x: float, color, name: str):
        try:
            arrow = pg.ArrowItem(angle=-90, tipAngle=30, headLen=12, tailLen=6, tailWidth=3, pen=pg.mkPen(color), brush=pg.mkBrush(color))
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            arrow = pg.ArrowItem(angle=-90)
        # Keep in-plot TextItem empty; overlay label will show the name
        label = pg.TextItem(text="", color=color)
        arrow.setZValue(1000)
        label.setZValue(1001)
        label.setAnchor((0.5, 0.0))
        label.setRotation(0)
        label.setAngle(0)
        try:
            self._plot.addItem(arrow, ignoreBounds=True)
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            self._plot.addItem(arrow)
        try:
            self._plot.addItem(label, ignoreBounds=True)
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            self._plot.addItem(label)
        return arrow, label

    def _bind_marker_head_handlers(self, arrow, label, mk_ref) -> None:
        def head_click(ev):
            if ev.button() == QtCore.Qt.RightButton:
                try:
                    x = mk_ref["pt"][0]
                except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                    try:
                        vb = self._plot.getPlotItem().getViewBox()
                        x = float(vb.mapSceneToView(ev.scenePos()).x())
                    except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                        x = None
                if x is not None:
                    self._show_marker_menu(mk_ref, global_pos=QtGui.QCursor.pos(), click_x=x)
                ev.accept()
            elif ev.button() == QtCore.Qt.LeftButton and getattr(ev, 'double', lambda: False)():
                ev.accept()

        def head_drag(ev):
            if ev.isStart():
                # Begin drag: defer chip/delta/overlay updates for performance
                self._marker_dragging = True
                ev.accept()
            if ev.isFinish():
                # End drag: one final sync of overlays and chips
                self._marker_dragging = False
                self._update_marker_readout()
                self._update_marker_heads()
                return
            vb = self._plot.getPlotItem().getViewBox()
            p = vb.mapSceneToView(ev.scenePos())
            self._on_marker_head_move_to_x(float(p.x()), mk_ref)

        arrow.mouseClickEvent = head_click
        arrow.mouseDragEvent = head_drag
        label.mouseClickEvent = head_click
        label.mouseDragEvent = head_drag

    def _on_marker_head_move_to_x(self, x: float, mk_ref) -> None:
        if mk_ref is None:
            mk_ref = self._nearest_marker_at_x(x)
        if mk_ref is None:
            return
        mk_ref["line"].setValue(x)

    def _update_marker_heads(self) -> None:
        if not getattr(self, '_markers_enabled', False) or not getattr(self, '_markers', []):
            return
        # During drag, avoid heavy overlay label work; arrows still follow for user feedback
        defer_overlay = bool(getattr(self, '_marker_dragging', False))
        vb = self._plot.getPlotItem().getViewBox()
        (xmin, xmax), (ymin, ymax) = vb.viewRange()
        # Use pixel-based offsets to keep heads/labels visible even in small views
        try:
            px = vb.viewPixelSize()
            # viewPixelSize may return QPointF or tuple
            dy = float(px[1] if isinstance(px, (tuple, list)) else getattr(px, 'y', lambda: px.y())())
            # Scale offsets for very small plots to keep text inside view
            base_arrow_px = 14.0
            base_label_px = 28.0
            base_sep_px = 8.0
            base_bottom_px = 6.0
            # Estimate view height in pixels from data range / dy
            try:
                view_h_px = max(1.0, (ymax - ymin) / max(dy, 1e-9))
            except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                view_h_px = 200.0
            scale = 1.0
            if view_h_px < 120.0:
                scale = max(0.6, view_h_px / 120.0)
            arrow_off_px = base_arrow_px * scale
            label_off_px = base_label_px * scale
            min_sep_px = base_sep_px * scale
            bottom_margin_px = base_bottom_px * scale
            y_arrow = ymax - dy * arrow_off_px
            y_label = ymax - dy * label_off_px
            y_min_margin = ymin + dy * bottom_margin_px
            if y_label < y_min_margin:
                y_label = y_min_margin
            if y_label > y_arrow - dy * min_sep_px:
                y_label = y_arrow - dy * min_sep_px
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:# Fallback to percentage-based if pixel size not available
            h = (ymax - ymin)
            y_arrow = ymax - h * 0.06
            y_label = max(ymin + h * 0.02, y_arrow - h * 0.04)
        for mk in self._markers:
            try:
                x = float(mk["line"].value())
            except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                x = mk["pt"][0]
            if mk.get("arrow"):
                mk["arrow"].setPos(x, y_arrow)
            if mk.get("label"):
                mk["label"].setPos(x, y_label)
            if not defer_overlay:
                self._update_overlay_label_for_marker(mk, x, y_label)

    def _install_context_menu_hook(self) -> None:
        vb = self._plot.getPlotItem().getViewBox()
        if getattr(vb, '_markers_menu_hooked', False):
            return
        if not hasattr(vb, 'getMenu'):
            return
        orig_get_menu = vb.getMenu
        def getMenu_hook(ev, orig=orig_get_menu, self_ref=self, vb_ref=vb):
            menu = orig(ev)
            if not getattr(self_ref, '_markers_enabled', False):
                return menu
            add_act = getattr(vb_ref, '_markers_add_action', None)
            rem_act = getattr(vb_ref, '_markers_remove_action', None)
            if add_act is None:
                add_act = QtGui.QAction("Add marker here", menu)
                vb_ref._markers_add_action = add_act  # type: ignore[attr-defined]
                add_act.triggered.connect(lambda: self_ref._add_marker_at_x(float(getattr(self_ref, '_context_click_x', 0.0))))
            if rem_act is None:
                rem_act = QtGui.QAction("Remove nearest marker", menu)
                vb_ref._markers_remove_action = rem_act  # type: ignore[attr-defined]
                rem_act.triggered.connect(lambda: self_ref._remove_nearest_marker_at_x(float(getattr(self_ref, '_context_click_x', 0.0))))
            acts = menu.actions()
            if add_act not in acts:
                if acts:
                    menu.insertAction(acts[0], rem_act)
                    menu.insertAction(acts[0], add_act)
                else:
                    menu.addAction(add_act)
                    menu.addAction(rem_act)
            return menu
        vb.getMenu = getMenu_hook  # type: ignore[assignment]
        vb._markers_menu_hooked = True  # type: ignore[attr-defined]

    def _remove_nearest_marker_at_x(self, x: float) -> None:
        mk = self._nearest_marker_at_x(x)
        if mk is None:
            return
        # Remove plot items if present
        for key in ("line", "arrow", "label"):
            item = mk.get(key)
            if item is not None:
                self._plot.removeItem(item)  # type: ignore[arg-type]
        # Remove from internal list if present
        if mk in getattr(self, "_markers", []):
            self._markers.remove(mk)
        # Remove any overlay UI and chip UI for this marker
        self._remove_overlay_label(mk)
        self._remove_marker_chip(mk)
        self._update_marker_readout()
        self._update_marker_heads()


class SpectrumPlotWidget(FrequencyPlotWidget):
    pass


class EventPlotWidget(PlotWidgetBase, MarkerSupportMixin):
    """Polls a getter periodically, appends returned points to a buffer, and renders.

    UI metadata keys (in feature.ui):
      - getter: callable or str -> returns list[float] or list[tuple[float,float]]
      - start: callable or str (optional)
      - stop: callable or str (optional)
      - interval_ms: int (optional, default 200)
      - max_points: int (optional, default 2000)
    Continuous file writing is enabled if a file is chosen BEFORE pressing Start.
    """

    def __init__(self, instrument: BaseInstrument, ui: Optional[dict] = None, parent: Optional[QtWidgets.QWidget] = None):
        super().__init__(parent)
        self._log = logging.getLogger(
            f"instrctl.gui.EventPlotWidget.{instrument.__class__.__name__}"
        )
        self._inst = instrument
        self._ui = ui or {}
        self._plot = pg.PlotWidget()
        # Disable antialiasing per plot for performance (guard for older pyqtgraph)
        if hasattr(self._plot, 'setAntialiasing'):
            self._plot.setAntialiasing(False)
        self._plot.setMinimumHeight(150)
        self.setMinimumHeight(200)
        self.setSizePolicy(QtWidgets.QSizePolicy.Preferred, QtWidgets.QSizePolicy.Expanding)
        self._curve = self._plot.plot([])
        self._curve.setPen(pg.mkPen(color=(255, 255, 0, 255), width=2))
        self._curve.destroyed.connect(self._on_curve_destroyed)
        # Keep it simple: let pyqtgraph handle ranges
        pi = self._plot.getPlotItem()
        # Disable built-in autoRange; we'll manage it so user interaction can pause it
        pi.enableAutoRange('xy', False)
        pi.setLogMode(False, False)
        self._plot.showGrid(x=True, y=True, alpha=0.3)
        # Stop auto-follow when user pans/zooms
        vb = pi.getViewBox()
        if hasattr(vb, 'sigRangeChangedManually'):
            vb.sigRangeChangedManually.connect(self._on_user_navigated)
        if hasattr(vb, 'sigRangeChanged'):
            vb.sigRangeChanged.connect(lambda *_: self._update_marker_heads())
        # Shared feed subscription handle
        self._feed_handle = None
        # Subscribe via PlotWidgetBase for repaint cadence (~30 fps)
        self._register_ui_clock_slot(self._on_ui_tick)
        self._pending_update = False
        # Internal buffers
        self._buf_x = []  # type: List[float]
        self._buf_y = []  # type: List[float]
        self._needs_initial_fit = True
        # Track whether X is implicit index (0..N) or explicit from data
        self._x_mode = "index"  # 'index' or 'explicit'
        self._max_points = int(self._ui.get("max_points", 2000))
        self._file_path = None
        self._file = None
        # Deterministic timebase for CSV saving (accumulates interval per tick)
        self._sample_time_s = 0.0
        # Auto-follow flag: when True, we call autoRange() after updates; paused on user interaction
        self._auto_follow = True
        # Throttle autoRange to avoid per-frame cost
        self._auto_follow_timer = QtCore.QElapsedTimer()
        self._auto_follow_timer.start()
        self._auto_follow_min_interval_ms = 120
        # Internal polling interval (ms) retained without exposing a spinbox
        self._interval_ms = int(self._ui.get("interval_ms", 200))

        # Controls
        ctrl = QtWidgets.QHBoxLayout()
        self._start_btn = QtWidgets.QPushButton("Start")
        self._stop_btn = QtWidgets.QPushButton("Stop")
        self._stop_btn.setEnabled(False)
        ctrl.addWidget(self._start_btn)
        ctrl.addWidget(self._stop_btn)
        # Removed Interval/Max controls per request; keep useful actions
        # Follow last N points (0 = all). Hidden control per request; keep internal behavior only.
        self._follow_pts = int(self._ui.get("follow_points", 2000))
        ctrl.addSpacing(10)
        self._fit_btn = QtWidgets.QPushButton("Autoscale")
        ctrl.addWidget(self._fit_btn)
        # Clear button for EventPlot
        self._clear_btn = QtWidgets.QPushButton("Clear")
        self._clear_btn.setToolTip("Clear plotted data")
        ctrl.addWidget(self._clear_btn)
        self._markers_enabled = bool(self._ui.get("markers", False))
        ctrl.addStretch(1)
        self._file_btn = QtWidgets.QPushButton("Choose File…")
        self._file_label = QtWidgets.QLabel("(no file)")
        self._file_label.setStyleSheet("color: #666;")
        self._file_label.setTextInteractionFlags(QtCore.Qt.TextSelectableByMouse)
        ctrl.addWidget(self._file_btn)
        ctrl.addWidget(self._file_label)

        # Controls widget for splitter (wrap controls + marker bars when enabled)
        self.controls_widget, ctrl_container = self._build_controls_container(ctrl)

        # Status widget for splitter
        self.status_widget = QtWidgets.QWidget()
        status_layout = QtWidgets.QVBoxLayout(self.status_widget)
        self._status = QtWidgets.QLabel("")
        self._status.setStyleSheet("color:#aab; font: 11px 'Consolas','Courier New',monospace;")
        self._status.setVisible(False)  # hide points count per request
        status_layout.addWidget(self._status)
        self.status_widget.setMinimumHeight(22)
        self.status_widget.setSizePolicy(QtWidgets.QSizePolicy.Preferred, QtWidgets.QSizePolicy.Fixed)
        if self._markers_enabled:
            # Place marker chips/deltas in the controls (top) container to avoid being crushed by plot resizing
            try:
                self.markers_init(ctrl_container, self._plot)
            except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:# Fallback to status layout if needed
                self.markers_init(status_layout, self._plot)
        self.status_widget.setMinimumHeight(22)
        self.status_widget.setSizePolicy(QtWidgets.QSizePolicy.Preferred, QtWidgets.QSizePolicy.Fixed)

        # Resolve callables
        self._getter = _resolve_on_instrument(self._inst, self._ui.get("getter"))
        self._start_fn = _resolve_on_instrument(self._inst, self._ui.get("start"))
        self._stop_fn = _resolve_on_instrument(self._inst, self._ui.get("stop"))
        # Range behavior handled by autoRange() gated by _auto_follow

        self._start_btn.clicked.connect(self._on_start)
        self._stop_btn.clicked.connect(self._on_stop)
        self._file_btn.clicked.connect(self._on_choose_file)
        self._fit_btn.clicked.connect(self._on_fit_last)
        self._clear_btn.clicked.connect(self._on_clear)
        # Follow points control removed from GUI; behavior controlled by _follow_pts only
        # Multi-markers state and mouse hooks
        self._markers = []  # list of dicts: {"idx": int, "name": str, "color": QColor, "line": InfiniteLine, "pt": (x,y), "arrow": ArrowItem, "label": TextItem}
        self._marker_seq = 0
        self._mouse_pos_vb = None  # type: Optional[QtCore.QPointF]
        # marker hooks are initialized above via markers_init

    def _resolve(self, spec):
        # Deprecated: keep for back-compat; delegate to shared resolver
        return _resolve_on_instrument(self._inst, spec)

    def _on_choose_file(self) -> None:
        path, _ = QtWidgets.QFileDialog.getSaveFileName(self, "Select CSV file", filter="CSV Files (*.csv);;All Files (*)")
        if path:
            self._file_path = Path(path)
            self._file_label.setText(self._file_path.name)
            self._file_label.setToolTip(str(self._file_path))

    def _on_start(self) -> None:
        if not callable(self._getter):
            QtWidgets.QMessageBox.critical(self, "Start", "Getter is not configured for this plot.")
            return
        # Call user-provided start function, if any
        self._log.info("EventPlot Start: interval=%d ms", int(self._interval_ms))
        try:
            if callable(self._start_fn):
                self._start_fn()
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            QtWidgets.QMessageBox.critical(self, "Start", str(e))
            return
        # Prepare file if chosen prior to start
        if self._file_path is not None:
            try:
                self._file = self._file_path.open("a", encoding="utf-8")
                if self._file.tell() == 0:
                    self._file.write("time_s,y\n")
            except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                QtWidgets.QMessageBox.critical(self, "File", str(e))
                self._file = None
        # Reset deterministic sample clock
        self._sample_time_s = 0.0
        # Subscribe to shared feed and start delivery
        def _deliver(pts):
            # Deliver feed data to this widget's append logic without consuming instrument data twice.
            self._append_points(pts)
        # EventPlot accumulates between deliveries
        self._feed_handle = _feed_mgr.subscribe(self._inst, self._getter, int(self._interval_ms), _deliver, accumulate=True)
        if self._feed_handle is not None:
            _feed_mgr.start(self._feed_handle)
        else:
            if not hasattr(self, "_timer"):
                self._timer = QtCore.QTimer(self)
                self._timer.setTimerType(QtCore.Qt.PreciseTimer)
                self._timer.timeout.connect(self._tick)
                self._register_timer(self._timer)
            self._timer.start(int(self._interval_ms))
        self._start_btn.setEnabled(False)
        self._stop_btn.setEnabled(True)
        # Force a quick first UI tick so the first data autoscale happens ASAP
        QtCore.QTimer.singleShot(0, lambda: self._on_ui_tick())

    def _on_stop(self) -> None:
        if getattr(self, '_feed_handle', None) is not None:
            _feed_mgr.stop(self._feed_handle)
            _feed_mgr.unsubscribe(self._feed_handle)
        self._feed_handle = None
        if hasattr(self, "_timer"):
            self._timer.stop()
        if callable(self._stop_fn):
            self._stop_fn()
        self._log.info("EventPlot Stop")
        if self._file:
            self._file.close()
        self._file = None
        self._start_btn.setEnabled(True)
        self._stop_btn.setEnabled(False)

    def _on_interval_changed(self, v: int) -> None:
        self._interval_ms = int(v)
        if getattr(self, '_feed_handle', None) is not None:
            _feed_mgr.update_interval(self._feed_handle, int(self._interval_ms))
        else:
            if hasattr(self, "_timer") and self._timer.isActive():
                self._timer.setInterval(int(self._interval_ms))

    def _append_points(self, pts):
        start_index = (self._buf_x[-1] + 1) if self._buf_x else 0
        xs, ys, mode = _normalize_plot_points(pts, start_index=start_index)
        if not xs:
            return
        self._x_mode = mode

        # Extend buffers and trim
        self._buf_x.extend(xs)
        self._buf_y.extend(ys)
        if self._max_points and self._max_points > 0 and len(self._buf_x) > self._max_points:
            cut = len(self._buf_x) - self._max_points
            self._buf_x = self._buf_x[cut:]
            self._buf_y = self._buf_y[cut:]

        # Render simply and autoscale (only if auto-follow is enabled)
        # Defer the actual setData to the shared UI clock
        self._pending_update = True
        # Request an immediate fit on first data
        if self._needs_initial_fit:
            self._auto_follow = True

        # Update compact status
        # Do not show points count in the UI

        # PERFORMANCE OPTIMIZATION: Async file I/O to prevent blocking main thread
        # Continuous write using deterministic per-interval timestamps
        if self._file:
            n = len(ys)
            if n > 0:
                dt_s = max(0.0, float(self._interval_ms) / 1000.0)
                step = (dt_s / n) if n > 0 else 0.0
                
                # Build write buffer without actually writing (defer to timer)
                # This prevents blocking the main thread during high-frequency updates
                lines = []
                for i, y in enumerate(ys, start=1):
                    t = self._sample_time_s + step * i
                    lines.append(f"{t:.6f},{y}\n")
                
                # Write in batch (still might block, but less frequently)
                if len(lines) > 0:
                    self._file.writelines(lines)
                    # Only flush every N writes to reduce I/O overhead
                    self._write_counter = getattr(self, '_write_counter', 0) + 1
                    if self._write_counter % 10 == 0:  # Flush every 10 batches
                        self._file.flush()
                
                self._sample_time_s += dt_s

    def _on_ui_tick(self) -> None:
        if not self._pending_update or not hasattr(self, "_curve") or self._curve is None:
            return
        self._pending_update = False
        
        xs = self._buf_x
        ys = self._buf_y
        
        # Convert to numpy arrays for efficiency
        if np is not None and xs and ys:
            try:
                xs_arr = np.asarray(xs, dtype=np.float32)
                ys_arr = np.asarray(ys, dtype=np.float32)
                xs_use, ys_use = xs_arr, ys_arr
            except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                xs_use, ys_use = xs, ys
        else:
            xs_use, ys_use = xs, ys
        
        # Render full dataset - let pyqtgraph's autoDownsample handle optimization
        if self._curve is not None:
            if len(xs_use) < 2:
                self._curve.setData(x=xs_use, y=ys_use,
                                    symbol=None,
                                    autoDownsample=True, clipToView=True, downsampleMethod='peak')
            else:
                self._curve.setData(x=xs_use, y=ys_use,
                                    autoDownsample=True, clipToView=True, downsampleMethod='peak')
        
        if self._auto_follow:
            # Perform an immediate first fit, then throttle subsequent updates
            if self._needs_initial_fit or (not self._auto_follow_timer.isValid() or self._auto_follow_timer.elapsed() >= self._auto_follow_min_interval_ms):
                self._auto_follow_update_range()
                self._auto_follow_timer.restart()
                self._needs_initial_fit = False
        
        if self._markers_enabled and not getattr(self, '_marker_dragging', False):
            self._update_marker_readout()

    def _on_max_points_changed(self, v: int) -> None:
        self._max_points = int(v)
        # Trim immediately if needed
        if self._max_points and self._max_points > 0 and len(self._buf_x) > self._max_points:
            cut = len(self._buf_x) - self._max_points
            self._buf_x = self._buf_x[cut:]
            self._buf_y = self._buf_y[cut:]
            if hasattr(self, "_curve") and self._curve is not None:
                self._curve.setData(x=self._buf_x, y=self._buf_y)

    def _on_fit_last(self) -> None:
        # Autoscale based on data only and resume auto-follow until next user interaction
        if self._buf_x and self._buf_y:
            if len(self._buf_x) != len(self._buf_y):
                return
            xs, ys = _select_follow_window(self._buf_x, self._buf_y, getattr(self, "_follow_pts", 0))
            if not xs or not ys:
                return
            xmin, xmax, ymin, ymax = _compute_plot_bounds(xs, ys)
            vb = self._plot.getPlotItem().getViewBox()
            vb.setXRange(xmin, xmax, padding=0.05)
            vb.setYRange(ymin, ymax, padding=0.10)
        self._auto_follow = True

    def _auto_follow_update_range(self) -> None:
        # Manual follow: use last N points (if configured). No need to include zero.
        if not (self._buf_x and self._buf_y):
            return
        if len(self._buf_x) != len(self._buf_y):
            return
        xs, ys = _select_follow_window(self._buf_x, self._buf_y, getattr(self, "_follow_pts", 0))
        if not xs or not ys:
            return
        xmin, xmax, ymin, ymax = _compute_plot_bounds(xs, ys)
        vb = self._plot.getPlotItem().getViewBox()
        # Keep X anchored to the current data window without padding to reduce drift
        vb.setXRange(xmin, xmax, padding=0.0)
        vb.setYRange(ymin, ymax, padding=0.10)

    def _on_follow_pts_changed(self, v: int) -> None:
        self._follow_pts = int(v)
        # If auto-follow is active, update range immediately
        if self._auto_follow:
            self._auto_follow_update_range()

    def _on_clear(self) -> None:
        # Clear buffered data and reset plot to empty
        self._buf_x.clear(); self._buf_y.clear()
        if hasattr(self, "_curve") and self._curve is not None:
            self._curve.setData([])
        self._status.setText("")
        # Resume auto-follow so next data auto-ranges
        self._auto_follow = True

    def _on_user_navigated(self, *args, **kwargs) -> None:
        # When the user pans/zooms, pause auto-follow
        self._auto_follow = False
        # No immediate action required; we just stop auto-follow. Next updates won't autoRange.

    def _on_curve_destroyed(self, *args):
        if hasattr(self, "_timer"):
            self._timer.stop()
        self._curve = None
        self._pending_update = False

    # ---- Marker helpers (multi-marker) ----
    def _on_mouse_moved(self, pos):
        vb = self._plot.getPlotItem().getViewBox()
        if vb is None:
            return
        self._mouse_pos_vb = vb.mapSceneToView(pos)

    def _nearest_point(self, x: float) -> Optional[tuple[float, float]]:
        try:
            if not self._buf_x:
                return None
            # Find nearest index by x distance
            # Linear scan is fine for a few thousand points
            best_i = min(range(len(self._buf_x)), key=lambda i: abs(self._buf_x[i] - x))
            return (self._buf_x[best_i], self._buf_y[best_i])
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            return None

    def _on_mouse_clicked(self, ev):
        if not self._markers_enabled:
            return
        pos = ev.scenePos()
        try:
            vb = self._plot.getPlotItem().getViewBox()
            if vb is None:
                return
            p = vb.mapSceneToView(pos)
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            return
        x = float(p.x())
        if ev.button() == QtCore.Qt.LeftButton and getattr(ev, 'double', lambda: False)():
            self._add_marker_at_x(x)
        elif ev.button() == QtCore.Qt.RightButton:
            # Store click x and delegate to the default ViewBox menu
            self._context_click_x = x
            try:
                vb.raiseContextMenu(ev)
            except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:# Fallback: custom small menu if default fails
                mk = self._nearest_marker_at_x(x)
                self._show_marker_menu(mk, global_pos=QtGui.QCursor.pos(), click_x=x)

    def _marker_color(self, idx: int):
        try:
            return pg.mkColor(pg.intColor(idx, hues=12))  # at least 10 distinct hues
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            return pg.mkColor((255, 255, 0))

    def _add_marker_at_x(self, x: float) -> None:
        pt = self._nearest_point(x)
        if not pt:
            return
        idx = self._marker_seq
        self._marker_seq += 1
        name = f"M{idx}"
        color = self._marker_color(idx)
        line = pg.InfiniteLine(angle=90, movable=True, pen=pg.mkPen(color, width=1))
        line.setValue(pt[0])
        # Add with ignoreBounds so it never influences view range calculations
        try:
            self._plot.addItem(line, ignoreBounds=True)
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            self._plot.addItem(line)
        line.sigPositionChanged.connect(lambda _: self._on_marker_line_moved(line))
        arrow, label = self._create_marker_head(pt[0], color, name)
        mk = {"idx": idx, "name": name, "color": color, "line": line, "pt": pt, "arrow": arrow, "label": label}
        self._bind_marker_head_handlers(arrow, label, mk)
        self._markers.append(mk)
        self._update_marker_readout()
        self._update_marker_heads()

    def _on_marker_line_moved(self, line) -> None:
        x = float(line.value())
        pt = self._nearest_point(x)
        if not pt:
            return
        for mk in self._markers:
            if mk["line"] is line:
                mk["pt"] = pt
                break
        self._update_marker_readout()
        self._update_marker_heads()

    def _nearest_marker_at_x(self, x: float):
        if not self._markers:
            return None
        try:
            vb = self._plot.getPlotItem().getViewBox()
            xr = vb.viewRange()[0]
            tol = (xr[1] - xr[0]) * 0.01
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            tol = 0.0
        best = None
        best_d = float('inf')
        for mk in self._markers:
            d = abs(float(mk["line"].value()) - x)
            if d < best_d:
                best = mk
                best_d = d
        return best if best_d <= tol else None

    def _show_marker_menu(self, marker, global_pos=None, click_x=None) -> None:
        menu = QtWidgets.QMenu(self)
        if marker is not None:
            remove_act = menu.addAction("Remove marker")
            def do_remove():
                self._plot.removeItem(marker["line"])
                if marker.get("arrow"):
                    self._plot.removeItem(marker["arrow"])  # type: ignore[arg-type]
                if marker.get("label"):
                    self._plot.removeItem(marker["label"])  # type: ignore[arg-type]
                self._markers.remove(marker)
                self._remove_overlay_label(marker)
                self._remove_marker_chip(marker)
                self._update_marker_readout()
                self._update_marker_heads()
            remove_act.triggered.connect(do_remove)
        else:
            add_act = menu.addAction("Add marker here")
            add_act.triggered.connect(lambda: self._add_marker_at_x(float(click_x)))
        menu.exec(global_pos or QtGui.QCursor.pos())

    def _update_marker_readout(self) -> None:
        if not self._markers_enabled:
            return
        self._sync_marker_chips()
        self._sync_marker_deltas()

    def _create_marker_head(self, x: float, color, name: str):
        # Arrow + empty in-plot label; overlay provides visible text
        try:
            arrow = pg.ArrowItem(angle=-90, tipAngle=30, headLen=12, tailLen=6, tailWidth=3, pen=pg.mkPen(color), brush=pg.mkBrush(color))
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            arrow = pg.ArrowItem(angle=-90)
        label = pg.TextItem(text="", color=color)
        arrow.setZValue(1000)
        label.setZValue(1001)
        label.setAnchor((0.5, 0.0))
        label.setRotation(0)
        label.setAngle(0)
        try:
            self._plot.addItem(arrow, ignoreBounds=True)
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            self._plot.addItem(arrow)
        try:
            self._plot.addItem(label, ignoreBounds=True)
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            self._plot.addItem(label)
        return arrow, label

    def _bind_marker_head_handlers(self, arrow, label, mk_ref) -> None:
        def head_click(ev):
            if ev.button() == QtCore.Qt.RightButton:
                # open menu for this specific marker (fallback to nearest if needed)
                try:
                    x = mk_ref["pt"][0]
                except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                    try:
                        vb = self._plot.getPlotItem().getViewBox()
                        x = float(vb.mapSceneToView(ev.scenePos()).x())
                    except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                        x = None
                if x is not None:
                    self._show_marker_menu(mk_ref, global_pos=QtGui.QCursor.pos(), click_x=x)
                ev.accept()
            elif ev.button() == QtCore.Qt.LeftButton and getattr(ev, 'double', lambda: False)():
                # no-op; double left is handled on plot to add new markers
                ev.accept()

        def head_drag(ev):
            if ev.isStart():
                ev.accept()
            if ev.isFinish():
                return
            vb = self._plot.getPlotItem().getViewBox()
            p = vb.mapSceneToView(ev.scenePos())
            self._on_marker_head_move_to_x(float(p.x()), mk_ref)

        arrow.mouseClickEvent = head_click
        arrow.mouseDragEvent = head_drag
        label.mouseClickEvent = head_click
        label.mouseDragEvent = head_drag

    def _on_marker_head_move_to_x(self, x: float, mk_ref) -> None:
        if mk_ref is None:
            # find nearest by x
            mk_ref = self._nearest_marker_at_x(x)
        if mk_ref is None:
            return
        mk_ref["line"].setValue(x)

    def _update_marker_heads(self) -> None:
        # Position arrow and label at top y for each marker; use pixel offsets for reliability
        if not self._markers_enabled or not self._markers:
            return
        vb = self._plot.getPlotItem().getViewBox()
        (xmin, xmax), (ymin, ymax) = vb.viewRange()
        try:
            px = vb.viewPixelSize()
            dy = float(px[1] if isinstance(px, (tuple, list)) else getattr(px, 'y', lambda: px.y())())
            base_arrow_px = 14.0
            base_label_px = 28.0
            base_sep_px = 8.0
            base_bottom_px = 6.0
            try:
                view_h_px = max(1.0, (ymax - ymin) / max(dy, 1e-9))
            except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                view_h_px = 200.0
            scale = 1.0
            if view_h_px < 120.0:
                scale = max(0.6, view_h_px / 120.0)
            arrow_off_px = base_arrow_px * scale
            label_off_px = base_label_px * scale
            min_sep_px = base_sep_px * scale
            bottom_margin_px = base_bottom_px * scale
            y_arrow = ymax - dy * arrow_off_px
            y_label = ymax - dy * label_off_px
            y_min_margin = ymin + dy * bottom_margin_px
            if y_label < y_min_margin:
                y_label = y_min_margin
            if y_label > y_arrow - dy * min_sep_px:
                y_label = y_arrow - dy * min_sep_px
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            h = (ymax - ymin)
            y_arrow = ymax - h * 0.06
            y_label = max(ymin + h * 0.02, y_arrow - h * 0.04)
        for mk in self._markers:
            try:
                x = float(mk["line"].value())
            except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                x = mk["pt"][0]
            if mk.get("arrow"):
                mk["arrow"].setPos(x, y_arrow)
            if mk.get("label"):
                mk["label"].setPos(x, y_label)
            self._update_overlay_label_for_marker(mk, x, y_label)

    def _install_context_menu_hook(self) -> None:
        vb = self._plot.getPlotItem().getViewBox()
        if getattr(vb, '_markers_menu_hooked', False):
            return
        if not hasattr(vb, 'getMenu'):
            return
        orig_get_menu = vb.getMenu
        def getMenu_hook(ev, orig=orig_get_menu, self_ref=self, vb_ref=vb):
            menu = orig(ev)
            if not self_ref._markers_enabled:
                return menu
            # Reuse persistent actions on the ViewBox; insert only if not already in the menu
            add_act = getattr(vb_ref, '_markers_add_action', None)
            rem_act = getattr(vb_ref, '_markers_remove_action', None)
            if add_act is None:
                add_act = QtGui.QAction("Add marker here", menu)
                vb_ref._markers_add_action = add_act  # type: ignore[attr-defined]
                add_act.triggered.connect(lambda: self_ref._add_marker_at_x(float(getattr(self_ref, '_context_click_x', 0.0))))
            if rem_act is None:
                rem_act = QtGui.QAction("Remove nearest marker", menu)
                vb_ref._markers_remove_action = rem_act  # type: ignore[attr-defined]
                rem_act.triggered.connect(lambda: self_ref._remove_nearest_marker_at_x(float(getattr(self_ref, '_context_click_x', 0.0))))
            acts = menu.actions()
            # Insert only if the exact action objects are not already part of this menu
            if add_act not in acts:
                if acts:
                    menu.insertAction(acts[0], rem_act)
                    menu.insertAction(acts[0], add_act)
                else:
                    menu.addAction(add_act)
                    menu.addAction(rem_act)
            return menu
        vb.getMenu = getMenu_hook  # type: ignore[assignment]
        vb._markers_menu_hooked = True  # type: ignore[attr-defined]

    def _remove_nearest_marker_at_x(self, x: float) -> None:
        mk = self._nearest_marker_at_x(x)
        if mk is None:
            return
        # Remove plot items if present
        for key in ("line", "arrow", "label"):
            item = mk.get(key)
            if item is not None:
                self._plot.removeItem(item)  # type: ignore[arg-type]
        # Remove from internal list if present
        if mk in getattr(self, "_markers", []):
            self._markers.remove(mk)
        # Remove any overlay UI and chip UI for this marker
        self._remove_overlay_label(mk)
        self._remove_marker_chip(mk)
        self._update_marker_readout()
        self._update_marker_heads()

    def _tick(self) -> None:
        if not callable(self._getter):
            return
        try:
            pts = self._getter()
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            QtWidgets.QMessageBox.critical(self, "Getter", str(e))
            self._on_stop()
            return
        try:
            if isinstance(pts, (list, tuple)):
                pts = list(pts)
            else:
                pts = []
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            pts = []
        self._log.info("EventPlot Tick: %d point(s)", len(pts))
        self._append_points(pts)

    def closeEvent(self, event):  # type: ignore[override]
        if getattr(self, '_feed_handle', None) is not None:
            _feed_mgr.stop(self._feed_handle)
            _feed_mgr.unsubscribe(self._feed_handle)
        self._feed_handle = None
        if self._file:
            self._file.close()
        super().closeEvent(event)


class SweepPlotWidget(PlotWidgetBase, MarkerSupportMixin):
    """Polls a getter periodically and renders only the latest sweep (discard history)."""

    def __init__(self, instrument: BaseInstrument, ui: Optional[dict] = None, parent: Optional[QtWidgets.QWidget] = None):
        super().__init__(parent)
        self._log = logging.getLogger(
            f"instrctl.gui.SweepPlotWidget.{instrument.__class__.__name__}"
        )
        self._inst = instrument
        self._ui = ui or {}
        # Marker features flag must be defined before building controls container
        self._markers_enabled = bool(self._ui.get("markers", False))

        # Plot
        self._plot = pg.PlotWidget()
        self._curve = self._plot.plot([])
        self._curve.destroyed.connect(self._on_curve_destroyed)
        # If the plot goes away, stop our timer promptly (guard against deleted timer)
        self._plot.destroyed.connect(self._on_plot_destroyed)
        self._plot.setMinimumHeight(150)
        self.setMinimumHeight(200)
        self.setSizePolicy(QtWidgets.QSizePolicy.Preferred, QtWidgets.QSizePolicy.Expanding)
        if hasattr(self._plot, 'setAntialiasing'):
            self._plot.setAntialiasing(False)
        # Disable built-in autoRange; we'll drive ranges manually
        pi = self._plot.getPlotItem()
        pi.enableAutoRange('xy', False)
        pi.setLogMode(False, False)
        self._plot.showGrid(x=True, y=True, alpha=0.3)
        vb = pi.getViewBox()
        if hasattr(vb, 'sigRangeChangedManually'):
            vb.sigRangeChangedManually.connect(self._on_user_navigated)

        # Controls
        ctrl = QtWidgets.QHBoxLayout()
        self._start_btn = QtWidgets.QPushButton("Start Sweep")
        self._stop_btn = QtWidgets.QPushButton("Stop Sweep")
        self._stop_btn.setEnabled(False)
        ctrl.addWidget(self._start_btn)
        ctrl.addWidget(self._stop_btn)
        # Internal polling interval (ms), no UI control
        self._interval_ms = int(self._ui.get("interval_ms", self._ui.get("sweep_time_ms", 500)))
        ctrl.addSpacing(10)
        self._fit_btn = QtWidgets.QPushButton("Autoscale")
        ctrl.addWidget(self._fit_btn)
        ctrl.addStretch(1)

        # Controls widget for splitter (wrap controls + marker bars when enabled)
        self.controls_widget, ctrl_container = self._build_controls_container(ctrl)

        # Status widget for splitter
        self.status_widget = QtWidgets.QWidget()
        status_layout = QtWidgets.QVBoxLayout(self.status_widget)
        self._status = QtWidgets.QLabel("")
        self._status.setStyleSheet("color:#888; font: 10px 'Consolas','Courier New',monospace;")
        self._status.setVisible(False)  # hide points/samples count per request
        status_layout.addWidget(self._status)
        self.status_widget.setMinimumHeight(22)
        self.status_widget.setSizePolicy(QtWidgets.QSizePolicy.Preferred, QtWidgets.QSizePolicy.Fixed)

        # Bindings
        self._getter = self._resolve(self._ui.get("getter"))
        self._start_fn = self._resolve(self._ui.get("start"))
        self._stop_fn = self._resolve(self._ui.get("stop"))
        self._remote_stream_key = _remote_stream_attr(self._getter)
        self._remote_stream_active = False

        # Shared feed subscription handles per source name
        self._feed_handles = {}
        self._register_ui_clock_slot(self._on_ui_tick)
        self._pending_update = False
        self._auto_follow = True
        # Marker features (already set _markers_enabled above)
        self._markers = []
        self._marker_seq = 0
        self._last_xs = []
        self._last_ys = []
        # Wire up controls
        self._start_btn.clicked.connect(self._on_start)
        self._stop_btn.clicked.connect(self._on_stop)
        self._fit_btn.clicked.connect(self._on_fit_all)
        if self._markers_enabled:
            # Place marker chips/deltas in the controls (top) container to avoid being crushed by plot resizing
            try:
                self.markers_init(ctrl_container or status_layout, self._plot)
            except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:# Fallback to status layout if needed
                self.markers_init(status_layout, self._plot)

        # Internal QTimer for polling sweeps (SweepPlot remains timer-based)
        self._timer = QtCore.QTimer(self)
        self._timer.setTimerType(QtCore.Qt.PreciseTimer)
        self._timer.timeout.connect(self._tick)
        self._register_timer(self._timer)

    def _tick(self) -> None:
        if not callable(self._getter):
            return
        try:
            pts = self._getter()
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            QtWidgets.QMessageBox.critical(self, "Getter", str(e))
            self._on_stop()
            return
        self._mark_remote_stream_started()
        if isinstance(pts, (list, tuple)):
            pts = list(pts)
        else:
            pts = []
        self._set_points(pts)

    def _mark_remote_stream_started(self) -> None:
        if self._remote_stream_active:
            return
        if self._remote_stream_key and _RemoteInstrumentProxy is not None and isinstance(self._inst, _RemoteInstrumentProxy):
            self._remote_stream_active = True

    def _stop_remote_stream(self) -> None:
        if not self._remote_stream_key:
            self._remote_stream_active = False
            return
        if not self._remote_stream_active:
            return
        inst = getattr(self, "_inst", None)
        if _RemoteInstrumentProxy is None or not isinstance(inst, _RemoteInstrumentProxy):
            self._remote_stream_active = False
            return
        stop_stream = getattr(inst, "_stop_stream_consumer", None)
        if callable(stop_stream):
            try:
                stop_stream(self._remote_stream_key)
            except Exception:
                logging.getLogger(__name__).debug(
                    "Failed to stop remote consumer for %s", self._remote_stream_key, exc_info=True
                )
        self._remote_stream_active = False

    def _resolve(self, spec):
        if callable(spec):
            name = getattr(spec, "__name__", None)
            if name:
                bound = getattr(self._inst, name, None)
                if callable(bound):
                    return bound
            # Fallback: try binding as method
            try:
                import types
                return types.MethodType(spec, self._inst)  # type: ignore[arg-type]
            except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                return None
        if isinstance(spec, str):
            return getattr(self._inst, spec, None)
        return None

    # (SweepPlotWidget) keep timer-based polling; shared feed not used here

    def _set_points(self, pts):
        # Skip if our curve has already been destroyed
        if not hasattr(self, "_curve") or self._curve is None:
            return
        xs, ys, _ = _normalize_plot_points(pts)
        if not xs:
            if self._curve is not None:
                self._curve.setData([])
            return

        # Defer drawing and range updates to UI clock
        self._last_xs, self._last_ys = xs, ys
        self._pending_update = True
        # Skip updating points count in UI

    def _on_ui_tick(self) -> None:
        if not self._pending_update or not hasattr(self, "_curve") or self._curve is None:
            return
        self._pending_update = False
        xs, ys = self._last_xs, self._last_ys
        if np is not None and xs and ys:
            try:
                xs_arr = np.asarray(xs, dtype=np.float32)
                ys_arr = np.asarray(ys, dtype=np.float32)
                xs_use, ys_use = xs_arr, ys_arr
            except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                xs_use, ys_use = xs, ys
        else:
            xs_use, ys_use = xs, ys
        if self._curve is not None:
            self._curve.setData(x=xs_use, y=ys_use, autoDownsample=True, clipToView=True, downsampleMethod='peak')
        if self._auto_follow:
            xs_seq = xs_use if hasattr(xs_use, "__len__") else list(xs_use)
            ys_seq = ys_use if hasattr(ys_use, "__len__") else list(ys_use)
            xs_len = len(xs_seq)
            ys_len = len(ys_seq)
            if xs_len > 0 and ys_len > 0 and xs_len == ys_len:
                plot_item_getter = getattr(self._plot, "getPlotItem", None)
                view_box_getter = None
                if callable(plot_item_getter):
                    plot_item = plot_item_getter()
                    view_box_getter = getattr(plot_item, "getViewBox", None)
                if callable(view_box_getter):
                    xmin, xmax, ymin, ymax = _compute_plot_bounds(xs_seq, ys_seq)
                    vb = view_box_getter()
                    if vb is not None:
                        vb.setXRange(float(xmin), float(xmax), padding=0.05)
                        vb.setYRange(float(ymin), float(ymax), padding=0.10)
        if self._markers_enabled and not getattr(self, '_marker_dragging', False):
            self._update_marker_readout()

    def _on_fit_all(self) -> None:
        xs, ys = self._last_xs, self._last_ys
        xs_seq = xs if hasattr(xs, "__len__") else list(xs)
        ys_seq = ys if hasattr(ys, "__len__") else list(ys)
        xs_len = len(xs_seq)
        ys_len = len(ys_seq)
        if xs_len == 0 or ys_len == 0 or xs_len != ys_len:
            return
        plot_item_getter = getattr(self._plot, "getPlotItem", None)
        if not callable(plot_item_getter):
            return
        view_box_getter = getattr(plot_item_getter(), "getViewBox", None)
        if not callable(view_box_getter):
            return
        xmin, xmax, ymin, ymax = _compute_plot_bounds(xs_seq, ys_seq)
        vb = view_box_getter()
        if vb is not None:
            vb.setXRange(xmin, xmax, padding=0.05)
            vb.setYRange(ymin, ymax, padding=0.10)
        self._auto_follow = True

    def _on_user_navigated(self, *args, **kwargs) -> None:
        self._auto_follow = False

    def _on_curve_destroyed(self, *args):
        self._timer.stop()
        self._curve = None

    def _on_plot_destroyed(self, *args):
        t = getattr(self, "_timer", None)
        if isinstance(t, QtCore.QTimer):
            t.stop()

    def _on_start(self) -> None:
        if not callable(self._getter):
            QtWidgets.QMessageBox.critical(self, "Start Sweep", "Getter is not configured for this plot.")
            return
        self._stop_remote_stream()
        self._remote_stream_active = False
        if self._remote_stream_key is None:
            self._remote_stream_key = _remote_stream_attr(self._getter)
        try:
            if callable(self._start_fn):
                self._start_fn()
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            QtWidgets.QMessageBox.critical(self, "Start Sweep", str(e))
            return
        # Start timer-based polling
        self._timer.start(int(self._interval_ms))
        self._start_btn.setEnabled(False)
        self._stop_btn.setEnabled(True)
        QtCore.QTimer.singleShot(0, self._tick)

    def _on_stop(self) -> None:
        self._timer.stop()
        self._stop_remote_stream()
        if callable(self._stop_fn):
            self._stop_fn()
        self._start_btn.setEnabled(True)
        self._stop_btn.setEnabled(False)

    def closeEvent(self, event):  # type: ignore[override]
        self._on_stop()
        super().closeEvent(event)

    # ---- Marker helpers (multi-marker) ----
    def _on_mouse_moved(self, pos):
        vb = self._plot.getPlotItem().getViewBox()
        if vb is None:
            return
        self._mouse_pos_vb = vb.mapSceneToView(pos)

    def _nearest_point(self, x: float) -> Optional[tuple[float, float]]:
        try:
            if not self._last_xs:
                return None
            best_i = min(range(len(self._last_xs)), key=lambda i: abs(self._last_xs[i] - x))
            return (self._last_xs[best_i], self._last_ys[best_i])
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            return None
    def _on_mouse_clicked(self, ev):
        if not self._markers_enabled:
            return
        pos = ev.scenePos()
        try:
            vb = self._plot.getPlotItem().getViewBox()
            if vb is None:
                return
            p = vb.mapSceneToView(pos)
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            return
        x = float(p.x())
        if ev.button() == QtCore.Qt.LeftButton and getattr(ev, 'double', lambda: False)():
            self._add_marker_at_x(x)
        elif ev.button() == QtCore.Qt.RightButton:
            self._context_click_x = x
            try:
                vb.raiseContextMenu(ev)
            except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                mk = self._nearest_marker_at_x(x)
                self._show_marker_menu(mk, global_pos=QtGui.QCursor.pos(), click_x=x)

    def _marker_color(self, idx: int):
        try:
            return pg.mkColor(pg.intColor(idx, hues=12))
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            return pg.mkColor((255, 255, 0))

    def _add_marker_at_x(self, x: float) -> None:
        pt = self._nearest_point(x)
        if not pt:
            return
        idx = self._marker_seq
        self._marker_seq += 1
        name = f"M{idx}"
        color = self._marker_color(idx)
        line = pg.InfiniteLine(angle=90, movable=True, pen=pg.mkPen(color, width=1))
        line.setValue(pt[0])
        try:
            self._plot.addItem(line, ignoreBounds=True)
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            self._plot.addItem(line)
        line.sigPositionChanged.connect(lambda _: self._on_marker_line_moved(line))
        arrow, label = self._create_marker_head(pt[0], color, name)
        mk = {"idx": idx, "name": name, "color": color, "line": line, "pt": pt, "arrow": arrow, "label": label}
        self._bind_marker_head_handlers(arrow, label, mk)
        self._markers.append(mk)
        self._update_marker_readout()
        self._update_marker_heads()

    def _on_marker_line_moved(self, line) -> None:
        x = float(line.value())
        pt = self._nearest_point(x)
        if not pt:
            return
        for mk in self._markers:
            if mk["line"] is line:
                mk["pt"] = pt
                break
        self._update_marker_readout()
        self._update_marker_heads()

    def _nearest_marker_at_x(self, x: float):
        if not self._markers:
            return None
        try:
            vb = self._plot.getPlotItem().getViewBox()
            xr = vb.viewRange()[0]
            tol = (xr[1] - xr[0]) * 0.01
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            tol = 0.0
        best = None
        best_d = float('inf')
        for mk in self._markers:
            d = abs(float(mk["line"].value()) - x)
            if d < best_d:
                best = mk
                best_d = d
        return best if best_d <= tol else None

    def _show_marker_menu(self, marker, global_pos=None, click_x=None) -> None:
        menu = QtWidgets.QMenu(self)
        if marker is not None:
            remove_act = menu.addAction("Remove marker")
            def do_remove():
                self._plot.removeItem(marker["line"])
                if marker.get("arrow"):
                    self._plot.removeItem(marker["arrow"])  # type: ignore[arg-type]
                if marker.get("label"):
                    self._plot.removeItem(marker["label"])  # type: ignore[arg-type]
                self._markers.remove(marker)
                self._remove_overlay_label(marker)
                self._remove_marker_chip(marker)
                self._update_marker_readout()
                self._update_marker_heads()
            remove_act.triggered.connect(do_remove)
        else:
            add_act = menu.addAction("Add marker here")
            add_act.triggered.connect(lambda: self._add_marker_at_x(float(click_x)))
        menu.exec(global_pos or QtGui.QCursor.pos())

    def _update_marker_readout(self) -> None:
        if not self._markers_enabled:
            return
        self._sync_marker_chips()
        self._sync_marker_deltas()

    def _create_marker_head(self, x: float, color, name: str):
        try:
            arrow = pg.ArrowItem(angle=-90, tipAngle=30, headLen=12, tailLen=6, tailWidth=3, pen=pg.mkPen(color), brush=pg.mkBrush(color))
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            arrow = pg.ArrowItem(angle=-90)
        # Keep in-plot TextItem empty; overlay label provides visible text
        label = pg.TextItem(text="", color=color)
        arrow.setZValue(1000)
        label.setZValue(1001)
        label.setAnchor((0.5, 0.0))
        label.setRotation(0)
        label.setAngle(0)
        f = QtGui.QFont()
        f.setPixelSize(12)
        label.setFont(f)
        try:
            self._plot.addItem(arrow, ignoreBounds=True)
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            self._plot.addItem(arrow)
        try:
            self._plot.addItem(label, ignoreBounds=True)
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            self._plot.addItem(label)
        return arrow, label

    def _bind_marker_head_handlers(self, arrow, label, mk_ref) -> None:
        def head_click(ev):
            if ev.button() == QtCore.Qt.RightButton:
                try:
                    x = mk_ref["pt"][0]
                except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                    try:
                        vb = self._plot.getPlotItem().getViewBox()
                        x = float(vb.mapSceneToView(ev.scenePos()).x())
                    except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                        x = None
                if x is not None:
                    self._show_marker_menu(mk_ref, global_pos=QtGui.QCursor.pos(), click_x=x)
                ev.accept()
            elif ev.button() == QtCore.Qt.LeftButton and getattr(ev, 'double', lambda: False)():
                ev.accept()

        def head_drag(ev):
            if ev.isStart():
                ev.accept()
            if ev.isFinish():
                return
            vb = self._plot.getPlotItem().getViewBox()
            p = vb.mapSceneToView(ev.scenePos())
            self._on_marker_head_move_to_x(float(p.x()), mk_ref)

        arrow.mouseClickEvent = head_click
        arrow.mouseDragEvent = head_drag
        label.mouseClickEvent = head_click
        label.mouseDragEvent = head_drag

    def _on_marker_head_move_to_x(self, x: float, mk_ref) -> None:
        if mk_ref is None:
            mk_ref = self._nearest_marker_at_x(x)
        if mk_ref is None:
            return
        mk_ref["line"].setValue(x)

    def _update_marker_heads(self) -> None:
        if not self._markers_enabled or not self._markers:
            return
        vb = self._plot.getPlotItem().getViewBox()
        (xmin, xmax), (ymin, ymax) = vb.viewRange()
        # Pixel-based offsets for robustness on small views
        try:
            px = vb.viewPixelSize()
            dy = float(px[1] if isinstance(px, (tuple, list)) else getattr(px, 'y', lambda: px.y())())
            base_arrow_px = 14.0
            base_label_px = 28.0
            base_sep_px = 8.0
            base_bottom_px = 6.0
            try:
                view_h_px = max(1.0, (ymax - ymin) / max(dy, 1e-9))
            except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                view_h_px = 200.0
            scale = 1.0
            if view_h_px < 120.0:
                scale = max(0.6, view_h_px / 120.0)
            arrow_off_px = base_arrow_px * scale
            label_off_px = base_label_px * scale
            min_sep_px = base_sep_px * scale
            bottom_margin_px = base_bottom_px * scale
            y_arrow = ymax - dy * arrow_off_px
            y_label = ymax - dy * label_off_px
            y_min_margin = ymin + dy * bottom_margin_px
            if y_label < y_min_margin:
                y_label = y_min_margin
            if y_label > y_arrow - dy * min_sep_px:
                y_label = y_arrow - dy * min_sep_px
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            h = (ymax - ymin)
            y_arrow = ymax - h * 0.06
            y_label = max(ymin + h * 0.02, y_arrow - h * 0.04)
        for mk in self._markers:
            try:
                x = float(mk["line"].value())
            except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                x = mk["pt"][0]
            if mk.get("arrow"):
                mk["arrow"].setPos(x, y_arrow)
            if mk.get("label"):
                mk["label"].setPos(x, y_label)
            self._update_overlay_label_for_marker(mk, x, y_label)

    def _install_context_menu_hook(self) -> None:
        vb = self._plot.getPlotItem().getViewBox()
        if getattr(vb, '_markers_menu_hooked', False):
            return
        if not hasattr(vb, 'getMenu'):
            return
        orig_get_menu = vb.getMenu
        def getMenu_hook(ev, orig=orig_get_menu, self_ref=self, vb_ref=vb):
            menu = orig(ev)
            if not self_ref._markers_enabled:
                return menu
            add_act = getattr(vb_ref, '_markers_add_action', None)
            rem_act = getattr(vb_ref, '_markers_remove_action', None)
            if add_act is None:
                add_act = QtGui.QAction("Add marker here", menu)
                vb_ref._markers_add_action = add_act  # type: ignore[attr-defined]
                add_act.triggered.connect(lambda: self_ref._add_marker_at_x(float(getattr(self_ref, '_context_click_x', 0.0))))
            if rem_act is None:
                rem_act = QtGui.QAction("Remove nearest marker", menu)
                vb_ref._markers_remove_action = rem_act  # type: ignore[attr-defined]
                rem_act.triggered.connect(lambda: self_ref._remove_nearest_marker_at_x(float(getattr(self_ref, '_context_click_x', 0.0))))
            acts = menu.actions()
            if add_act not in acts:
                if acts:
                    menu.insertAction(acts[0], rem_act)
                    menu.insertAction(acts[0], add_act)
                else:
                    menu.addAction(add_act)
                    menu.addAction(rem_act)
            return menu
        vb.getMenu = getMenu_hook  # type: ignore[assignment]
        vb._markers_menu_hooked = True  # type: ignore[attr-defined]

    def _remove_nearest_marker_at_x(self, x: float) -> None:
        mk = self._nearest_marker_at_x(x)
        if mk is None:
            return
        # Remove plot items if present
        for key in ("line", "arrow", "label"):
            item = mk.get(key)
            if item is not None:
                self._plot.removeItem(item)  # type: ignore[arg-type]
        # Remove from internal list if present
        if mk in getattr(self, "_markers", []):
            self._markers.remove(mk)
        # Remove overlay and chip UI
        self._remove_overlay_label(mk)
        self._remove_marker_chip(mk)
        self._update_marker_readout()
        self._update_marker_heads()


class MultiTracePlotWidget(PlotWidgetBase, MarkerSupportMixin):
    """Plot multiple selectable channels. Supports 'event' (append) and 'sweep' (replace) modes per source.

    ui example:
      {
        "sources": [
          {"name": "Ch1", "getter": inst.get_ch1, "mode": "event"},
          {"name": "Ch2", "getter": inst.get_ch2, "mode": "sweep"}
        ],
        "interval_ms": 200
      }
    """

    def __init__(self, instrument: BaseInstrument, ui: Optional[dict] = None, parent: Optional[QtWidgets.QWidget] = None):
        super().__init__(parent)
        self._inst = instrument
        self._ui = ui or {}
        self._plot = pg.PlotWidget()
        self._plot.showGrid(x=True, y=True, alpha=0.3)
        self._plot.setMinimumHeight(150)
        self.setMinimumHeight(200)
        self.setSizePolicy(QtWidgets.QSizePolicy.Preferred, QtWidgets.QSizePolicy.Expanding)
        if hasattr(self._plot, 'setAntialiasing'):
            self._plot.setAntialiasing(False)
        pi = self._plot.getPlotItem()
        # Disable built-in autoRange; manage ranges manually to avoid overlays affecting it
        pi.enableAutoRange('xy', False)
        vb = pi.getViewBox()
        if hasattr(vb, 'sigRangeChangedManually'):
            vb.sigRangeChangedManually.connect(lambda *_: self._on_user_navigated())
        if hasattr(vb, 'sigRangeChanged'):
            vb.sigRangeChanged.connect(lambda *_: self._update_marker_heads())
        # Controls
        ctrl = QtWidgets.QHBoxLayout()
        self._start_btn = QtWidgets.QPushButton("Start")
        self._stop_btn = QtWidgets.QPushButton("Stop")
        self._stop_btn.setEnabled(False)
        ctrl.addWidget(self._start_btn)
        ctrl.addWidget(self._stop_btn)
        # Internal polling interval (ms), no exposed UI control
        self._interval_ms = int(self._ui.get("interval_ms", 200))
        ctrl.addSpacing(10)
        # Channel selection via dropdown
        self._traces_btn = QtWidgets.QToolButton()
        self._traces_btn.setText("Traces")
        self._traces_btn.setPopupMode(QtWidgets.QToolButton.InstantPopup)
        self._traces_menu = QtWidgets.QMenu(self._traces_btn)
        self._traces_btn.setMenu(self._traces_menu)
        ctrl.addWidget(self._traces_btn)
        # Autoscale
        self._fit_btn = QtWidgets.QPushButton("Autoscale")
        ctrl.addWidget(self._fit_btn)
        # Clear (resets event buffers)
        self._clear_btn = QtWidgets.QPushButton("Clear")
        self._clear_btn.setToolTip("Clear plotted data for event-mode traces")
        ctrl.addWidget(self._clear_btn)
        # Keep a reference so we can insert buttons later
        self._controls_layout = ctrl
        # Placeholders for optional file UI
        self._file_btn = None
        self._file_label = None
        ctrl.addStretch(1)

        # Controls widget for splitter (wrap markers in controls container too)
        self._markers_enabled = bool(self._ui.get("markers", True))
        self.controls_widget, ctrl_container = self._build_controls_container(ctrl)

        # Status widget for splitter
        self.status_widget = QtWidgets.QWidget()
        status_layout = QtWidgets.QVBoxLayout(self.status_widget)
        self._status = QtWidgets.QLabel("")
        self._status.setStyleSheet("color:#888; font: 10px 'Consolas','Courier New',monospace;")
        status_layout.addWidget(self._status)
        if self._markers_enabled:
            self.markers_init(ctrl_container or status_layout, self._plot)

        # Sources
        self._sources = []  # list of dicts with name, getter, mode
        src_specs = list(self._ui.get("sources", []))
        for spec in src_specs:
            getter = _resolve_on_instrument(self._inst, spec.get("getter"))
            if not callable(getter):
                continue
            mode = spec.get("mode", "sweep")
            name = spec.get("name") or getattr(getter, "__name__", "ch")
            self._sources.append({"name": name, "getter": getter, "mode": mode})
        # Actions per source
        self._actions = []
        for src in self._sources:
            act = QtGui.QAction(src["name"], self)
            act.setCheckable(True)
            act.setChecked(True)
            act.toggled.connect(lambda _v, s=src: self._on_trace_toggle(s["name"], _v))
            self._traces_menu.addAction(act)
            self._actions.append(act)

        # File save parity with EventPlot: support only event-mode traces
        self._event_sources_present = any(s.get("mode") == "event" for s in self._sources)
        self._file_path = None
        self._file = None
        self._sample_time_s = 0.0  # deterministic timebase across ticks
        # Instrument start/stop hooks for entire multi-trace session
        self._start_fn = _resolve_on_instrument(self._inst, self._ui.get("start"))
        self._stop_fn = _resolve_on_instrument(self._inst, self._ui.get("stop"))
        if self._event_sources_present and self._controls_layout is not None:
            self._file_btn = QtWidgets.QPushButton("Choose File…")
            self._file_label = QtWidgets.QLabel("(no file)")
            self._file_label.setStyleSheet("color: #666;")
            self._file_label.setTextInteractionFlags(QtCore.Qt.TextSelectableByMouse)
            idx = max(0, self._controls_layout.count() - 1)
            self._controls_layout.insertWidget(idx, self._file_btn)
            self._controls_layout.insertWidget(idx + 1, self._file_label)
            self._file_btn.clicked.connect(self._on_mt_choose_file)

        # No internal layout stacking; InstrumentTab will add controls_widget, _plot, and status_widget into a splitter

        # Curves and buffers
        self._curves = {}
        self._event_bufs = {}  # name -> (xs, ys)
        for i, src in enumerate(self._sources):
            pen = pg.intColor(i, hues=len(self._sources))
            self._curves[src["name"]] = self._plot.plot([], pen=pen, name=src["name"])  # type: ignore[arg-type]
            if src["mode"] == "event":
                self._event_bufs[src["name"]] = ([], [])

        # Shared feed subscriptions container and UI clock
        self._feed_handles = {}
        self._register_ui_clock_slot(self._on_ui_tick)

        # Wire buttons
        self._start_btn.clicked.connect(self._on_start)
        self._stop_btn.clicked.connect(self._on_stop)
        self._fit_btn.clicked.connect(self._on_fit_all)
        self._clear_btn.clicked.connect(self._on_clear)

        # Follow mode default + throttle
        self._auto_follow = True
        self._auto_follow_timer = QtCore.QElapsedTimer()
        self._auto_follow_timer.start()
        self._auto_follow_min_interval_ms = 120
        self._pending_range = False

    def _on_user_navigated(self) -> None:
        # When user pans/zooms, pause auto-follow
        self._auto_follow = False

    def _on_clear(self):
        # Clear only event-mode buffers
        try:
            for name, (xs, ys) in self._event_bufs.items():
                xs.clear(); ys.clear()
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            self._event_bufs = {k: ([], []) for k in self._event_bufs.keys()}
        for name, curve in self._curves.items():
            if next((s for s in self._sources if s['name'] == name and s['mode'] == 'event'), None) is not None:
                curve.setData([])
        self._auto_follow = True

    # Provide marker series by concatenating all visible curves' current data
    def _marker_series(self):
        try:
            xs_all, ys_all = [], []
            for name, curve in self._curves.items():
                act = next((a for a in self._actions if a.text() == name), None)
                if act is not None and not act.isChecked():
                    continue
                data = curve.getData() if hasattr(curve, 'getData') else None
                if not data:
                    continue
                xs, ys = data
                if xs is None or ys is None:
                    continue
                xs_all.extend(xs)
                ys_all.extend(ys)
            return xs_all, ys_all
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            return [], []

    def _set_follow(self, on: bool):
        self._auto_follow = on

    def _on_fit_all(self):
        xs_all: list[float] = []
        ys_all: list[float] = []
        for name, curve in self._curves.items():
            act = next((a for a in self._actions if a.text() == name), None)
            if act is not None and not act.isChecked():
                continue
            data = curve.getData() if hasattr(curve, 'getData') else None
            if not data:
                continue
            xs, ys = data
            if xs is None or ys is None or len(xs) == 0:
                continue
            xs_all.extend(xs)
            ys_all.extend(ys)
        if xs_all:
            if len(xs_all) == len(ys_all):
                plot_item_getter = getattr(self._plot, "getPlotItem", None)
                if callable(plot_item_getter):
                    view_box_getter = getattr(plot_item_getter(), "getViewBox", None)
                    if callable(view_box_getter):
                        xmin, xmax, ymin, ymax = _compute_plot_bounds(xs_all, ys_all)
                        vb = view_box_getter()
                        if vb is not None:
                            vb.setXRange(float(xmin), float(xmax), padding=0.05)
                            vb.setYRange(float(ymin), float(ymax), padding=0.10)
        self._auto_follow = True

    def _on_start(self):
        if not self._sources:
            QtWidgets.QMessageBox.critical(self, "Multi-Trace", "No sources configured.")
            return
        start_fn = getattr(self, "_start_fn", None)
        if callable(start_fn):
            try:
                start_fn()
            except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                logging.getLogger(__name__).warning("Multi-Trace start hook failed: %s", e, exc_info=True)
                return
        # Reset deterministic sample clock
        self._sample_time_s = 0.0
        # Open file if chosen and at least one event-mode source exists
        if self._event_sources_present and self._file_path is not None and self._file is None:
            try:
                self._file = self._file_path.open("a", encoding="utf-8")
                if self._file.tell() == 0:
                    # Long format for multiple channels
                    self._file.write("time_s,name,y\n")
            except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                QtWidgets.QMessageBox.critical(self, "File", str(e))
                self._file = None
        # Subscribe each source to shared feed and start
        for src in self._sources:
            getter = src["getter"]
            name = src["name"]
            mode = src["mode"]
            def make_cb(name=name, mode=mode):
                def cb(pts):
                    self._on_feed_points(name, mode, pts)
                return cb
            # Accumulate for event sources; don't accumulate for sweep
            accumulate = (mode == "event")
            handle = _feed_mgr.subscribe(self._inst, getter, int(self._interval_ms), make_cb(), accumulate=accumulate)
            self._feed_handles[name] = handle
            _feed_mgr.start(handle)
        self._start_btn.setEnabled(False)
        self._stop_btn.setEnabled(True)

    def _on_stop(self):
        # Stop and unsubscribe all feeds
        for name, handle in list(self._feed_handles.items()):
            _feed_mgr.stop(handle)
            _feed_mgr.unsubscribe(handle)
            self._feed_handles.pop(name, None)
        stop_fn = getattr(self, "_stop_fn", None)
        if callable(stop_fn):
            try:
                stop_fn()
            except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                logging.getLogger(__name__).warning("Multi-Trace stop hook failed: %s", e, exc_info=True)
        self._start_btn.setEnabled(True)
        self._stop_btn.setEnabled(False)
        if self._file:
            self._file.close()
        self._file = None

    def _on_trace_toggle(self, name: str, visible: bool):
        curve = self._curves.get(name)
        if curve is not None:
            curve.setVisible(visible)

    def _on_feed_points(self, name: str, mode: str, pts):
        # Skip processing if trace is hidden, but still keep buffers updated for consistency
        act = next((a for a in self._actions if a.text() == name), None)
        try:
            pts = list(pts) if isinstance(pts, (list, tuple)) else []
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            pts = []
        if not pts:
            return
        if mode == "sweep":
            p0 = pts[0]
            is_pair = hasattr(p0, "__len__") and not isinstance(p0, (int, float)) and len(p0) >= 2
            if is_pair:
                xs = []
                ys = []
                for p in pts:
                    try:
                        x = float(p[0]); y = float(p[1])
                    except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                        continue
                    if x == x and y == y and abs(x) != float('inf') and abs(y) != float('inf'):
                        xs.append(x); ys.append(y)
            else:
                ys = []
                for v in pts:
                    try:
                        vv = float(v)
                    except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                        continue
                    if vv == vv and abs(vv) != float('inf'):
                        ys.append(vv)
                xs = list(range(len(ys)))
            if np is not None and xs and ys:
                try:
                    xs_arr = np.asarray(xs, dtype=np.float32)
                    ys_arr = np.asarray(ys, dtype=np.float32)
                    xs_use, ys_use = xs_arr, ys_arr
                except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                    xs_use, ys_use = xs, ys
            else:
                xs_use, ys_use = xs, ys
            self._curves[name].setData(x=xs_use, y=ys_use, autoDownsample=True, clipToView=True)
        else:
            xs, ys = self._event_bufs[name]
            before_len = len(ys)
            p0 = pts[0]
            is_pair = hasattr(p0, "__len__") and not isinstance(p0, (int, float)) and len(p0) >= 2
            if is_pair:
                for p in pts:
                    try:
                        x = float(p[0]); y = float(p[1])
                    except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                        continue
                    if x == x and y == y and abs(x) != float('inf') and abs(y) != float('inf'):
                        xs.append(x); ys.append(y)
            else:
                for v in pts:
                    try:
                        vv = float(v)
                    except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                        continue
                    if vv == vv and abs(vv) != float('inf'):
                        ys.append(vv)
                start = (xs[-1] + 1) if xs else 0
                xs.extend([start + i for i in range(len(ys) - len(xs))])
            max_points = int(self._ui.get("max_points", 2000))
            if len(xs) > max_points:
                cut = len(xs) - max_points
                xs[:] = xs[cut:]
                ys[:] = ys[cut:]
            if np is not None and xs and ys:
                try:
                    xs_arr = np.asarray(xs, dtype=np.float32)
                    ys_arr = np.asarray(ys, dtype=np.float32)
                    xs_use, ys_use = xs_arr, ys_arr
                except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                    xs_use, ys_use = xs, ys
            else:
                xs_use, ys_use = xs, ys
            self._curves[name].setData(x=xs_use, y=ys_use, autoDownsample=True, clipToView=True)
            # Write CSV rows for this event-mode source immediately using this widget's interval
            if self._file and self._event_sources_present:
                added_count = max(0, len(ys) - before_len)
                if added_count > 0:
                    vals = list(ys[-added_count:])
                    dt_s = max(0.0, float(self._interval_ms) / 1000.0)
                    n = len(vals)
                    step = (dt_s / n) if n > 0 else 0.0
                    for i, yv in enumerate(vals, start=1):
                        t = self._sample_time_s + step * i
                        self._file.write(f"{t:.6f},{name},{yv}\n")
                    self._file.flush()
                    self._sample_time_s += dt_s
        # After any data, schedule a coalesced auto-follow range update
        if self._auto_follow:
            self._pending_range = True
        if getattr(self, '_markers_enabled', False):
            self._update_marker_readout()
            self._update_marker_heads()

    def _on_ui_tick(self):
        if not self._pending_range or not self._auto_follow:
            return
        self._pending_range = False
        xs_all: list[float] = []
        ys_all: list[float] = []
        for name, curve in self._curves.items():
            act = next((a for a in self._actions if a.text() == name), None)
            if act is not None and not act.isChecked():
                continue
            data = curve.getData() if hasattr(curve, 'getData') else None
            if not data:
                continue
            xs, ys = data
            if xs is None or ys is None or len(xs) == 0:
                continue
            xs_all.extend(xs)
            ys_all.extend(ys)
        if xs_all:
            if len(xs_all) == len(ys_all):
                plot_item_getter = getattr(self._plot, "getPlotItem", None)
                if callable(plot_item_getter):
                    view_box_getter = getattr(plot_item_getter(), "getViewBox", None)
                    if callable(view_box_getter):
                        xmin, xmax, ymin, ymax = _compute_plot_bounds(xs_all, ys_all)
                        vb = view_box_getter()
                        if vb is not None:
                            vb.setXRange(float(xmin), float(xmax), padding=0.05)
                            vb.setYRange(float(ymin), float(ymax), padding=0.10)

    def _on_mt_choose_file(self) -> None:
        path, _ = QtWidgets.QFileDialog.getSaveFileName(self, "Select CSV file", filter="CSV Files (*.csv);;All Files (*)")
        if path:
            self._file_path = Path(path)
            if self._file_label is not None:
                self._file_label.setText(self._file_path.name)
                self._file_label.setToolTip(str(self._file_path))

    # No public interval control; internal _interval_ms retained

    # Rely on PlotWidgetBase.closeEvent for cleanup of feeds/files


class WaterfallWidget(PlotWidgetBase):
    """Spectrogram/waterfall for repeated sweeps.

    ui example: {"getter": inst.get_sweep_points, "history": 300, "interval_ms": 100}
    Requires numpy; if missing, shows a placeholder message.
    """

    def __init__(self, instrument: BaseInstrument, ui: Optional[dict] = None, parent: Optional[QtWidgets.QWidget] = None):
        super().__init__(parent)
        self._inst = instrument
        self._ui = ui or {}
        self._getter = _resolve_on_instrument(self._inst, self._ui.get("getter"))
        self._start_fn = _resolve_on_instrument(self._inst, self._ui.get("start"))
        self._stop_fn = _resolve_on_instrument(self._inst, self._ui.get("stop"))

        # Plot area
        self._plot = pg.PlotWidget()
        self._img = pg.ImageItem()
        self._plot.addItem(self._img)
        self._plot.showGrid(x=True, y=True, alpha=0.2)
        self._plot.setMinimumHeight(150)
        self.setMinimumHeight(200)
        self.setSizePolicy(QtWidgets.QSizePolicy.Preferred, QtWidgets.QSizePolicy.Expanding)
        if hasattr(self._plot, 'setAntialiasing'):
            self._plot.setAntialiasing(False)

        # Controls row
        ctrl = QtWidgets.QHBoxLayout()
        self._start_btn = QtWidgets.QPushButton("Start")
        self._stop_btn = QtWidgets.QPushButton("Stop")
        self._stop_btn.setEnabled(False)
        ctrl.addWidget(self._start_btn)
        ctrl.addWidget(self._stop_btn)
        # Internal polling interval (ms), no exposed UI control
        self._interval_ms = int(self._ui.get("interval_ms", 100))
        ctrl.addStretch(1)

        # Controls widget for splitter
        self.controls_widget = QtWidgets.QWidget()
        self.controls_widget.setLayout(ctrl)

        # Status widget for splitter
        self.status_widget = QtWidgets.QWidget()
        status_layout = QtWidgets.QVBoxLayout(self.status_widget)
        self._status = QtWidgets.QLabel("")
        self._status.setStyleSheet("color:#888; font: 10px 'Consolas','Courier New',monospace;")
        status_layout.addWidget(self._status)

        # History buffer for image rows
        self._history = int(self._ui.get("history", 200))
        self._buffer = None  # type: ignore[assignment]
        self._ncols = None   # type: ignore[assignment]

        # Shared feed subscription handle
        self._feed_handle = None

        # Wire buttons
        self._start_btn.clicked.connect(self._on_start)
        self._stop_btn.clicked.connect(self._on_stop)
        # no interval control; keep internal value only

        if np is None:
            # Show a note in status if numpy is missing
            self._status.setText("numpy not installed; waterfall disabled")

    def _resolve(self, spec):
        # Deprecated: keep for back-compat
        return _resolve_on_instrument(self._inst, spec)

    def _on_start(self):
        if not callable(self._getter):
            QtWidgets.QMessageBox.critical(self, "Waterfall", "Getter is not configured for this widget.")
            return
        if np is None:
            QtWidgets.QMessageBox.critical(self, "Waterfall", "NumPy is required for the spectrogram. Please install numpy.")
            return
        if callable(self._start_fn):
            self._start_fn()
        # Subscribe via shared feed (do not accumulate: we render latest sweep as next row)
        def deliver(pts):
            self._on_points(pts)
        self._feed_handle = _feed_mgr.subscribe(self._inst, self._getter, int(self._interval_ms), deliver, accumulate=False)
        if self._feed_handle is not None:
            _feed_mgr.start(self._feed_handle)
        self._start_btn.setEnabled(False)
        self._stop_btn.setEnabled(True)

    def _on_stop(self):
        if self._feed_handle is not None:
            _feed_mgr.stop(self._feed_handle)
            _feed_mgr.unsubscribe(self._feed_handle)
        self._feed_handle = None
        if callable(self._stop_fn):
            self._stop_fn()
        self._start_btn.setEnabled(True)
        self._stop_btn.setEnabled(False)

    def _on_points(self, ys):
        # Expect a 1D sequence of magnitudes per sweep (already polled by feed)
        try:
            ys = list(ys) if isinstance(ys, (list, tuple)) else []
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            ys = []
        if not ys:
            return
        row = []
        for v in ys:
            try:
                fv = float(v)
            except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                continue
            if fv == fv and abs(fv) != float('inf'):
                row.append(fv)
        if not row:
            return
        # initialize/reset buffer shape
        if self._ncols is None or self._buffer is None:
            self._ncols = len(row)
            self._buffer = np.zeros((self._history, self._ncols), dtype=float)
        elif len(row) != self._ncols:
            self._ncols = len(row)
            self._buffer = np.zeros((self._history, self._ncols), dtype=float)
        # roll and insert
        self._buffer = np.roll(self._buffer, -1, axis=0)
        self._buffer[-1, :] = np.array(row)
        self._img.setImage(self._buffer, autoLevels=True)

    def _on_interval_changed(self, v: int) -> None:
        if self._feed_handle is not None:
            _feed_mgr.update_interval(self._feed_handle, int(self._interval_ms))

    # Rely on PlotWidgetBase.closeEvent for safe cleanup


class _Overlay(QtWidgets.QFrame):
    """A semi-transparent overlay that captures clicks to activate a tab."""

    clicked = QtCore.Signal()

    def __init__(self, parent: QtWidgets.QWidget):
        super().__init__(parent)
        self.setAttribute(QtCore.Qt.WA_NoSystemBackground)
        self.setAttribute(QtCore.Qt.WA_TransparentForMouseEvents, False)
        # Darker and clearer overlay; larger, bold text
        self.setStyleSheet(
            "QFrame { background-color: rgba(0,0,0,150); color: white; border: 1px solid #666; }\n"
            "QLabel { color: white; font: bold 15px 'Segoe UI','Arial'; padding: 6px; }"
        )
        self.setVisible(False)
        parent.installEventFilter(self)
        lay = QtWidgets.QVBoxLayout(self)
        lay.setContentsMargins(12, 12, 12, 12)
        lay.addStretch()
        self._label = QtWidgets.QLabel("🔒 Exclusive resource in use. Click to switch here")
        self._label.setAlignment(QtCore.Qt.AlignCenter)
        lay.addWidget(self._label)
        lay.addStretch()

    def set_message(self, text: str) -> None:
        self._label.setText(text)

    def resizeEvent(self, e):  # type: ignore[override]
        self.setGeometry(self.parentWidget().rect())
        return super().resizeEvent(e)

    def mousePressEvent(self, e):  # type: ignore[override]
        self.clicked.emit()
        e.accept()

    def showEvent(self, e):  # type: ignore[override]
        self.setGeometry(self.parentWidget().rect())
        self.raise_()
        return super().showEvent(e)

    def eventFilter(self, obj, event):  # type: ignore[override]
        et = int(event.type())
        if et in (12, 14, 17):  # Resize, LayoutRequest, Show
            self.setGeometry(self.parentWidget().rect())
            self.raise_()
        try:
            return QtWidgets.QFrame.eventFilter(self, obj, event)
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            return False


class InstrumentTab(QtWidgets.QWidget):
    activated = QtCore.Signal()

    def __init__(self, instrument: BaseInstrument):
        super().__init__()
        self.instrument = instrument
        # Keep references to composite plot widgets so their timers/slots remain valid
        self._owned_plot_widgets: list[QtWidgets.QWidget] = []
        # Outer layout contains a vertical splitter so user can resize sections via drag handles
        outer_layout = QtWidgets.QVBoxLayout(self)
        self._splitter = QtWidgets.QSplitter(QtCore.Qt.Vertical)
        self._splitter.setHandleWidth(6)
        outer_layout.addWidget(self._splitter)
        self._splitter.setChildrenCollapsible(False)

        # UI logger for this instrument tab
        self._log = logging.getLogger(
            f"instrctl.gui.InstrumentTab.{instrument.__class__.__name__}"
        )
        features = instrument.features()
        handled: set[str] = set()

        # Render widgets based on feature.ui metadata; fallback to generic buttons when ui is missing.
        gpio_added = False
        for disp_name, meta in sorted(features.items()):
            attr = meta.get("attr", meta["name"])  # actual attribute on instrument
            if attr in handled:
                continue
            ui = meta.get("ui") or {}
            widget_spec = ui.get("widget")
            self._log.info("Feature '%s' (attr=%s) widget=%s", disp_name, attr, getattr(widget_spec, "__name__", str(widget_spec)))
            widget_type = None
            if widget_spec is not None:
                # Class-based mapping only
                if widget_spec is UnitLineEdit:
                    widget_type = "unit_input"
                elif widget_spec is LabeledSlider:
                    widget_type = "slider"
                elif widget_spec is ToggleSwitch:
                    widget_type = "toggle"
                elif widget_spec is GPIOPanel:
                    widget_type = "gpio_panel"
                elif widget_spec is FrequencyPlotWidget or widget_spec is SpectrumPlotWidget:
                    widget_type = "spectrum_plot"
                elif widget_spec is QtWidgets.QPushButton:
                    widget_type = "button"

            # GPIO panel (only once)
            if widget_type == "gpio_panel" and not gpio_added:
                if all(hasattr(instrument, name) for name in ("pins_count", "set_pin_mode", "write_pin", "read_pin")):
                    w = GPIOPanel(instrument)
                    self._splitter.addWidget(w)
                    i = self._splitter.indexOf(w)
                    self._splitter.setStretchFactor(i, 0)
                    self._log.info("Added GPIOPanel for '%s'", disp_name)
                    gpio_added = True
                handled.add(attr)
                continue

            # Unit input (e.g., frequency)
            if widget_type == "unit_input":
                row = QtWidgets.QHBoxLayout()
                label = QtWidgets.QLabel(ui.get("label", disp_name))
                line = UnitLineEdit()
                line.setClearButtonEnabled(True)
                # Helpful placeholder based on units if provided
                ph_unit = ui.get("unit")
                if ph_unit:
                    line.setPlaceholderText(f"e.g. 99.5M {ph_unit}")
                else:
                    line.setPlaceholderText("e.g. 99.5M")
                read_lbl = QtWidgets.QLabel("")
                read_lbl.setMinimumWidth(140)
                read_lbl.setStyleSheet("color: #666;")
                row.addWidget(label)
                row.addWidget(line, 1)
                row.addWidget(read_lbl)
                row_w = QtWidgets.QWidget()
                row_w.setLayout(row)
                self._splitter.addWidget(row_w)
                i = self._splitter.indexOf(row_w)
                self._splitter.setStretchFactor(i, 0)
                self._log.info("Added unit_input row for '%s'", disp_name)

                def update_readback_display(value: object) -> None:
                    if isinstance(value, numbers.Real):
                        read_lbl.setText(_format_engineering(float(value), unit))
                        line.setText(_format_engineering(float(value), None))
                    elif value is not None:
                        read_lbl.setText(str(value))

                fn = getattr(instrument, attr, None)
                if callable(fn):
                    def make_handler(
                        f,
                        disp_name=disp_name,
                        ui=ui,
                        instrument=instrument,
                        line=line,
                        read_lbl=read_lbl,
                    ):
                        def handler():
                            meth = getattr(f, "__name__", str(f))
                            self._log.info("UI commit unit_input '%s' -> %s", disp_name, meth)
                            val = line.value()
                            if val is not None:
                                if _RemoteInstrumentProxy is not None and isinstance(self._inst, _RemoteInstrumentProxy):
                                    attr_name = None
                                    try:
                                        attr_name = getattr(self._getter, "_orig_attr", None)
                                    except Exception:
                                        attr_name = None
                                    if not attr_name:
                                        try:
                                            attr_name = getattr(self._getter, "__name__", None)
                                        except Exception:
                                            attr_name = None
                                    if isinstance(attr_name, str) and attr_name:
                                        try:
                                            self._inst._stop_stream_consumer(attr_name)
                                        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                                            logging.getLogger(__name__).debug("Failed to stop remote consumer for %s: %s", attr_name, e, exc_info=True)
                                try:
                                    f(float(val))
                                except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                                    QtWidgets.QMessageBox.critical(self, "Error", str(e))
                                else:
                                    # Update readback after setting
                                    rb_fn = ui.get("readback")
                                    unit = ui.get("unit")
                                    if callable(rb_fn):
                                        name = getattr(rb_fn, "__name__", None)
                                        getter = getattr(instrument, name, None) if name else None
                                        if callable(getter):
                                            actual = getter()
                                            update_readback_display(actual)
                        return handler
                    handler = make_handler(fn)
                    # Apply on Enter or focus-out via unified signal
                    line.committed.connect(handler)

                # Initialize readback on create if available
                rb_fn = ui.get("readback")
                unit = ui.get("unit")
                if callable(rb_fn):
                    name = getattr(rb_fn, "__name__", None)
                    getter = getattr(instrument, name, None) if name else None
                    if callable(getter):
                        actual = getter()
                        update_readback_display(actual)
                handled.add(attr)
                continue

            # Slider
            if widget_type == "slider":
                row = QtWidgets.QHBoxLayout()
                label = QtWidgets.QLabel(ui.get("label", disp_name))
                minimum = int(ui.get("min", 0))
                maximum = int(ui.get("max", 100))
                value = int(ui.get("value", minimum))
                slider = LabeledSlider(minimum, maximum, value)
                read_lbl = QtWidgets.QLabel("")
                read_lbl.setMinimumWidth(140)
                read_lbl.setStyleSheet("color: #666;")
                row.addWidget(label)
                row.addWidget(slider)
                row.addWidget(read_lbl)
                row_w = QtWidgets.QWidget()
                row_w.setLayout(row)
                self._splitter.addWidget(row_w)
                i = self._splitter.indexOf(row_w)
                self._splitter.setStretchFactor(i, 0)
                self._log.info("Added slider row for '%s'", disp_name)

                fn = getattr(instrument, attr, None)
                if callable(fn):
                    apply_on_release = ui.get("apply_on_release", True)
                    commit_debounce_ms = int(ui.get("commit_debounce_ms", 200))
                    # Commit handler (invoked on release by default)
                    def commit(
                        v: int,
                        f=fn,
                        disp_name=disp_name,
                        ui=ui,
                        instrument=instrument,
                        read_lbl=read_lbl,
                        slider=slider,
                    ):
                        meth = getattr(f, "__name__", str(f))
                        self._log.info("UI slider commit '%s' -> %s (fn=%s)", disp_name, v, meth)
                        try:
                            f(float(v))
                        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                            QtWidgets.QMessageBox.critical(self, "Error", str(e))
                        else:
                            rb_fn = ui.get("readback")
                            unit = ui.get("unit")
                            if callable(rb_fn):
                                name = getattr(rb_fn, "__name__", None)
                                getter = getattr(instrument, name, None) if name else None
                                if callable(getter):
                                    actual = getter()
                                    if isinstance(actual, numbers.Real):
                                        read_lbl.setText(_format_engineering(float(actual), unit))
                                        # Snap slider to the actual device value (rounded to int)
                                        try:
                                            sv = int(round(float(actual)))
                                            sv = max(int(slider.slider.minimum()), min(int(slider.slider.maximum()), sv))
                                            if slider.value() != sv:
                                                slider.slider.blockSignals(True)
                                                slider.slider.setValue(sv)
                                                slider.label.setText(str(sv))
                                        finally:
                                            slider.slider.blockSignals(False)
                                    elif actual is not None:
                                        read_lbl.setText(str(actual))
                    # Create a debounce timer for valueChanged events (wheel/keyboard)
                    if apply_on_release:
                        tmr = QtCore.QTimer(self)
                        tmr.setSingleShot(True)
                        def fire_commit():
                            commit(slider.value())
                        tmr.timeout.connect(fire_commit)
                        # keep a reference on the slider instance
                        setattr(slider, "_commit_timer", tmr)
                        slider.released.connect(commit)
                        # Debounced commit on any value change (wheel/keyboard)
                        def on_changed(_v: int, timer=tmr):
                            timer.stop()
                            timer.start(int(commit_debounce_ms))
                        slider.valueChanged.connect(on_changed)
                    else:
                        # Legacy behavior: apply on every change
                        slider.valueChanged.connect(commit)

                # Initialize readback
                rb_fn = ui.get("readback")
                unit = ui.get("unit")
                if callable(rb_fn):
                    name = getattr(rb_fn, "__name__", None)
                    getter = getattr(instrument, name, None) if name else None
                    if callable(getter):
                        actual = getter()
                        if isinstance(actual, numbers.Real):
                            read_lbl.setText(_format_engineering(float(actual), unit))
                            try:
                                sv = int(round(float(actual)))
                                sv = max(int(slider.slider.minimum()), min(int(slider.slider.maximum()), sv))
                                if slider.value() != sv:
                                    slider.slider.blockSignals(True)
                                    slider.slider.setValue(sv)
                                    slider.label.setText(str(sv))
                            finally:
                                slider.slider.blockSignals(False)
                        elif actual is not None:
                            read_lbl.setText(str(actual))
                handled.add(attr)
                continue

            # Toggle with paired off method
            if widget_type == "toggle":
                row = QtWidgets.QHBoxLayout()
                label = QtWidgets.QLabel(ui.get("label", disp_name))
                toggle = ToggleSwitch()
                row.addWidget(label)
                row.addWidget(toggle)
                row_w = QtWidgets.QWidget()
                row_w.setLayout(row)
                self._splitter.addWidget(row_w)
                i = self._splitter.indexOf(row_w)
                self._splitter.setStretchFactor(i, 0)
                self._log.info("Added toggle row for '%s'", disp_name)

                on_fn = getattr(instrument, attr, None)
                off_spec = ui.get("off_method")
                off_fn = None
                off_attr_name = None
                if callable(off_spec):
                    off_attr_name = getattr(off_spec, "__name__", None)
                    off_fn = getattr(instrument, off_attr_name, None) if off_attr_name else None
                elif isinstance(off_spec, str):
                    off_attr_name = off_spec
                    off_fn = getattr(instrument, off_attr_name, None)

                def on_toggled(checked: bool, onf=on_fn, offf=off_fn, disp_name=disp_name):
                    self._log.info("UI toggle '%s' -> %s", disp_name, checked)
                    try:
                        if checked and callable(onf):
                            onf()
                        elif not checked and callable(offf):
                            offf()
                    except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                        QtWidgets.QMessageBox.critical(self, "Error", str(e))

                toggle.toggled.connect(on_toggled)
                handled.add(attr)
                if off_attr_name:
                    handled.add(off_attr_name)
                continue

            # Spectrum plot widget subscribes to 'sweep' events
            if widget_type == "spectrum_plot":
                try:
                    w = widget_spec(instrument=instrument)  # type: ignore[misc]
                except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                    try:
                        w = widget_spec()  # type: ignore[misc]
                    except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                        w = None
                if isinstance(w, QtWidgets.QWidget):
                    self._splitter.addWidget(w)
                    i = self._splitter.indexOf(w)
                    # Let plots expand more by default
                    self._splitter.setStretchFactor(i, 1)
                    self._log.info("Added SpectrumPlotWidget for '%s'", disp_name)
                    handled.add(attr)
                    continue

            # Generic plugin-provided QWidget subclass: instantiate dynamically
            if inspect.isclass(widget_spec) and issubclass(widget_spec, QtWidgets.QWidget):
                w = None
                # Try a few common constructor signatures
                # If the widget expects a getter and ui doesn't specify one, inject the feature method
                ui_for_widget = dict(ui) if isinstance(ui, dict) else {}
                meth = getattr(instrument, attr, None)
                # Inject default getter if missing OR provided but falsy/non-callable
                if not ui_for_widget.get("getter") and callable(meth):
                    ui_for_widget["getter"] = meth
                candidates = [
                    {"instrument": instrument, "ui": ui_for_widget},
                    {"instrument": instrument},
                    {"parent": self, "instrument": instrument, "ui": ui_for_widget},
                    {"parent": self, "instrument": instrument},
                    {"parent": self},
                    {},
                ]
                for kwargs in candidates:
                    try:
                        # Filter kwargs to match the constructor signature
                        sig = inspect.signature(widget_spec.__init__)
                        call_kwargs = {k: v for k, v in kwargs.items() if k in sig.parameters}
                        # Pass as keyword arguments so custom widgets can accept instrument/ui
                        w = widget_spec(**call_kwargs)  # type: ignore[misc]
                        break
                    except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                        w = None
                        logging.getLogger(__name__).warning(
                            "Failed to construct %s with kwargs %s: %s",
                            getattr(widget_spec, "__name__", str(widget_spec)),
                            list(kwargs.keys()),
                            e,
                        )
                # If this is a known plot widget, insert its controls/plot/status as separate splitter items
                # so users can resize each section. Keep ownership of the root widget to preserve timers/signals.
                plot_types = (EventPlotWidget, SweepPlotWidget, MultiTracePlotWidget, WaterfallWidget)
                if not isinstance(w, QtWidgets.QWidget):
                    logging.getLogger(__name__).warning(
                        "Plugin widget %s did not produce a QWidget for feature '%s' — got %r; skipping.",
                        getattr(widget_spec, "__name__", str(widget_spec)), disp_name, w,
                    )
                    handled.add(attr)
                    continue

                if isinstance(w, plot_types):
                    cw = getattr(w, "controls_widget", None)
                    pw = getattr(w, "_plot", None)
                    sw = getattr(w, "status_widget", None)
                    # Validate sub-widgets; fall back to adding the whole widget if anything is missing
                    if isinstance(cw, QtWidgets.QWidget) and isinstance(pw, QtWidgets.QWidget) and isinstance(sw, QtWidgets.QWidget):
                        # Maintain reference so Python GC doesn't collect the composite object
                        self._owned_plot_widgets.append(w)
                        self._splitter.addWidget(cw)
                        i = self._splitter.indexOf(cw)
                        self._splitter.setStretchFactor(i, 0)
                        self._splitter.addWidget(pw)
                        i = self._splitter.indexOf(pw)
                        self._splitter.setStretchFactor(i, 1)
                        self._splitter.addWidget(sw)
                        i = self._splitter.indexOf(sw)
                        self._splitter.setStretchFactor(i, 0)
                        self._log.info("Added plot widget '%s' as tri-part splitter items", getattr(widget_spec, "__name__", str(widget_spec)))
                        handled.add(attr)
                        continue
                    # If any sub-widget is missing, add the whole widget as a safe fallback
                self._splitter.addWidget(w)
                i = self._splitter.indexOf(w)
                # If the widget advertises an expanding vertical size policy, let it grow.
                prefer_expand = False
                try:
                    sp = w.sizePolicy()
                    vp = int(sp.verticalPolicy())
                    prefer_expand = vp in (
                        int(QtWidgets.QSizePolicy.Expanding),
                        int(QtWidgets.QSizePolicy.MinimumExpanding),
                    )
                except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                    prefer_expand = False
                self._splitter.setStretchFactor(i, 1 if (isinstance(w, plot_types) or prefer_expand) else 0)
                self._log.info("Added widget '%s' as single splitter item", getattr(widget_spec, "__name__", str(widget_spec)))
                handled.add(attr)
                continue

            # If no ui mapping, create a generic button for the feature
            btn = QtWidgets.QPushButton(disp_name)
            fn = getattr(instrument, attr, None)
            if callable(fn):
                def make_handler(f, disp_name=disp_name):
                    def handler():
                        self._log.info("UI button '%s' press", disp_name)
                        try:
                            argc = f.__code__.co_argcount - 1
                        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                            argc = 0
                        args = []
                        for i in range(argc):
                            text, ok = QtWidgets.QInputDialog.getText(self, "Input", f"Arg {i+1}:")
                            if not ok:
                                return
                            try:
                                val = eval(text, {"__builtins__": {}}, {})
                            except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                                val = text
                            args.append(val)
                        try:
                            f(*args)
                        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                            QtWidgets.QMessageBox.critical(self, "Error", str(e))
                    return handler
                btn.clicked.connect(make_handler(fn))
            self._splitter.addWidget(btn)
            i = self._splitter.indexOf(btn)
            self._splitter.setStretchFactor(i, 0)
            handled.add(attr)

    # Default plots removed; plugins can opt-in by declaring a plot widget in feature.ui

    def mousePressEvent(self, e):  # type: ignore[override]
        self.activated.emit()
        super().mousePressEvent(e)

    # ---- Exclusivity control from _MultiManager ----
    def set_exclusive_active(self, active: bool) -> None:
        """When inactive, force-stop any running plots in this tab.

        This does not auto-start anything when becoming active; it only ensures
        that exclusive siblings stop polling/streaming and the UI clearly halts.
        """
        # Stop all known plot widgets unconditionally when inactive
        if not active:
            for w in list(getattr(self, "_owned_plot_widgets", [])):
                # Common stop handler name across plots
                if hasattr(w, "_on_stop") and callable(getattr(w, "_on_stop")):
                    w._on_stop()  # type: ignore[attr-defined]


class InstrumentDock(QtWidgets.QDockWidget):
    """Dock widget wrapping an InstrumentTab that can be floated/detached."""

    def __init__(self, instrument: BaseInstrument, parent: QtWidgets.QMainWindow, *, lazy: bool = False):
        super().__init__(parent)
        self.instrument = instrument
        # Lazy mode: start with a lightweight placeholder and build InstrumentTab on demand
        if lazy:
            placeholder = QtWidgets.QFrame()
            lay = QtWidgets.QVBoxLayout(placeholder)
            lay.setContentsMargins(16, 16, 16, 16)
            lbl = QtWidgets.QLabel("Panel will initialize on activation…")
            lbl.setAlignment(QtCore.Qt.AlignCenter)
            lay.addStretch(1)
            lay.addWidget(lbl)
            lay.addStretch(1)
            self.setWidget(placeholder)
            self._lazy = True
        else:
            tab = InstrumentTab(instrument)
            self.setWidget(tab)
            self._lazy = False
        # Encourage width for this dock so embedded pages aren't squished
        self.setMinimumWidth(900)
        self.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Preferred)
        self.setFeatures(
            QtWidgets.QDockWidget.DockWidgetClosable
            | QtWidgets.QDockWidget.DockWidgetMovable
            | QtWidgets.QDockWidget.DockWidgetFloatable
        )
        # Overlay for exclusivity enforcement (used by MultiInstrument manager)
        self._overlay = _Overlay(self.widget())
        self._overlay.raise_()
        # Default action: emit activated; _MultiManager may also preempt
        self._overlay.clicked.connect(lambda: self._emit_activated())
        self._dim_effect = None

    def ensure_built(self) -> None:
        """If created in lazy mode, build the actual InstrumentTab now."""
        if isinstance(self.widget(), InstrumentTab):
            return
        # Replace placeholder with real tab
        tab = InstrumentTab(self.instrument)
        self.setWidget(tab)
        if isinstance(self._overlay, _Overlay):
            self._overlay.deleteLater()
        self._overlay = _Overlay(tab)
        self._overlay.raise_()
        self._overlay.clicked.connect(lambda: self._emit_activated())
        self._lazy = False

    def set_dimmed(self, dim: bool) -> None:
        w = self.widget()
        if not isinstance(w, QtWidgets.QWidget):
            return
        # Avoid opacity effects when OpenGL rendering is enabled to prevent artifacts
        try:
            from . import config as gui_config
            gl_on = bool(gui_config.get_use_opengl())
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            gl_on = False
        if dim:
            if gl_on:
                if self._dim_effect is not None:
                    w.setGraphicsEffect(None)
                    self._dim_effect = None
            else:
                if self._dim_effect is None:
                    eff = QtWidgets.QGraphicsOpacityEffect(w)
                    eff.setOpacity(0.45)
                    w.setGraphicsEffect(eff)
                    self._dim_effect = eff
        else:
            if self._dim_effect is not None:
                w.setGraphicsEffect(None)
                self._dim_effect = None

    def _emit_activated(self) -> None:
        self.ensure_built()
        w = self.widget()
        if isinstance(w, InstrumentTab):
            w.activated.emit()

    def closeEvent(self, event):  # type: ignore[override]
        self.instrument.disconnect()
        mw = self.parent()
        if hasattr(mw, "_on_dock_closed"):
            mw._on_dock_closed(self)  # type: ignore[attr-defined]
        super().closeEvent(event)


class _ZeroCentralWidget(QtWidgets.QWidget):
    """Central widget that yields almost all space to dock areas.

    Menus/toolbars remain intact; only the central filler shrinks.
    """
    def __init__(self):
        super().__init__()
        self.setMinimumSize(0, 0)
        self.setMaximumSize(0, 0)
        self.setSizePolicy(QtWidgets.QSizePolicy.Fixed, QtWidgets.QSizePolicy.Fixed)
        self.setContentsMargins(0, 0, 0, 0)

    def sizeHint(self):  # type: ignore[override]
        try:
            return QtCore.QSize(0, 0)
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            return super().sizeHint()


class MainWindow(QtWidgets.QMainWindow):
    def __init__(self, bus: EventBus):
        super().__init__()
        self.setWindowTitle("Instrument Control")
        self.events = bus
        # Use a minimal central widget so the first dock can take maximum space
        self.setCentralWidget(_ZeroCentralWidget())
        self.setStatusBar(QtWidgets.QStatusBar())

        # Logs dock (hidden by default)
        self.log = LogViewer()
        dock = QtWidgets.QDockWidget("Logs")
        dock.setWidget(self.log)
        self.addDockWidget(QtCore.Qt.BottomDockWidgetArea, dock)
        dock.hide()

        class _QtLogHandler(logging.Handler):
            def __init__(self, w: LogViewer):
                super().__init__()
                self._w = w

            def emit(self, record: logging.LogRecord) -> None:
                if not _qt_object_is_alive(self._w):
                    root_logger = logging.getLogger()
                    root_logger.removeHandler(self)
                    self._w = None
                    return
                msg = self.format(record)
                try:
                    QtCore.QMetaObject.invokeMethod(
                        self._w,
                        "append_log",
                        QtCore.Qt.QueuedConnection,
                        QtCore.Q_ARG(str, msg),
                    )
                except RuntimeError:
                    root_logger = logging.getLogger()
                    root_logger.removeHandler(self)
                    self._w = None

        # Attach a GUI log handler once per process
        root = logging.getLogger()
        root.setLevel(logging.INFO)
        existing = any(isinstance(h, _QtLogHandler) for h in root.handlers)
        if not existing:
            handler = _QtLogHandler(self.log)
            handler.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(name)s: %(message)s"))
            handler.setLevel(logging.DEBUG)
            root.addHandler(handler)

        # Main toolbar (keep only primary actions)
        tb = self.addToolBar("Main")
        add_act = tb.addAction("Add Instrument")
        add_act.triggered.connect(self._add_instrument)
        reload_act = tb.addAction("Reload Plugins")
        reload_act.triggered.connect(self._reload_plugins)

        # Create actions for Session/Debug menus (not on toolbars)
        save_act = QtGui.QAction("Save Session…", self)
        save_act.triggered.connect(self._save_session_dialog)
        save_act.setShortcut(QtGui.QKeySequence.Save)
        load_act = QtGui.QAction("Load Session…", self)
        load_act.triggered.connect(self._load_session_dialog)
        load_act.setShortcut(QtGui.QKeySequence.Open)

        show_logs = QtGui.QAction("Show Logs", self)
        show_logs.triggered.connect(self._show_logs_panel)
        show_diag = QtGui.QAction("Show Diagnostics", self)
        show_diag.triggered.connect(self._show_diagnostics_panel)
        show_diag.setShortcut(QtGui.QKeySequence(QtCore.Qt.Key_F12))

        # Menubar with Session and Debug menus
        menubar = self.menuBar()
        session_menu = menubar.addMenu("Session")
        session_menu.addAction(save_act)
        session_menu.addAction(load_act)

        debug_menu = menubar.addMenu("Debug")
        debug_menu.addAction(show_logs)
        debug_menu.addAction(show_diag)
        from . import config as gui_config
        use_gl = bool(gui_config.get_use_opengl())
        toggle_gl = QtGui.QAction("Use OpenGL acceleration (requires restart)", self)
        toggle_gl.setCheckable(True)
        toggle_gl.setChecked(use_gl)
        def _on_toggle_gl(checked: bool):
            gui_config.set_use_opengl(bool(checked))
            QtWidgets.QMessageBox.information(
                self,
                "OpenGL Setting Updated",
                "The OpenGL setting was updated. Please restart the application to apply.",
            )
        toggle_gl.toggled.connect(_on_toggle_gl)
        debug_menu.addSeparator()
        debug_menu.addAction(toggle_gl)
        from . import config as gui_config
        web_menu = debug_menu.addMenu("WebEngine")
        # External browser toggle
        ext_toggle = QtGui.QAction("Force external browser (no QtWebEngine)", self)
        ext_toggle.setCheckable(True)
        ext_toggle.setChecked(bool(gui_config.get_force_external_browser()))
        def _on_toggle_ext(v: bool):
            gui_config.set_force_external_browser(bool(v))
            QtWidgets.QMessageBox.information(self, "WebEngine", "External browser setting persisted. Restart may be required.")
        ext_toggle.toggled.connect(_on_toggle_ext)
        web_menu.addAction(ext_toggle)

        web_menu.addSeparator()
        scen_group = QtGui.QActionGroup(self)
        scen_group.setExclusive(True)
        current = gui_config.get_webengine_scenario("warp") or "warp"
        scenarios = [
            ("ANGLE WARP (software)", "warp"),
            ("SwiftShader (software)", "swiftshader"),
            ("ANGLE D3D11 (hardware)", "d3d11"),
            ("Desktop OpenGL (hardware)", "desktop"),
        ]
        for label, key in scenarios:
            act = QtGui.QAction(label, self)
            act.setCheckable(True)
            act.setChecked(key == current)
            act.setActionGroup(scen_group)
            def _mk_setter(s=key):
                def _set():
                    gui_config.set_webengine_scenario(s)
                    QtWidgets.QMessageBox.information(self, "WebEngine Scenario Updated", f"Scenario set to '{s}'. Restart the application to apply.")
                return _set
            act.triggered.connect(_mk_setter())
            web_menu.addAction(act)

        web_menu.addSeparator()
        diag_act = QtGui.QAction("Show WebEngine Diagnostics", self)
        def _show_diag():
            import os
            flags = os.environ.get("QTWEBENGINE_CHROMIUM_FLAGS", "")
            scen = gui_config.get_webengine_scenario("warp") or "warp"
            ext = "1" if gui_config.get_force_external_browser() else "0"
            res = [
                f"Scenario (persisted): {scen}",
                f"INSTRCTL_FORCE_EXTERNAL_BROWSER: {ext}",
                f"QT_OPENGL: {os.environ.get('QT_OPENGL','')}",
                f"QT_ANGLE_PLATFORM: {os.environ.get('QT_ANGLE_PLATFORM','')}",
                f"QTWEBENGINEPROCESS_PATH: {os.environ.get('QTWEBENGINEPROCESS_PATH','')}",
                f"QTWEBENGINE_RESOURCES_PATH: {os.environ.get('QTWEBENGINE_RESOURCES_PATH','')}",
                f"QTWEBENGINE_LOCALES_PATH: {os.environ.get('QTWEBENGINE_LOCALES_PATH','')}",
                f"QTWEBENGINE_CHROMIUM_FLAGS: {flags}",
            ]
            QtWidgets.QMessageBox.information(self, "WebEngine Diagnostics", "\n".join(res))
        diag_act.triggered.connect(_show_diag)
        web_menu.addAction(diag_act)

        # Self-test to verify QtWebEngine availability
        test_act = QtGui.QAction("Self-test WebEngine", self)
        def _self_test():
            import os
            from pathlib import Path
            msgs = []
            ok = True
            # Try to import QtWebEngineWidgets
            try:
                from PySide6 import QtWebEngineWidgets  # type: ignore
                msgs.append("Import QtWebEngineWidgets: OK")
            except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                ok = False
                msgs.append(f"Import QtWebEngineWidgets: FAIL ({type(e).__name__}: {e})")
            # Check helper exe and resources paths
            try:
                import PySide6 as _p6  # type: ignore
                base = Path(_p6.__file__).parent
                proc = base / "QtWebEngineProcess.exe"
                res = base / "resources"
                locales = res / "qtwebengine_locales"
                msgs.append(f"QtWebEngineProcess.exe: {'FOUND' if proc.exists() else 'MISSING'} -> {proc}")
                msgs.append(f"resources/: {'FOUND' if res.exists() else 'MISSING'} -> {res}")
                msgs.append(f"qtwebengine_locales/: {'FOUND' if locales.exists() else 'MISSING'} -> {locales}")
            except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                ok = False
                msgs.append(f"Locate PySide6 resources: FAIL ({type(e).__name__}: {e})")
            # Summarize
            title = "WebEngine Self-test: PASS" if ok else "WebEngine Self-test: FAIL"
            QtWidgets.QMessageBox.information(self, title, "\n".join(str(m) for m in msgs))
        test_act.triggered.connect(_self_test)
        web_menu.addAction(test_act)

        self.setDockOptions(self.dockOptions() | QtWidgets.QMainWindow.AllowTabbedDocks)
        self.setTabPosition(QtCore.Qt.AllDockWidgetAreas, QtWidgets.QTabWidget.North)

        # State containers
        self.instruments = []
        self.docks = []
        self._anchor_dock = None
        # For managing multi-instrument exclusivity
        self._multi_managers = []
        # Diagnostics panel (created on demand)
        self._diag_dock = None

    # ---- Session management ----
    def _session_state(self) -> Dict:
        items = []
        for inst in self.instruments:
            items.append({
                "kind": getattr(inst, "kind", ""),
                "model": getattr(inst, "model", ""),
            })
        return {"instruments": items}

    def _save_session_dialog(self) -> None:
        from .app import save_state, APP_STATE_FILE
        path_str, _ = QtWidgets.QFileDialog.getSaveFileName(
            self,
            "Save Session",
            str(APP_STATE_FILE),
            "Session Files (*.json);;All Files (*)",
        )
        if not path_str:
            return
        try:
            save_state(self._session_state(), Path(path_str))
            self.statusBar().showMessage(f"Session saved to {path_str}", 3000)
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            QtWidgets.QMessageBox.critical(self, "Save Session", str(e))

    def _load_session_dialog(self) -> None:
        from .app import load_state, APP_STATE_FILE
        path_str, _ = QtWidgets.QFileDialog.getOpenFileName(
            self,
            "Load Session",
            str(APP_STATE_FILE),
            "Session Files (*.json);;All Files (*)",
        )
        if not path_str:
            return
        try:
            state = load_state(Path(path_str))
            self._load_session(state)
            self.statusBar().showMessage(f"Session loaded from {path_str}", 3000)
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            QtWidgets.QMessageBox.critical(self, "Load Session", str(e))

    def _load_session(self, state: Dict) -> None:
        # Close existing docks/instruments
        for dock in list(self.docks):
            dock.close()
        # Create from state
        for item in state.get("instruments", []):
            kind = item.get("kind")
            model = item.get("model")
            if not kind or not model:
                continue
            try:
                inst = InstrumentFactory.create(kind, model, event_bus=self.events)
                # Prompt connection options per instrument on load as well (best-effort)
                connected = False
                try:
                    dlg = AddInstrumentDialog(self)
                    dlg.kind_combo.setCurrentText(kind)
                    dlg.model_combo.setCurrentText(model)
                    # Only show the connection group when loading; hide kind/model selection
                    dlg.kind_combo.setEnabled(False)
                    dlg.model_combo.setEnabled(False)
                    dlg.setWindowTitle("Connect Instrument")
                    if dlg.exec() == QtWidgets.QDialog.Accepted:
                        conn = dlg.connection_params()
                        if conn is not None:
                            try:
                                # If 'Use remote agent' is checked, instantiate proxy prior to connecting
                                if dlg.conn_remote_chk.isChecked():
                                    from ..core.remote import RemoteInstrumentProxy, RemoteConfig
                                    impl = InstrumentRegistry.get(kind, model)
                                    host = dlg._remote_host.text().strip()
                                    port = int(dlg._remote_port.value())
                                    if not host:
                                        raise ValueError("Remote agent host is required")
                                    cfg = RemoteConfig(
                                        host=host,
                                        port=port,
                                        use_ssh=bool(dlg._remote_use_ssh.isChecked()),
                                        ssh_user=dlg._remote_ssh_user.text().strip() or None,
                                        ssh_password=dlg._remote_ssh_password.text().strip() or None,
                                        ssh_keyfile=dlg._remote_ssh_keyfile.text().strip() or None,
                                        token=dlg._remote_token.text().strip() or None,
                                    )
                                    inst = RemoteInstrumentProxy(kind=kind, model=model, config=cfg, event_bus=self.events)
                                    type(inst)._impl_cls = impl  # type: ignore[attr-defined]
                                # If remote proxy, show a progress dialog and feed bootstrap/connect messages
                                if _RemoteInstrumentProxy is not None and isinstance(inst, _RemoteInstrumentProxy):
                                    pd = QtWidgets.QDialog(self)
                                    pd.setWindowTitle("Connecting…")
                                    v = QtWidgets.QVBoxLayout(pd)
                                    v.addWidget(QtWidgets.QLabel(f"Connecting to agent at {cfg.host}:{cfg.port}…"))
                                    log = QtWidgets.QPlainTextEdit()
                                    log.setReadOnly(True)
                                    v.addWidget(log)
                                    bar = QtWidgets.QProgressBar()
                                    bar.setRange(0, 0)  # indeterminate
                                    v.addWidget(bar)
                                    pd.setModal(True)
                                    pd.show()
                                    QtWidgets.QApplication.processEvents()
                                    def _progress(msg: str):
                                        log.appendPlainText(str(msg))
                                        QtWidgets.QApplication.processEvents()
                                    try:
                                        inst.connect(progress=_progress, **conn)
                                    finally:
                                        pd.close()
                                else:
                                    inst.connect(**conn)
                                connected = bool(inst.is_connected())
                            except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:# Show rich error with details to help distinguish auth/launch/connect issues
                                self._show_connect_error(e)
                                connected = False
                except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                    connected = False
                # Only add the instrument UI if connection succeeded
                if connected:
                    self.add_instrument(inst)
                else:
                    inst.disconnect()
            except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                logging.getLogger(__name__).warning("Failed to load instrument %s:%s: %s", kind, model, e)

    def _add_instrument(self):
        dlg = AddInstrumentDialog(self)
        if dlg.exec() == QtWidgets.QDialog.Accepted:
            sel = dlg.selected()
            if sel:
                kind, model = sel
                try:
                    # If 'Use remote agent' is checked, instantiate the proxy instead of local impl
                    if dlg.conn_remote_chk.isChecked():
                        from ..core.remote import RemoteInstrumentProxy, RemoteConfig
                        impl = InstrumentRegistry.get(kind, model)
                        host = dlg._remote_host.text().strip()
                        port = int(dlg._remote_port.value())
                        port_data = int(dlg._remote_port_data.value())
                        if not host:
                            raise ValueError("Remote agent host is required")
                        cfg = RemoteConfig(
                            host=host,
                            port=port,
                            port_data=port_data,
                            use_ssh=bool(dlg._remote_use_ssh.isChecked()),
                            ssh_user=dlg._remote_ssh_user.text().strip() or None,
                            ssh_password=dlg._remote_ssh_password.text().strip() or None,
                            ssh_keyfile=dlg._remote_ssh_keyfile.text().strip() or None,
                            token=dlg._remote_token.text().strip() or None,
                        )
                        inst = RemoteInstrumentProxy(kind=kind, model=model, config=cfg, event_bus=self.events)
                        type(inst)._impl_cls = impl  # type: ignore[attr-defined]
                    else:
                        inst = InstrumentFactory.create(kind, model, event_bus=self.events)
                    logging.getLogger(__name__).info("Added instrument %s:%s", kind, model)
                    # Connect if user provided connection info
                    conn = dlg.connection_params()
                    if conn is not None:
                        try:
                            # Pass kwargs to support plugin-defined types and extra fields
                            if _RemoteInstrumentProxy is not None and isinstance(inst, _RemoteInstrumentProxy):
                                pd = QtWidgets.QDialog(self)
                                pd.setWindowTitle("Connecting…")
                                v = QtWidgets.QVBoxLayout(pd)
                                try:
                                    cfg = getattr(inst, "_cfg", None)
                                    host = getattr(cfg, "host", "?") if cfg else "?"
                                    port = getattr(cfg, "port", "?") if cfg else "?"
                                    v.addWidget(QtWidgets.QLabel(f"Connecting to agent at {host}:{port}…"))
                                except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                                    v.addWidget(QtWidgets.QLabel("Connecting to agent…"))
                                log = QtWidgets.QPlainTextEdit(); log.setReadOnly(True); v.addWidget(log)
                                bar = QtWidgets.QProgressBar(); bar.setRange(0, 0); v.addWidget(bar)
                                pd.setModal(True); pd.show(); QtWidgets.QApplication.processEvents()
                                def _progress(msg: str):
                                    log.appendPlainText(str(msg))
                                    QtWidgets.QApplication.processEvents()
                                try:
                                    inst.connect(progress=_progress, **conn)
                                finally:
                                    pd.close()
                            else:
                                inst.connect(**conn)
                        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                            self._show_connect_error(e)
                            return
                        # Only add UI if actually connected
                        if not inst.is_connected():
                            QtWidgets.QMessageBox.critical(self, "Connect", "Instrument failed to connect.")
                            inst.disconnect()
                            return
                    self.add_instrument(inst)
                except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                    QtWidgets.QMessageBox.critical(self, "Error", str(e))

    def add_instrument(self, inst: BaseInstrument):
        # Check if it's a MultiInstrument by trying to get children (works for local and remote)
        try:
            children_dict = inst.list_children()
            has_children = isinstance(children_dict, dict) and len(children_dict) > 0
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            has_children = False
            children_dict = {}
        
        # If it's a MultiInstrument (local or remote), open per-child docks and set up exclusivity
        if has_children:
            mgr = _MultiManager(self, inst)
            self._multi_managers.append(mgr)
            children = list(children_dict.items())
            first_dock = None  # Track first dock to raise it at the end
            for i, (alias, child) in enumerate(children):
                # Use a child proxy so all method calls from the GUI enforce exclusivity automatically
                try:
                    proxy = inst.child(alias, ttl=1.0, preempt=False)
                except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                    proxy = child
                # Build lazily except for the first child (which should be visible immediately)
                self._add_single_instrument(proxy, title=f"{inst.kind}:{inst.model} · {alias}", lazy=(i != 0))
                # connect activation
                dock = self.docks[-1]
                if i == 0:
                    first_dock = dock  # Remember first dock
                w = dock.widget()
                if isinstance(w, InstrumentTab):
                    w.activated.connect(lambda a=alias, m=mgr: m.activate(a))
                # When the dock becomes visible (tab selected), build lazily without forcing activation
                def _on_vis(_v, d=dock, m=mgr, a=alias):
                    # Build content if needed
                    d.ensure_built()
                    ov = getattr(d, "_overlay", None)
                    if isinstance(ov, _Overlay) and not getattr(ov, "_preempt_attached", False):
                        ov.clicked.connect(lambda a=a, m=m: m.on_overlay_clicked(a))
                        setattr(ov, "_preempt_attached", True)
                    # Refresh overlays/dimming for current active alias
                    m.refresh()
                dock.visibilityChanged.connect(_on_vis)
                ov = getattr(dock, "_overlay", None)
                if isinstance(ov, _Overlay):
                    ov.clicked.connect(lambda a=alias, m=mgr: (dock.ensure_built(), m.on_overlay_clicked(a)))
            # Raise the FIRST dock tab so it's visible
            if first_dock is not None:
                first_dock.raise_()
            # initialize active to first child if any
            first_alias = next(iter(children_dict.keys()), None)
            if first_alias is not None:
                mgr.activate(first_alias)
        else:
            self._add_single_instrument(inst)

    def _add_single_instrument(self, inst: BaseInstrument, title: Optional[str] = None, *, lazy: bool = False):
        self.instruments.append(inst)
        prev_dock_count = len(self.docks)
        dock = InstrumentDock(inst, self, lazy=lazy)
        dock.setWindowTitle(title or f"{inst.kind}:{inst.model}")
        self.addDockWidget(QtCore.Qt.LeftDockWidgetArea, dock)
        if self._anchor_dock and self._anchor_dock in self.docks:
            self.tabifyDockWidget(self._anchor_dock, dock)
        elif self.docks:
            self._anchor_dock = self.docks[0]
            self.tabifyDockWidget(self._anchor_dock, dock)
        else:
            self._anchor_dock = dock
        self.docks.append(dock)
        dock.raise_()
        if prev_dock_count == 0:
            w = max(900, int(self.size().width() * 0.85))
            self.resizeDocks([dock], [w], QtCore.Qt.Horizontal)
        if dock.widget():
            dock.widget().setFocus()
        w = dock.widget()
        if isinstance(w, QtWidgets.QWidget):
            highlight = QtCore.QTimer(self)

            def apply_flash():
                w.setStyleSheet("background-color: #fff6bf;")

            def clear_flash():
                w.setStyleSheet("")

            apply_flash()
            highlight.setSingleShot(True)
            highlight.timeout.connect(clear_flash)
            highlight.start(900)

    def _on_dock_closed(self, dock: InstrumentDock) -> None:
        self.docks.remove(dock)
        self.instruments.remove(dock.instrument)
        if dock is self._anchor_dock:
            self._anchor_dock = self.docks[0] if self.docks else None
        dock.deleteLater()

    def _reload_plugins(self) -> None:
        try:
            loaded_before = set(InstrumentRegistry.list_kinds().keys())
            discover_all()
            loaded_after = set(InstrumentRegistry.list_kinds().keys())
            added = sorted(loaded_after - loaded_before)
            msg = "Plugins reloaded." + (f" New kinds: {', '.join(added)}" if added else "")
            logging.getLogger(__name__).info(msg)
            self.statusBar().showMessage(msg, 3000)
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            QtWidgets.QMessageBox.critical(self, "Reload Plugins", str(e))

    def _show_connect_error(self, exc: BaseException) -> None:
        try:
            title = "Connect"
            # Message from exception; if empty, use class name
            msg = str(exc) or exc.__class__.__name__
            tb = traceback.format_exc()
            mbox = QtWidgets.QMessageBox(self)
            mbox.setIcon(QtWidgets.QMessageBox.Critical)
            mbox.setWindowTitle(title)
            mbox.setText(msg)
            if tb and "Traceback" in tb:
                mbox.setDetailedText(tb)
            mbox.exec()
        except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
            QtWidgets.QMessageBox.critical(self, "Connect", str(exc))

    def _show_logs_panel(self) -> None:
        # Ensure the logs dock is visible
        for dock in self.findChildren(QtWidgets.QDockWidget):
            if dock.windowTitle() == "Logs":
                dock.show()
                dock.raise_()
                return

    def _show_diagnostics_panel(self) -> None:
        if self._diag_dock and not self._diag_dock.isHidden():
            self._diag_dock.raise_()
            widget = self._diag_dock.widget()
            if isinstance(widget, DiagnosticsPanel):
                widget.refresh()
            return
        panel = DiagnosticsPanel()
        panel.refresh()
        dock = QtWidgets.QDockWidget("Diagnostics")
        dock.setWidget(panel)
        self.addDockWidget(QtCore.Qt.BottomDockWidgetArea, dock)
        self._diag_dock = dock


class _MultiManager:
    """Manages exclusivity overlays for a MultiInstrument's child docks."""

    def __init__(self, window: MainWindow, multi: MultiInstrument):
        self._win = window
        self._multi = multi
        # Map alias -> set of conflicting aliases
        self._conflicts: dict[str, set[str]] = {}
        self._compute_conflicts()
        self._active: Optional[str] = None

    def _compute_conflicts(self) -> None:
        self._conflicts.clear()
        for g in self._multi.groups().values():
            aliases = set(g.members)
            for a in aliases:
                self._conflicts.setdefault(a, set()).update(aliases - {a})

    def activate(self, alias: str) -> None:
        self._active = alias
        # Determine which docks belong to this multi and which alias each is
        # We used the window title suffix " · {alias}" when creating
        for dock in self._win.docks:
            title = dock.windowTitle()
            if " · " not in title:
                continue
            try:
                alias_suffix = title.rsplit(" · ", 1)[1]
            except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
                continue
            ov = getattr(dock, "_overlay", None)
            tab = dock.widget() if isinstance(dock.widget(), InstrumentTab) else dock.widget()
            # Determine conflict and update overlay + activity
            conflicting = alias_suffix != alias and alias_suffix in self._conflicts.get(alias, set())
            if conflicting:
                if isinstance(ov, _Overlay):
                    ov.set_message(f"🔒 In use by '{alias}'. Click to switch here")
                    ov.setVisible(True)
                    ov.raise_()
                # Stop any running plots in conflicting tabs
                if isinstance(tab, InstrumentTab):
                    tab.set_exclusive_active(False)
                dock.set_dimmed(True)  # type: ignore[attr-defined]
            else:
                if isinstance(ov, _Overlay):
                    ov.setVisible(False)
                if isinstance(tab, InstrumentTab):
                    tab.set_exclusive_active(True)
                dock.set_dimmed(False)  # type: ignore[attr-defined]

    # Allow overlay click to preempt and switch access immediately
    def on_overlay_clicked(self, alias: str) -> None:
        self._multi.ensure_access(alias, ttl=1.0, preempt=True)
        self.activate(alias)

    # Refresh overlays/dimming for all docks based on current active alias
    def refresh(self) -> None:
        if self._active is None:
            return
        # Re-apply activation to update overlays and dimming without changing owner
        self.activate(self._active)
