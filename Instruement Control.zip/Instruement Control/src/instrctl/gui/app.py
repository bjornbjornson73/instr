from __future__ import annotations

import os
import json
from pathlib import Path
from typing import Dict, Optional
from logging.handlers import RotatingFileHandler

def _prepare_webengine_env() -> None:
    """Set conservative defaults for QtWebEngine and honor WEBENGINE_SCENARIO.

    Scenarios:
      - swiftshader (default): fully software
      - warp: ANGLE D3D WARP (software rasterizer via D3D)
      - d3d11: ANGLE D3D11 (hardware path)
      - desktop: desktop OpenGL
    Existing flags like --use-angle/--use-gl are preserved if already present.
    """
    # Prefer persisted GUI setting, then env, default to ANGLE WARP
    try:
        from . import config as _cfg
        cfg_scen = _cfg.get_webengine_scenario("warp")
    except (ImportError, AttributeError):
        cfg_scen = "warp"
    scenario = os.environ.get("WEBENGINE_SCENARIO", cfg_scen or "warp").strip().lower()
    existing = os.environ.get("QTWEBENGINE_CHROMIUM_FLAGS", "").strip()
    base = [
        "--disable-gpu",
        "--disable-gpu-compositing",
        "--disable-gpu-vsync",
        "--in-process-gpu",
        "--disable-features=VaapiVideoDecoder,UseSkiaRenderer",
    ]
    if scenario == "warp":
        scen = ["--use-angle=warp"]
        os.environ.setdefault("QT_ANGLE_PLATFORM", "warp")
        os.environ.setdefault("QT_OPENGL", "angle")
    elif scenario == "d3d11":
        scen = ["--use-angle=d3d11"]
        os.environ.setdefault("QT_OPENGL", "angle")
    elif scenario == "desktop":
        scen = ["--use-gl=desktop"]
        os.environ.setdefault("QT_OPENGL", "desktop")
    else:  # swiftshader
        scen = ["--use-angle=swiftshader", "--use-gl=swiftshader"]
        os.environ.setdefault("QT_ANGLE_PLATFORM", "swiftshader")
        os.environ.setdefault("QT_OPENGL", "software")

    has_use_angle = "use-angle=" in existing
    has_use_gl = "use-gl=" in existing
    scenario_flags: list[str] = []
    for f in scen:
        if f.startswith("--use-angle=") and has_use_angle:
            continue
        if f.startswith("--use-gl=") and has_use_gl:
            continue
        scenario_flags.append(f)

    merged = existing
    # Remove any inherited --no-sandbox if present
    merged = " ".join(p for p in merged.split() if p != "--no-sandbox").strip()
    for f in base + scenario_flags:
        if f and f not in merged:
            merged = (merged + " " + f).strip()
    os.environ["QTWEBENGINE_CHROMIUM_FLAGS"] = merged
    # Ensure sandbox is not force-disabled by a global env var
    if "QTWEBENGINE_DISABLE_SANDBOX" in os.environ:
        os.environ.pop("QTWEBENGINE_DISABLE_SANDBOX", None)
    # Do not set QSG_RHI_BACKEND to an invalid value like 'software'.
    # Let Qt pick the appropriate RHI (typically d3d11 on Windows; ANGLE WARP is selected via flags above).
    # Optional external browser override
    if os.environ.get("INSTRCTL_FORCE_EXTERNAL_BROWSER") in ("1", "true", "True"):
        os.environ["INSTRCTL_FORCE_EXTERNAL_BROWSER"] = "1"

    # Sanitize inherited QSG_RHI_BACKEND/QT_QUICK_BACKEND if misconfigured in the environment
    allowed_rhi = {"opengl", "d3d11", "vulkan", "metal", "null"}
    rhi = os.environ.get("QSG_RHI_BACKEND")
    if rhi and rhi.strip().lower() not in allowed_rhi:
        # Clear invalid value (e.g., 'software') to avoid Qt warnings and failures
        os.environ.pop("QSG_RHI_BACKEND", None)
    # QT_QUICK_BACKEND='software' is not applicable for RHI in Qt 6; clear if present
    if os.environ.get("QT_QUICK_BACKEND", "").strip().lower() == "software":
        os.environ.pop("QT_QUICK_BACKEND", None)


# Configure environment for safest Qt/QtWebEngine rendering BEFORE importing PySide6
_prepare_webengine_env()

from PySide6 import QtWidgets, QtCore
import logging

from ..core import InstrumentFactory, InstrumentRegistry, EventBus
from ..core.plugins import discover_all
from .widgets import MainWindow, _ui_clock
from . import config as gui_config


APP_STATE_FILE = Path.home() / ".instrctl_session.json"


def load_state(path: Optional[Path] = None) -> Dict:
    p = path or APP_STATE_FILE
    try:
        return json.loads(p.read_text())
    except (OSError, ValueError):
        # Missing/invalid state -> start fresh
        return {"instruments": []}


def save_state(state: Dict, path: Optional[Path] = None) -> None:
    p = path or APP_STATE_FILE
    p.write_text(json.dumps(state, indent=2))


def main() -> None:
    QtCore.QCoreApplication.setAttribute(QtCore.Qt.AA_ShareOpenGLContexts, True)
    QtCore.QCoreApplication.setAttribute(QtCore.Qt.AA_UseSoftwareOpenGL, True)

    app = QtWidgets.QApplication.instance() or QtWidgets.QApplication([])
    import PySide6 as _p6  # type: ignore
    base = Path(_p6.__file__).parent
    res = base / "resources"
    locales = res / "qtwebengine_locales"
    proc = base / "QtWebEngineProcess.exe"
    os.environ.setdefault("QTWEBENGINE_RESOURCES_PATH", str(res))
    if locales.exists():
        os.environ.setdefault("QTWEBENGINE_LOCALES_PATH", str(locales))
    if proc.exists():
        os.environ.setdefault("QTWEBENGINEPROCESS_PATH", str(proc))
    # Ensure shared UI clock is running now that a QApplication exists
    _ui_clock.ensure_started()
    # Log WebEngine environment for diagnostics
    try:
        from . import config as _cfg
        scen = _cfg.get_webengine_scenario("warp") or "warp"
    except (ImportError, AttributeError):
        scen = "warp"
    logging.getLogger(__name__).info(
        "WebEngine env: scenario=%s, QT_OPENGL=%s, QT_ANGLE_PLATFORM=%s, QSG_RHI_BACKEND=%s, FLAGS=%s",
        scen,
        os.environ.get("QT_OPENGL", ""),
        os.environ.get("QT_ANGLE_PLATFORM", ""),
        os.environ.get("QSG_RHI_BACKEND", ""),
        os.environ.get("QTWEBENGINE_CHROMIUM_FLAGS", ""),
    )
    # Configure logging early: root level INFO, rotating file + console will be added in MainWindow
    root = logging.getLogger()
    if not root.handlers:
        root.setLevel(logging.INFO)
    # Add a rotating file handler under user profile
    log_dir = Path.home() / ".instrctl"
    log_dir.mkdir(parents=True, exist_ok=True)
    log_file = log_dir / "instrctl.log"
    try:
        file_handler = RotatingFileHandler(str(log_file), maxBytes=2_000_000, backupCount=3, encoding="utf-8")
        file_handler.setLevel(logging.INFO)
        file_handler.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(name)s: %(message)s"))
        root.addHandler(file_handler)
    except (OSError, ValueError):
        logging.getLogger(__name__).warning("Failed to initialize rotating file logger at %s", log_file, exc_info=True)
    
    # PERFORMANCE: Configure pyqtgraph for better performance with large datasets
    try:
        import pyqtgraph as pg
        # Set reasonable limits for anti-aliasing (trades quality for speed)
        pg.setConfigOption('antialias', False)  # Disable for better performance
        logging.getLogger(__name__).info("pyqtgraph performance optimizations enabled")
    except (ImportError, RuntimeError, AttributeError, KeyError) as e:
        logging.getLogger(__name__).warning("Could not configure pyqtgraph optimizations: %s", e)
    
    # Optionally enable OpenGL acceleration based on GUI setting (default: off)
    if gui_config.get_use_opengl():
        try:
            import pyqtgraph as pg
            from PySide6 import QtOpenGLWidgets
            w = QtOpenGLWidgets.QOpenGLWidget()
            w.deleteLater()
            pg.setConfigOptions(useOpenGL=True)
            logging.getLogger(__name__).info("OpenGL acceleration enabled")
        except (ImportError, RuntimeError):
            logging.getLogger(__name__).warning(
                "OpenGL acceleration not available; continuing without it.", exc_info=True
            )
    bus = EventBus()
    win = MainWindow(bus)

    # Discover plugins on startup (no session restore by default)
    discover_all()

    # Do not auto-restore sessions; let the user load/save sessions from the UI.
    # Keep default update mode for stability unless we revisit GL mode later
    win.show()
    app.exec()


if __name__ == "__main__":
    main()
