"""
Simple SSH/SFTP server using AsyncSSH (Python-only).

Features:
- Generates an Ed25519 host key on first run (stored next to this file).
- Password authentication for a small set of demo users.
- SFTP enabled (and SCP optionally), good for quick local testing.

Windows-friendly: Run with Python 3.10+; no admin rights required for high ports.

Security note: This is a demo server. If you expose it to the internet,
use unique credentials, prefer key auth, and restrict access (firewall/VPN).
"""

from __future__ import annotations

import argparse
import asyncio
import hmac
from pathlib import Path
import sys
import locale
import asyncio.subprocess as aiosub

try:
    import asyncssh  # type: ignore
except ImportError as exc:  # pragma: no cover - helpful error if missing
    print("This demo requires 'asyncssh'. Install it with: pip install asyncssh", file=sys.stderr)
    raise

try:
    import bcrypt  # type: ignore[import-not-found]  # optional; improves password storage
except ImportError:  # pragma: no cover
    bcrypt = None  # type: ignore


# Default demo users. Change these for your own use.
DEMO_PASSWORDS = {
    "demo": "demo",          # username: password
    "user123": "secretpw",
}


def _to_bytes(data: object) -> bytes:
    if isinstance(data, (bytes, bytearray)):
        return bytes(data)
    return str(data).encode("utf-8")


def _ensure_host_key(path: Path) -> Path:
    """Create an Ed25519 host key if it doesn't exist."""
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists():
        # AsyncSSH can generate and export keys in OpenSSH format
        key = asyncssh.generate_private_key("ssh-ed25519")
        pem = key.export_private_key("openssh")  # bytes or str
        path.write_bytes(_to_bytes(pem))
        # Optional: write public key for convenience
        pub = key.export_public_key("openssh")  # bytes or str
        path.with_suffix(path.suffix + ".pub").write_bytes(_to_bytes(pub))
        print(f"Generated host key at {path}")
    return path


class _PasswordAuthServer(asyncssh.SSHServer):
    def __init__(self, users_hashed: dict[str, bytes] | None, users_plain: dict[str, str] | None) -> None:
        super().__init__()
        self._users_hashed = users_hashed or {}
        self._users_plain = users_plain or {}

    # Require auth unless username has empty password configured
    def begin_auth(self, username: str) -> bool:
        if username in self._users_plain and self._users_plain[username] == "":
            return False
        return True

    def password_auth_supported(self) -> bool:
        return True

    def validate_password(self, username: str, password: str) -> bool:
        # Hashed users take precedence if provided
        if username in self._users_hashed:
            if bcrypt is None:
                return False
            return bcrypt.checkpw(password.encode("utf-8"), self._users_hashed[username])

        if username in self._users_plain:
            # Constant-time compare for plain storage
            return hmac.compare_digest(password, self._users_plain[username])

        return False


async def _handle_process(process: asyncssh.SSHServerProcess) -> None:
    """Handle both exec requests and interactive shells.

    - Exec request (process.command is set): run the command via system shell and return its output/exit code.
    - Shell (no command): provide a simple line-oriented REPL which executes each line via the system shell.
    """
    enc = locale.getpreferredencoding(False) or "utf-8"
    username = process.get_extra_info("username")
    host = process.get_extra_info("peername")
    cmd = getattr(process, "command", None)

    async def run_shell_command(command: str) -> tuple[bytes, bytes, int]:
        try:
            proc = await asyncio.create_subprocess_shell(
                command,
                stdout=aiosub.PIPE,
                stderr=aiosub.PIPE,
            )
            out, err = await proc.communicate()
            return out or b"", err or b"", int(proc.returncode or 0)
        except (OSError, ValueError, asyncio.CancelledError) as e:
            msg = f"Command error: {type(e).__name__}: {e}\n".encode(enc, errors="ignore")
            return b"", msg, 127

    # Exec request: run a single command and exit
    if cmd:
        out, err, rc = await run_shell_command(cmd)
        if out:
            process.stdout.write(out.decode(enc, errors="ignore"))
            await process.stdout.drain()
        if err:
            process.stderr.write(err.decode(enc, errors="ignore"))
            await process.stderr.drain()
        process.exit(rc)
        return

    # Interactive shell
    welcome = f"Welcome {username}! Type commands or 'exit' to quit.\n"
    process.stdout.write(welcome)
    await process.stdout.drain()

    prompt = "$ "
    process.stdout.write(prompt)
    await process.stdout.drain()
    while True:
        line = await process.stdin.readline()
        if not line:
            break
        cmdline = line.decode(enc, errors="ignore").strip()
        if not cmdline:
            process.stdout.write(prompt)
            await process.stdout.drain()
            continue
        if cmdline.lower() in ("exit", "quit", "logout", "bye"):
            break
        out, err, rc = await run_shell_command(cmdline)
        if out:
            process.stdout.write(out.decode(enc, errors="ignore"))
        if err:
            process.stderr.write(err.decode(enc, errors="ignore"))
        # Show exit code for transparency when non-zero
        if rc != 0:
            process.stdout.write(f"[exit {rc}]\n")
        await process.stdout.drain()
        await process.stderr.drain()
        process.stdout.write(prompt)
        await process.stdout.drain()

    process.exit(0)


async def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Run a simple AsyncSSH server")
    parser.add_argument("--host", default="127.0.0.1", help="Host/IP to listen on (default: 127.0.0.1)")
    parser.add_argument("--port", type=int, default=8022, help="Port to listen on (default: 8022)")
    parser.add_argument("--allow-scp", action="store_true", help="Allow SCP in addition to SFTP")
    parser.add_argument("--no-sftp", action="store_true", help="Disable SFTP (enabled by default)")
    parser.add_argument("--user", action="append", default=[], metavar="USER:PASS",
                        help="Add a user credential (repeatable). Example: --user alice:hunter2")
    parser.add_argument("--key", default=None, help="Path to host private key file (OpenSSH format).")
    args = parser.parse_args(argv)

    # Determine host key location
    key_path = Path(args.key) if args.key else Path(__file__).with_name("ssh_host_key")
    key_path = _ensure_host_key(key_path)

    # Build user database from args, fallback to demo users
    users_plain: dict[str, str] = {}
    users_hashed: dict[str, bytes] = {}

    # Load from CLI
    for item in args.user:
        if ":" not in item:
            print(f"Ignoring malformed --user entry: {item}", file=sys.stderr)
            continue
        u, p = item.split(":", 1)
        users_plain[u] = p

    if not users_plain:
        users_plain.update(DEMO_PASSWORDS)

    # If bcrypt available, convert to hashed storage
    if bcrypt is not None:
        for u, p in list(users_plain.items()):
            # Empty passwords remain empty/unauthenticated path
            if p:
                users_hashed[u] = bcrypt.hashpw(p.encode("utf-8"), bcrypt.gensalt())
                del users_plain[u]

    server = _PasswordAuthServer(users_hashed=users_hashed, users_plain=users_plain)

    sftp_factory = None if args.no_sftp else True

    print(f"Starting AsyncSSH server on {args.host}:{args.port} (SFTP={'on' if sftp_factory else 'off'}, SCP={'on' if args.allow_scp else 'off'})")
    print(f"Host key: {key_path}")
    if users_hashed or users_plain:
        print("Users:")
        for u in sorted({**users_plain, **users_hashed}.keys()):
            print(f"  - {u}")

    try:
        listener = await asyncssh.listen(
            host=args.host,
            port=args.port,
            server_factory=lambda: server,
            server_host_keys=[str(key_path)],
            sftp_factory=sftp_factory,
            allow_scp=args.allow_scp,
            process_factory=_handle_process,
        )
    except (OSError, asyncssh.Error) as exc:
        print(f"Error starting server: {exc}", file=sys.stderr)
        return 1

    print("Server is running. Press Ctrl+C to stop.")
    try:
        await listener.wait_closed()  # Run forever
    except KeyboardInterrupt:
        print("\nShutting down...")
        listener.close()
        await listener.wait_closed()

    return 0


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
