#!/usr/bin/env python3
"""
Demo agent running both RPyC and Arrow Flight servers for dual-plane testing.

This is a minimal agent for testing the dual transport architecture without
the full instrument abstraction layer.

Run this before running remote_testing.py:
  python demo/dual_agent_demo.py
"""
from __future__ import annotations

import argparse
import logging
import sys
import threading
import time
from typing import Any

# Add src to path
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

try:
    import rpyc
    from rpyc.utils.server import ThreadedServer
except ImportError as e:
    print(f"Failed to import rpyc: {e}")
    print("Install with: pip install rpyc>=5.3.0")
    sys.exit(1)

try:
    import pyarrow as pa
    from pyarrow import flight
except ImportError as e:
    print(f"Failed to import pyarrow: {e}")
    print("Install with: pip install pyarrow>=16.0")
    sys.exit(1)

import numpy as np


log = logging.getLogger(__name__)


class DemoService(rpyc.Service):
    """Simple RPyC service for testing control plane."""
    
    def __init__(self):
        super().__init__()
        self.call_count = 0
        self.data_streams = {}  # stream_name -> list of data batches
        
    def exposed_test_method(self, value: Any) -> dict:
        """Simple method call for testing."""
        self.call_count += 1
        return {
            "status": "ok",
            "call_count": self.call_count,
            "received": value,
            "timestamp": time.time()
        }
    
    def exposed_get_complex_object(self, index: int):
        """Return a complex object (thread) that can't be serialized."""
        # Return a thread object - RPyC will wrap it as a netref
        t = threading.Thread(target=lambda: time.sleep(0.1), daemon=True)
        t.name = f"test_thread_{index}"
        return t
    
    def exposed_set_parameter(self, name: str, value: Any) -> dict:
        """Simulate setting a parameter."""
        return {
            "status": "ok",
            "parameter": name,
            "value": value,
            "timestamp": time.time()
        }
    
    def exposed_store_data(self, stream_name: str, data: Any) -> dict:
        """Store data for a stream (called via control plane)."""
        if stream_name not in self.data_streams:
            self.data_streams[stream_name] = []
        self.data_streams[stream_name].append(data)
        return {
            "status": "ok",
            "stream": stream_name,
            "batches": len(self.data_streams[stream_name])
        }
    
    def exposed_get_stats(self) -> dict:
        """Get service statistics."""
        return {
            "call_count": self.call_count,
            "streams": {name: len(batches) for name, batches in self.data_streams.items()},
            "uptime": time.time()
        }


class DemoFlightServer(flight.FlightServerBase):
    """Simple Flight server for testing data plane."""
    
    def __init__(self, location: flight.Location, **kwargs):
        super().__init__(location, **kwargs)
        self.data_count = 0
        log.info(f"Flight server initialized at {location.uri}")
    
    def do_put(self, context, descriptor, reader, writer):
        """Handle data upload via Flight."""
        # Read all batches from the stream
        batches = []
        try:
            for chunk in reader:
                batches.append(chunk.data)
                self.data_count += 1
        except Exception as e:
            log.error(f"Error reading data: {e}")
            raise
        
        log.info(f"Received {len(batches)} batches ({self.data_count} total)")
        
        # Send acknowledgment
        result = pa.record_batch([
            pa.array([len(batches)]),
            pa.array([self.data_count])
        ], names=['batches_received', 'total_count'])
        
        writer.write_batch(result)
    
    def list_actions(self, context):
        """List available actions."""
        return [
            flight.ActionType("ping", "Ping the server"),
            flight.ActionType("stats", "Get server statistics"),
        ]
    
    def do_action(self, context, action):
        """Handle actions."""
        if action.type == "ping":
            yield flight.Result(b"pong")
        elif action.type == "stats":
            import json
            stats = {
                "data_count": self.data_count,
                "timestamp": time.time()
            }
            yield flight.Result(json.dumps(stats).encode('utf-8'))
        else:
            log.warning(f"Unknown action: {action.type}")


def run_rpyc_server(host: str, port: int, service_instance: DemoService):
    """Run RPyC server in a thread."""
    try:
        server = ThreadedServer(
            service_instance,
            hostname=host,
            port=port,
            protocol_config={
                "allow_public_attrs": True,
                "allow_all_attrs": True,
                "sync_request_timeout": 30
            }
        )
        log.info(f"RPyC server listening on {host}:{port}")
        server.start()
    except Exception as e:
        log.error(f"RPyC server error: {e}")


def run_flight_server(host: str, port: int):
    """Run Arrow Flight server in a thread."""
    try:
        location = flight.Location.for_grpc_tcp(host, port)
        server = DemoFlightServer(location)
        log.info(f"Flight server listening on {host}:{port}")
        server.serve()
    except Exception as e:
        log.error(f"Flight server error: {e}")


def main() -> int:
    """Main entry point."""
    parser = argparse.ArgumentParser(
        description="Demo agent with RPyC and Arrow Flight servers"
    )
    parser.add_argument("--host", default="0.0.0.0", help="Bind host (default: 0.0.0.0)")
    parser.add_argument("--rpyc-port", type=int, default=18861, help="RPyC port (default: 18861)")
    parser.add_argument("--flight-port", type=int, default=8815, help="Flight port (default: 8815)")
    parser.add_argument("--log-level", default="INFO", 
                       choices=["DEBUG", "INFO", "WARNING", "ERROR"],
                       help="Logging level")
    args = parser.parse_args()
    
    # Setup logging
    logging.basicConfig(
        level=getattr(logging, args.log_level),
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s"
    )
    
    log.info("Starting dual-plane demo agent...")
    log.info(f"  RPyC control plane: {args.host}:{args.rpyc_port}")
    log.info(f"  Flight data plane:  {args.host}:{args.flight_port}")
    
    # Create shared service instance
    service = DemoService()
    
    # Start RPyC server in a thread
    rpyc_thread = threading.Thread(
        target=run_rpyc_server,
        args=(args.host, args.rpyc_port, service),
        daemon=True,
        name="rpyc-server"
    )
    rpyc_thread.start()
    
    # Give RPyC a moment to start
    time.sleep(0.5)
    
    # Start Flight server in main thread (it blocks)
    try:
        run_flight_server(args.host, args.flight_port)
    except KeyboardInterrupt:
        log.info("Shutting down agent...")
    
    return 0


if __name__ == "__main__":
    sys.exit(main())
