#!/usr/bin/env python3
"""
Self-contained dual-plane architecture test.
Starts agent, runs throughput tests, and reports results.
"""
from __future__ import annotations

import sys
import os
import time
import threading
import logging
from statistics import mean, median, stdev
from dataclasses import dataclass
from typing import List, Optional

# Add src to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

try:
    import rpyc
    from rpyc.utils.server import ThreadedServer
    import pyarrow as pa
    from pyarrow import flight
    import numpy as np
except ImportError as e:
    print(f"Missing dependencies: {e}")
    print("Install with: pip install rpyc>=5.3.0 pyarrow>=16.0 numpy")
    sys.exit(1)

from instrctl.core.dual_transport import DualTransport, RemoteConfig

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)-5s] %(name)s: %(message)s"
)
log = logging.getLogger(__name__)


# ============================================================================
# AGENT IMPLEMENTATION
# ============================================================================

class TestService(rpyc.Service):
    """Simple RPyC service for testing"""
    
    def __init__(self):
        super().__init__()
        self.call_count = 0
        
    def exposed_test_method(self, value):
        """Simple test method"""
        self.call_count += 1
        return {
            "status": "ok",
            "call_count": self.call_count,
            "received": value
        }
    
    def exposed_get_complex_object(self, index: int):
        """Return a thread (complex object)"""
        t = threading.Thread(target=lambda: time.sleep(0.1), daemon=True)
        t.name = f"test_thread_{index}"
        return t
    
    def exposed_set_parameter(self, name: str, value):
        """Simulate parameter setting"""
        return {"status": "ok", "parameter": name, "value": value}
    
    def exposed_get_stats(self):
        """Get service stats"""
        return {"call_count": self.call_count}


class TestFlightServer(flight.FlightServerBase):
    """Simple Flight server for testing"""
    
    def __init__(self, location: flight.Location):
        super().__init__(location)
        self.data_count = 0
        
    def do_put(self, context, descriptor, reader, writer):
        """Handle data upload"""
        batches = 0
        for chunk in reader:
            batches += 1
            self.data_count += 1
        # No acknowledgment needed for benchmarking
    
    def list_actions(self, context):
        return [
            flight.ActionType("ping", "Ping server")
        ]
    
    def do_action(self, context, action):
        if action.type == "ping":
            yield flight.Result(b"pong")


def run_agent(rpyc_port: int, flight_port: int, stop_event: threading.Event):
    """Run both RPyC and Flight servers"""
    
    # Start RPyC server
    service = TestService()
    rpyc_server = ThreadedServer(
        service,
        hostname="localhost",
        port=rpyc_port,
        protocol_config={
            "allow_public_attrs": True,
            "allow_all_attrs": True,
        }
    )
    
    def rpyc_worker():
        log.info(f"RPyC server starting on localhost:{rpyc_port}")
        rpyc_server.start()
    
    rpyc_thread = threading.Thread(target=rpyc_worker, daemon=True)
    rpyc_thread.start()
    
    # Give RPyC time to start
    time.sleep(0.5)
    
    # Start Flight server in current thread
    location = flight.Location.for_grpc_tcp("localhost", flight_port)
    flight_server = TestFlightServer(location)
    log.info(f"Flight server starting on localhost:{flight_port}")
    
    # Run Flight server until stop event
    def flight_worker():
        flight_server.serve()
    
    flight_thread = threading.Thread(target=flight_worker, daemon=True)
    flight_thread.start()
    
    # Wait for stop signal
    stop_event.wait()
    
    log.info("Shutting down agent...")
    rpyc_server.close()


# ============================================================================
# TEST RESULTS
# ============================================================================

@dataclass
class TestResult:
    """Result of a throughput test"""
    name: str
    operation_count: int
    total_time_s: float
    throughput_ops_per_sec: float
    mean_latency_ms: float
    median_latency_ms: float
    p95_latency_ms: float
    p99_latency_ms: float
    stdev_latency_ms: float
    data_transferred_mb: float = 0.0
    bandwidth_mbps: float = 0.0
    error: Optional[str] = None


def compute_result(name: str, count: int, total_time: float, 
                   latencies: List[float], data_mb: float = 0) -> TestResult:
    """Compute test result statistics"""
    if not latencies:
        return TestResult(
            name=name,
            operation_count=0,
            total_time_s=total_time,
            throughput_ops_per_sec=0,
            mean_latency_ms=0,
            median_latency_ms=0,
            p95_latency_ms=0,
            p99_latency_ms=0,
            stdev_latency_ms=0,
            error="No successful operations"
        )
    
    sorted_latencies = sorted(latencies)
    p95_idx = int(len(sorted_latencies) * 0.95)
    p99_idx = int(len(sorted_latencies) * 0.99)
    
    return TestResult(
        name=name,
        operation_count=count,
        total_time_s=total_time,
        throughput_ops_per_sec=count / total_time if total_time > 0 else 0,
        mean_latency_ms=mean(latencies),
        median_latency_ms=median(latencies),
        p95_latency_ms=sorted_latencies[p95_idx] if p95_idx < len(sorted_latencies) else 0,
        p99_latency_ms=sorted_latencies[p99_idx] if p99_idx < len(sorted_latencies) else 0,
        stdev_latency_ms=stdev(latencies) if len(latencies) > 1 else 0,
        data_transferred_mb=data_mb,
        bandwidth_mbps=data_mb / total_time if total_time > 0 else 0
    )


# ============================================================================
# TESTS
# ============================================================================

def test_rpyc_simple_calls(transport: DualTransport, count: int = 100) -> TestResult:
    """Test simple RPyC method calls"""
    log.info(f"Testing {count} simple RPyC calls...")
    
    latencies = []
    start = time.time()
    
    for i in range(count):
        t0 = time.time()
        try:
            result = transport.invoke("test_method", i)
        except Exception as e:
            log.debug(f"Call {i} failed: {e}")
        latencies.append((time.time() - t0) * 1000)
    
    total_time = time.time() - start
    return compute_result("RPyC Simple Calls", count, total_time, latencies)


def test_rpyc_complex_objects(transport: DualTransport, count: int = 50) -> TestResult:
    """Test RPyC with complex objects (netrefs)"""
    log.info(f"Testing {count} RPyC calls with complex objects...")
    
    latencies = []
    start = time.time()
    
    for i in range(count):
        t0 = time.time()
        try:
            result = transport.invoke("get_complex_object", i)
            # Access property on the netref
            if hasattr(result, '__class__'):
                _ = result.__class__.__name__
        except Exception as e:
            log.debug(f"Call {i} failed: {e}")
        latencies.append((time.time() - t0) * 1000)
    
    total_time = time.time() - start
    return compute_result("RPyC Complex Objects", count, total_time, latencies)


def test_flight_small_batches(transport: DualTransport, count: int = 100, 
                              batch_size: int = 100) -> TestResult:
    """Test Flight with small data batches"""
    log.info(f"Testing {count} Flight batches of {batch_size} points...")
    
    latencies = []
    total_bytes = 0
    start = time.time()
    
    for i in range(count):
        data = np.random.rand(batch_size, 2)
        t0 = time.time()
        try:
            transport.stream_data("test_stream", data)
            total_bytes += data.nbytes
        except Exception as e:
            log.debug(f"Stream {i} failed: {e}")
        latencies.append((time.time() - t0) * 1000)
    
    total_time = time.time() - start
    data_mb = total_bytes / (1024 * 1024)
    
    result = compute_result(f"Flight Small Batches ({batch_size} pts)", 
                           count, total_time, latencies, data_mb)
    return result


def test_flight_large_batches(transport: DualTransport, count: int = 10, 
                              batch_size: int = 10000) -> TestResult:
    """Test Flight with large data batches"""
    log.info(f"Testing {count} Flight batches of {batch_size} points...")
    
    latencies = []
    total_bytes = 0
    start = time.time()
    
    for i in range(count):
        data = np.random.rand(batch_size, 2)
        t0 = time.time()
        try:
            transport.stream_data("test_stream", data)
            total_bytes += data.nbytes
        except Exception as e:
            log.debug(f"Stream {i} failed: {e}")
        latencies.append((time.time() - t0) * 1000)
    
    total_time = time.time() - start
    data_mb = total_bytes / (1024 * 1024)
    
    result = compute_result(f"Flight Large Batches ({batch_size} pts)", 
                           count, total_time, latencies, data_mb)
    return result


def test_concurrent_operations(transport: DualTransport, duration_s: int = 5) -> tuple[TestResult, TestResult]:
    """Test RPyC and Flight operating concurrently"""
    log.info(f"Testing concurrent operations for {duration_s} seconds...")
    
    rpyc_latencies = []
    flight_latencies = []
    rpyc_count = [0]
    flight_count = [0]
    flight_bytes = [0]
    stop_flag = threading.Event()
    
    def rpyc_worker():
        while not stop_flag.is_set():
            t0 = time.time()
            transport.invoke("test_method", rpyc_count[0])
            rpyc_count[0] += 1
            rpyc_latencies.append((time.time() - t0) * 1000)
            time.sleep(0.001)
    
    def flight_worker():
        batch_size = 1000
        while not stop_flag.is_set():
            data = np.random.rand(batch_size, 2)
            t0 = time.time()
            transport.stream_data("test_stream", data)
            flight_count[0] += 1
            flight_bytes[0] += data.nbytes
            flight_latencies.append((time.time() - t0) * 1000)
            time.sleep(0.01)
    
    # Start workers
    rpyc_thread = threading.Thread(target=rpyc_worker, daemon=True)
    flight_thread = threading.Thread(target=flight_worker, daemon=True)
    
    start = time.time()
    rpyc_thread.start()
    flight_thread.start()
    
    time.sleep(duration_s)
    stop_flag.set()
    
    rpyc_thread.join(timeout=2.0)
    flight_thread.join(timeout=2.0)
    
    total_time = time.time() - start
    
    rpyc_result = compute_result("Concurrent RPyC Calls", rpyc_count[0], 
                                 total_time, rpyc_latencies)
    
    flight_mb = flight_bytes[0] / (1024 * 1024)
    flight_result = compute_result("Concurrent Flight Streams", flight_count[0], 
                                   total_time, flight_latencies, flight_mb)
    
    return rpyc_result, flight_result


def test_mixed_workload(transport: DualTransport, duration_s: int = 5) -> TestResult:
    """Test realistic mixed workload (10% control, 90% data) with LARGE batches"""
    log.info(f"Testing mixed workload for {duration_s} seconds...")
    
    latencies = []
    data_bytes = [0]
    op_count = [0]
    stop_flag = threading.Event()
    
    def worker():
        while not stop_flag.is_set():
            # 10% control operations
            if op_count[0] % 10 == 0:
                t0 = time.time()
                transport.invoke("set_parameter", "freq", 1e9 + op_count[0])
                latencies.append((time.time() - t0) * 1000)
            else:
                # 90% data operations - LARGE BATCHES (10k points like high-bandwidth test)
                data = np.random.rand(10000, 2)
                t0 = time.time()
                transport.stream_data("measurement", data)
                data_bytes[0] += data.nbytes
                latencies.append((time.time() - t0) * 1000)
            
            op_count[0] += 1
            # No sleep - max throughput!
    
    thread = threading.Thread(target=worker, daemon=True)
    start = time.time()
    thread.start()
    
    time.sleep(duration_s)
    stop_flag.set()
    thread.join(timeout=2.0)
    
    total_time = time.time() - start
    data_mb = data_bytes[0] / (1024 * 1024)
    
    return compute_result("Mixed Workload", op_count[0], total_time, latencies, data_mb)


# ============================================================================
# MAIN
# ============================================================================

def print_result(result: TestResult):
    """Print test result"""
    print(f"\n{'=' * 70}")
    print(f"Test: {result.name}")
    print(f"{'=' * 70}")
    
    if result.error:
        print(f"ERROR: {result.error}")
        return
    
    print(f"Operations:     {result.operation_count:,}")
    print(f"Total Time:     {result.total_time_s:.2f} s")
    print(f"Throughput:     {result.throughput_ops_per_sec:,.1f} ops/s")
    print()
    print(f"Latency Stats (ms):")
    print(f"  Mean:         {result.mean_latency_ms:.2f}")
    print(f"  Median:       {result.median_latency_ms:.2f}")
    print(f"  Std Dev:      {result.stdev_latency_ms:.2f}")
    print(f"  95th %ile:    {result.p95_latency_ms:.2f}")
    print(f"  99th %ile:    {result.p99_latency_ms:.2f}")
    
    if result.data_transferred_mb > 0:
        print()
        print(f"Data Transfer:")
        print(f"  Total:        {result.data_transferred_mb:.2f} MB")
        print(f"  Bandwidth:    {result.bandwidth_mbps:.2f} MB/s")


def main():
    """Main entry point"""
    print("=" * 70)
    print("DUAL-PLANE REMOTE ARCHITECTURE - STANDALONE TEST")
    print("=" * 70)
    print()
    
    # Configuration
    RPYC_PORT = 18861
    FLIGHT_PORT = 8815
    
    # Start agent
    print("Starting agent servers...")
    stop_event = threading.Event()
    agent_thread = threading.Thread(
        target=run_agent,
        args=(RPYC_PORT, FLIGHT_PORT, stop_event),
        daemon=True
    )
    agent_thread.start()
    
    # Wait for servers to start
    print("Waiting for servers to initialize...")
    time.sleep(2.0)
    
    # Connect client
    print("Connecting client...")
    config = RemoteConfig(
        host="localhost",
        port_control=RPYC_PORT,
        port_data=FLIGHT_PORT
    )
    transport = DualTransport(config)
    
    try:
        transport.connect()
        print("✓ Connected successfully")
        print()
    except Exception as e:
        print(f"✗ Failed to connect: {e}")
        stop_event.set()
        return 1
    
    # Run tests
    results = []
    
    try:
        print("Running tests...")
        print()
        
        # RPyC tests
        results.append(test_rpyc_simple_calls(transport, count=100))
        results.append(test_rpyc_complex_objects(transport, count=50))
        
        # Flight tests
        results.append(test_flight_small_batches(transport, count=100, batch_size=100))
        results.append(test_flight_large_batches(transport, count=10, batch_size=10000))
        
        # Concurrent test
        rpyc_result, flight_result = test_concurrent_operations(transport, duration_s=5)
        results.extend([rpyc_result, flight_result])
        
        # Mixed workload
        results.append(test_mixed_workload(transport, duration_s=5))
        
    except Exception as e:
        log.error(f"Test failed: {e}", exc_info=True)
        return 1
    finally:
        transport.disconnect()
        stop_event.set()
    
    # Print all results
    for result in results:
        print_result(result)
    
    # Summary
    print(f"\n{'=' * 70}")
    print("SUMMARY")
    print(f"{'=' * 70}")
    
    print(f"\n{'Test':<45s} {'Throughput':>20s}")
    print("-" * 70)
    for result in results:
        if not result.error:
            print(f"{result.name:<45s} {result.throughput_ops_per_sec:>15,.1f} ops/s")
            if result.bandwidth_mbps > 0:
                print(f"{'  └─ Bandwidth':<45s} {result.bandwidth_mbps:>15,.1f} MB/s")
    
    print()
    print("=" * 70)
    print("PERFORMANCE TARGETS vs ACTUAL")
    print("=" * 70)
    
    # Check against targets
    rpyc_simple = next((r for r in results if "Simple Calls" in r.name), None)
    flight_large = next((r for r in results if "Large Batches" in r.name), None)
    
    print()
    print(f"{'Metric':<35s} {'Target':>15s} {'Actual':>15s} {'Status':>10s}")
    print("-" * 75)
    
    if rpyc_simple:
        target = 200
        actual = rpyc_simple.throughput_ops_per_sec
        status = "✓ PASS" if actual >= target else "✗ FAIL"
        print(f"{'RPyC Throughput (ops/s)':<35s} {f'>{target}':>15s} {actual:>15,.1f} {status:>10s}")
        
        target_lat = 10
        actual_lat = rpyc_simple.mean_latency_ms
        status = "✓ PASS" if actual_lat <= target_lat else "✗ FAIL"
        print(f"{'RPyC Latency (ms)':<35s} {f'<{target_lat}':>15s} {actual_lat:>15,.2f} {status:>10s}")
    
    if flight_large:
        target = 100
        actual = flight_large.bandwidth_mbps
        status = "✓ PASS" if actual >= target else "✗ FAIL"
        print(f"{'Flight Bandwidth (MB/s)':<35s} {f'>{target}':>15s} {actual:>15,.1f} {status:>10s}")
    
    print()
    print("=" * 70)
    print("TEST COMPLETE!")
    print("=" * 70)
    
    return 0


if __name__ == "__main__":
    sys.exit(main())
