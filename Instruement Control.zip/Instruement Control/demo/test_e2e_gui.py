#!/usr/bin/env python3
"""
End-to-End GUI Test with Dual-Plane Architecture

This test validates the complete workflow:
1. Start DualAgentServer backend
2. Launch GUI application
3. Connect to remote instruments via GUI
4. Verify data streaming through GUI widgets
5. Test GUI controls and interactions
6. Clean shutdown

Usage:
    python demo/test_e2e_gui.py [--headless] [--duration SECONDS]
"""

import sys
import os
import time
import logging
import threading
from pathlib import Path

# Add src to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from PySide6 import QtWidgets, QtCore, QtTest
from PySide6.QtCore import Qt

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger(__name__)


def setup_backend():
    """Start the DualAgentServer in a background thread."""
    from instrctl.core.dual_agent import DualAgentServer
    from instrctl.core.plugins import discover_all
    
    # Discover plugins to register instruments
    discover_all()
    
    # Create and start server
    server = DualAgentServer(host="localhost", port_control=18861, port_data=8815)
    server_thread = threading.Thread(target=server.start, daemon=True)
    server_thread.start()
    
    # Wait for server to be ready
    time.sleep(2.0)
    
    logger.info("Backend server started on localhost:18861 (RPyC) and localhost:8815 (Flight)")
    return server, server_thread


def create_remote_instrument(kind: str, model: str) -> "RemoteInstrumentProxy":
    """Create a RemoteInstrumentProxy for testing."""
    from instrctl.core.remote import RemoteInstrumentProxy, RemoteConfig
    
    config = RemoteConfig(
        host="localhost",
        port=18861,
        port_data=8815,
    )
    
    proxy = RemoteInstrumentProxy(kind=kind, model=model, config=config)
    logger.info(f"Created remote proxy: {kind}/{model}")
    return proxy


class E2EGUITest(QtCore.QObject):
    """Automated E2E test runner for GUI with dual-plane backend."""
    
    finished = QtCore.Signal(bool, str)  # success, message
    
    def __init__(self, app: QtWidgets.QApplication, headless: bool = False, duration: int = 10):
        super().__init__()
        self.app = app
        self.headless = headless
        self.duration = duration
        self.main_window = None
        self.test_passed = False
        self.test_message = ""
        
    def run(self):
        """Execute the E2E test sequence."""
        try:
            logger.info("=== Starting E2E GUI Test ===")
            
            # Step 1: Create MainWindow
            self.create_main_window()
            
            # Step 2: Add remote instruments via GUI
            self.add_remote_instruments()
            
            # Step 3: Verify data streaming
            self.verify_data_streaming()
            
            # Step 4: Test GUI interactions
            self.test_gui_controls()
            
            # Step 5: Monitor for duration
            self.monitor_streaming()
            
            # Test passed
            self.test_passed = True
            self.test_message = "E2E GUI test completed successfully"
            logger.info(f"✅ {self.test_message}")
            
        except Exception as e:
            self.test_passed = False
            self.test_message = f"E2E GUI test failed: {e}"
            logger.error(f"❌ {self.test_message}", exc_info=True)
        
        finally:
            # Signal completion
            QtCore.QTimer.singleShot(1000, lambda: self.finished.emit(self.test_passed, self.test_message))
    
    def create_main_window(self):
        """Create and show the main window."""
        from instrctl.core import EventBus
        from instrctl.gui.widgets import MainWindow
        
        logger.info("Creating MainWindow...")
        bus = EventBus()
        self.main_window = MainWindow(bus)
        
        if not self.headless:
            self.main_window.show()
            QtTest.QTest.qWait(500)  # Wait for window to render
        
        logger.info("✓ MainWindow created")
    
    def add_remote_instruments(self):
        """Add remote instruments to the GUI."""
        logger.info("Adding remote instruments...")
        
        # Create 2 remote spectrum analyzers
        for i in range(2):
            proxy = create_remote_instrument("SpectrumAnalyzer", "FullDemo")
            
            # Add to MainWindow's instrument list
            # Note: This simulates what the GUI does when user adds an instrument
            if hasattr(self.main_window, '_instruments'):
                self.main_window._instruments.append(proxy)
            
            logger.info(f"✓ Added SpectrumAnalyzer-{i}")
        
        QtTest.QTest.qWait(500)
    
    def verify_data_streaming(self):
        """Verify that data is streaming through the GUI."""
        logger.info("Verifying data streaming...")
        
        # Start instruments if they have start_sweep method
        if hasattr(self.main_window, '_instruments'):
            for inst in self.main_window._instruments:
                if hasattr(inst, 'start_sweep'):
                    inst.start_sweep()
                    logger.info(f"✓ Started sweep on {inst}")
        
        # Wait for data to flow
        QtTest.QTest.qWait(2000)
        
        # Try to fetch some data to verify connection
        if hasattr(self.main_window, '_instruments'):
            for inst in self.main_window._instruments:
                if hasattr(inst, 'get_sweep_points'):
                    data = inst.get_sweep_points()
                    if data and len(data) > 0:
                        logger.info(f"✓ Verified data streaming: {len(data)} points")
                    else:
                        raise RuntimeError(f"No data received from {inst}")
        
        logger.info("✓ Data streaming verified")
    
    def test_gui_controls(self):
        """Test GUI controls and interactions."""
        logger.info("Testing GUI controls...")
        
        # Find and interact with GUI elements
        if self.main_window:
            # Test menu bar
            menubar = self.main_window.menuBar()
            if menubar:
                logger.info("✓ MenuBar accessible")
            
            # Test status bar
            statusbar = self.main_window.statusBar()
            if statusbar:
                statusbar.showMessage("E2E Test Running...")
                logger.info("✓ StatusBar accessible")
            
            # Process events to update GUI
            QtTest.QTest.qWait(500)
        
        logger.info("✓ GUI controls tested")
    
    def monitor_streaming(self):
        """Monitor streaming for the specified duration."""
        logger.info(f"Monitoring streaming for {self.duration} seconds...")
        
        start_time = time.time()
        checks = 0
        
        while time.time() - start_time < self.duration:
            # Process events
            self.app.processEvents()
            
            # Periodic check
            if int(time.time() - start_time) % 2 == 0 and checks < 5:
                if hasattr(self.main_window, '_instruments'):
                    for inst in self.main_window._instruments:
                        if hasattr(inst, 'get_sweep_points'):
                            data = inst.get_sweep_points()
                            if data:
                                checks += 1
                                logger.info(f"  [{int(time.time() - start_time)}s] Data point: {len(data)} points")
            
            time.sleep(0.1)
        
        logger.info(f"✓ Monitored streaming for {self.duration}s ({checks} data checks)")
    
    def cleanup(self):
        """Clean up resources."""
        logger.info("Cleaning up...")
        
        # Stop instruments
        if hasattr(self.main_window, '_instruments'):
            for inst in self.main_window._instruments:
                if hasattr(inst, 'stop_sweep'):
                    try:
                        inst.stop_sweep()
                        logger.info(f"✓ Stopped {inst}")
                    except Exception as e:
                        logger.warning(f"Failed to stop {inst}: {e}")
        
        # Close main window
        if self.main_window:
            self.main_window.close()
            logger.info("✓ MainWindow closed")


def main():
    """Main entry point for E2E GUI test."""
    import argparse
    
    parser = argparse.ArgumentParser(description="E2E GUI Test with Dual-Plane Backend")
    parser.add_argument("--headless", action="store_true", help="Run without showing GUI (for CI)")
    parser.add_argument("--duration", type=int, default=10, help="Test duration in seconds")
    args = parser.parse_args()
    
    # Start backend server
    logger.info("Starting backend server...")
    server, server_thread = setup_backend()
    
    try:
        # Create Qt application
        app = QtWidgets.QApplication.instance() or QtWidgets.QApplication(sys.argv)
        
        # Create test runner
        test_runner = E2EGUITest(app, headless=args.headless, duration=args.duration)
        
        # Connect finish signal to quit app
        def on_finished(success: bool, message: str):
            logger.info(f"\n{'='*70}")
            logger.info(f"E2E GUI TEST RESULT")
            logger.info(f"{'='*70}")
            logger.info(f"Status: {'✅ PASSED' if success else '❌ FAILED'}")
            logger.info(f"Message: {message}")
            logger.info(f"{'='*70}\n")
            
            # Cleanup
            test_runner.cleanup()
            
            # Stop server
            logger.info("Stopping backend server...")
            server.stop()
            
            # Quit app
            QtCore.QTimer.singleShot(500, app.quit)
            
            # Exit with appropriate code
            sys.exit(0 if success else 1)
        
        test_runner.finished.connect(on_finished)
        
        # Start test after a short delay
        QtCore.QTimer.singleShot(1000, test_runner.run)
        
        # Run application
        logger.info("Starting Qt application...")
        return app.exec()
        
    except KeyboardInterrupt:
        logger.info("\nTest interrupted by user")
        server.stop()
        return 1
    except Exception as e:
        logger.error(f"Fatal error: {e}", exc_info=True)
        server.stop()
        return 1


if __name__ == "__main__":
    sys.exit(main())
