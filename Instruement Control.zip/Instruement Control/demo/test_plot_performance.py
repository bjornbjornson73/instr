"""
Performance Test for GUI Plotting

This script tests the GUI's ability to handle high-frequency data streaming
with large batches (4096 points/batch).

Usage:
    python demo/test_plot_performance.py [--duration SECONDS] [--batch-size N]

Expected Results:
    - GUI should remain responsive
    - Frame rate should be stable ~20 FPS
    - CPU usage should be 30-50%
    - No freezing or lag
"""

import sys
import time
from collections.abc import Iterable

import numpy as np  # type: ignore[import-not-found]
from PySide6.QtCore import QTimer  # type: ignore[import-not-found]
from PySide6.QtWidgets import (  # type: ignore[import-not-found]
    QApplication,
    QHBoxLayout,
    QLabel,
    QMainWindow,
    QPushButton,
    QVBoxLayout,
    QWidget,
)  # type: ignore[import-not-found]

from instrctl.gui.widgets import TimeSeriesPlotWidget


class StripChart(TimeSeriesPlotWidget):
    """Local compatibility shim backed by ``TimeSeriesPlotWidget``."""

    def __init__(self, max_points: int = 50_000, parent: QWidget | None = None):
        super().__init__(max_points=max_points)
        self._series = "stream"

    def append(self, samples: float | Iterable[float]) -> None:
        """Append one or more samples to the backing time-series."""
        if isinstance(samples, (int, float)):
            values = [float(samples)]
        else:
            try:
                values = [float(v) for v in samples]
            except TypeError:
                # Gracefully ignore non-iterables
                return

        for value in values:
            self.append_value(self._series, value)

    def clear(self) -> None:
        series = self._series_data.get(self._series)
        if series is not None:
            series.clear()
        curve = self._curves.get(self._series)
        if curve is not None:
            try:
                curve.clear()
            except AttributeError:
                curve.setData([], [])  # type: ignore[call-arg]


class PerformanceTestWindow(QMainWindow):
    """Test window for plotting performance"""
    
    def __init__(self, batch_size=4096, update_rate_hz=30):
        super().__init__()
        
        self.batch_size = batch_size
        self.update_interval_ms = int(1000 / update_rate_hz)
        
        self.setWindowTitle(f"Plot Performance Test - {batch_size} points/batch @ {update_rate_hz} Hz")
        self.resize(1200, 700)
        
        # Central widget
        central = QWidget()
        self.setCentralWidget(central)
        layout = QVBoxLayout(central)
        
        # Info label
        self.info_label = QLabel()
        layout.addWidget(self.info_label)
        
        # Plot widget
        self.plot = StripChart()
        self.plot.setWindowTitle(f"High-Frequency Stream ({batch_size} points/batch)")
        layout.addWidget(self.plot)
        
        # Control buttons
        btn_layout = QHBoxLayout()
        
        self.start_btn = QPushButton("Start Streaming")
        self.start_btn.clicked.connect(self.start_streaming)
        btn_layout.addWidget(self.start_btn)
        
        self.stop_btn = QPushButton("Stop Streaming")
        self.stop_btn.clicked.connect(self.stop_streaming)
        self.stop_btn.setEnabled(False)
        btn_layout.addWidget(self.stop_btn)
        
        self.clear_btn = QPushButton("Clear Plot")
        self.clear_btn.clicked.connect(self.plot.clear)
        btn_layout.addWidget(self.clear_btn)
        
        layout.addLayout(btn_layout)
        
        # Statistics
        self.stats_label = QLabel()
        layout.addWidget(self.stats_label)
        
        # Timer for data generation
        self.timer = QTimer()
        self.timer.timeout.connect(self.generate_batch)
        
        # Performance tracking
        self.start_time = None
        self.batch_count = 0
        self.total_points = 0
        
        # Stats update timer
        self.stats_timer = QTimer()
        self.stats_timer.timeout.connect(self.update_stats)
        self.stats_timer.start(1000)  # Update stats every second
        
        self.update_info()
    
    def update_info(self):
        """Update info label"""
        info = (
            f"<b>Performance Test Configuration:</b><br>"
            f"Batch Size: {self.batch_size} points<br>"
            f"Update Rate: {1000/self.update_interval_ms:.1f} Hz ({self.update_interval_ms}ms interval)<br>"
            f"Expected Data Rate: {self.batch_size * 1000/self.update_interval_ms:,.0f} points/second<br><br>"
            f"<b>Expected Performance:</b><br>"
            f"✓ GUI should remain responsive<br>"
            f"✓ Smooth cursor movement<br>"
            f"✓ Frame rate: ~20 FPS<br>"
            f"✓ CPU usage: 30-50%"
        )
        self.info_label.setText(info)
    
    def start_streaming(self):
        """Start streaming data"""
        self.start_btn.setEnabled(False)
        self.stop_btn.setEnabled(True)
        
        self.start_time = time.time()
        self.batch_count = 0
        self.total_points = 0
        
        # Start timer
        self.timer.start(self.update_interval_ms)
        
        print(f"\n{'='*60}")
        print("STREAMING STARTED")
        print(f"{'='*60}")
        print(f"Batch size: {self.batch_size} points")
        print(f"Update rate: {1000/self.update_interval_ms:.1f} Hz")
        print(f"Expected data rate: {self.batch_size * 1000/self.update_interval_ms:,.0f} points/second")
        print(f"\nMonitor GUI responsiveness...")
        print(f"- Try moving the mouse")
        print(f"- Try clicking buttons")
        print(f"- Try panning/zooming the plot")
        print(f"{'='*60}\n")
    
    def stop_streaming(self):
        """Stop streaming data"""
        self.timer.stop()
        
        self.start_btn.setEnabled(True)
        self.stop_btn.setEnabled(False)
        
        elapsed = time.time() - self.start_time if self.start_time else 0
        
        print(f"\n{'='*60}")
        print("STREAMING STOPPED")
        print(f"{'='*60}")
        print(f"Duration: {elapsed:.1f} seconds")
        print(f"Total batches: {self.batch_count}")
        print(f"Total points: {self.total_points:,}")
        print(f"Average rate: {self.total_points/elapsed:,.0f} points/second")
        print(f"{'='*60}\n")
    
    def generate_batch(self):
        """Generate and plot a batch of data"""
        # Simulate realistic signal: sine wave + noise
        t = time.time()
        freq = 1.0  # 1 Hz sine wave
        phase = 2 * np.pi * freq * t
        
        # Generate batch
        signal = 1000 + 100 * np.sin(phase + np.linspace(0, 2*np.pi, self.batch_size))
        noise = np.random.randn(self.batch_size) * 10
        data = signal + noise
        
        # Send to plot
        self.plot.append(data.tolist())
        
        # Update counters
        self.batch_count += 1
        self.total_points += self.batch_size
    
    def update_stats(self):
        """Update statistics display"""
        if self.start_time is None:
            self.stats_label.setText("<b>Status:</b> Not streaming")
            return
        
        elapsed = time.time() - self.start_time
        if elapsed > 0:
            rate = self.total_points / elapsed
            
            stats = (
                f"<b>Streaming Statistics:</b><br>"
                f"Duration: {elapsed:.1f} seconds<br>"
                f"Batches: {self.batch_count}<br>"
                f"Total points: {self.total_points:,}<br>"
                f"Data rate: {rate:,.0f} points/second<br>"
                f"<br>"
                f"<b>Performance Check:</b><br>"
                f"{'✓' if rate > 50000 else '✗'} High throughput (>50K pts/s)<br>"
                f"{'✓' if self.batch_count > 10 else '✗'} Sustained streaming (>10 batches)"
            )
            self.stats_label.setText(stats)


def main():
    """Run performance test"""
    import argparse
    
    parser = argparse.ArgumentParser(description="GUI Plotting Performance Test")
    parser.add_argument("--batch-size", type=int, default=4096, help="Points per batch (default: 4096)")
    parser.add_argument("--rate", type=int, default=30, help="Update rate in Hz (default: 30)")
    parser.add_argument("--duration", type=int, default=None, help="Auto-stop after N seconds (optional)")
    args = parser.parse_args()
    
    app = QApplication(sys.argv)
    
    print("\n" + "="*60)
    print("GUI PLOT PERFORMANCE TEST")
    print("="*60)
    print(f"Configuration:")
    print(f"  Batch size: {args.batch_size} points")
    print(f"  Update rate: {args.rate} Hz")
    print(f"  Expected data rate: {args.batch_size * args.rate:,} points/second")
    print("="*60)
    print("\nExpected Results:")
    print("  ✓ GUI remains responsive")
    print("  ✓ Smooth mouse cursor")
    print("  ✓ No freezing or lag")
    print("  ✓ CPU usage 30-50%")
    print("="*60)
    print("\nClick 'Start Streaming' to begin test")
    print("Try interacting with GUI while streaming:\n")
    print("  - Move mouse around")
    print("  - Click buttons")
    print("  - Pan/zoom plot")
    print("  - Resize window")
    print("\nAll should work smoothly!")
    print("="*60 + "\n")
    
    window = PerformanceTestWindow(batch_size=args.batch_size, update_rate_hz=args.rate)
    window.show()
    
    # Auto-start if duration specified
    if args.duration:
        print(f"Auto-starting test for {args.duration} seconds...")
        QTimer.singleShot(500, window.start_streaming)
        QTimer.singleShot(500 + args.duration * 1000, window.stop_streaming)
        QTimer.singleShot(1000 + args.duration * 1000, app.quit)
    
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
