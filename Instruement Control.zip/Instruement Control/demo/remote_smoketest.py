from __future__ import annotations

import threading
import time

from instrctl.core.remote_agent import main as agent_main
from instrctl.core.remote import RemoteInstrumentProxy, RemoteConfig
from instrctl.core.registry import InstrumentRegistry
from instrctl.core.events import EventBus


def run_agent_bg():
    # Run agent listening on localhost:8815
    agent_main(["--host", "127.0.0.1", "--port", "8815"])  # blocking until Ctrl+C


if __name__ == "__main__":
    # Start agent in a background thread (for demo purposes)
    t = threading.Thread(target=run_agent_bg, daemon=True)
    t.start()
    time.sleep(0.3)

    # Pick any registered instrument (plugins should be discoverable when importing agent)
    kinds = InstrumentRegistry.list_kinds()
    kind = next(iter(kinds.keys()))
    model = next(iter(kinds[kind].keys()))

    proxy = RemoteInstrumentProxy(kind=kind, model=model, config=RemoteConfig(host="127.0.0.1", port=8815), event_bus=EventBus())
    proxy.connect()

    # Try to call a method that likely exists: features()
    try:
        print("features keys:", list(proxy.features().keys())[:5])
    except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
        print("features failed:", e)

    # If the instrument has an event-like getter, call it twice to drain
    feats = proxy.features()
    getter_name = None
    for v in feats.values():
        ui = v.get("ui", {})
        if ui.get("getter"):
            getter_name = v.get("attr")
            break
    if getter_name:
        g = getattr(proxy, getter_name)
        print("first:", g())
        time.sleep(0.2)
        print("second:", g())
    else:
        print("No getter found to demo stream.")
