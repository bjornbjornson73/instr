from __future__ import annotations

import sys
from typing import Optional

from PySide6 import QtCore, QtWidgets

# Ensure package is importable if running from source tree
try:
    from instrctl.core import EventBus, InstrumentFactory, InstrumentRegistry
    from instrctl.core.plugins import discover_all
    from instrctl.gui.widgets import MainWindow, _ui_clock
except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
    print("Failed to import instrctl: ", e)
    sys.exit(1)


def main() -> None:
    app = QtWidgets.QApplication.instance() or QtWidgets.QApplication([])
    bus = EventBus()
    _ui_clock.ensure_started()
    discover_all()
    win = MainWindow(bus)

    # Add instruments discovered from plugins
    try:
        kinds = InstrumentRegistry.list_kinds()
        added_any = False
        for kind, models in kinds.items():
            for model in models.keys():
                inst = InstrumentFactory.create(kind, model, event_bus=bus)
                win.add_instrument(inst)
                added_any = True
        if not added_any:
            QtWidgets.QMessageBox.information(
                None,
                "No Instruments",
                "No plugin instruments found. Add a plugin (e.g., plugins/my_gpio_plugin.py) and click Reload Plugins.",
            )
    except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
        QtWidgets.QMessageBox.critical(None, "Error", str(e))
        sys.exit(2)

    # Periodic timers to generate data
    # - Call demo SG observable getter frequently to publish 'value' events
    # - Trigger single_sweep on SA to publish 'sweep'
    def tick_sg():
        sg_inst = next((i for i in win.instruments if hasattr(i, "read_output_level")), None)
        if sg_inst:
            getattr(sg_inst, "read_output_level")()

    def tick_sa():
        sa_inst = next((i for i in win.instruments if hasattr(i, "single_sweep")), None)
        if sa_inst:
            sa_inst.single_sweep()

    t1 = QtCore.QTimer(win)
    t1.timeout.connect(tick_sg)
    t1.start(200)  # 5 Hz

    t2 = QtCore.QTimer(win)
    t2.timeout.connect(tick_sa)
    t2.start(1000)  # 1 Hz

    # Optional: If a GPIO instrument was added (DemoGPIO/MyDemoGPIO), try to find it and toggle
    def tick_gpio():
        gpio_inst = next((i for i in win.instruments if hasattr(i, "set_pin_mode") and hasattr(i, "read_pin")), None)
        if not gpio_inst:
            return
        gpio_inst.set_pin_mode(0, "OUT")
        v = 0 if gpio_inst.read_pin(0) else 1
        gpio_inst.write_pin(0, v)

    t3 = QtCore.QTimer(win)
    t3.timeout.connect(tick_gpio)
    t3.start(500)

    win.show()
    app.exec()


if __name__ == "__main__":
    main()
