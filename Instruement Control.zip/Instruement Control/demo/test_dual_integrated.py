"""
Integrated test for dual-plane remote architecture using real app instruments.

This test:
1. Starts a DualAgentServer with real instrument registry
2. Uses RemoteInstrumentProxy to connect
3. Tests control operations (setters) via RPyC
4. Tests data operations (getters) via Arrow Flight
5. Measures throughput, latency, and bandwidth

Usage:
    python demo/test_dual_integrated.py [--mode quick|full|multi]
    
    quick: Fast tests with single instrument
    full:  Comprehensive tests with single instrument
    multi: Multi-instrument concurrent streaming test
"""

import argparse
import logging
import sys
import time
import threading
import statistics
from pathlib import Path
from typing import List, Dict, Any

# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from instrctl.core.dual_agent import DualAgentServer
from instrctl.core.remote import RemoteInstrumentProxy, RemoteConfig
from instrctl.core.plugins import discover_all
from instrctl.core.registry import InstrumentRegistry

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(name)s: %(message)s'
)
log = logging.getLogger(__name__)


class TestResult:
    """Container for test results."""
    def __init__(self, name: str):
        self.name = name
        self.latencies: List[float] = []
        self.throughput: float = 0.0
        self.bandwidth: float = 0.0
        self.success = False
        self.error: str = ""


def compute_stats(latencies: List[float]) -> Dict[str, float]:
    """Compute statistics from latency measurements."""
    if not latencies:
        return {}
    
    return {
        "mean": statistics.mean(latencies),
        "median": statistics.median(latencies),
        "p95": statistics.quantiles(latencies, n=20)[18] if len(latencies) >= 20 else max(latencies),
        "p99": statistics.quantiles(latencies, n=100)[98] if len(latencies) >= 100 else max(latencies),
        "min": min(latencies),
        "max": max(latencies)
    }


def print_result(result: TestResult, targets: Dict[str, float] = None):
    """Pretty print test results with pass/fail indicators."""
    print(f"\n{'=' * 70}")
    print(f"Test: {result.name}")
    print(f"{'=' * 70}")
    
    if not result.success:
        print(f"FAILED: {result.error}")
        return
    
    stats = compute_stats(result.latencies)
    
    print(f"Throughput:  {result.throughput:,.1f} ops/s")
    print(f"Bandwidth:   {result.bandwidth:.2f} MB/s")
    
    if stats:
        print(f"\nLatency:")
        print(f"  Mean:      {stats['mean']*1000:.2f} ms")
        print(f"  Median:    {stats['median']*1000:.2f} ms")
        print(f"  P95:       {stats['p95']*1000:.2f} ms")
        print(f"  P99:       {stats['p99']*1000:.2f} ms")
        print(f"  Range:     {stats['min']*1000:.2f} - {stats['max']*1000:.2f} ms")
    
    # Check against targets
    if targets:
        print(f"\nTargets:")
        passed = True
        
        if "throughput" in targets:
            target = targets["throughput"]
            status = "[PASS]" if result.throughput >= target else "[FAIL]"
            print(f"  Throughput:  {status} {result.throughput:,.1f} >= {target:,.1f} ops/s")
            passed = passed and (result.throughput >= target)
        
        if "bandwidth" in targets:
            target = targets["bandwidth"]
            status = "[PASS]" if result.bandwidth >= target else "[FAIL]"
            print(f"  Bandwidth:   {status} {result.bandwidth:.2f} >= {target:.2f} MB/s")
            passed = passed and (result.bandwidth >= target)
        
        if "latency" in targets:
            target = targets["latency"]
            mean_latency = stats.get("mean", 0) * 1000
            status = "[PASS]" if mean_latency <= target else "[FAIL]"
            print(f"  Latency:     {status} {mean_latency:.2f} <= {target:.2f} ms")
            passed = passed and (mean_latency <= target)
        
        print(f"\n{'PASS' if passed else 'FAIL'}")


def test_control_simple(proxy: RemoteInstrumentProxy, iterations: int = 1000) -> TestResult:
    """Test simple control operations via RPyC."""
    result = TestResult("Control - Simple Setters")
    
    try:
        log.info("Testing simple control operations (%d iterations)", iterations)
        
        latencies = []
        t_start = time.perf_counter()
        
        for i in range(iterations):
            # Test center frequency setter
            t0 = time.perf_counter()
            proxy.set_center(1e9 + i * 1000)
            t1 = time.perf_counter()
            latencies.append(t1 - t0)
        
        t_end = time.perf_counter()
        duration = t_end - t_start
        
        result.latencies = latencies
        result.throughput = iterations / duration
        result.success = True
        
    except Exception as e:
        result.error = str(e)
        log.exception("Control simple test failed")
    
    return result


def test_control_complex(proxy: RemoteInstrumentProxy, iterations: int = 500) -> TestResult:
    """Test complex control operations with multiple parameters."""
    result = TestResult("Control - Complex Operations")
    
    try:
        log.info("Testing complex control operations (%d iterations)", iterations)
        
        latencies = []
        t_start = time.perf_counter()
        
        for i in range(iterations):
            t0 = time.perf_counter()
            
            # Multiple operations in sequence
            proxy.set_center(2.4e9 + i * 1e6)
            proxy.set_span(100e6 + (i % 20) * 1e6)
            
            # Query state
            center = proxy.get_center()
            span = proxy.get_span()
            
            t1 = time.perf_counter()
            latencies.append(t1 - t0)
        
        t_end = time.perf_counter()
        duration = t_end - t_start
        
        result.latencies = latencies
        result.throughput = iterations / duration
        result.success = True
        
    except Exception as e:
        result.error = str(e)
        log.exception("Control complex test failed")
    
    return result


def test_data_small_batches(proxy: RemoteInstrumentProxy, iterations: int = 1000) -> TestResult:
    """Test data streaming with small batches via Flight."""
    result = TestResult("Data - Small Batches")
    
    try:
        log.info("Testing data streaming with small batches (%d iterations)", iterations)
        
        # Start the sweep
        proxy.start_sweep()
        time.sleep(0.1)  # Let it start generating data
        
        latencies = []
        total_points = 0
        t_start = time.perf_counter()
        
        for i in range(iterations):
            t0 = time.perf_counter()
            points = proxy.get_sweep_points()
            t1 = time.perf_counter()
            
            if points:
                latencies.append(t1 - t0)
                total_points += len(points)
        
        t_end = time.perf_counter()
        duration = t_end - t_start
        
        proxy.stop_sweep()
        
        result.latencies = latencies
        result.throughput = len(latencies) / duration
        # Assume 8 bytes per point (float64)
        result.bandwidth = (total_points * 8) / (duration * 1024 * 1024)
        result.success = True
        
    except Exception as e:
        result.error = str(e)
        log.exception("Data small batches test failed")
    
    return result


def test_data_large_batches(proxy: RemoteInstrumentProxy, iterations: int = 100) -> TestResult:
    """Test data streaming with large batches via Flight."""
    result = TestResult("Data - Large Batches (10K points)")
    
    try:
        log.info("Testing data streaming with large batches (%d iterations)", iterations)
        
        proxy.start_sweep()
        time.sleep(0.1)
        
        latencies = []
        total_points = 0
        t_start = time.perf_counter()
        
        for i in range(iterations):
            t0 = time.perf_counter()
            points = proxy.get_sweep_points()
            t1 = time.perf_counter()
            
            if points:
                latencies.append(t1 - t0)
                total_points += len(points)
        
        t_end = time.perf_counter()
        duration = t_end - t_start
        
        proxy.stop_sweep()
        
        result.latencies = latencies
        result.throughput = len(latencies) / duration
        result.bandwidth = (total_points * 8) / (duration * 1024 * 1024)
        result.success = True
        
    except Exception as e:
        result.error = str(e)
        log.exception("Data large batches test failed")
    
    return result


def test_mixed_workload(proxy: RemoteInstrumentProxy, duration_s: float = 5.0) -> TestResult:
    """Test mixed control + data operations."""
    result = TestResult("Mixed Workload")
    
    try:
        log.info("Testing mixed workload for %.1f seconds", duration_s)
        
        proxy.start_sweep()
        
        control_ops = 0
        data_ops = 0
        total_points = 0
        latencies = []
        
        t_start = time.perf_counter()
        t_end = t_start + duration_s
        
        while time.perf_counter() < t_end:
            # Control operation
            t0 = time.perf_counter()
            proxy.set_center(2.4e9 + control_ops * 1e6)
            t1 = time.perf_counter()
            control_ops += 1
            latencies.append(t1 - t0)
            
            # Data operation
            t0 = time.perf_counter()
            points = proxy.get_sweep_points()
            t1 = time.perf_counter()
            if points:
                data_ops += 1
                total_points += len(points)
                latencies.append(t1 - t0)
        
        actual_duration = time.perf_counter() - t_start
        proxy.stop_sweep()
        
        result.latencies = latencies
        result.throughput = (control_ops + data_ops) / actual_duration
        result.bandwidth = (total_points * 8) / (actual_duration * 1024 * 1024)
        result.success = True
        
        log.info("Mixed workload: %d control ops, %d data ops, %d points",
                 control_ops, data_ops, total_points)
        
    except Exception as e:
        result.error = str(e)
        log.exception("Mixed workload test failed")
    
    return result


def test_object_method_calls(proxy: RemoteInstrumentProxy, iterations: int = 100) -> TestResult:
    """Test calling methods on objects returned via getters (RPyC netref overhead)."""
    result = TestResult("Object Method Calls (RPyC Netref)")
    
    try:
        log.info("Testing object method calls (%d iterations)", iterations)
        
        latencies = []
        t_start = time.perf_counter()
        
        for i in range(iterations):
            t0 = time.perf_counter()
            
            # Get an object from the remote instrument
            state_obj = proxy.get_state_object()
            
            # Call methods on the returned object (RPyC netref)
            center = state_obj.get_center()
            span = state_obj.get_span()
            running = state_obj.is_running()
            count = state_obj.get_call_count()
            
            t1 = time.perf_counter()
            latencies.append(t1 - t0)
        
        t_end = time.perf_counter()
        duration = t_end - t_start
        
        result.latencies = latencies
        result.throughput = iterations / duration
        result.success = True
        
        log.info("Object method calls: %d iterations, 4 method calls per iteration", iterations)
        
    except Exception as e:
        result.error = str(e)
        log.exception("Object method calls test failed")
    
    return result


def test_multi_instrument_concurrent(duration_s: float = 10.0) -> TestResult:
    """Test concurrent data streaming from multiple instruments simultaneously."""
    result = TestResult("Multi-Instrument Concurrent Streaming")
    
    try:
        log.info("Testing multi-instrument concurrent streaming for %.1f seconds", duration_s)
        
        # Create proxies for multiple instrument instances (all SpectrumAnalyzers for simplicity)
        instruments = []
        num_instruments = 4
        
        kinds = InstrumentRegistry.list_kinds()
        kind = "SpectrumAnalyzer"
        if kind not in kinds or not kinds[kind]:
            result.error = f"{kind} not available"
            return result
        
        model = list(kinds[kind].keys())[0]
        
        # Create multiple proxies to the same instrument type
        for i in range(num_instruments):
            config = RemoteConfig(
                host="localhost",
                port=18861,
                port_data=8815
            )
            proxy = RemoteInstrumentProxy(kind=kind, model=model, config=config)
            proxy.connect()
            instruments.append((proxy, "get_sweep_points", f"{kind}-{i}"))
            log.info("Connected to %s instance %d", kind, i)
        
        if len(instruments) < 2:
            result.error = "Need at least 2 instruments for concurrent test"
            return result
        
        # Start all instruments
        for proxy, _, name in instruments:
            proxy.start_sweep()
            log.info("Started %s", name)
        
        time.sleep(0.2)  # Let them start generating data
        
        # Concurrent data collection
        stop_flag = threading.Event()
        results_lock = threading.Lock()
        thread_results = {i: {"ops": 0, "points": 0, "latencies": []} for i in range(len(instruments))}
        
        def worker(idx: int, proxy: RemoteInstrumentProxy, getter: str):
            """Worker thread for each instrument."""
            while not stop_flag.is_set():
                try:
                    t0 = time.perf_counter()
                    points = getattr(proxy, getter)()
                    t1 = time.perf_counter()
                    
                    if points:
                        with results_lock:
                            thread_results[idx]["ops"] += 1
                            thread_results[idx]["points"] += len(points)
                            thread_results[idx]["latencies"].append(t1 - t0)
                except Exception as e:
                    log.error("Worker %d error: %s", idx, e)
                    break
        
        # Start worker threads
        threads = []
        for idx, (proxy, getter, kind) in enumerate(instruments):
            t = threading.Thread(target=worker, args=(idx, proxy, getter), name=f"Worker-{kind}")
            t.daemon = True
            t.start()
            threads.append(t)
        
        # Run for specified duration
        t_start = time.perf_counter()
        time.sleep(duration_s)
        stop_flag.set()
        
        # Wait for threads to finish
        for t in threads:
            t.join(timeout=2.0)
        
        t_end = time.perf_counter()
        actual_duration = t_end - t_start
        
        # Stop all instruments
        for proxy, _, _ in instruments:
            proxy.stop_sweep()
        
        # Aggregate results
        total_ops = sum(r["ops"] for r in thread_results.values())
        total_points = sum(r["points"] for r in thread_results.values())
        all_latencies = []
        for r in thread_results.values():
            all_latencies.extend(r["latencies"])
        
        result.latencies = all_latencies
        result.throughput = total_ops / actual_duration
        result.bandwidth = (total_points * 8) / (actual_duration * 1024 * 1024)
        result.success = True
        
        log.info("Multi-instrument: %d instruments, %d total ops, %d total points",
                 len(instruments), total_ops, total_points)
        
        # Per-instrument breakdown
        for idx, (proxy, _, kind) in enumerate(instruments):
            ops = thread_results[idx]["ops"]
            points = thread_results[idx]["points"]
            bandwidth = (points * 8) / (actual_duration * 1024 * 1024)
            log.info("  %s: %d ops, %d points, %.2f MB/s", 
                     kind, ops, points, bandwidth)
        
        # Disconnect
        for proxy, _, _ in instruments:
            proxy.disconnect()
        
    except Exception as e:
        result.error = str(e)
        log.exception("Multi-instrument concurrent test failed")
    
    return result


def run_tests(mode: str = "quick"):
    """Run all tests."""
    # Start agent server in background
    log.info("Starting DualAgentServer...")
    agent = DualAgentServer(host="localhost", port_control=18861, port_data=8815)
    agent.start()
    time.sleep(2.0)  # Wait for servers to be ready
    
    # Create remote proxy
    log.info("Creating RemoteInstrumentProxy for SpectrumAnalyzer...")
    
    # Check what's registered
    kinds = InstrumentRegistry.list_kinds()
    log.info("Available instruments: %s", kinds)
    
    # Use SpectrumAnalyzer if available, otherwise use first available instrument
    kind = "SpectrumAnalyzer"
    model = None
    
    if kind in kinds and kinds[kind]:
        model = list(kinds[kind].keys())[0]
    else:
        # Use first available kind/model
        for k, models in kinds.items():
            if models:
                kind = k
                model = list(models.keys())[0]
                break
    
    if not model:
        log.error("No instruments registered! Did plugins load correctly?")
        agent.stop()
        return
    
    log.info("Using instrument: %s:%s", kind, model)
    
    config = RemoteConfig(
        host="localhost",
        port=18861,
        port_data=8815,
        use_dual_transport=True
    )
    
    proxy = RemoteInstrumentProxy(kind=kind, model=model, config=config)
    
    try:
        # Connect
        log.info("Connecting to remote instrument...")
        proxy.connect()
        
        # WARMUP: Trigger plugin loading by calling getters once
        log.info("Warming up: triggering plugin discovery and PySide6 loads...")
        try:
            _ = proxy.set_center(1e9)
            _ = proxy.get_center()  # This will trigger all lazy plugin imports
            _ = proxy.get_span()
            log.info("Warmup complete - all plugins loaded")
        except Exception as e:
            log.warning("Warmup failed (non-critical): %s", e)
        
        # Run tests based on mode
        results = []
        
        if mode == "quick":
            log.info("Running QUICK test suite")
            results.append(test_control_simple(proxy, iterations=100))
            results.append(test_control_complex(proxy, iterations=50))
            results.append(test_object_method_calls(proxy, iterations=100))
            results.append(test_mixed_workload(proxy, duration_s=10.0))  # Longer test for accurate bandwidth
        elif mode == "multi":
            log.info("Running MULTI-INSTRUMENT test suite")
            results.append(test_control_simple(proxy, iterations=100))
            results.append(test_multi_instrument_concurrent(duration_s=10.0))
        else:
            log.info("Running FULL test suite")
            results.append(test_control_simple(proxy, iterations=1000))
            results.append(test_control_complex(proxy, iterations=500))
            results.append(test_object_method_calls(proxy, iterations=500))
            results.append(test_data_small_batches(proxy, iterations=1000))
            results.append(test_data_large_batches(proxy, iterations=100))
            results.append(test_mixed_workload(proxy, duration_s=10.0))
            results.append(test_multi_instrument_concurrent(duration_s=10.0))
        
        # Print results
        print("\n" + "=" * 70)
        print("DUAL-PLANE INTEGRATED TEST RESULTS")
        print("=" * 70)
        
        targets = {
            "Control - Simple Setters": {"throughput": 100, "latency": 10},
            "Control - Complex Operations": {"throughput": 50, "latency": 20},
            "Object Method Calls (RPyC Netref)": {"throughput": 20, "latency": 50},
            "Data - Small Batches": {"throughput": 100, "bandwidth": 1.0},
            "Data - Large Batches (10K points)": {"throughput": 10, "bandwidth": 50},
            "Mixed Workload": {"throughput": 100, "bandwidth": 10},
            "Multi-Instrument Concurrent Streaming": {"throughput": 400, "bandwidth": 2.0}
        }
        
        for result in results:
            print_result(result, targets.get(result.name, {}))
        
        # Disconnect
        proxy.disconnect()
        
    except Exception as e:
        log.exception("Test execution failed: %s", e)
    
    finally:
        # Stop agent
        log.info("Stopping DualAgentServer...")
        agent.stop()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Test dual-plane integrated architecture")
    parser.add_argument("--mode", choices=["quick", "full", "multi"], default="quick",
                        help="Test mode (quick=fast smoke test, full=comprehensive, multi=concurrent multi-instrument)")
    args = parser.parse_args()
    
    run_tests(args.mode)
