from __future__ import annotations

"""
Matrix smoketest for PySide6 QtWebEngine on Windows.

Runs a series of isolated subprocess preflights that each:
- set specific Qt/Chromium environment flags
- construct QWebEngineView
- load a minimal inline HTML snippet
- exit 0 only if loadFinished reported ok

Prints PASS/FAIL per case and a compact stderr snippet to help diagnose.
"""

import os
import sys
import subprocess
from typing import Dict, List


def _run_case(name: str, extra_env: Dict[str, str], extra_flags: List[str], timeout: float = 10.0) -> Dict[str, str]:
    code = r"""
import os, sys

# Apply base-conservative flags
flags = [
    "--disable-gpu",
    "--disable-gpu-compositing",
    "--disable-gpu-vsync",
    "--in-process-gpu",
]
# Append scenario-specific flags from PARENT_FLAGS
parent_flags = os.environ.get("PARENT_FLAGS", "").strip()
if parent_flags:
    flags.extend([f for f in parent_flags.split(" ") if f])
existing = os.environ.get("QTWEBENGINE_CHROMIUM_FLAGS", "").strip()
os.environ["QTWEBENGINE_CHROMIUM_FLAGS"] = (" ".join(flags + ([existing] if existing else []))).strip()

# Safety env fallbacks; scenario-specific env was already set by parent
os.environ.setdefault("QTWEBENGINE_DISABLE_SANDBOX", "1")

from PySide6.QtCore import Qt, QTimer
from PySide6.QtWidgets import QApplication
from PySide6.QtWebEngineWidgets import QWebEngineView

# Attributes before app
QApplication.setAttribute(Qt.AA_UseSoftwareOpenGL, True)
QApplication.setAttribute(Qt.AA_ShareOpenGLContexts, True)

app = QApplication([])
view = QWebEngineView()
ok = {"v": False}
def on_loaded(okay: bool):
    ok["v"] = bool(okay)
    QTimer.singleShot(20, app.quit)
view.loadFinished.connect(on_loaded)
view.setHtml('<!doctype html><meta charset="utf-8"><title>x</title><body>ok</body>')
QTimer.singleShot(3000, app.quit)
app.exec()
if ok["v"]:
    print("OK")
    sys.exit(0)
else:
    print("FAIL")
    sys.exit(3)
""".strip()

    env = os.environ.copy()
    # Scenario-specific env
    env.update(extra_env)
    # Provide flags to child via env
    env["PARENT_FLAGS"] = " ".join(extra_flags).strip()

    try:
        proc = subprocess.run(
            [sys.executable, "-c", code],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=timeout,
            text=True,
        )
        ok = (proc.returncode == 0) and ("OK" in (proc.stdout or ""))
        err_head = (proc.stderr or "").strip().splitlines()[:2]
        return {
            "name": name,
            "rc": str(proc.returncode),
            "stdout": (proc.stdout or "").strip(),
            "stderr_head": " | ".join(err_head),
            "result": "PASS" if ok else "FAIL",
        }
    except subprocess.TimeoutExpired:
        return {"name": name, "rc": "TIMEOUT", "stdout": "", "stderr_head": "", "result": "TIMEOUT"}


def main() -> int:
    cases = []
    # Case variants: try different ANGLE/GL/RHI combinations
    def add(name: str, env: Dict[str, str], flags: List[str]):
        cases.append((name, env, flags))

    # 1) Full software path (Qt software, RHI software, ANGLE swiftshader)
    add(
        "soft-swiftshader",
        {
            "QT_OPENGL": "software",
            # QSG_RHI_BACKEND 'software' is invalid on Qt6 RHI; leave unset and use WEBENGINE_SCENARIO flags instead
            "QT_ANGLE_PLATFORM": "swiftshader",
        },
        ["--use-angle=swiftshader", "--use-gl=swiftshader", "--no-sandbox", "--disable-features=UseSkiaRenderer"],
    )

    # 2) Software + ANGLE warp (D3D11 WARP)
    add(
        "soft-warp",
        {
            "QT_OPENGL": "angle",
            "QSG_RHI_BACKEND": "opengl",
            "QT_ANGLE_PLATFORM": "warp",
        },
        ["--use-angle=warp", "--no-sandbox"],
    )

    # 3) ANGLE default d3d11, RHI opengl
    add(
        "angle-d3d11",
        {"QT_OPENGL": "angle", "QSG_RHI_BACKEND": "opengl", "QT_ANGLE_PLATFORM": "d3d11"},
        ["--no-sandbox"],
    )

    # 4) Desktop GL fallback (may fail on some machines)
    add(
        "desktop-gl",
        {"QT_OPENGL": "desktop", "QSG_RHI_BACKEND": "opengl"},
        ["--no-sandbox"],
    )

    # 5) Minimal flags, let Qt decide, only disable sandbox
    add("minimal-nosandbox", {}, ["--no-sandbox"])

    # 6) Heavy disable GPU + in-process GPU + Skia off
    add(
        "strict-sw",
        {"QT_OPENGL": "software", "QSG_RHI_BACKEND": "software"},
        [
            "--disable-gpu",
            "--disable-gpu-compositing",
            "--in-process-gpu",
            "--no-sandbox",
            "--disable-features=VaapiVideoDecoder,UseSkiaRenderer",
            "--use-angle=swiftshader",
            "--use-gl=swiftshader",
        ],
    )

    results = []
    for name, env, flags in cases:
        r = _run_case(name, env, flags)
        results.append(r)
        print(f"{r['name']}: {r['result']} (rc={r['rc']})")
        if r["stderr_head"]:
            print(f"  stderr: {r['stderr_head']}")

    # Summarize
    ok = [r for r in results if r["result"] == "PASS"]
    if ok:
        print("\nWorking configurations:")
        for r in ok:
            print(f"- {r['name']}")
        return 0
    else:
        print("\nNo passing configuration found.")
        return 1


if __name__ == "__main__":
    sys.exit(main())
