#!/usr/bin/env python3
"""
Comprehensive throughput testing for dual-plane remote architecture.

Tests the performance characteristics of:
1. RPyC control plane - method calls, object references
2. Arrow Flight data plane - bulk data streaming
3. Concurrent operation - both planes operating simultaneously
4. Various data sizes and call patterns

Run this script to benchmark the dual transport system.
"""
from __future__ import annotations

import argparse
import logging
import sys
import time
import threading
from dataclasses import dataclass
from statistics import mean, median, stdev
from typing import Any, List, Optional

# Add src to path for imports
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

try:
    from instrctl.core.dual_transport import DualTransport, RemoteConfig
except ImportError as e:
    print(f"Failed to import DualTransport: {e}")
    print("Make sure rpyc and pyarrow are installed:")
    print("  pip install rpyc>=5.3.0 pyarrow>=14.0.0")
    sys.exit(1)

log = logging.getLogger(__name__)


@dataclass
class TestResult:
    """Result of a throughput test."""
    name: str
    operation_count: int
    total_time_s: float
    throughput_ops_per_sec: float
    latencies_ms: List[float]
    mean_latency_ms: float
    median_latency_ms: float
    p95_latency_ms: float
    p99_latency_ms: float
    stdev_latency_ms: float
    data_transferred_mb: float = 0.0
    bandwidth_mbps: float = 0.0
    error: Optional[str] = None


class BenchmarkHarness:
    """Test harness for dual transport benchmarking."""
    
    def __init__(self, host: str = "localhost", rpyc_port: int = 18861, flight_port: int = 8815):
        self.host = host
        self.rpyc_port = rpyc_port
        self.flight_port = flight_port
        self.transport: Optional[DualTransport] = None
        
    def setup(self) -> bool:
        """Connect to remote agent."""
        try:
            config = RemoteConfig(
                host=self.host,
                port_control=self.rpyc_port,
                port_data=self.flight_port
            )
            self.transport = DualTransport(config)
            self.transport.connect()
            log.info(f"Connected to agent at {self.host} (RPyC:{self.rpyc_port}, Flight:{self.flight_port})")
            return True
        except Exception as e:
            log.error(f"Failed to connect to agent: {e}")
            return False
    
    def teardown(self) -> None:
        """Disconnect from remote agent."""
        if self.transport:
            try:
                self.transport.disconnect()
                log.info("Disconnected from agent")
            except Exception as e:
                log.warning(f"Error during disconnect: {e}")
    
    def benchmark_rpyc_simple_calls(self, count: int = 1000) -> TestResult:
        """Benchmark simple RPyC method calls with small payloads."""
        log.info(f"Benchmarking {count} simple RPyC calls...")
        
        latencies = []
        start = time.time()
        
        for i in range(count):
            t0 = time.time()
            try:
                # Simple call with minimal args
                result = self.transport.invoke("test_method", i)
            except Exception as e:
                log.debug(f"Call {i} failed: {e}")
            latencies.append((time.time() - t0) * 1000)
        
        total_time = time.time() - start
        
        return self._compute_result(
            name="RPyC Simple Calls",
            count=count,
            total_time=total_time,
            latencies=latencies
        )
    
    def benchmark_rpyc_complex_objects(self, count: int = 500) -> TestResult:
        """Benchmark RPyC calls with complex object returns (netrefs)."""
        log.info(f"Benchmarking {count} RPyC calls with complex objects...")
        
        latencies = []
        start = time.time()
        
        for i in range(count):
            t0 = time.time()
            try:
                # Call that returns a complex object (thread, file handle, etc)
                result = self.transport.invoke("get_complex_object", i)
                # Access properties on the netref
                if hasattr(result, '__class__'):
                    _ = result.__class__.__name__
            except Exception as e:
                log.debug(f"Call {i} failed: {e}")
            latencies.append((time.time() - t0) * 1000)
        
        total_time = time.time() - start
        
        return self._compute_result(
            name="RPyC Complex Objects",
            count=count,
            total_time=total_time,
            latencies=latencies
        )
    
    def benchmark_flight_small_batches(self, count: int = 1000, batch_size: int = 100) -> TestResult:
        """Benchmark Flight streaming with small batches."""
        log.info(f"Benchmarking {count} Flight batches of {batch_size} points...")
        
        import numpy as np
        
        latencies = []
        total_bytes = 0
        start = time.time()
        
        for i in range(count):
            # Generate test data
            data = np.random.rand(batch_size, 2)
            t0 = time.time()
            try:
                self.transport.stream_data("test_stream", data)
                total_bytes += data.nbytes
            except Exception as e:
                log.debug(f"Stream {i} failed: {e}")
            latencies.append((time.time() - t0) * 1000)
        
        total_time = time.time() - start
        data_mb = total_bytes / (1024 * 1024)
        bandwidth = data_mb / total_time if total_time > 0 else 0
        
        result = self._compute_result(
            name=f"Flight Small Batches ({batch_size} pts)",
            count=count,
            total_time=total_time,
            latencies=latencies
        )
        result.data_transferred_mb = data_mb
        result.bandwidth_mbps = bandwidth
        return result
    
    def benchmark_flight_large_batches(self, count: int = 100, batch_size: int = 10000) -> TestResult:
        """Benchmark Flight streaming with large batches."""
        log.info(f"Benchmarking {count} Flight batches of {batch_size} points...")
        
        import numpy as np
        
        latencies = []
        total_bytes = 0
        start = time.time()
        
        for i in range(count):
            # Generate test data
            data = np.random.rand(batch_size, 2)
            t0 = time.time()
            try:
                self.transport.stream_data("test_stream", data)
                total_bytes += data.nbytes
            except Exception as e:
                log.debug(f"Stream {i} failed: {e}")
            latencies.append((time.time() - t0) * 1000)
        
        total_time = time.time() - start
        data_mb = total_bytes / (1024 * 1024)
        bandwidth = data_mb / total_time if total_time > 0 else 0
        
        result = self._compute_result(
            name=f"Flight Large Batches ({batch_size} pts)",
            count=count,
            total_time=total_time,
            latencies=latencies
        )
        result.data_transferred_mb = data_mb
        result.bandwidth_mbps = bandwidth
        return result
    
    def benchmark_concurrent_operations(self, duration_s: int = 10) -> tuple[TestResult, TestResult]:
        """Benchmark RPyC and Flight operating concurrently."""
        log.info(f"Benchmarking concurrent operations for {duration_s} seconds...")
        
        import numpy as np
        
        # Shared state for threads
        rpyc_latencies = []
        flight_latencies = []
        rpyc_count = [0]
        flight_count = [0]
        flight_bytes = [0]
        stop_flag = threading.Event()
        
        def rpyc_worker():
            """Worker thread making RPyC calls."""
            while not stop_flag.is_set():
                t0 = time.time()
                try:
                    self.transport.invoke("test_method", rpyc_count[0])
                    rpyc_count[0] += 1
                    rpyc_latencies.append((time.time() - t0) * 1000)
                except Exception as e:
                    log.debug(f"RPyC call failed: {e}")
                time.sleep(0.001)  # Small delay to avoid overwhelming
        
        def flight_worker():
            """Worker thread streaming data via Flight."""
            batch_size = 1000
            while not stop_flag.is_set():
                data = np.random.rand(batch_size, 2)
                t0 = time.time()
                try:
                    self.transport.stream_data("test_stream", data)
                    flight_count[0] += 1
                    flight_bytes[0] += data.nbytes
                    flight_latencies.append((time.time() - t0) * 1000)
                except Exception as e:
                    log.debug(f"Flight stream failed: {e}")
                time.sleep(0.01)  # Batch frequency control
        
        # Start workers
        rpyc_thread = threading.Thread(target=rpyc_worker, daemon=True)
        flight_thread = threading.Thread(target=flight_worker, daemon=True)
        
        start = time.time()
        rpyc_thread.start()
        flight_thread.start()
        
        # Run for specified duration
        time.sleep(duration_s)
        stop_flag.set()
        
        # Wait for threads to finish
        rpyc_thread.join(timeout=2.0)
        flight_thread.join(timeout=2.0)
        
        total_time = time.time() - start
        
        # Compute results for both planes
        rpyc_result = self._compute_result(
            name="Concurrent RPyC Calls",
            count=rpyc_count[0],
            total_time=total_time,
            latencies=rpyc_latencies
        )
        
        flight_result = self._compute_result(
            name="Concurrent Flight Streams",
            count=flight_count[0],
            total_time=total_time,
            latencies=flight_latencies
        )
        flight_result.data_transferred_mb = flight_bytes[0] / (1024 * 1024)
        flight_result.bandwidth_mbps = flight_result.data_transferred_mb / total_time if total_time > 0 else 0
        
        return rpyc_result, flight_result
    
    def benchmark_mixed_workload(self, duration_s: int = 10) -> TestResult:
        """Benchmark realistic mixed workload: control + data streaming."""
        log.info(f"Benchmarking mixed workload for {duration_s} seconds...")
        
        import numpy as np
        
        operations = []
        latencies = []
        data_bytes = [0]
        stop_flag = threading.Event()
        
        def worker():
            """Worker performing mixed operations."""
            op_count = 0
            while not stop_flag.is_set():
                # Alternate between control and data operations
                if op_count % 10 == 0:
                    # Control operation (10% of operations)
                    t0 = time.time()
                    try:
                        self.transport.invoke("set_parameter", "freq", 1e9 + op_count)
                        operations.append("control")
                        latencies.append((time.time() - t0) * 1000)
                    except Exception as e:
                        log.debug(f"Control call failed: {e}")
                else:
                    # Data operation (90% of operations)
                    data = np.random.rand(500, 2)
                    t0 = time.time()
                    try:
                        self.transport.stream_data("measurement", data)
                        operations.append("data")
                        data_bytes[0] += data.nbytes
                        latencies.append((time.time() - t0) * 1000)
                    except Exception as e:
                        log.debug(f"Data stream failed: {e}")
                
                op_count += 1
                time.sleep(0.005)  # 200 ops/sec target
        
        # Start worker
        thread = threading.Thread(target=worker, daemon=True)
        start = time.time()
        thread.start()
        
        # Run for specified duration
        time.sleep(duration_s)
        stop_flag.set()
        thread.join(timeout=2.0)
        
        total_time = time.time() - start
        
        result = self._compute_result(
            name="Mixed Workload",
            count=len(operations),
            total_time=total_time,
            latencies=latencies
        )
        result.data_transferred_mb = data_bytes[0] / (1024 * 1024)
        result.bandwidth_mbps = result.data_transferred_mb / total_time if total_time > 0 else 0
        return result
    
    def _compute_result(self, name: str, count: int, total_time: float, 
                       latencies: List[float]) -> TestResult:
        """Compute test result statistics."""
        if not latencies:
            return TestResult(
                name=name,
                operation_count=0,
                total_time_s=total_time,
                throughput_ops_per_sec=0,
                latencies_ms=[],
                mean_latency_ms=0,
                median_latency_ms=0,
                p95_latency_ms=0,
                p99_latency_ms=0,
                stdev_latency_ms=0,
                error="No successful operations"
            )
        
        sorted_latencies = sorted(latencies)
        p95_idx = int(len(sorted_latencies) * 0.95)
        p99_idx = int(len(sorted_latencies) * 0.99)
        
        return TestResult(
            name=name,
            operation_count=count,
            total_time_s=total_time,
            throughput_ops_per_sec=count / total_time if total_time > 0 else 0,
            latencies_ms=latencies,
            mean_latency_ms=mean(latencies),
            median_latency_ms=median(latencies),
            p95_latency_ms=sorted_latencies[p95_idx] if p95_idx < len(sorted_latencies) else 0,
            p99_latency_ms=sorted_latencies[p99_idx] if p99_idx < len(sorted_latencies) else 0,
            stdev_latency_ms=stdev(latencies) if len(latencies) > 1 else 0
        )


def print_result(result: TestResult) -> None:
    """Print test result in a formatted way."""
    print(f"\n{'=' * 70}")
    print(f"Test: {result.name}")
    print(f"{'=' * 70}")
    
    if result.error:
        print(f"ERROR: {result.error}")
        return
    
    print(f"Operations:     {result.operation_count:,}")
    print(f"Total Time:     {result.total_time_s:.2f} s")
    print(f"Throughput:     {result.throughput_ops_per_sec:,.1f} ops/s")
    print()
    print(f"Latency Stats (ms):")
    print(f"  Mean:         {result.mean_latency_ms:.2f}")
    print(f"  Median:       {result.median_latency_ms:.2f}")
    print(f"  Std Dev:      {result.stdev_latency_ms:.2f}")
    print(f"  95th %ile:    {result.p95_latency_ms:.2f}")
    print(f"  99th %ile:    {result.p99_latency_ms:.2f}")
    
    if result.data_transferred_mb > 0:
        print()
        print(f"Data Transfer:")
        print(f"  Total:        {result.data_transferred_mb:.2f} MB")
        print(f"  Bandwidth:    {result.bandwidth_mbps:.2f} MB/s")


def main() -> int:
    """Main entry point."""
    parser = argparse.ArgumentParser(
        description="Dual-plane remote architecture throughput testing",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Test Modes:
  all               Run all tests (default)
  rpyc              RPyC control plane tests only
  flight            Arrow Flight data plane tests only
  concurrent        Concurrent operation test
  mixed             Mixed workload test
  quick             Quick test suite (reduced counts)

Examples:
  python remote_testing.py                    # Run all tests
  python remote_testing.py --mode rpyc        # RPyC tests only
  python remote_testing.py --mode quick       # Quick test
  python remote_testing.py --host 192.168.1.100  # Remote agent
        """
    )
    parser.add_argument("--host", default="localhost", help="Agent hostname (default: localhost)")
    parser.add_argument("--rpyc-port", type=int, default=18861, help="RPyC port (default: 18861)")
    parser.add_argument("--flight-port", type=int, default=8815, help="Flight port (default: 8815)")
    parser.add_argument("--mode", default="all", 
                       choices=["all", "rpyc", "flight", "concurrent", "mixed", "quick"],
                       help="Test mode to run")
    parser.add_argument("--log-level", default="INFO", 
                       choices=["DEBUG", "INFO", "WARNING", "ERROR"],
                       help="Logging level")
    args = parser.parse_args()
    
    # Setup logging
    logging.basicConfig(
        level=getattr(logging, args.log_level),
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s"
    )
    
    # Create harness and connect
    harness = BenchmarkHarness(args.host, args.rpyc_port, args.flight_port)
    
    if not harness.setup():
        log.error("Failed to connect to agent. Make sure the agent is running:")
        log.error(f"  python -m instrctl.core.remote_agent --host 0.0.0.0 --port {args.flight_port}")
        return 1
    
    try:
        results = []
        
        # Determine which tests to run
        mode = args.mode
        
        if mode in ("all", "rpyc", "quick"):
            # RPyC tests
            count = 100 if mode == "quick" else 1000
            results.append(harness.benchmark_rpyc_simple_calls(count))
            
            count = 50 if mode == "quick" else 500
            results.append(harness.benchmark_rpyc_complex_objects(count))
        
        if mode in ("all", "flight", "quick"):
            # Flight tests
            count = 100 if mode == "quick" else 1000
            results.append(harness.benchmark_flight_small_batches(count, 100))
            
            count = 10 if mode == "quick" else 100
            results.append(harness.benchmark_flight_large_batches(count, 10000))
        
        if mode in ("all", "concurrent", "quick"):
            # Concurrent test
            duration = 5 if mode == "quick" else 10
            rpyc_result, flight_result = harness.benchmark_concurrent_operations(duration)
            results.extend([rpyc_result, flight_result])
        
        if mode in ("all", "mixed", "quick"):
            # Mixed workload test
            duration = 5 if mode == "quick" else 10
            results.append(harness.benchmark_mixed_workload(duration))
        
        # Print all results
        for result in results:
            print_result(result)
        
        # Summary
        print(f"\n{'=' * 70}")
        print("SUMMARY")
        print(f"{'=' * 70}")
        for result in results:
            if not result.error:
                print(f"{result.name:40s} {result.throughput_ops_per_sec:>12,.1f} ops/s")
        print()
        
    finally:
        harness.teardown()
    
    return 0


if __name__ == "__main__":
    sys.exit(main())
