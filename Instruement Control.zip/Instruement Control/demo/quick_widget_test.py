from __future__ import annotations

from PySide6 import QtWidgets
from instrctl.gui.widgets import SweepPlotWidget, MultiTracePlotWidget
from plugins.my_multi_device_plugin import MySpecAnDemo

app = QtWidgets.QApplication.instance() or QtWidgets.QApplication([])
inst = MySpecAnDemo(event_bus=None)

ui_sweep = {
    "interval_ms": 200,
    # rely on InstrumentTab injection fallback normally; here provide getter explicitly as name
    "getter": "get_sweep_points",
}

ui_multi = {
    "interval_ms": 150,
    "sources": [
        {"name": "Spectrum", "getter": "get_sweep_points", "mode": "sweep"},
        {"name": "Measure", "getter": "get_current_measure_points", "mode": "event"},
    ],
}

print("Constructing SweepPlotWidget...")
sw = SweepPlotWidget(instrument=inst, ui=ui_sweep)
print("SweepPlotWidget instance:", type(sw))

print("Constructing MultiTracePlotWidget...")
mt = MultiTracePlotWidget(instrument=inst, ui=ui_multi)
print("MultiTracePlotWidget instance:", type(mt))

print("OK")
