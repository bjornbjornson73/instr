from __future__ import annotations

"""
Minimal QtWebEngine smoketest independent of the app.

What it does:
- Sets conservative software-rendering flags for Qt/Chromium
- Starts a QApplication
- Initializes QtWebEngine if available
- Loads an inline HTML string into a QWebEngineView, prints 'INLINE_OK' when done
- Then navigates to https://example.com and prints 'URL_OK' if it loads
- Exits the app automatically

Run with your Python:
  py -m demo.webengine_smoketest
"""

import os
import sys
from pathlib import Path

def _prepare_env():
	"""Prepare conservative flags/env before importing PySide6.

	Supports selecting a scenario via WEBENGINE_SCENARIO env var:
	  - swiftshader (default)
	  - warp        (D3D WARP)
	  - d3d11       (ANGLE D3D11/hardware path)
	  - desktop     (desktop OpenGL)
	We respect preexisting use-angle/use-gl flags, so callers can override.
	"""
	scenario = os.environ.get("WEBENGINE_SCENARIO", "swiftshader").lower().strip()

	# Base safety flags applicable to all scenarios
	existing = os.environ.get("QTWEBENGINE_CHROMIUM_FLAGS", "").strip()
	base_flags = [
		"--disable-gpu",
		"--disable-gpu-compositing",
		"--disable-gpu-vsync",
		"--in-process-gpu",
		"--no-sandbox",
		"--disable-features=UseSkiaRenderer",
	]

	# Scenario-specific flags
	if scenario == "warp":
		scen = ["--use-angle=warp"]
		os.environ.setdefault("QT_ANGLE_PLATFORM", "warp")
		os.environ.setdefault("QT_OPENGL", "angle")
	elif scenario == "d3d11":
		scen = ["--use-angle=d3d11"]
		os.environ.setdefault("QT_OPENGL", "angle")
	elif scenario == "desktop":
		scen = ["--use-gl=desktop"]
		os.environ.setdefault("QT_OPENGL", "desktop")
	else:  # default swiftshader (full software)
		scen = ["--use-angle=swiftshader", "--use-gl=swiftshader"]
		os.environ.setdefault("QT_ANGLE_PLATFORM", "swiftshader")
		os.environ.setdefault("QT_OPENGL", "software")

	# Respect preexisting explicit choices
	has_use_angle = "use-angle=" in existing
	has_use_gl = "use-gl=" in existing
	scenario_flags: list[str] = []
	for f in scen:
		if f.startswith("--use-angle=") and has_use_angle:
			continue
		if f.startswith("--use-gl=") and has_use_gl:
			continue
		scenario_flags.append(f)

	merged = existing
	for extra in base_flags + scenario_flags:
		if extra and extra not in merged:
			merged = (merged + " " + extra).strip()
	os.environ["QTWEBENGINE_CHROMIUM_FLAGS"] = merged
	os.environ.setdefault("QTWEBENGINE_DISABLE_SANDBOX", "1")
	# Widgets app: prefer software RHI; harmless for desktop/angle paths
	# Do not force invalid RHI backend; let Qt choose or use flags via WEBENGINE_SCENARIO
	# Slightly reduce GPU feature usage
	os.environ.setdefault("QTWEBENGINE_DISABLE_GPU_THREAD", "1")
	# For logging clarity
	os.environ.setdefault("WEBENGINE_SCENARIO", scenario)


_prepare_env()

from PySide6 import QtCore, QtWidgets


def main() -> int:
	QtCore.QCoreApplication.setAttribute(QtCore.Qt.AA_UseSoftwareOpenGL, True)
	QtCore.QCoreApplication.setAttribute(QtCore.Qt.AA_ShareOpenGLContexts, True)
	# Fully software path requested above; attributes ensure software GL

	app = QtWidgets.QApplication.instance() or QtWidgets.QApplication([])

	# Announce scenario for debugging
	print(f"SCENARIO: {os.environ.get('WEBENGINE_SCENARIO','swiftshader')}\nFLAGS: {os.environ.get('QTWEBENGINE_CHROMIUM_FLAGS','')}")
	import PySide6 as _p6
	base = Path(_p6.__file__).parent
	res = base / "resources"
	locales = res / "qtwebengine_locales"
	proc = base / "QtWebEngineProcess.exe"
	os.environ.setdefault("QTWEBENGINE_RESOURCES_PATH", str(res))
	if locales.exists():
		os.environ.setdefault("QTWEBENGINE_LOCALES_PATH", str(locales))
	if proc.exists():
		os.environ.setdefault("QTWEBENGINEPROCESS_PATH", str(proc))

	# Import QtWebEngine
	try:
		from PySide6.QtWebEngineWidgets import QWebEngineView
	except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:
		print(f"NO_QTWEBENGINE: {type(e).__name__}: {e}")
		return 2
	from PySide6.QtWebEngineCore import QtWebEngine
	QtWebEngine.initialize()  # type: ignore[attr-defined]

	view = QWebEngineView()
	view.resize(800, 600)
	view.show()

	# Determine target URL (env or argv) for step 2
	import os as _os
	_target = _os.environ.get("WEBENGINE_TEST_URL") or (sys.argv[1] if len(sys.argv) > 1 else "https://example.com/")
	print(f"TARGET_URL: {_target}")

	# Step 1: inline HTML
	def on_inline_loaded(ok: bool):
		print("INLINE_OK" if ok else "INLINE_FAIL")
		# Step 2: navigate to example.com
		view.loadFinished.disconnect(on_inline_loaded)
		view.load(QtCore.QUrl(_target))
		view.loadFinished.connect(on_url_loaded)

	def on_url_loaded(ok: bool):
		print("URL_OK" if ok else "URL_FAIL")
		QtCore.QTimer.singleShot(300, app.quit)

	html = """
<!doctype html><html><body>
<div style='font:14px Consolas, monospace; color:#0b0;'>QtWebEngine smoketest inline content.</div>
</body></html>
"""
	view.setHtml(html)
	view.loadFinished.connect(on_inline_loaded)

	rc = app.exec()
	return rc


if __name__ == "__main__":
	sys.exit(main())

