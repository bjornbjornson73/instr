import os
import sys


def _set_safe_env():
    # Force Chromium/Qt to software paths to avoid GPU context failures
    flags = [
        "--disable-gpu",
        "--disable-gpu-compositing",
        "--disable-gpu-sandbox",
        "--in-process-gpu",
        "--no-sandbox",
        "--disable-features=VaapiVideoDecoder,UseSkiaRenderer",
        "--use-angle=swiftshader",
        "--use-gl=swiftshader",
        "--disable-gpu-vsync",
    ]
    # Prepend our flags so user flags can still append
    existing = os.environ.get("QTWEBENGINE_CHROMIUM_FLAGS", "").strip()
    joined = " ".join(flags + ([existing] if existing else []))
    os.environ["QTWEBENGINE_CHROMIUM_FLAGS"] = joined
    # Disable sandbox and prefer software GL
    os.environ.setdefault("QTWEBENGINE_DISABLE_SANDBOX", "1")
    os.environ.setdefault("QT_OPENGL", "software")
    # Widgets app, but set RHI backend to software to be extra safe
    # Avoid forcing invalid RHI backend; rely on WEBENGINE_SCENARIO flags
    # ANGLE hint (some builds respect this)
    os.environ.setdefault("QT_ANGLE_PLATFORM", "swiftshader")


def main():
    _set_safe_env()
    try:
        from PyQt6.QtCore import Qt, QTimer
        from PyQt6.QtWidgets import QApplication, QWidget, QVBoxLayout
        from PyQt6.QtWebEngineWidgets import QWebEngineView
        # Ensure software OpenGL is requested BEFORE app is created
        QApplication.setAttribute(Qt.ApplicationAttribute.AA_UseSoftwareOpenGL, True)
        QApplication.setAttribute(Qt.ApplicationAttribute.AA_ShareOpenGLContexts, True)
    except (AttributeError, RuntimeError, OSError, ValueError, TypeError) as e:# Import failure: PyQt6 or webengine not installed
        sys.stderr.write(f"IMPORT_ERROR: {e}\n")
        print("PYQT6_IMPORT_FAIL")
        sys.exit(2)

    app = QApplication(sys.argv)

    # Minimal window containing a single web view
    win = QWidget()
    layout = QVBoxLayout(win)
    view = QWebEngineView(win)
    layout.addWidget(view)
    win.resize(900, 700)
    win.setWindowTitle("PyQt6 WebEngine Smoketest")
    win.show()

    # Single-stage handler with state
    setattr(view, "_stage", "inline")

    def on_load_finished(ok: bool):
        stage = getattr(view, "_stage", "inline")
        if stage == "inline":
            print("INLINE_OK" if ok else "INLINE_FAIL")
            setattr(view, "_inline_ok", bool(ok))
            # Move to URL stage
            setattr(view, "_stage", "url")
            QTimer.singleShot(200, lambda: view.setUrl("https://example.com"))
        else:
            print("URL_OK" if ok else "URL_FAIL")
            inline_ok = getattr(view, "_inline_ok", False)
            code = 0 if (ok and inline_ok) else 1
            QTimer.singleShot(50, lambda: app.exit(code))

        view.loadFinished.connect(on_load_finished)

        # Kick off by loading inline HTML
        view.setHtml("""
        <!doctype html>
        <html>
          <head><meta charset=\"utf-8\"><title>Inline</title></head>
          <body>
            <h1>Inline works</h1>
            <p>If you can see this, INLINE_OK should print.</p>
          </body>
        </html>
    """)

    # Safety timeout: if nothing loads within N seconds, fail
    def on_timeout():
        print("TIMEOUT_FAIL")
        app.exit(1)

    QTimer.singleShot(20000, on_timeout)  # 20s timeout

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
