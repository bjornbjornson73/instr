# GUI Integration Examples

This directory contains examples demonstrating how to use and extend the InstrCtl GUI application.

## Overview

The InstrCtl GUI provides a powerful interface for:
- Real-time instrument control and monitoring
- Data visualization with customizable plots
- Remote instrument access via dual-plane architecture
- Session management for reproducible measurements
- Plugin integration for custom instruments

## Examples

### 01_basic_gui.py - Basic GUI Usage
**Difficulty:** Beginner

Demonstrates launching the InstrCtl GUI with local instruments.

**Features:**
- Starting the GUI application
- Connecting to local instrument backend
- Basic instrument management
- Real-time data visualization

**Usage:**
```bash
python 01_basic_gui.py
```

**What You'll Learn:**
- How to initialize the Qt application
- Creating and configuring MainWindow
- Connecting backend to GUI
- Basic GUI workflow

---

### 02_custom_widgets.py - Custom Plot Widgets
**Difficulty:** Intermediate

Shows how to create custom plot widgets with enhanced features.

**Features:**
- Custom spectrum analyzer widget with peak detection
- Waterfall display widget
- Signal averaging implementation
- Custom styling and markers
- Real-time data updates

**Usage:**
```bash
python 02_custom_widgets.py
```

**What You'll Learn:**
- Subclassing PlotWidget
- Adding custom controls
- Implementing data processing (averaging, peak detection)
- Creating waterfall displays
- Timer-based updates

**Key Classes:**
- `CustomSpectrumWidget` - Enhanced spectrum display
- `CustomWaterfallWidget` - Time-scrolling spectrogram
- `CustomWidgetDemo` - Demo application window

---

### 03_gui_with_remote.py - Remote Instrument GUI
**Difficulty:** Intermediate

Demonstrates connecting the GUI to remote instruments using the dual-plane architecture.

**Features:**
- Remote backend configuration
- Dual-plane transport (RPyC + Arrow Flight)
- Connection error handling
- Performance monitoring
- Remote instrument control through GUI

**Prerequisites:**
Start the remote server first:
```bash
python examples/remote_access/03_server_setup.py
```

**Usage:**
```bash
python 03_gui_with_remote.py
```

**Advanced Usage:**
```bash
# Connect to custom host/port
python 03_gui_with_remote.py --host 192.168.1.100 --port 18861 --port-data 8815
```

**What You'll Learn:**
- Configuring RemoteInstrumentProxy for GUI
- Command line argument parsing
- Connection error handling with dialogs
- Remote data visualization
- Network troubleshooting

---

### 04_session_management.py - Session Save/Load
**Difficulty:** Intermediate

Shows how to save and load instrument configurations and measurement sessions.

**Features:**
- Session persistence to JSON files
- Instrument configuration save/restore
- Session metadata and timestamps
- File dialog integration
- Session management best practices

**Usage:**
```bash
python 04_session_management.py
```

**What You'll Learn:**
- Creating session data structures
- JSON serialization of configurations
- File dialogs (QFileDialog)
- Session manager implementation
- Configuration extraction from instruments

**Session File Format:**
```json
{
  "version": "1.0",
  "timestamp": "2025-01-08T12:34:56",
  "instruments": [
    {
      "class": "SpectrumAnalyzer",
      "name": "Spectrum Analyzer 1",
      "config": {
        "center_frequency": 1.5e9,
        "span": 100e6,
        "rbw": 1e6
      }
    }
  ]
}
```

## Prerequisites

All examples require:
- Python 3.8 or higher
- PySide6 (Qt for Python)
- pyqtgraph (plotting library)
- InstrCtl package installed

Install dependencies:
```bash
pip install PySide6 pyqtgraph instrctl
```

## Qt and GUI Notes

### PySide6 vs PyQt6
The examples use PySide6 (official Qt bindings), but can be adapted for PyQt6 with minimal changes:
- Change imports from `PySide6` to `PyQt6`
- `app.exec()` becomes `app.exec_()` in PyQt5

### Running in Headless Environments
For automated testing or CI/CD, set the QT_QPA_PLATFORM environment variable:
```bash
export QT_QPA_PLATFORM=offscreen  # Linux/Mac
$env:QT_QPA_PLATFORM="offscreen"  # PowerShell
```

### WebEngine Support
Some features (like embedded help) require QtWebEngine. If not available, the GUI will fall back to basic widgets.

## Extending the GUI

### Creating Custom Widgets

1. **Subclass PlotWidget:**
```python
from instrctl.gui.widgets import PlotWidget

class MyCustomWidget(PlotWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setTitle("My Custom Plot")
        # Add custom features
```

2. **Implement Update Methods:**
```python
def update_data(self, x, y):
    self.plot(x, y, pen='r')
```

3. **Add to Main Window:**
```python
window.add_custom_widget(MyCustomWidget())
```

### Adding Custom Actions

```python
from PySide6.QtGui import QAction

action = QAction("My Action", window)
action.triggered.connect(my_handler)
window.toolbar.addAction(action)
```

### Custom Instrument Panels

Create instrument-specific control panels:
```python
from PySide6.QtWidgets import QWidget, QFormLayout

class MyInstrumentPanel(QWidget):
    def __init__(self, instrument):
        super().__init__()
        self.instrument = instrument
        layout = QFormLayout()
        # Add controls
        self.setLayout(layout)
```

## Performance Considerations

### Data Update Rates
- Use QTimer for periodic updates (avoid tight loops)
- Limit plot update rate to ~30-60 Hz for smooth display
- Buffer data and update in batches

### Remote Instruments
- Enable dual-plane transport for high-throughput data
- Use Arrow Flight for continuous streaming
- Monitor network bandwidth usage

### Large Datasets
- Use downsampling for display (pyqtgraph.PlotItem.setDownsampling())
- Implement data decimation for zoom levels
- Use PlotDataItem.setClipToView() for performance

## Troubleshooting

### Qt Platform Plugin Error
**Error:** `could not find or load the Qt platform plugin "windows"`

**Solution:**
```bash
pip uninstall PySide6
pip install PySide6 --force-reinstall
```

### Import Errors
**Error:** `ImportError: cannot import name 'MainWindow'`

**Solution:**
Ensure InstrCtl is installed and in PYTHONPATH:
```bash
pip install -e .
# or
export PYTHONPATH=/path/to/instrctl/src:$PYTHONPATH
```

### Display Issues
**Problem:** Plots not updating or flickering

**Solution:**
- Check update rate (should be < 60 Hz)
- Disable vsync if needed
- Use QTimer instead of tight loops

### Remote Connection Failures
**Problem:** Cannot connect to remote server

**Solution:**
1. Verify server is running
2. Check firewall settings
3. Test connectivity: `telnet host port`
4. Review server logs for errors

## Additional Resources

- [PySide6 Documentation](https://doc.qt.io/qtforpython/)
- [PyQtGraph Documentation](https://pyqtgraph.readthedocs.io/)
- [InstrCtl Core Examples](../basic_usage/README.md)
- [Remote Access Examples](../remote_access/README.md)

## Next Steps

After mastering these examples:
1. Create custom instrument panels for your hardware
2. Implement advanced data processing widgets
3. Build multi-instrument synchronized displays
4. Add automation and scripting capabilities
5. Integrate with measurement databases

## Contributing

Have an interesting GUI example? Contributions welcome!
- Fork the repository
- Add your example with documentation
- Submit a pull request
