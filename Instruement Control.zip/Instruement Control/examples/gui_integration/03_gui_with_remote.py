"""
GUI with Remote Instruments - Connecting to Remote Backend

This example demonstrates using the GUI with remote instruments
connected via the dual-plane architecture (RPyC + Arrow Flight).

The example shows:
- Launching GUI connected to remote backend
- Configuring RemoteInstrumentProxy for GUI use
- Monitoring remote instrument performance
- Handling connection errors gracefully

Prerequisites:
    1. Start the remote server first:
       python examples/remote_access/03_server_setup.py
    
    2. Then run this GUI client:
       python 03_gui_with_remote.py

Usage:
    python 03_gui_with_remote.py [--host HOST] [--port PORT]
"""

import sys
import argparse
from PySide6.QtWidgets import QApplication, QMessageBox
from instrctl.gui.app import MainWindow
from instrctl import InstrumentBackend
from instrctl.core.remote import RemoteInstrumentProxy, RemoteConfig


def parse_args():
    """Parse command line arguments"""
    parser = argparse.ArgumentParser(description="InstrCtl GUI with Remote Instruments")
    parser.add_argument("--host", default="localhost", help="Remote server hostname (default: localhost)")
    parser.add_argument("--port", type=int, default=18861, help="Remote control port (default: 18861)")
    parser.add_argument("--port-data", type=int, default=8815, help="Remote data port (default: 8815)")
    return parser.parse_args()


def create_remote_backend(host, port, port_data):
    """
    Create a backend with remote instruments
    
    Args:
        host: Remote server hostname
        port: Control plane port (RPyC)
        port_data: Data plane port (Arrow Flight)
    
    Returns:
        InstrumentBackend configured with remote instruments
    """
    
    backend = InstrumentBackend()
    
    # Create remote configuration
    config = RemoteConfig(
        host=host,
        port=port,
        port_data=port_data,
        use_dual_transport=True  # Enable dual-plane transport
    )
    
    print(f"Connecting to remote server at {host}:{port} (control) and {host}:{port_data} (data)...")
    
    try:
        # Create remote proxy for SpectrumAnalyzer
        # Note: The actual instrument class must exist on the remote server
        remote_inst = RemoteInstrumentProxy(
            instrument_class="SpectrumAnalyzer",
            config=config
        )
        
        # Register with backend
        backend.register_instance(remote_inst)
        print(f"✓ Connected to remote SpectrumAnalyzer")
        
        return backend
        
    except Exception as e:
        print(f"❌ Failed to connect to remote server: {e}")
        raise


def show_connection_error(parent, host, port, error):
    """Show connection error dialog"""
    
    msg = QMessageBox(parent)
    msg.setIcon(QMessageBox.Critical)
    msg.setWindowTitle("Connection Error")
    msg.setText(f"Failed to connect to remote server at {host}:{port}")
    msg.setInformativeText(str(error))
    msg.setDetailedText(
        "Make sure the remote server is running:\n"
        "  python examples/remote_access/03_server_setup.py\n\n"
        "Check that:\n"
        "  - Server is running on the specified host\n"
        "  - Ports are not blocked by firewall\n"
        "  - Network connectivity is available"
    )
    msg.exec()


def main():
    """Launch GUI with remote instruments"""
    
    # Parse arguments
    args = parse_args()
    
    # Create Qt application
    app = QApplication(sys.argv)
    app.setApplicationName("InstrCtl GUI - Remote Mode")
    
    try:
        # Create backend with remote instruments
        backend = create_remote_backend(args.host, args.port, args.port_data)
        
        # Create main window
        window = MainWindow()
        window.backend = backend
        window.show()
        
        print("\n✓ GUI launched with remote instruments")
        print("\nRemote Connection Info:")
        print(f"  Host: {args.host}")
        print(f"  Control Port: {args.port}")
        print(f"  Data Port: {args.port_data}")
        print("\nGUI Features:")
        print("  - View remote instrument data in real-time")
        print("  - Configure remote instruments through GUI")
        print("  - Monitor connection status in status bar")
        print("  - Data transfer via high-speed Arrow Flight")
        
        # Run application
        sys.exit(app.exec())
        
    except Exception as e:
        # Show error dialog if GUI is initialized
        if 'window' in locals():
            show_connection_error(window, args.host, args.port, e)
        
        print(f"\n❌ Failed to start GUI: {e}")
        print("\nTroubleshooting:")
        print("  1. Start the remote server first:")
        print("     python examples/remote_access/03_server_setup.py")
        print(f"  2. Check connectivity: telnet {args.host} {args.port}")
        print("  3. Check firewall settings")
        
        return 1


if __name__ == "__main__":
    sys.exit(main())
