"""
Session Management - Saving and Loading GUI Sessions

This example demonstrates how to save and load instrument configurations
and data acquisition sessions in the GUI.

Features shown:
- Saving instrument configurations to JSON
- Loading previous sessions
- Exporting data to various formats
- Session management best practices

Usage:
    python 04_session_management.py
"""

import sys
import json
import os
from datetime import datetime
from PySide6.QtWidgets import (QApplication, QMainWindow, QVBoxLayout, QWidget, 
                               QPushButton, QHBoxLayout, QFileDialog, QMessageBox,
                               QTextEdit, QLabel)
from PySide6.QtCore import QTimer
from instrctl import InstrumentBackend
from instrctl.gui.app import MainWindow


class SessionManager:
    """
    Manages saving and loading instrument sessions
    
    A session includes:
    - Instrument configurations
    - Acquisition settings
    - Plot configurations
    - Timestamps and metadata
    """
    
    def __init__(self, backend):
        self.backend = backend
        
    def save_session(self, filepath):
        """
        Save current session to file
        
        Args:
            filepath: Path to save session file (.json)
        
        Returns:
            True if successful, False otherwise
        """
        try:
            session_data = {
                'version': '1.0',
                'timestamp': datetime.now().isoformat(),
                'instruments': []
            }
            
            # Save instrument configurations
            for inst in self.backend.list_registered_instances():
                inst_data = {
                    'class': inst.__class__.__name__,
                    'name': inst.name,
                    'config': self._get_instrument_config(inst)
                }
                session_data['instruments'].append(inst_data)
            
            # Write to file
            with open(filepath, 'w') as f:
                json.dump(session_data, f, indent=2)
            
            print(f"✓ Session saved to {filepath}")
            return True
            
        except Exception as e:
            print(f"❌ Failed to save session: {e}")
            return False
    
    def load_session(self, filepath):
        """
        Load session from file
        
        Args:
            filepath: Path to session file (.json)
        
        Returns:
            True if successful, False otherwise
        """
        try:
            with open(filepath, 'r') as f:
                session_data = json.load(f)
            
            print(f"Loading session from {session_data['timestamp']}")
            
            # Clear existing instruments
            self.backend.unregister_all()
            
            # Load instruments
            for inst_data in session_data['instruments']:
                print(f"  Loading {inst_data['class']}: {inst_data['name']}")
                
                # Create instrument
                inst_class = inst_data['class']
                self.backend.discover_and_register(inst_class)
                
                # Get instance and apply configuration
                inst = self.backend.get_registered_instance(inst_class)
                if inst:
                    self._set_instrument_config(inst, inst_data['config'])
            
            print(f"✓ Session loaded from {filepath}")
            return True
            
        except Exception as e:
            print(f"❌ Failed to load session: {e}")
            return False
    
    def _get_instrument_config(self, instrument):
        """Extract configuration from instrument"""
        config = {}
        
        # Try to get common configuration attributes
        attrs_to_save = [
            'center_frequency', 'span', 'rbw', 'vbw',
            'reference_level', 'attenuation'
        ]
        
        for attr in attrs_to_save:
            if hasattr(instrument, attr):
                config[attr] = getattr(instrument, attr)
        
        return config
    
    def _set_instrument_config(self, instrument, config):
        """Apply configuration to instrument"""
        for key, value in config.items():
            if hasattr(instrument, f'set_{key}'):
                try:
                    setter = getattr(instrument, f'set_{key}')
                    setter(value)
                except Exception as e:
                    print(f"  Warning: Could not set {key}: {e}")


class SessionManagerWindow(QMainWindow):
    """Demo window with session management controls"""
    
    def __init__(self):
        super().__init__()
        
        self.setWindowTitle("Session Management Demo")
        self.resize(800, 600)
        
        # Create backend
        self.backend = InstrumentBackend()
        self.session_mgr = SessionManager(self.backend)
        
        # Setup UI
        self._setup_ui()
        
        # Current session file
        self.current_session_file = None
        
    def _setup_ui(self):
        """Setup user interface"""
        
        central = QWidget()
        self.setCentralWidget(central)
        layout = QVBoxLayout(central)
        
        # Title
        title = QLabel("<h2>Session Management Demo</h2>")
        layout.addWidget(title)
        
        # Info text
        self.info_text = QTextEdit()
        self.info_text.setReadOnly(True)
        self.info_text.setMaximumHeight(200)
        layout.addWidget(self.info_text)
        
        # Button layout
        btn_layout = QHBoxLayout()
        
        # Load session
        load_btn = QPushButton("Load Session")
        load_btn.clicked.connect(self.load_session)
        btn_layout.addWidget(load_btn)
        
        # Save session
        save_btn = QPushButton("Save Session")
        save_btn.clicked.connect(self.save_session)
        btn_layout.addWidget(save_btn)
        
        # Save As
        save_as_btn = QPushButton("Save As...")
        save_as_btn.clicked.connect(self.save_session_as)
        btn_layout.addWidget(save_as_btn)
        
        # Launch GUI
        gui_btn = QPushButton("Launch Main GUI")
        gui_btn.clicked.connect(self.launch_gui)
        btn_layout.addWidget(gui_btn)
        
        layout.addLayout(btn_layout)
        
        # Update info
        self.update_info()
        
    def update_info(self):
        """Update information display"""
        
        info = []
        info.append("Session Management")
        info.append("=" * 60)
        
        if self.current_session_file:
            info.append(f"Current Session: {self.current_session_file}")
        else:
            info.append("Current Session: (none)")
        
        info.append("")
        info.append(f"Registered Instruments: {len(self.backend.list_registered_instances())}")
        
        for inst in self.backend.list_registered_instances():
            info.append(f"  - {inst.__class__.__name__}: {inst.name}")
        
        info.append("")
        info.append("Session files are saved in JSON format and include:")
        info.append("  - Instrument configurations")
        info.append("  - Acquisition settings")
        info.append("  - Timestamps and metadata")
        
        self.info_text.setPlainText("\n".join(info))
    
    def load_session(self):
        """Load session from file"""
        
        filepath, _ = QFileDialog.getOpenFileName(
            self,
            "Load Session",
            "",
            "Session Files (*.json)"
        )
        
        if filepath:
            if self.session_mgr.load_session(filepath):
                self.current_session_file = filepath
                self.update_info()
                QMessageBox.information(self, "Success", "Session loaded successfully")
            else:
                QMessageBox.critical(self, "Error", "Failed to load session")
    
    def save_session(self):
        """Save session to current file"""
        
        if self.current_session_file:
            if self.session_mgr.save_session(self.current_session_file):
                QMessageBox.information(self, "Success", "Session saved successfully")
            else:
                QMessageBox.critical(self, "Error", "Failed to save session")
        else:
            self.save_session_as()
    
    def save_session_as(self):
        """Save session to new file"""
        
        filepath, _ = QFileDialog.getSaveFileName(
            self,
            "Save Session As",
            f"session_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
            "Session Files (*.json)"
        )
        
        if filepath:
            if self.session_mgr.save_session(filepath):
                self.current_session_file = filepath
                self.update_info()
                QMessageBox.information(self, "Success", "Session saved successfully")
            else:
                QMessageBox.critical(self, "Error", "Failed to save session")
    
    def launch_gui(self):
        """Launch the main GUI with current backend"""
        
        self.main_window = MainWindow()
        self.main_window.backend = self.backend
        self.main_window.show()
        
        print("✓ Main GUI launched with current backend")


def main():
    """Run the session management demo"""
    
    app = QApplication(sys.argv)
    app.setApplicationName("InstrCtl Session Manager")
    
    window = SessionManagerWindow()
    window.show()
    
    print("\nSession Management Demo")
    print("=" * 60)
    print("This demo shows:")
    print("  - Saving instrument configurations to JSON")
    print("  - Loading previous sessions")
    print("  - Session metadata and timestamps")
    print("  - Integration with main GUI")
    print("\nUse the buttons to:")
    print("  1. Create/load instruments")
    print("  2. Save session configurations")
    print("  3. Launch main GUI with session")
    
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
