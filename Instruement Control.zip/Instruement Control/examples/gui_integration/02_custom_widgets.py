"""
Custom Widget Example - Creating Custom Plot Widgets

This example shows how to create custom plot widgets that can be
embedded in the InstrCtl GUI or used standalone.

The example demonstrates:
- Creating a custom PlotWidget subclass
- Adding custom controls and styling
- Integrating with the EventBus for data updates
- Standalone widget usage

Usage:
    python 02_custom_widgets.py
"""

import sys
import time
import numpy as np
from PySide6.QtWidgets import QApplication, QMainWindow, QVBoxLayout, QWidget, QPushButton, QHBoxLayout
from PySide6.QtCore import QTimer
from instrctl.gui.widgets import PlotWidget
from instrctl import InstrumentBackend


class CustomSpectrumWidget(PlotWidget):
    """
    Custom spectrum analyzer widget with enhanced features
    
    This widget extends the base PlotWidget to add:
    - Peak detection and markers
    - Frequency span controls
    - Averaging capabilities
    - Custom color schemes
    """
    
    def __init__(self, parent=None):
        super().__init__(parent)
        
        # Configure the plot
        self.setTitle("Custom Spectrum Analyzer")
        self.setLabel('left', 'Power', units='dBm')
        self.setLabel('bottom', 'Frequency', units='Hz')
        
        # Enable grid
        self.showGrid(x=True, y=True, alpha=0.3)
        
        # Custom styling - use a different color
        self.plot_item = self.plot(pen='g', width=2)
        
        # Peak marker
        self.peak_marker = self.plot([], [], symbol='o', symbolBrush='r', symbolSize=10)
        
        # Averaging buffer
        self.avg_buffer = []
        self.avg_count = 10
        
    def update_spectrum(self, frequencies, power):
        """Update the spectrum display with peak detection"""
        
        # Add to averaging buffer
        self.avg_buffer.append(power)
        if len(self.avg_buffer) > self.avg_count:
            self.avg_buffer.pop(0)
        
        # Calculate average
        avg_power = np.mean(self.avg_buffer, axis=0)
        
        # Update plot
        self.plot_item.setData(frequencies, avg_power)
        
        # Find and mark peak
        peak_idx = np.argmax(avg_power)
        peak_freq = frequencies[peak_idx]
        peak_power = avg_power[peak_idx]
        
        self.peak_marker.setData([peak_freq], [peak_power])
        
        # Update title with peak info
        self.setTitle(f"Custom Spectrum Analyzer - Peak: {peak_freq/1e6:.2f} MHz @ {peak_power:.1f} dBm")


class CustomWaterfallWidget(PlotWidget):
    """
    Custom waterfall display widget
    
    Shows spectrum data as a time-scrolling waterfall/spectrogram display.
    """
    
    def __init__(self, parent=None):
        super().__init__(parent)
        
        self.setTitle("Waterfall Display")
        self.setLabel('left', 'Time', units='s')
        self.setLabel('bottom', 'Frequency', units='Hz')
        
        # Waterfall data buffer
        self.waterfall_data = []
        self.max_history = 100
        
        # Image item for waterfall
        from pyqtgraph import ImageItem
        self.img_item = ImageItem()
        self.addItem(self.img_item)
        
    def update_waterfall(self, frequencies, power):
        """Add new spectrum line to waterfall"""
        
        self.waterfall_data.append(power)
        if len(self.waterfall_data) > self.max_history:
            self.waterfall_data.pop(0)
        
        # Update image
        data = np.array(self.waterfall_data)
        self.img_item.setImage(data.T, autoLevels=True)


class CustomWidgetDemo(QMainWindow):
    """Demo window showing custom widgets"""
    
    def __init__(self):
        super().__init__()
        
        self.setWindowTitle("Custom Widget Demo")
        self.resize(1200, 600)
        
        # Create central widget
        central = QWidget()
        self.setCentralWidget(central)
        
        # Layout
        layout = QVBoxLayout(central)
        
        # Create custom widgets
        self.spectrum_widget = CustomSpectrumWidget()
        self.waterfall_widget = CustomWaterfallWidget()
        
        layout.addWidget(self.spectrum_widget)
        layout.addWidget(self.waterfall_widget)
        
        # Control buttons
        btn_layout = QHBoxLayout()
        
        self.start_btn = QPushButton("Start")
        self.start_btn.clicked.connect(self.start_simulation)
        btn_layout.addWidget(self.start_btn)
        
        self.stop_btn = QPushButton("Stop")
        self.stop_btn.clicked.connect(self.stop_simulation)
        self.stop_btn.setEnabled(False)
        btn_layout.addWidget(self.stop_btn)
        
        layout.addLayout(btn_layout)
        
        # Update timer
        self.timer = QTimer()
        self.timer.timeout.connect(self.update_data)
        
        # Simulation parameters
        self.time = 0
        
    def start_simulation(self):
        """Start data simulation"""
        self.start_btn.setEnabled(False)
        self.stop_btn.setEnabled(True)
        self.timer.start(100)  # Update every 100ms
        print("Simulation started")
        
    def stop_simulation(self):
        """Stop data simulation"""
        self.timer.stop()
        self.start_btn.setEnabled(True)
        self.stop_btn.setEnabled(False)
        print("Simulation stopped")
        
    def update_data(self):
        """Generate and display simulated data"""
        
        # Generate simulated spectrum
        frequencies = np.linspace(1e9, 2e9, 1000)  # 1-2 GHz
        
        # Base noise floor
        power = -80 + np.random.randn(1000) * 2
        
        # Add a drifting signal
        signal_freq = 1.5e9 + 0.1e9 * np.sin(self.time * 0.1)
        signal_power = -30
        
        # Find closest frequency bin
        freq_idx = np.argmin(np.abs(frequencies - signal_freq))
        power[freq_idx-5:freq_idx+5] += signal_power + 80  # Add signal above noise
        
        # Update widgets
        self.spectrum_widget.update_spectrum(frequencies, power)
        self.waterfall_widget.update_waterfall(frequencies, power)
        
        self.time += 0.1


def main():
    """Run the custom widget demo"""
    
    app = QApplication(sys.argv)
    
    window = CustomWidgetDemo()
    window.show()
    
    print("\nCustom Widget Demo")
    print("=" * 60)
    print("This demo shows:")
    print("  - Custom spectrum widget with peak detection")
    print("  - Waterfall display widget")
    print("  - Signal averaging")
    print("  - Custom styling and markers")
    print("\nClick 'Start' to begin simulation")
    
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
