"""
Basic GUI Example - Launching the InstrCtl GUI Application

This example demonstrates how to launch the InstrCtl GUI application
with local instruments and basic usage patterns.

The GUI provides:
- Instrument management (add/remove)
- Real-time data visualization
- Configuration controls
- Data export capabilities

Usage:
    python 01_basic_gui.py
"""

import sys
from PySide6.QtWidgets import QApplication
from instrctl.gui.app import MainWindow
from instrctl import InstrumentBackend


def main():
    """Launch the GUI with a simple instrument setup"""
    
    # Create the Qt application
    app = QApplication(sys.argv)
    app.setApplicationName("InstrCtl GUI Example")
    
    # Create the backend with instruments
    print("Creating instrument backend...")
    backend = InstrumentBackend()
    
    # Register a spectrum analyzer (if available in plugins)
    try:
        backend.discover_and_register("SpectrumAnalyzer")
        print("✓ Registered SpectrumAnalyzer")
    except Exception as e:
        print(f"⚠ Could not register SpectrumAnalyzer: {e}")
    
    # Create the main window
    print("Creating main window...")
    window = MainWindow()
    
    # Connect the backend to the window
    window.backend = backend
    
    # Show the window
    window.show()
    print("✓ GUI launched successfully")
    
    print("\nGUI Features:")
    print("  - Add instruments using the toolbar")
    print("  - Configure instrument parameters in the side panel")
    print("  - View real-time data in the plot area")
    print("  - Export data using File > Export")
    
    # Run the application
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
