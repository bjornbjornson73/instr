#!/usr/bin/env python3
"""
Example 3: EventBus Communication

This example demonstrates:
- Using EventBus for loosely coupled communication
- Publishing and subscribing to events
- Event-driven architecture patterns
- Instrument state change notifications

Run: python 03_event_bus.py
"""

import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent / "src"))

from instrctl.core import InstrumentFactory, EventBus
from instrctl.core.plugins import discover_all

discover_all()

print("=== EventBus Communication Example ===\n")

# Create an event bus
bus = EventBus()

# Define event handlers
def on_frequency_change(event_data):
    """Called when frequency changes"""
    print(f"📡 Frequency changed: {event_data['frequency']/1e9:.2f} GHz")

def on_power_change(event_data):
    """Called when power level changes"""
    print(f"⚡ Power changed: {event_data['power']:.1f} dBm")

def on_sweep_complete(event_data):
    """Called when a sweep completes"""
    points = event_data.get('points', 0)
    print(f"✓ Sweep complete: {points} points acquired")

def on_any_event(event_data):
    """Catch-all handler for logging"""
    event_type = event_data.get('type', 'unknown')
    print(f"  [LOG] Event: {event_type}")

# Subscribe to specific events
print("Setting up event handlers...")
bus.subscribe("frequency_changed", on_frequency_change)
bus.subscribe("power_changed", on_power_change)
bus.subscribe("sweep_complete", on_sweep_complete)
bus.subscribe("*", on_any_event)  # Subscribe to all events
print("✓ Handlers registered\n")

# Create an instrument with the event bus
print("Creating instrument with EventBus...")
spec_analyzer = InstrumentFactory.create(
    kind="SpectrumAnalyzer",
    model="FullDemo",
    event_bus=bus
)
print(f"Created: {spec_analyzer}\n")

# Simulate instrument operations that trigger events
print("=== Simulating Instrument Operations ===\n")

# Change frequency (triggers event)
print("Setting frequency to 2.4 GHz...")
bus.publish({
    'type': 'frequency_changed',
    'frequency': 2.4e9,
    'source': 'SpectrumAnalyzer'
})
time.sleep(0.5)

# Change power (triggers event)
print("\nSetting power to -20 dBm...")
bus.publish({
    'type': 'power_changed',
    'power': -20.0,
    'source': 'SpectrumAnalyzer'
})
time.sleep(0.5)

# Start sweep and simulate completion
print("\nStarting sweep...")
spec_analyzer.start_sweep()
time.sleep(0.5)

# Simulate sweep completion
print("Completing sweep...")
bus.publish({
    'type': 'sweep_complete',
    'points': 512,
    'duration_ms': 45,
    'source': 'SpectrumAnalyzer'
})
time.sleep(0.5)

# Custom application event
print("\nPublishing custom event...")
bus.publish({
    'type': 'custom_event',
    'message': 'This is a custom application event',
    'timestamp': time.time()
})
time.sleep(0.5)

# Unsubscribe from events
print("\n=== Cleanup ===")
print("Unsubscribing handlers...")
bus.unsubscribe("frequency_changed", on_frequency_change)
bus.unsubscribe("power_changed", on_power_change)
bus.unsubscribe("sweep_complete", on_sweep_complete)
bus.unsubscribe("*", on_any_event)
print("✓ Handlers unsubscribed")

# Stop instrument
spec_analyzer.stop_sweep()
print("✓ Instrument stopped")

print("\n=== EventBus Pattern Benefits ===")
print("✓ Loosely coupled components")
print("✓ Easy to add new event handlers")
print("✓ Instruments don't need to know about subscribers")
print("✓ Supports multiple handlers per event")
print("✓ Wildcard subscriptions for logging/debugging")

print("\nExample completed successfully!")
