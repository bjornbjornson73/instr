#!/usr/bin/env python3
"""
Example 4: Continuous Data Streaming

This example demonstrates:
- High-performance continuous data streaming
- Real-time data processing
- Statistics calculation
- Data buffering patterns

Run: python 04_data_streaming.py
"""

import sys
import time
import statistics
from pathlib import Path
from collections import deque

sys.path.insert(0, str(Path(__file__).parent.parent.parent / "src"))

from instrctl.core import InstrumentFactory
from instrctl.core.plugins import discover_all

discover_all()

print("=== Continuous Data Streaming Example ===\n")

# Create spectrum analyzer
spec_analyzer = InstrumentFactory.create("SpectrumAnalyzer", "FullDemo")
spec_analyzer.center_freq = 2.45e9
spec_analyzer.span = 100e6
spec_analyzer.rbw = 1e6

print(f"Instrument: {spec_analyzer}")
print(f"Configuration:")
print(f"  Center: {spec_analyzer.center_freq/1e9:.2f} GHz")
print(f"  Span: {spec_analyzer.span/1e6:.0f} MHz")
print(f"  RBW: {spec_analyzer.rbw/1e6:.0f} MHz\n")

# Data buffer for moving statistics
buffer_size = 100
data_buffer = deque(maxlen=buffer_size)

# Statistics tracking
stats = {
    'samples': 0,
    'total_points': 0,
    'min_value': float('inf'),
    'max_value': float('-inf'),
    'sum': 0.0,
}

def update_statistics(data):
    """Update running statistics with new data"""
    stats['samples'] += 1
    stats['total_points'] += len(data)
    
    for value in data:
        data_buffer.append(value)
        stats['min_value'] = min(stats['min_value'], value)
        stats['max_value'] = max(stats['max_value'], value)
        stats['sum'] += value

def print_statistics():
    """Print current statistics"""
    if stats['samples'] == 0:
        return
    
    avg = stats['sum'] / stats['total_points']
    
    # Moving average from buffer
    moving_avg = statistics.mean(data_buffer) if data_buffer else 0.0
    moving_std = statistics.stdev(data_buffer) if len(data_buffer) > 1 else 0.0
    
    print(f"Samples: {stats['samples']:>5} | "
          f"Points: {stats['total_points']:>7} | "
          f"Avg: {avg:>7.2f} dBm | "
          f"Min: {stats['min_value']:>7.2f} dBm | "
          f"Max: {stats['max_value']:>7.2f} dBm | "
          f"MA: {moving_avg:>7.2f} | "
          f"Std: {moving_std:>6.2f}")

# Start streaming
print("=== Starting Continuous Streaming ===")
spec_analyzer.start_sweep()
print(f"Duration: 10 seconds")
print(f"Buffer size: {buffer_size} points\n")

start_time = time.time()
last_print = start_time
print_interval = 1.0  # Print every second

try:
    while time.time() - start_time < 10.0:
        # Get data
        data = spec_analyzer.get_sweep_points()
        
        if data and len(data) > 0:
            # Update statistics
            update_statistics(data)
            
            # Print statistics at regular intervals
            current_time = time.time()
            if current_time - last_print >= print_interval:
                print_statistics()
                last_print = current_time
        
        time.sleep(0.001)  # Minimal delay for high throughput

except KeyboardInterrupt:
    print("\n\nInterrupted by user")

# Final statistics
elapsed = time.time() - start_time
spec_analyzer.stop_sweep()

print("\n=== Final Statistics ===")
print(f"Duration: {elapsed:.2f} seconds")
print(f"Total samples: {stats['samples']}")
print(f"Total points: {stats['total_points']}")
print(f"Throughput: {stats['samples']/elapsed:.1f} samples/sec")
print(f"Data rate: {stats['total_points']/elapsed:.1f} points/sec")

if stats['total_points'] > 0:
    avg = stats['sum'] / stats['total_points']
    print(f"\nData Statistics:")
    print(f"  Average: {avg:.2f} dBm")
    print(f"  Minimum: {stats['min_value']:.2f} dBm")
    print(f"  Maximum: {stats['max_value']:.2f} dBm")
    print(f"  Range: {stats['max_value'] - stats['min_value']:.2f} dB")

if len(data_buffer) > 1:
    print(f"\nMoving Window ({buffer_size} points):")
    print(f"  Mean: {statistics.mean(data_buffer):.2f} dBm")
    print(f"  Std Dev: {statistics.stdev(data_buffer):.2f} dB")
    print(f"  Median: {statistics.median(data_buffer):.2f} dBm")

print("\nExample completed successfully!")
