#!/usr/bin/env python3
"""
Example 1: Basic Local Instrument Usage

This example demonstrates:
- Creating a local instrument instance
- Configuring instrument parameters
- Starting data acquisition
- Reading data in a loop
- Stopping and cleanup

Run: python 01_local_instrument.py
"""

import sys
import time
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent.parent / "src"))

from instrctl.core import InstrumentFactory, InstrumentRegistry
from instrctl.core.plugins import discover_all

# Discover available instruments from plugins
print("Discovering plugins...")
discover_all()

# List available instruments
print("\nAvailable instruments:")
for kind in InstrumentRegistry.list_kinds():
    models = InstrumentRegistry.list_models(kind)
    print(f"  {kind}: {', '.join(models)}")

# Create a spectrum analyzer
print("\n=== Creating Spectrum Analyzer ===")
spec_analyzer = InstrumentFactory.create(
    kind="SpectrumAnalyzer",
    model="FullDemo"
)

print(f"Created: {spec_analyzer}")
print(f"Features: {spec_analyzer.features()}")

# Configure the instrument
print("\n=== Configuring Instrument ===")
spec_analyzer.center_freq = 2.45e9  # 2.45 GHz
spec_analyzer.span = 100e6          # 100 MHz
spec_analyzer.rbw = 1e6             # 1 MHz resolution bandwidth

print(f"Center Frequency: {spec_analyzer.center_freq / 1e9:.2f} GHz")
print(f"Span: {spec_analyzer.span / 1e6:.0f} MHz")
print(f"RBW: {spec_analyzer.rbw / 1e6:.0f} MHz")

# Start data acquisition
print("\n=== Starting Data Acquisition ===")
spec_analyzer.start_sweep()
print("Sweep started")

# Read data for 5 seconds
print("\n=== Reading Data ===")
start_time = time.time()
sample_count = 0

try:
    while time.time() - start_time < 5.0:
        # Get sweep data
        data = spec_analyzer.get_sweep_points()
        
        if data and len(data) > 0:
            sample_count += 1
            
            # Print every 10th sample
            if sample_count % 10 == 0:
                avg_power = sum(data) / len(data)
                max_power = max(data)
                min_power = min(data)
                
                print(f"Sample {sample_count}: {len(data)} points, "
                      f"Avg: {avg_power:.2f} dBm, "
                      f"Max: {max_power:.2f} dBm, "
                      f"Min: {min_power:.2f} dBm")
        
        time.sleep(0.01)  # Small delay

except KeyboardInterrupt:
    print("\nInterrupted by user")

# Stop and cleanup
print("\n=== Cleanup ===")
spec_analyzer.stop_sweep()
print("Sweep stopped")

print(f"\nTotal samples collected: {sample_count}")
print("Example completed successfully!")
