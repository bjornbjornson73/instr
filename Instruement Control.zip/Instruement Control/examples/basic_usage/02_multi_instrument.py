#!/usr/bin/env python3
"""
Example 2: Multi-Instrument Backend

This example demonstrates:
- Using MultiInstrument for shared resource management
- Creating multiple instrument instances
- Concurrent data acquisition from multiple instruments
- Preventing resource conflicts

Run: python 02_multi_instrument.py
"""

import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent / "src"))

from instrctl.core import InstrumentFactory, MultiInstrument
from instrctl.core.plugins import discover_all

discover_all()

print("=== Multi-Instrument Backend Example ===\n")

# Create a multi-instrument backend (manages shared resources)
print("Creating multi-instrument backend...")
multi = MultiInstrument()

# Add multiple instruments of different types
print("\nAdding instruments:")

# Add 2 spectrum analyzers
sa1 = InstrumentFactory.create("SpectrumAnalyzer", "FullDemo")
sa2 = InstrumentFactory.create("SpectrumAnalyzer", "FullDemo")

multi.add_instrument("SA1", sa1)
multi.add_instrument("SA2", sa2)
print(f"  ✓ Added SA1: {sa1}")
print(f"  ✓ Added SA2: {sa2}")

# Add a signal generator
sg = InstrumentFactory.create("VectorSignalGenerator", "FullDemo")
multi.add_instrument("SigGen", sg)
print(f"  ✓ Added SigGen: {sg}")

# List all instruments
print(f"\nTotal instruments: {len(multi.list_instruments())}")
for name in multi.list_instruments():
    print(f"  - {name}")

# Configure instruments
print("\n=== Configuring Instruments ===")
sa1.center_freq = 2.4e9
sa1.span = 50e6
print(f"SA1: {sa1.center_freq/1e9:.1f} GHz ± {sa1.span/2e6:.0f} MHz")

sa2.center_freq = 5.0e9
sa2.span = 100e6
print(f"SA2: {sa2.center_freq/1e9:.1f} GHz ± {sa2.span/2e6:.0f} MHz")

sg.frequency = 2.45e9
sg.power = -10
print(f"SigGen: {sg.frequency/1e9:.2f} GHz @ {sg.power:.0f} dBm")

# Start all instruments
print("\n=== Starting Data Acquisition ===")
sa1.start_sweep()
sa2.start_sweep()
sg.start_generation()
print("All instruments started")

# Collect data from all instruments
print("\n=== Collecting Data ===")
start_time = time.time()
duration = 3.0

sa1_samples = 0
sa2_samples = 0
sg_samples = 0

try:
    while time.time() - start_time < duration:
        # Read from all instruments
        if data1 := sa1.get_sweep_points():
            sa1_samples += 1
        
        if data2 := sa2.get_sweep_points():
            sa2_samples += 1
        
        if data3 := sg.get_evm_points():
            sg_samples += 1
        
        # Print status every second
        elapsed = time.time() - start_time
        if int(elapsed) != int(elapsed - 0.05):  # Approximately once per second
            print(f"[{elapsed:.1f}s] SA1: {sa1_samples}, SA2: {sa2_samples}, SigGen: {sg_samples}")
        
        time.sleep(0.01)

except KeyboardInterrupt:
    print("\nInterrupted by user")

# Stop all instruments
print("\n=== Stopping Instruments ===")
sa1.stop_sweep()
sa2.stop_sweep()
sg.stop_generation()
print("All instruments stopped")

# Summary
print("\n=== Summary ===")
print(f"SA1 samples: {sa1_samples}")
print(f"SA2 samples: {sa2_samples}")
print(f"SigGen samples: {sg_samples}")
print(f"Total samples: {sa1_samples + sa2_samples + sg_samples}")

# Remove instruments
multi.remove_instrument("SA1")
multi.remove_instrument("SA2")
multi.remove_instrument("SigGen")
print("\nAll instruments removed from backend")
print("Example completed successfully!")
