# InstrCtl Examples

This directory contains comprehensive examples demonstrating the various features of the InstrCtl instrument control framework.

## Directory Structure

```
examples/
├── README.md                    # This file
├── basic_usage/                 # Basic instrument usage examples
│   ├── 01_local_instrument.py   # Using local instruments
│   ├── 02_multi_instrument.py   # Multi-instrument backend
│   ├── 03_event_bus.py          # EventBus patterns
│   └── 04_data_streaming.py    # Continuous data streaming
├── remote_access/               # Remote instrument examples
│   ├── 01_remote_client.py      # Basic remote client
│   ├── 02_dual_plane.py         # Dual-plane architecture
│   ├── 03_server_setup.py       # Setting up a remote server
│   └── 04_multi_client.py       # Multiple concurrent clients
├── custom_plugin/               # Example pip-installable plugin
│   ├── README.md                # Plugin documentation
│   ├── setup.py                 # Pip installation config
│   ├── pyproject.toml           # Modern Python packaging
│   └── my_instruments/          # Plugin package
│       ├── __init__.py
│       ├── oscilloscope.py      # Custom oscilloscope
│       └── power_supply.py      # Custom power supply
└── gui_integration/             # GUI usage examples
    ├── README.md                # GUI documentation
    ├── 01_basic_gui.py          # Launching the GUI
    ├── 02_custom_widgets.py     # Creating custom widgets
    ├── 03_gui_with_remote.py    # GUI with remote instruments
    └── 04_session_management.py # Saving/loading sessions
```

## Quick Start

### 1. Local Instrument Usage
```bash
cd examples/basic_usage
python 01_local_instrument.py
```

### 2. Remote Access
```bash
# Terminal 1: Start server
cd examples/remote_access
python 03_server_setup.py

# Terminal 2: Run client
python 01_remote_client.py
```

### 3. Install Custom Plugin
```bash
cd examples/custom_plugin
pip install -e .
python test_plugin.py
```

## Prerequisites

Ensure InstrCtl is installed:
```bash
# From the project root
pip install -e .
```

## Features Demonstrated

### Basic Usage
- ✅ Creating and using local instruments
- ✅ Multi-instrument backend for shared resources
- ✅ EventBus for loosely coupled communication
- ✅ Continuous data streaming patterns

### Remote Access
- ✅ Dual-plane architecture (RPyC + Arrow Flight)
- ✅ High-performance bulk data transfer
- ✅ Setting up remote servers
- ✅ Multiple concurrent clients
- ✅ Transparent remote proxy

### Custom Plugins
- ✅ Creating custom instrument classes
- ✅ Plugin registration and discovery
- ✅ Pip-installable package structure
- ✅ Entry points for auto-discovery

### GUI Integration
- ✅ Launching the GUI application
- ✅ Creating custom plot widgets
- ✅ Integrating remote instruments with GUI
- ✅ Session management

## Documentation

For more detailed documentation, see:
- [Main README](../README.md)
- [Dual-Plane Architecture](../DUAL_PLANE_ARCHITECTURE.md)
- [Quick Start Guide](../QUICK_START_DUAL_PLANE.md)

## Support

If you have questions or need help:
1. Check the documentation in the project root
2. Look at the demo files in `demo/`
3. Review test files in `tests/`

## Contributing

Feel free to add your own examples! Submit a pull request with:
- Clear, well-commented code
- A descriptive filename
- README updates if needed
