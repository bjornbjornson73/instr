#!/usr/bin/env python3
"""
Example 1: Basic Remote Client

This example demonstrates:
- Connecting to a remote instrument server
- Using RemoteInstrumentProxy for transparent remote access
- Same API as local instruments
- Remote data acquisition

Prerequisites:
- Start the server first: python 03_server_setup.py

Run: python 01_remote_client.py
"""

import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent / "src"))

from instrctl.core.remote import RemoteInstrumentProxy, RemoteConfig

print("=== Basic Remote Client Example ===\n")

# Configure remote connection
print("Configuring remote connection...")
config = RemoteConfig(
    host="localhost",      # Server hostname/IP
    port=18861,           # RPyC control port
    port_data=8815,       # Arrow Flight data port
)

print(f"Server: {config.host}:{config.port}")
print(f"Data port: {config.port_data}\n")

# Create remote instrument proxy
print("Creating remote instrument proxy...")
spec_analyzer = RemoteInstrumentProxy(
    kind="SpectrumAnalyzer",
    model="FullDemo",
    config=config
)

print(f"Connected to: {spec_analyzer}")
print(f"Features: {spec_analyzer.features()}\n")

# Use remote instrument just like a local one!
print("=== Configuring Remote Instrument ===")
spec_analyzer.center_freq = 2.45e9
spec_analyzer.span = 100e6
spec_analyzer.rbw = 1e6

print(f"Center Frequency: {spec_analyzer.center_freq / 1e9:.2f} GHz")
print(f"Span: {spec_analyzer.span / 1e6:.0f} MHz")
print(f"RBW: {spec_analyzer.rbw / 1e6:.0f} MHz\n")

# Start remote data acquisition
print("=== Starting Remote Data Acquisition ===")
spec_analyzer.start_sweep()
print("Sweep started on remote server\n")

# Read data from remote server
print("=== Reading Remote Data ===")
sample_count = 0
start_time = time.time()

try:
    while time.time() - start_time < 5.0:
        # Get data from remote instrument (via Arrow Flight)
        data = spec_analyzer.get_sweep_points()
        
        if data and len(data) > 0:
            sample_count += 1
            
            # Print every 10th sample
            if sample_count % 10 == 0:
                avg_power = sum(data) / len(data)
                print(f"Sample {sample_count}: {len(data)} points, "
                      f"Avg: {avg_power:.2f} dBm")
        
        time.sleep(0.01)

except KeyboardInterrupt:
    print("\nInterrupted by user")

# Stop remote instrument
print("\n=== Cleanup ===")
spec_analyzer.stop_sweep()
print("Sweep stopped")

# Calculate statistics
elapsed = time.time() - start_time
throughput = sample_count / elapsed

print(f"\n=== Performance ===")
print(f"Duration: {elapsed:.2f} seconds")
print(f"Samples: {sample_count}")
print(f"Throughput: {throughput:.1f} samples/sec")
print(f"Data rate: {throughput * 512:.1f} points/sec")

print("\n✓ Remote client example completed!")
print("\nKey Points:")
print("  • RemoteInstrumentProxy provides transparent remote access")
print("  • Same API as local instruments")
print("  • Control via RPyC, data via Arrow Flight")
print("  • High-performance bulk data transfer")
