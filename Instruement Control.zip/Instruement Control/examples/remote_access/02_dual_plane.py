#!/usr/bin/env python3
"""
Example 2: Dual-Plane Architecture

This example demonstrates:
- Understanding the dual-plane architecture
- Control plane (RPyC) for commands and setters
- Data plane (Arrow Flight) for bulk data transfer
- Performance benefits of separation

Prerequisites:
- Start the server first: python 03_server_setup.py

Run: python 02_dual_plane.py
"""

import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent / "src"))

from instrctl.core.remote import RemoteInstrumentProxy, RemoteConfig

print("=== Dual-Plane Architecture Example ===\n")

# Configure connection
config = RemoteConfig(
    host="localhost",
    port=18861,        # Control plane (RPyC)
    port_data=8815,    # Data plane (Arrow Flight)
)

# Create proxy
spec_analyzer = RemoteInstrumentProxy(
    kind="SpectrumAnalyzer",
    model="FullDemo",
    config=config
)

print("Architecture Overview:")
print("  Control Plane (RPyC):")
print("    • Port: 18861")
print("    • Used for: setters, getters, commands")
print("    • Example: start_sweep(), stop_sweep(), set frequency")
print("  ")
print("  Data Plane (Arrow Flight):")
print("    • Port: 8815")
print("    • Used for: bulk data transfer")
print("    • Example: get_sweep_points() -> large arrays")
print()

# Demonstrate control plane operations
print("=== Control Plane Operations (RPyC) ===")
print("These operations use the RPyC control plane:\n")

start = time.time()
spec_analyzer.center_freq = 2.45e9
elapsed_control = (time.time() - start) * 1000
print(f"• Set center_freq: {elapsed_control:.2f} ms")

start = time.time()
spec_analyzer.span = 100e6
elapsed_control = (time.time() - start) * 1000
print(f"• Set span: {elapsed_control:.2f} ms")

start = time.time()
spec_analyzer.start_sweep()
elapsed_control = (time.time() - start) * 1000
print(f"• Start sweep: {elapsed_control:.2f} ms")

print(f"\nControl plane latency: ~{elapsed_control:.1f} ms (typical)")

# Demonstrate data plane operations
print("\n=== Data Plane Operations (Arrow Flight) ===")
print("Large data transfers use the Arrow Flight data plane:\n")

# Wait for data to be ready
time.sleep(0.1)

# Measure data transfer performance
data_samples = []
for i in range(50):
    start = time.time()
    data = spec_analyzer.get_sweep_points()
    elapsed_data = (time.time() - start) * 1000
    
    if data and len(data) > 0:
        data_samples.append({
            'elapsed_ms': elapsed_data,
            'points': len(data),
            'bytes': len(data) * 4  # 4 bytes per float32
        })

if data_samples:
    avg_elapsed = sum(s['elapsed_ms'] for s in data_samples) / len(data_samples)
    avg_points = sum(s['points'] for s in data_samples) / len(data_samples)
    avg_bytes = sum(s['bytes'] for s in data_samples) / len(data_samples)
    avg_bandwidth = (avg_bytes / 1024) / (avg_elapsed / 1000)  # KB/s
    
    print(f"Samples: {len(data_samples)}")
    print(f"Average latency: {avg_elapsed:.2f} ms")
    print(f"Average points: {avg_points:.0f}")
    print(f"Average bytes: {avg_bytes:.0f}")
    print(f"Bandwidth: {avg_bandwidth:.1f} KB/s ({avg_bandwidth/1024:.2f} MB/s)")

# Stop
spec_analyzer.stop_sweep()

# Show the benefits
print("\n=== Benefits of Dual-Plane Architecture ===")
print("✓ Control operations don't block data transfer")
print("✓ Data transfer doesn't slow down control commands")
print("✓ Optimized protocols for each purpose:")
print("  • RPyC: Low-latency RPC for control")
print("  • Arrow Flight: High-throughput for bulk data")
print("✓ Scalable to multiple concurrent clients")
print("✓ No interference between planes")

print("\n=== Architecture Diagram ===")
print("""
    Client Side                    Server Side
    
    RemoteInstrumentProxy
           |
           |
    ┌──────┴──────┐
    │             │
    ▼             ▼
Control Plane  Data Plane
(RPyC:18861)  (Flight:8815)
    │             │
    │             │
    └──────┬──────┘
           │
           ▼
    Physical Instrument
""")

print("\n✓ Dual-plane architecture example completed!")
