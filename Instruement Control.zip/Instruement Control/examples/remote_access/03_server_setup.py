#!/usr/bin/env python3
"""
Example 3: Server Setup

This example demonstrates:
- Setting up a DualAgentServer
- Serving instruments remotely
- Handling multiple concurrent clients
- Server lifecycle management

Run this FIRST, then run client examples:
  python 03_server_setup.py

Press Ctrl+C to stop the server.
"""

import sys
import time
import signal
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent / "src"))

from instrctl.core.dual_agent import DualAgentServer
from instrctl.core.plugins import discover_all

print("=== DualAgentServer Setup ===\n")

# Discover plugins to make instruments available
print("Discovering instrument plugins...")
discover_all()
print("✓ Plugins discovered\n")

# Configure server
HOST = "localhost"
PORT_CONTROL = 18861
PORT_DATA = 8815

print("Server Configuration:")
print(f"  Host: {HOST}")
print(f"  Control Port (RPyC): {PORT_CONTROL}")
print(f"  Data Port (Arrow Flight): {PORT_DATA}\n")

# Create server
print("Creating DualAgentServer...")
server = DualAgentServer(
    host=HOST,
    port_control=PORT_CONTROL,
    port_data=PORT_DATA
)
print("✓ Server created\n")

# Setup signal handler for graceful shutdown
shutdown_flag = False

def signal_handler(sig, frame):
    global shutdown_flag
    print("\n\nReceived shutdown signal...")
    shutdown_flag = True

signal.signal(signal.SIGINT, signal_handler)

# Start server
print("="*70)
print("Starting server...")
print("="*70)

try:
    # Start in a non-blocking way by using a separate thread
    import threading
    server_thread = threading.Thread(target=server.start, daemon=False)
    server_thread.start()
    
    # Wait for server to initialize
    time.sleep(1.0)
    
    print("\n✅ Server is running!")
    print(f"   Control plane: {HOST}:{PORT_CONTROL}")
    print(f"   Data plane: {HOST}:{PORT_DATA}")
    print("\nClients can now connect using:")
    print("  python 01_remote_client.py")
    print("  python 02_dual_plane.py")
    print("  python 04_multi_client.py")
    print("\nPress Ctrl+C to stop the server\n")
    print("="*70)
    
    # Keep server running
    while not shutdown_flag:
        time.sleep(1.0)
    
    # Graceful shutdown
    print("\nShutting down server...")
    server.stop()
    server_thread.join(timeout=5.0)
    print("✓ Server stopped cleanly")

except Exception as e:
    print(f"\n❌ Server error: {e}")
    import traceback
    traceback.print_exc()
    server.stop()

print("\n=== Server Information ===")
print("The DualAgentServer provides:")
print("  ✓ RPyC service for control operations")
print("  ✓ Arrow Flight service for data transfer")
print("  ✓ Shared instrument instances")
print("  ✓ Thread-safe concurrent access")
print("  ✓ Automatic resource management")

print("\n=== Supported Instruments ===")
print("Clients can create remote proxies for:")
print("  • SpectrumAnalyzer")
print("  • VectorSignalGenerator")
print("  • Oven")
print("  • DCPowerSupply")
print("  • And any custom plugins installed")

print("\nServer setup example completed!")
