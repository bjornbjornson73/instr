#!/usr/bin/env python3
"""
Example 4: Multiple Concurrent Clients

This example demonstrates:
- Multiple clients connecting to the same server
- Independent instrument instances per client
- No interference between clients
- Concurrent data streaming

Prerequisites:
- Start the server first: python 03_server_setup.py

Run: python 04_multi_client.py
"""

import sys
import time
import threading
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent / "src"))

from instrctl.core.remote import RemoteInstrumentProxy, RemoteConfig

print("=== Multiple Concurrent Clients Example ===\n")

# Shared configuration
config = RemoteConfig(
    host="localhost",
    port=18861,
    port_data=8815,
)

# Statistics for each client
client_stats = {}
stats_lock = threading.Lock()

def run_client(client_id: int, duration: float = 5.0):
    """Run a client that connects and streams data"""
    try:
        # Create unique instrument instance
        proxy = RemoteInstrumentProxy(
            kind="SpectrumAnalyzer",
            model="FullDemo",
            config=config
        )
        
        print(f"Client {client_id}: Connected")
        
        # Configure with unique settings
        proxy.center_freq = 2.4e9 + (client_id * 100e6)
        proxy.span = 50e6
        
        # Start streaming
        proxy.start_sweep()
        print(f"Client {client_id}: Started sweep at {proxy.center_freq/1e9:.2f} GHz")
        
        # Collect data
        sample_count = 0
        total_points = 0
        start_time = time.time()
        
        while time.time() - start_time < duration:
            data = proxy.get_sweep_points()
            
            if data and len(data) > 0:
                sample_count += 1
                total_points += len(data)
            
            time.sleep(0.01)
        
        # Stop
        proxy.stop_sweep()
        elapsed = time.time() - start_time
        
        # Record statistics
        with stats_lock:
            client_stats[client_id] = {
                'samples': sample_count,
                'points': total_points,
                'duration': elapsed,
                'throughput': sample_count / elapsed if elapsed > 0 else 0,
            }
        
        print(f"Client {client_id}: Completed - {sample_count} samples, "
              f"{sample_count/elapsed:.1f} samples/sec")
    
    except Exception as e:
        print(f"Client {client_id}: Error - {e}")

# Launch multiple concurrent clients
print("Launching concurrent clients...\n")
num_clients = 4
duration = 5.0

threads = []
for i in range(num_clients):
    t = threading.Thread(
        target=run_client,
        args=(i, duration),
        daemon=False
    )
    threads.append(t)
    t.start()
    time.sleep(0.2)  # Stagger starts slightly

print(f"\n{num_clients} clients running concurrently for {duration} seconds...\n")

# Wait for all clients to complete
for t in threads:
    t.join()

# Print aggregate statistics
print("\n=== Aggregate Statistics ===")
print(f"Number of clients: {num_clients}")

if client_stats:
    total_samples = sum(s['samples'] for s in client_stats.values())
    total_points = sum(s['points'] for s in client_stats.values())
    avg_duration = sum(s['duration'] for s in client_stats.values()) / len(client_stats)
    total_throughput = sum(s['throughput'] for s in client_stats.values())
    
    print(f"Total samples: {total_samples}")
    print(f"Total points: {total_points}")
    print(f"Average duration: {avg_duration:.2f} seconds")
    print(f"Aggregate throughput: {total_throughput:.1f} samples/sec")
    print(f"Average per client: {total_throughput/num_clients:.1f} samples/sec")
    
    print("\n=== Per-Client Performance ===")
    for client_id in sorted(client_stats.keys()):
        stats = client_stats[client_id]
        print(f"Client {client_id}:")
        print(f"  Samples: {stats['samples']}")
        print(f"  Points: {stats['points']}")
        print(f"  Throughput: {stats['throughput']:.1f} samples/sec")
        print(f"  Bandwidth: {(stats['points']/stats['duration']*4/1024):.1f} KB/s")

print("\n=== Key Observations ===")
print("✓ Multiple clients connected simultaneously")
print("✓ Each client has independent instrument instance")
print("✓ No interference between clients")
print("✓ Server handles concurrent requests efficiently")
print("✓ Linear scaling of throughput")

print("\n=== Architecture Benefits ===")
print("• Shared server reduces resource overhead")
print("• Independent instrument instances per client")
print("• Thread-safe concurrent access")
print("• Efficient multiplexing of connections")
print("• Scalable to many clients")

print("\n✓ Multiple concurrent clients example completed!")
