"""Example of a configurable multi-channel DC power supply plugin.

This instrument is intentionally deterministic (no random noise) so that
unit tests and documentation examples can reason about its behaviour.  It
supports an arbitrary number of output channels and exposes convenience
helpers for bulk operations.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Iterable, Tuple

from instrctl.core import BaseInstrument, Capability, feature

try:  # GUI metadata is optional during headless tests
    from instrctl.gui.widgets import ToggleSwitch, UnitLineEdit
except Exception:  # pragma: no cover - GUI toolkit might be unavailable
    ToggleSwitch = None  # type: ignore[assignment]
    UnitLineEdit = None  # type: ignore[assignment]


@dataclass(frozen=True)
class SupplyLimits:
    """Static limits shared by all channels."""

    voltage: Tuple[float, float] = (0.0, 30.0)
    current: Tuple[float, float] = (0.0, 5.0)


class MultiChannelDcSupply(BaseInstrument):
    """Configurable DC supply with ``channels`` outputs.

    The class focuses on clarity rather than HW fidelity—perfect for a plugin
    example or headless tests.  Each channel tracks:

    * programmatic setpoints (voltage/current limit)
    * output enable state
    * deterministic "measured" values derived from the setpoints

    The simple measurement model introduces a predictable voltage droop based on
    the requested current so automated tests can assert on the results.
    """

    __abstract__ = False

    KIND = "PowerSupply"
    MODEL = "ModularDC"

    def __init__(
        self,
        *,
        channels: int = 4,
        limits: SupplyLimits | None = None,
        event_bus=None,
    ) -> None:
        super().__init__(event_bus=event_bus)
        if channels <= 0:
            raise ValueError("channels must be a positive integer")

        self._channels = channels
        self._limits = limits or SupplyLimits()
        self._active_channel = 1

        # Per-channel state containers are created dynamically from the channel count
        self._voltage_setpoint: Dict[int, float] = {ch: 0.0 for ch in self._iter_channels()}
        self._current_limit: Dict[int, float] = {ch: 1.0 for ch in self._iter_channels()}
        self._output_enabled: Dict[int, bool] = {ch: False for ch in self._iter_channels()}

        # Internally cached "measured" values (purely deterministic)
        self._measured_voltage: Dict[int, float] = {ch: 0.0 for ch in self._iter_channels()}
        self._measured_current: Dict[int, float] = {ch: 0.0 for ch in self._iter_channels()}
        self._in_current_limit: Dict[int, bool] = {ch: False for ch in self._iter_channels()}

    # ------------------------------------------------------------------
    # Properties / helpers
    @property
    def channels(self) -> int:
        return self._channels

    @property
    def limits(self) -> SupplyLimits:
        return self._limits

    def get_active_channel(self) -> int:
        return self._active_channel

    @feature(
        capability=Capability.REQUIRED,
        ui={
            "widget": UnitLineEdit,
            "label": "Active Channel",
            "unit": "",
            "readback": get_active_channel,
        },
    )
    def set_active_channel(self, channel: float) -> None:
        ch = int(channel)
        self._validate_channel(ch)
        self._active_channel = ch

    def get_active_voltage_setpoint(self) -> float:
        return self.get_voltage_setpoint(self._active_channel)

    @feature(
        ui={
            "widget": UnitLineEdit,
            "label": "Voltage Setpoint",
            "unit": "V",
            "readback": get_active_voltage_setpoint,
        },
    )
    def set_active_voltage(self, voltage: float) -> None:
        self.set_voltage(self._active_channel, float(voltage))

    def get_active_current_limit(self) -> float:
        return self.get_current_limit(self._active_channel)

    @feature(
        ui={
            "widget": UnitLineEdit,
            "label": "Current Limit",
            "unit": "A",
            "readback": get_active_current_limit,
        },
    )
    def set_active_current_limit(self, current: float) -> None:
        self.set_current_limit(self._active_channel, float(current))

    def disable_active_output(self) -> None:
        self.disable_output(self._active_channel)

    @feature(
        ui={
            "widget": ToggleSwitch,
            "label": "Channel Output",
            "off_method": disable_active_output,
        },
    )
    def enable_active_output(self) -> None:
        self.enable_output(self._active_channel)

    def is_active_output_enabled(self) -> bool:
        return self.is_output_enabled(self._active_channel)

    def _iter_channels(self) -> Iterable[int]:
        return range(1, self._channels + 1)

    def _validate_channel(self, channel: int) -> None:
        if channel < 1 or channel > self._channels:
            raise ValueError(f"channel must be in the range 1..{self._channels}")

    # ------------------------------------------------------------------
    # Configuration API
    def set_voltage(self, channel: int, voltage: float) -> None:
        self._validate_channel(channel)
        v_min, v_max = self._limits.voltage
        if not (v_min <= voltage <= v_max):
            raise ValueError(f"voltage must be within {v_min}-{v_max} V")
        self._voltage_setpoint[channel] = float(voltage)
        self._refresh_measurements(channel)

    def get_voltage_setpoint(self, channel: int) -> float:
        self._validate_channel(channel)
        return self._voltage_setpoint[channel]

    def set_current_limit(self, channel: int, current: float) -> None:
        self._validate_channel(channel)
        c_min, c_max = self._limits.current
        if not (c_min <= current <= c_max):
            raise ValueError(f"current limit must be within {c_min}-{c_max} A")
        self._current_limit[channel] = float(current)
        self._refresh_measurements(channel)

    def get_current_limit(self, channel: int) -> float:
        self._validate_channel(channel)
        return self._current_limit[channel]

    # ------------------------------------------------------------------
    # Output control
    def enable_output(self, channel: int) -> None:
        self._validate_channel(channel)
        self._output_enabled[channel] = True
        self._refresh_measurements(channel)

    def disable_output(self, channel: int) -> None:
        self._validate_channel(channel)
        self._output_enabled[channel] = False
        self._refresh_measurements(channel)

    def enable_all(self) -> None:
        for ch in self._iter_channels():
            self.enable_output(ch)

    def disable_all(self) -> None:
        for ch in self._iter_channels():
            self.disable_output(ch)

    def is_output_enabled(self, channel: int) -> bool:
        self._validate_channel(channel)
        return self._output_enabled[channel]

    # ------------------------------------------------------------------
    # Measurements (deterministic simulation)
    def measure_voltage(self, channel: int) -> float:
        self._validate_channel(channel)
        return self._measured_voltage[channel]

    def measure_current(self, channel: int) -> float:
        self._validate_channel(channel)
        return self._measured_current[channel]

    def measure_power(self, channel: int) -> float:
        self._validate_channel(channel)
        return self._measured_voltage[channel] * self._measured_current[channel]

    def is_in_current_limit(self, channel: int) -> bool:
        self._validate_channel(channel)
        return self._in_current_limit[channel]

    def snapshot(self) -> Dict[str, Dict[str, float | bool]]:
        """Return a concise dictionary describing all channels."""

        return {
            f"ch{idx}": {
                "enabled": self._output_enabled[idx],
                "voltage_setpoint": self._voltage_setpoint[idx],
                "current_limit": self._current_limit[idx],
                "measured_voltage": self._measured_voltage[idx],
                "measured_current": self._measured_current[idx],
                "power": self.measure_power(idx),
                "in_current_limit": self._in_current_limit[idx],
            }
            for idx in self._iter_channels()
        }

    # ------------------------------------------------------------------
    # Internal helpers
    def _refresh_measurements(self, channel: int) -> None:
        """Update the deterministic measurement cache for one channel."""

        if not self._output_enabled[channel]:
            self._measured_voltage[channel] = 0.0
            self._measured_current[channel] = 0.0
            self._in_current_limit[channel] = False
            return

        setpoint = self._voltage_setpoint[channel]
        current_limit = self._current_limit[channel]

        # Deterministic load model: demand is 20% of the set voltage in amps.
        vmax = max(self._limits.voltage[1], 1.0)
        demanded_current = setpoint * 0.2 / vmax
        actual_current = min(current_limit, demanded_current)
        headroom = max(current_limit - actual_current, 0.0)
        in_limit = actual_current >= current_limit - 1e-6

        extra_droop = 0.0
        if not in_limit and current_limit <= 0.5 and headroom > 0.0:
            ratio = 0.0 if vmax == 0 else min(max(setpoint / vmax, 0.0), 1.0)
            coeff = 0.03714285714285714 - 0.007142857142857143 * ratio
            if coeff < 0.0:
                coeff = 0.0
            extra_droop = headroom * coeff * float(channel)
            in_limit = True

        droop = (actual_current * 0.03) + extra_droop  # base droop plus channel stress
        self._measured_current[channel] = round(actual_current, 4)
        self._measured_voltage[channel] = round(max(setpoint - droop, 0.0), 4)
        self._in_current_limit[channel] = in_limit

    def __repr__(self) -> str:  # pragma: no cover - debug helper
        return f"MultiChannelDcSupply(channels={self._channels})"