"""
Digital Oscilloscope Implementation

A custom oscilloscope instrument demonstrating:
- Multi-channel support
- Configurable sampling
- Trigger configuration
- Waveform acquisition
"""

import random
import math
from typing import List, Optional

from instrctl.core import BaseInstrument


class DigitalOscilloscope(BaseInstrument):
    """
    Digital Oscilloscope with 4 channels.
    
    Features:
    - 4 analog input channels
    - Configurable sample rate (up to 10 GSa/s)
    - Hardware trigger
    - Deep memory
    - Waveform statistics
    """
    
    __abstract__ = False
    
    KIND = "Oscilloscope"
    MODEL = "Digital"
    
    def __init__(self, event_bus=None):
        super().__init__(event_bus=event_bus)
        
        # Configuration
        self._channels = 4
        self._sample_rate = 1e9  # 1 GSa/s
        self._record_length = 10000
        self._time_scale = 1e-6  # 1 us/div
        self._trigger_level = 0.0
        self._trigger_channel = 1
        
        # Channel settings (per channel)
        self._channel_enabled = {i: True for i in range(1, 5)}
        self._channel_scale = {i: 1.0 for i in range(1, 5)}  # V/div
        self._channel_offset = {i: 0.0 for i in range(1, 5)}
        self._channel_coupling = {i: "DC" for i in range(1, 5)}
        
        # Acquisition state
        self._acquiring = False
        self._waveform_data = {}
    
    @staticmethod
    def features():
        return ["control", "data_streaming", "triggering", "multi_channel"]
    
    # Configuration properties
    @property
    def channels(self) -> int:
        """Number of available channels"""
        return self._channels
    
    @property
    def sample_rate(self) -> float:
        """Sample rate in samples/second"""
        return self._sample_rate
    
    @sample_rate.setter
    def sample_rate(self, value: float):
        if value <= 0 or value > 10e9:
            raise ValueError("Sample rate must be 0 < rate <= 10 GSa/s")
        self._sample_rate = value
    
    @property
    def record_length(self) -> int:
        """Number of samples to acquire"""
        return self._record_length
    
    @record_length.setter
    def record_length(self, value: int):
        if value < 100 or value > 1000000:
            raise ValueError("Record length must be 100 <= length <= 1M")
        self._record_length = value
    
    @property
    def time_scale(self) -> float:
        """Time scale in seconds/division"""
        return self._time_scale
    
    @time_scale.setter
    def time_scale(self, value: float):
        if value <= 0:
            raise ValueError("Time scale must be positive")
        self._time_scale = value
    
    # Channel configuration
    def enable_channel(self, channel: int, enabled: bool = True):
        """Enable or disable a channel"""
        if channel < 1 or channel > self._channels:
            raise ValueError(f"Channel must be 1-{self._channels}")
        self._channel_enabled[channel] = enabled
    
    def set_channel_scale(self, channel: int, scale: float):
        """Set channel vertical scale (V/div)"""
        if channel < 1 or channel > self._channels:
            raise ValueError(f"Channel must be 1-{self._channels}")
        if scale <= 0:
            raise ValueError("Scale must be positive")
        self._channel_scale[channel] = scale
    
    def set_channel_offset(self, channel: int, offset: float):
        """Set channel vertical offset (V)"""
        if channel < 1 or channel > self._channels:
            raise ValueError(f"Channel must be 1-{self._channels}")
        self._channel_offset[channel] = offset
    
    def set_channel_coupling(self, channel: int, coupling: str):
        """Set channel coupling (AC/DC/GND)"""
        if channel < 1 or channel > self._channels:
            raise ValueError(f"Channel must be 1-{self._channels}")
        if coupling not in ["AC", "DC", "GND"]:
            raise ValueError("Coupling must be AC, DC, or GND")
        self._channel_coupling[channel] = coupling
    
    # Trigger configuration
    def set_trigger(self, channel: int, level: float):
        """Configure edge trigger"""
        if channel < 1 or channel > self._channels:
            raise ValueError(f"Channel must be 1-{self._channels}")
        self._trigger_channel = channel
        self._trigger_level = level
    
    # Acquisition control
    def start_acquisition(self):
        """Start continuous acquisition"""
        self._acquiring = True
        self._generate_waveforms()
    
    def stop_acquisition(self):
        """Stop acquisition"""
        self._acquiring = False
    
    def single_acquisition(self):
        """Trigger a single acquisition"""
        self._generate_waveforms()
    
    # Data retrieval
    def get_waveform(self, channel: int) -> List[float]:
        """
        Get waveform data for specified channel.
        
        Returns:
            List of voltage samples
        """
        if channel < 1 or channel > self._channels:
            raise ValueError(f"Channel must be 1-{self._channels}")
        
        if not self._channel_enabled[channel]:
            return []
        
        if self._acquiring:
            self._generate_waveforms()
        
        return self._waveform_data.get(channel, [])
    
    def get_statistics(self, channel: int) -> dict:
        """
        Calculate waveform statistics.
        
        Returns:
            Dictionary with min, max, mean, rms, frequency
        """
        waveform = self.get_waveform(channel)
        if not waveform:
            return {}
        
        return {
            "min": min(waveform),
            "max": max(waveform),
            "mean": sum(waveform) / len(waveform),
            "rms": math.sqrt(sum(v**2 for v in waveform) / len(waveform)),
            "peak_to_peak": max(waveform) - min(waveform),
            "samples": len(waveform),
        }
    
    # Internal simulation
    def _generate_waveforms(self):
        """Generate simulated waveform data"""
        for ch in range(1, self._channels + 1):
            if not self._channel_enabled[ch]:
                continue
            
            # Generate sine wave with noise
            waveform = []
            amplitude = self._channel_scale[ch] * 2.0
            offset = self._channel_offset[ch]
            frequency = 1.0 / (self._time_scale * 10)  # Complete cycle in 10 divisions
            
            for i in range(self._record_length):
                t = i / self._sample_rate
                # Sine wave + noise
                value = amplitude * math.sin(2 * math.pi * frequency * t)
                value += offset
                value += random.gauss(0, amplitude * 0.02)  # 2% noise
                waveform.append(value)
            
            self._waveform_data[ch] = waveform
    
    def __repr__(self):
        return (f"DigitalOscilloscope(channels={self._channels}, "
                f"rate={self._sample_rate/1e9:.1f}GSa/s, "
                f"length={self._record_length})")
