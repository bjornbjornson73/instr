"""
Custom Instrument Plugin Package

This package demonstrates how to create a pip-installable plugin for InstrCtl.
"""

from instrctl.core.registry import InstrumentRegistry
from .oscilloscope import DigitalOscilloscope
from .power_supply import ProgrammablePowerSupply
from .n_channel_power_supply import MultiChannelDcSupply

__version__ = "0.1.0"
__all__ = [
    "DigitalOscilloscope",
    "ProgrammablePowerSupply",
    "MultiChannelDcSupply",
    "register",
]


def register() -> None:
    """Register all instruments in this plugin with the global registry."""

    InstrumentRegistry.register(
        getattr(DigitalOscilloscope, "KIND"),
        getattr(DigitalOscilloscope, "MODEL"),
        DigitalOscilloscope,
    )

    InstrumentRegistry.register(
        getattr(ProgrammablePowerSupply, "KIND"),
        getattr(ProgrammablePowerSupply, "MODEL"),
        ProgrammablePowerSupply,
    )

    InstrumentRegistry.register(
        getattr(MultiChannelDcSupply, "KIND"),
        getattr(MultiChannelDcSupply, "MODEL"),
        MultiChannelDcSupply,
    )


# Auto-register when package is imported
register()
