"""
Programmable Power Supply Implementation

A custom power supply instrument demonstrating:
- Multi-channel output
- Voltage/current control
- Current limiting
- Measurement capability
"""

import random
from typing import Dict

from instrctl.core import BaseInstrument


class ProgrammablePowerSupply(BaseInstrument):
    """
    Programmable DC Power Supply with 3 channels.
    
    Features:
    - 3 independent output channels
    - Voltage control (0-30V)
    - Current control (0-5A)
    - Current limiting
    - Voltage/current measurement
    - Over-voltage/over-current protection
    """
    
    __abstract__ = False
    
    KIND = "PowerSupply"
    MODEL = "Programmable"
    
    def __init__(self, event_bus=None):
        super().__init__(event_bus=event_bus)
        
        # Configuration
        self._num_channels = 3
        
        # Per-channel state
        self._voltage_setpoint = {i: 0.0 for i in range(1, 4)}
        self._current_limit = {i: 1.0 for i in range(1, 4)}
        self._output_enabled = {i: False for i in range(1, 4)}
        
        # Measurement (simulated)
        self._measured_voltage = {i: 0.0 for i in range(1, 4)}
        self._measured_current = {i: 0.0 for i in range(1, 4)}
        self._in_current_limit = {i: False for i in range(1, 4)}
    
    @staticmethod
    def features():
        return ["control", "measurement", "multi_channel"]
    
    @property
    def num_channels(self) -> int:
        """Number of output channels"""
        return self._num_channels
    
    # Voltage control
    def set_voltage(self, channel: int, voltage: float):
        """
        Set output voltage for channel.
        
        Args:
            channel: Channel number (1-3)
            voltage: Voltage in Volts (0-30V)
        """
        self._validate_channel(channel)
        if voltage < 0 or voltage > 30:
            raise ValueError("Voltage must be 0-30V")
        
        self._voltage_setpoint[channel] = voltage
        
        # Update measurements if output is enabled
        if self._output_enabled[channel]:
            self._update_measurements(channel)
    
    def get_voltage_setpoint(self, channel: int) -> float:
        """Get voltage setpoint for channel"""
        self._validate_channel(channel)
        return self._voltage_setpoint[channel]
    
    # Current control
    def set_current_limit(self, channel: int, current: float):
        """
        Set current limit for channel.
        
        Args:
            channel: Channel number (1-3)
            current: Current limit in Amps (0-5A)
        """
        self._validate_channel(channel)
        if current < 0 or current > 5:
            raise ValueError("Current limit must be 0-5A")
        
        self._current_limit[channel] = current
        
        # Update measurements if output is enabled
        if self._output_enabled[channel]:
            self._update_measurements(channel)
    
    def get_current_limit(self, channel: int) -> float:
        """Get current limit for channel"""
        self._validate_channel(channel)
        return self._current_limit[channel]
    
    # Output control
    def enable_output(self, channel: int):
        """Enable output for channel"""
        self._validate_channel(channel)
        self._output_enabled[channel] = True
        self._update_measurements(channel)
    
    def disable_output(self, channel: int):
        """Disable output for channel"""
        self._validate_channel(channel)
        self._output_enabled[channel] = False
        self._measured_voltage[channel] = 0.0
        self._measured_current[channel] = 0.0
        self._in_current_limit[channel] = False
    
    def is_output_enabled(self, channel: int) -> bool:
        """Check if output is enabled"""
        self._validate_channel(channel)
        return self._output_enabled[channel]
    
    def enable_all_outputs(self):
        """Enable all outputs"""
        for ch in range(1, self._num_channels + 1):
            self.enable_output(ch)
    
    def disable_all_outputs(self):
        """Disable all outputs"""
        for ch in range(1, self._num_channels + 1):
            self.disable_output(ch)
    
    # Measurements
    def measure_voltage(self, channel: int) -> float:
        """
        Measure actual output voltage.
        
        Returns:
            Measured voltage in Volts
        """
        self._validate_channel(channel)
        if not self._output_enabled[channel]:
            return 0.0
        
        self._update_measurements(channel)
        return self._measured_voltage[channel]
    
    def measure_current(self, channel: int) -> float:
        """
        Measure actual output current.
        
        Returns:
            Measured current in Amps
        """
        self._validate_channel(channel)
        if not self._output_enabled[channel]:
            return 0.0
        
        self._update_measurements(channel)
        return self._measured_current[channel]
    
    def measure_power(self, channel: int) -> float:
        """
        Calculate output power.
        
        Returns:
            Power in Watts
        """
        voltage = self.measure_voltage(channel)
        current = self.measure_current(channel)
        return voltage * current
    
    def is_in_current_limit(self, channel: int) -> bool:
        """Check if channel is in current limiting mode"""
        self._validate_channel(channel)
        return self._in_current_limit[channel]
    
    # Status
    def get_channel_status(self, channel: int) -> Dict:
        """
        Get complete status for channel.
        
        Returns:
            Dictionary with all channel parameters
        """
        self._validate_channel(channel)
        
        return {
            "enabled": self._output_enabled[channel],
            "voltage_setpoint": self._voltage_setpoint[channel],
            "current_limit": self._current_limit[channel],
            "measured_voltage": self.measure_voltage(channel),
            "measured_current": self.measure_current(channel),
            "measured_power": self.measure_power(channel),
            "in_current_limit": self._in_current_limit[channel],
        }
    
    def get_all_status(self) -> Dict:
        """Get status for all channels"""
        return {
            f"channel_{ch}": self.get_channel_status(ch)
            for ch in range(1, self._num_channels + 1)
        }
    
    # Internal helpers
    def _validate_channel(self, channel: int):
        """Validate channel number"""
        if channel < 1 or channel > self._num_channels:
            raise ValueError(f"Channel must be 1-{self._num_channels}")
    
    def _update_measurements(self, channel: int):
        """Simulate measurements (add some noise and load effects)"""
        if not self._output_enabled[channel]:
            return
        
        # Simulate voltage droop under load (0-2% depending on current)
        setpoint = self._voltage_setpoint[channel]
        limit = self._current_limit[channel]
        
        # Simulated load current (random, but respects limit)
        load_current = random.uniform(0, limit * 1.1)
        
        # Check if in current limiting
        if load_current > limit:
            self._in_current_limit[channel] = True
            actual_current = limit
            # Voltage drops significantly when current limited
            actual_voltage = setpoint * 0.95
        else:
            self._in_current_limit[channel] = False
            actual_current = load_current
            # Small voltage drop proportional to current
            droop = (actual_current / limit) * 0.02 * setpoint
            actual_voltage = setpoint - droop
        
        # Add measurement noise (0.1%)
        actual_voltage += random.gauss(0, setpoint * 0.001)
        actual_current += random.gauss(0, actual_current * 0.001)
        
        self._measured_voltage[channel] = max(0, actual_voltage)
        self._measured_current[channel] = max(0, actual_current)
    
    def __repr__(self):
        enabled = sum(1 for v in self._output_enabled.values() if v)
        return (f"ProgrammablePowerSupply(channels={self._num_channels}, "
                f"enabled={enabled})")
