"""Lightweight regression tests for the custom plugin package.

The script can be executed directly (``python test_plugin.py``) or collected by
pytest.  It exercises both the existing demo instruments and the new
``MultiChannelDcSupply`` example to ensure the plugin stays installable and
functional.
"""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

from instrctl.core import InstrumentFactory, InstrumentRegistry
from instrctl.core.plugins import discover_all

_HERE = Path(__file__).resolve().parent
if str(_HERE) not in sys.path:
	sys.path.insert(0, str(_HERE))

import my_instruments


@pytest.fixture(scope="module", autouse=True)
def _ensure_plugin_registered():
	"""Guarantee the plugin is registered before any tests run."""

	discover_all()
	my_instruments.register()


def test_plugin_models_present():
	available = InstrumentRegistry.list_kinds()

	assert "Oscilloscope" in available
	assert "Digital" in available["Oscilloscope"]

	assert "PowerSupply" in available
	assert "Programmable" in available["PowerSupply"]
	assert "ModularDC" in available["PowerSupply"]


def test_programmable_power_supply_status():
	supply = InstrumentFactory.create("PowerSupply", "Programmable")

	supply.set_voltage(1, 5.0)
	supply.set_current_limit(1, 2.0)
	supply.enable_output(1)

	status = supply.get_channel_status(1)
	assert status["enabled"] is True
	assert 0.0 <= status["voltage_setpoint"] <= 30.0
	assert 0.0 <= status["measured_voltage"] <= 30.0
	assert 0.0 <= status["measured_current"] <= 5.0


def test_modular_power_supply_dynamic_channels():
	supply = InstrumentFactory.create("PowerSupply", "ModularDC", channels=6)

	assert supply.channels == 6

	supply.set_voltage(6, 12.0)
	supply.set_current_limit(6, 1.5)

	with pytest.raises(ValueError):
		supply.set_voltage(7, 1.0)

	supply.enable_output(6)

	measured_v = supply.measure_voltage(6)
	measured_i = supply.measure_current(6)
	measured_p = supply.measure_power(6)

	assert measured_v == pytest.approx(11.9976, abs=1e-4)
	assert measured_i == pytest.approx(0.08, abs=1e-3)
	assert measured_p == pytest.approx(measured_v * measured_i, abs=1e-5)

	snapshot = supply.snapshot()
	ch6 = snapshot["ch6"]
	assert ch6["enabled"] is True
	assert ch6["measured_voltage"] == pytest.approx(measured_v, abs=1e-6)
	assert ch6["power"] == pytest.approx(measured_p, abs=1e-6)

	supply.disable_output(6)
	assert supply.measure_voltage(6) == 0.0
	assert supply.measure_current(6) == 0.0


if __name__ == "__main__":  # pragma: no cover - manual execution helper
	raise SystemExit(pytest.main([__file__]))
