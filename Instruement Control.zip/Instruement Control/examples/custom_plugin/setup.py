"""
Setup configuration for custom InstrCtl plugin
"""

from setuptools import setup, find_packages
from pathlib import Path

# Read README for long description
readme_file = Path(__file__).parent / "README.md"
long_description = readme_file.read_text() if readme_file.exists() else ""

setup(
    name="instrctl-my-instruments",
    version="0.1.0",
    description="Custom instrument plugin for InstrCtl",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Your Name",
    author_email="your.email@example.com",
    url="https://github.com/yourusername/instrctl-my-instruments",
    
    # Package discovery
    packages=find_packages(),
    
    # Dependencies
    install_requires=[
        "instrctl",  # Main InstrCtl package
    ],
    
    # Python version requirement
    python_requires=">=3.8",
    
    # Entry points for plugin discovery
    entry_points={
        "instrctl.plugins": [
            "my_instruments = my_instruments:register",
        ],
    },
    
    # Classification
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Science/Research",
        "Topic :: Scientific/Engineering :: Interface Engine/Protocol Translator",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    
    # Keywords for PyPI search
    keywords="instrumentation, test equipment, oscilloscope, power supply, remote control",
    
    # Project URLs
    project_urls={
        "Bug Reports": "https://github.com/yourusername/instrctl-my-instruments/issues",
        "Source": "https://github.com/yourusername/instrctl-my-instruments",
        "Documentation": "https://github.com/yourusername/instrctl-my-instruments/blob/main/README.md",
    },
)
