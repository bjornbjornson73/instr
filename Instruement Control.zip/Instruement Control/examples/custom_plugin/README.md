# Custom Instrument Plugin Example

This directory contains a complete example of a **pip-installable instrument plugin** for InstrCtl.

## What's Included

- **Custom Instruments**: Oscilloscope and Power Supply implementations
- **Plugin Registration**: Automatic discovery via entry points
- **Pip Installation**: Standard Python packaging with setup.py and pyproject.toml
- **Complete Documentation**: Usage examples and API reference

## Installation

### Development Mode (Editable Install)
```bash
cd examples/custom_plugin
pip install -e .
```

### Production Mode
```bash
cd examples/custom_plugin
pip install .
```

## Directory Structure

```
custom_plugin/
├── README.md                    # This file
├── setup.py                     # Installation configuration
├── pyproject.toml               # Modern Python packaging
├── test_plugin.py               # Test the plugin
└── my_instruments/              # Plugin package
    ├── __init__.py              # Package initialization
    ├── oscilloscope.py          # Custom oscilloscope
    └── power_supply.py          # Custom power supply
```

## Creating Your Own Plugin

### 1. Create Package Structure

```bash
mkdir my_plugin
cd my_plugin
mkdir my_plugin  # Package directory with same name
```

### 2. Implement Instruments

Create `my_plugin/my_instrument.py`:

```python
from instrctl.core import BaseInstrument

class MyInstrument(BaseInstrument):
    __abstract__ = False
    
    KIND = "MyInstrument"
    MODEL = "Version1"
    
    def __init__(self, event_bus=None):
        super().__init__(event_bus=event_bus)
        self._data = []
    
    @staticmethod
    def features():
        return ["control", "data_streaming"]
    
    def start_acquisition(self):
        """Start data acquisition"""
        pass
    
    def stop_acquisition(self):
        """Stop data acquisition"""
        pass
    
    def get_data(self):
        """Get acquired data"""
        return self._data
```

### 3. Register Plugin

Create `my_plugin/__init__.py`:

```python
from instrctl.core import InstrumentRegistry
from .my_instrument import MyInstrument

def register():
    """Register instruments with InstrCtl"""
    InstrumentRegistry.register(MyInstrument)
    print(f"Registered {MyInstrument.KIND}/{MyInstrument.MODEL}")

# Auto-register on import
register()
```

### 4. Setup Installation

Create `setup.py`:

```python
from setuptools import setup, find_packages

setup(
    name="my-instrctl-plugin",
    version="0.1.0",
    packages=find_packages(),
    install_requires=[
        "instrctl",
    ],
    entry_points={
        "instrctl.plugins": [
            "my_plugin = my_plugin:register",
        ],
    },
)
```

### 5. Install and Use

```bash
pip install -e .
```

```python
from instrctl.core import InstrumentFactory
from instrctl.core.plugins import discover_all

discover_all()  # Auto-discovers installed plugins

inst = InstrumentFactory.create("MyInstrument", "Version1")
inst.start_acquisition()
data = inst.get_data()
```

## Using This Example Plugin

After installation, the plugin is automatically discovered:

```python
from instrctl.core import InstrumentFactory
from instrctl.core.plugins import discover_all

# Discover all plugins (including this one)
discover_all()

# Create oscilloscope
scope = InstrumentFactory.create("Oscilloscope", "Digital")
scope.channels = 4
scope.sample_rate = 1e9  # 1 GSa/s
scope.start_acquisition()
data = scope.get_waveform(channel=1)

# Create power supply
psu = InstrumentFactory.create("PowerSupply", "Programmable")
psu.set_voltage(channel=1, voltage=5.0)
psu.set_current_limit(channel=1, current=2.0)
psu.enable_output(channel=1)
```

## Testing the Plugin

```bash
python test_plugin.py
```

This will:
- Discover and load the plugin
- Create instances of each instrument
- Test basic functionality
- Verify remote compatibility

## Plugin Features

### Oscilloscope
- Multi-channel support (1-4 channels)
- Configurable sample rate
- Trigger configuration
- Waveform acquisition
- Statistics calculation

### Power Supply
- Multi-channel support
- Voltage/current setting
- Current limiting
- Output enable/disable
- Measurement readback

## Remote Access

Your custom plugin instruments can be used remotely:

```python
from instrctl.core.remote import RemoteInstrumentProxy, RemoteConfig

config = RemoteConfig(host="localhost", port=18861, port_data=8815)

# Remote oscilloscope
scope = RemoteInstrumentProxy(
    kind="Oscilloscope",
    model="Digital",
    config=config
)

# Use exactly like local instrument!
scope.start_acquisition()
data = scope.get_waveform(channel=1)
```

## GUI Integration

Your instruments automatically work with the GUI:

```python
from instrctl.gui.app import main

# Your instruments will appear in the GUI's instrument list
main()
```

## Best Practices

1. **Inherit from BaseInstrument**: Use the framework's base class
2. **Set KIND and MODEL**: Unique identifiers for your instrument
3. **Implement features()**: Document capabilities
4. **Use EventBus**: For loosely coupled communication
5. **Thread Safety**: Ensure thread-safe operations
6. **Error Handling**: Robust exception handling
7. **Documentation**: Docstrings for all public methods

## Distribution

### PyPI Upload
```bash
python setup.py sdist bdist_wheel
twine upload dist/*
```

### Users Install
```bash
pip install my-instrctl-plugin
```

## License

Choose an appropriate license for your plugin (MIT, Apache, GPL, etc.)

## Contributing

Contributions welcome! Please:
1. Follow the existing code style
2. Add tests for new features
3. Update documentation
4. Submit pull requests

## Support

For questions about plugin development:
- See main InstrCtl documentation
- Check existing plugins in `plugins/` directory
- Review example instruments in `plugins/example_instrumnets.py`
