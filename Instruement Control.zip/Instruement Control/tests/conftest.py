import contextlib
import socket
import sys
import time
from pathlib import Path
from typing import Dict, Iterator

# Ensure local sources take precedence over any installed instrctl package
_ROOT = Path(__file__).resolve().parents[1]
_SRC = _ROOT / "src"
if _SRC.exists():
    sys.path.insert(0, str(_SRC))

import pytest

from instrctl.core.dual_agent import DualAgentServer


def _find_free_port() -> int:
    with contextlib.closing(socket.socket(socket.AF_INET, socket.SOCK_STREAM)) as sock:
        sock.bind(("127.0.0.1", 0))
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        return int(sock.getsockname()[1])


@pytest.fixture(scope="session", autouse=True)
def _load_builtin_plugins() -> None:
    """Ensure built-in and bundled plugins are registered for tests."""
    print("[FIXTURE] Loading built-in plugins for test session", flush=True)
    from instrctl.core.plugins import discover_all

    discover_all()


@pytest.fixture(scope="session")
def dual_agent_endpoint() -> Iterator[Dict[str, int]]:
    """Start a DualAgentServer on ephemeral ports for integration tests."""
    print("[FIXTURE] Launching DualAgentServer for test session", flush=True)
    host = "127.0.0.1"
    control_port = _find_free_port()
    data_port = _find_free_port()
    server = DualAgentServer(host=host, port_control=control_port, port_data=data_port)
    server.start()

    # Give background threads time to bind sockets
    time.sleep(1.0)

    try:
        yield {
            "host": host,
            "port_control": control_port,
            "port_data": data_port,
        }
    finally:
        server.stop()
        time.sleep(0.5)


@pytest.fixture
def remote_config(dual_agent_endpoint):
    from instrctl.core.remote import RemoteConfig
    print("[FIXTURE] Creating RemoteConfig for test", flush=True)
    return RemoteConfig(
        host=dual_agent_endpoint["host"],
        port=dual_agent_endpoint["port_control"],
        port_data=dual_agent_endpoint["port_data"],
        use_dual_transport=True,
    )
