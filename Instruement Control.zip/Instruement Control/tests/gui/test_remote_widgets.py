import os
import sys
import time

import contextlib

import pytest
from PySide6 import QtTest, QtWidgets  # type: ignore[import]


pytestmark = pytest.mark.skipif(
    sys.platform.startswith("win"),
    reason="Qt offscreen remote streaming tests are unstable on Windows",
)

from instrctl.core.remote import RemoteInstrumentProxy
from instrctl.gui.widgets import EventPlotWidget, SweepPlotWidget


@pytest.fixture(scope="session")
def qt_app():
    os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
    app = QtWidgets.QApplication.instance()
    owns_app = False
    if app is None:
        app = QtWidgets.QApplication([])
        owns_app = True
    yield app
    if owns_app:
        app.quit()


@pytest.fixture
def remote_proxy(remote_config):
    proxy = RemoteInstrumentProxy(kind="RemoteDemo", model="RemoteDemoFull", config=remote_config)
    proxy.connect()
    try:
        yield proxy
    finally:
        with contextlib.suppress(Exception):
            proxy.stop()
        with contextlib.suppress(Exception):
            proxy.stop_rate()
        proxy.disconnect()


def _drain_events(app: QtWidgets.QApplication, duration_s: float = 1.5) -> None:
    deadline = time.monotonic() + float(duration_s)
    while time.monotonic() < deadline:
        app.processEvents()
        QtTest.QTest.qWait(25)


def test_event_plot_remote_stream(qt_app, remote_proxy):
    ui_meta = {
        "getter": "get_data_rate_bps",
        "start": "start_rate",
        "stop": "stop_rate",
        "interval_ms": 200,
        "max_points": 500,
    }
    widget = EventPlotWidget(remote_proxy, ui=ui_meta)
    widget.show()
    try:
        widget._on_start()
        _drain_events(qt_app, duration_s=1.8)
        qt_app.processEvents()
        assert widget._buf_y, "event plot should accumulate remote samples"
    finally:
        widget._on_stop()
        widget.close()


def test_sweep_plot_remote_stream(qt_app, remote_proxy):
    ui_meta = {
        "getter": "get_points",
        "start": "start",
        "stop": "stop",
        "interval_ms": 150,
    }
    widget = SweepPlotWidget(remote_proxy, ui=ui_meta)
    widget.show()
    try:
        widget._on_start()
        _drain_events(qt_app, duration_s=1.8)
        qt_app.processEvents()
        assert widget._last_ys, "sweep plot should render latest sweep samples"
    finally:
        widget._on_stop()
        widget.close()
