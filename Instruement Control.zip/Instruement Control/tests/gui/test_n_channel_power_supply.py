from __future__ import annotations

import pytest

from examples.custom_plugin.my_instruments.n_channel_power_supply import (
    MultiChannelDcSupply,
    SupplyLimits,
)


def test_constructor_validates_channel_count():
    with pytest.raises(ValueError):
        MultiChannelDcSupply(channels=0)

    supply = MultiChannelDcSupply(channels=3)
    assert supply.channels == 3


def test_voltage_and_current_setpoints_update_measurements():
    supply = MultiChannelDcSupply(channels=2)

    supply.enable_output(1)
    supply.set_voltage(1, 12.0)
    supply.set_current_limit(1, 1.0)

    assert supply.get_voltage_setpoint(1) == 12.0
    assert supply.get_current_limit(1) == 1.0
    assert supply.measure_voltage(1) == pytest.approx(11.9976, abs=1e-4)
    assert supply.measure_current(1) == pytest.approx(0.08, abs=1e-4)
    assert supply.measure_power(1) == pytest.approx(supply.measure_voltage(1) * supply.measure_current(1))


def test_limits_enforced():
    limits = SupplyLimits(voltage=(0.0, 5.0), current=(0.0, 0.5))
    supply = MultiChannelDcSupply(channels=1, limits=limits)

    supply.enable_output(1)

    with pytest.raises(ValueError):
        supply.set_voltage(1, 6.0)
    supply.set_voltage(1, 5.0)

    with pytest.raises(ValueError):
        supply.set_current_limit(1, 0.6)
    supply.set_current_limit(1, 0.5)

    assert supply.measure_voltage(1) == pytest.approx(4.985, abs=1e-4)
    assert supply.is_in_current_limit(1) is True


def test_enable_disable():
    supply = MultiChannelDcSupply(channels=2)

    supply.set_voltage(2, 9.0)
    supply.set_current_limit(2, 0.2)
    supply.enable_output(2)
    assert supply.is_output_enabled(2) is True
    assert supply.measure_voltage(2) > 0.0

    supply.disable_output(2)
    assert supply.is_output_enabled(2) is False
    assert supply.measure_voltage(2) == 0.0
    assert supply.measure_current(2) == 0.0


def test_enable_all_disable_all():
    supply = MultiChannelDcSupply(channels=3)

    supply.enable_all()
    assert all(supply.is_output_enabled(ch) for ch in range(1, 4))

    supply.disable_all()
    assert not any(supply.is_output_enabled(ch) for ch in range(1, 4))


def test_snapshot_contains_all_channels():
    supply = MultiChannelDcSupply(channels=4)

    for ch in range(1, 5):
        supply.set_voltage(ch, 3.0 * ch)
        supply.set_current_limit(ch, 0.5)
        supply.enable_output(ch)

    snap = supply.snapshot()
    assert len(snap) == 4

    ch4 = snap["ch4"]
    assert ch4["enabled"] is True
    assert ch4["voltage_setpoint"] == 12.0
    assert ch4["measured_voltage"] == pytest.approx(11.94, abs=1e-4)
    assert ch4["power"] == pytest.approx(ch4["measured_voltage"] * ch4["measured_current"], abs=1e-6)