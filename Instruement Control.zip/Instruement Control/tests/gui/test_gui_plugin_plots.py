from __future__ import annotations

import contextlib
import logging
import os
from typing import Dict

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import pytest

pytest.importorskip("pytestqt")

from PySide6 import QtCore  # type: ignore[import]

from instrctl.core import EventBus, InstrumentFactory
from instrctl.core.registry import InstrumentRegistry
from instrctl.core.remote import RemoteInstrumentProxy
from instrctl.core.plugins import discover_all
from instrctl.gui import widgets


@pytest.mark.gui
def test_demo_plugin_plots_render_and_stop(qtbot):
    discover_all()

    bus = EventBus()
    window = widgets.MainWindow(bus)
    widgets._ui_clock.ensure_started()
    qtbot.addWidget(window)
    with qtbot.waitExposed(window):
        window.show()

    # Multi-trace plot (Network Analyzer)
    net = InstrumentFactory.create("NetworkAnalyzer", "NetworkAnalyzerFullDemo", event_bus=bus)
    net.connect(type="DEMO")
    window.add_instrument(net)
    assert window.docks, "Instrument dock was not created"
    net_dock = window.docks[-1]
    net_dock.ensure_built()
    net_tab = net_dock.widget()
    assert isinstance(net_tab, widgets.InstrumentTab)
    multi_plot = next(
        (w for w in getattr(net_tab, "_owned_plot_widgets", []) if isinstance(w, widgets.MultiTracePlotWidget)),
        None,
    )
    assert multi_plot is not None

    qtbot.mouseClick(multi_plot._start_btn, QtCore.Qt.LeftButton)

    def _multi_has_samples() -> bool:
        curves: Dict[str, object] = getattr(multi_plot, "_curves", {})
        for curve in curves.values():
            try:
                data = curve.getData()  # type: ignore[call-arg]
            except Exception:  # pragma: no cover - defensive for pyqtgraph changes
                continue
            if not data:
                continue
            xs = data[0]
            if xs is not None and len(xs) > 0:
                return True
        return False

    qtbot.waitUntil(_multi_has_samples, timeout=4000)
    qtbot.mouseClick(multi_plot._stop_btn, QtCore.Qt.LeftButton)
    qtbot.waitUntil(lambda: not getattr(multi_plot, "_feed_handles", {}), timeout=1000)

    # Event plot (Vector Signal Generator)
    vec = InstrumentFactory.create("VectorSignalGenerator", "VectorSignalGeneratorFullDemo", event_bus=bus)
    vec.connect(type="DEMO")
    window.add_instrument(vec)
    assert len(window.docks) >= 2
    event_dock = window.docks[-1]
    event_dock.ensure_built()
    event_tab = event_dock.widget()
    assert isinstance(event_tab, widgets.InstrumentTab)
    event_plot = next(
        (w for w in getattr(event_tab, "_owned_plot_widgets", []) if isinstance(w, widgets.EventPlotWidget)),
        None,
    )
    assert event_plot is not None

    start_len = len(getattr(event_plot, "_buf_x", []) or [])
    qtbot.mouseClick(event_plot._start_btn, QtCore.Qt.LeftButton)

    def _event_has_samples() -> bool:
        buf = getattr(event_plot, "_buf_x", None)
        return bool(buf) and len(buf) > start_len

    qtbot.waitUntil(_event_has_samples, timeout=4000)
    qtbot.mouseClick(event_plot._stop_btn, QtCore.Qt.LeftButton)
    qtbot.waitUntil(lambda: getattr(event_plot, "_feed_handle", None) is None, timeout=1000)

    window.close()
    qtbot.wait(100)


@pytest.mark.gui
def test_remote_multi_trace_stop_releases_remote_stream(qtbot, remote_config, monkeypatch):
    discover_all()

    from plugins.example_instrumnets import NetworkAnalyzerFullDemo

    call_counts = {"get_s11": 0}

    orig_get_s11 = NetworkAnalyzerFullDemo.get_s11

    def _wrapped_get_s11(self):
        call_counts["get_s11"] += 1
        return orig_get_s11(self)

    monkeypatch.setattr(NetworkAnalyzerFullDemo, "get_s11", _wrapped_get_s11, raising=False)

    bus = EventBus()
    proxy = RemoteInstrumentProxy(kind="NetworkAnalyzer", model="NetworkAnalyzerFullDemo", config=remote_config, event_bus=bus)
    impl = InstrumentRegistry.get("NetworkAnalyzer", "NetworkAnalyzerFullDemo")
    if impl is not None:
        type(proxy)._impl_cls = impl  # type: ignore[attr-defined]

    proxy.connect()
    assert proxy.is_connected()

    ui_meta = proxy.features()["show_network"]["ui"]
    widget = widgets.MultiTracePlotWidget(proxy, ui=ui_meta)
    widgets._ui_clock.ensure_started()
    qtbot.addWidget(widget)
    widget.show()

    try:
        qtbot.mouseClick(widget._start_btn, QtCore.Qt.LeftButton)
        qtbot.waitUntil(lambda: call_counts["get_s11"] >= 3, timeout=5000)

        qtbot.mouseClick(widget._stop_btn, QtCore.Qt.LeftButton)
        qtbot.waitUntil(lambda: not getattr(widget, "_feed_handles", {}), timeout=2000)

        stopped_at = call_counts["get_s11"]
        qtbot.wait(1000)
        post_stop = call_counts["get_s11"]
        assert post_stop <= stopped_at + 1, f"remote sweep continued streaming after stop (delta={post_stop - stopped_at})"
    finally:
        widget.close()
        with contextlib.suppress(Exception):
            proxy.disconnect()


@pytest.mark.gui
def test_remote_sweep_stop_releases_remote_stream(qtbot, remote_config, monkeypatch):
    logging.getLogger().setLevel(logging.DEBUG)
    logging.getLogger("instrctl").setLevel(logging.DEBUG)
    print("[TEST] Starting remote_sweep_stop test", flush=True)
    discover_all()

    from plugins.remote_demo_plugin import RemoteDemoFull

    call_counts = {"get_points": 0}

    orig_get_points = RemoteDemoFull.get_points

    def _wrapped_get_points(self):
        call_counts["get_points"] += 1
        return orig_get_points(self)

    monkeypatch.setattr(RemoteDemoFull, "get_points", _wrapped_get_points, raising=False)

    bus = EventBus()
    proxy = RemoteInstrumentProxy(kind="RemoteDemo", model="RemoteDemoFull", config=remote_config, event_bus=bus)
    impl = InstrumentRegistry.get("RemoteDemo", "RemoteDemoFull")
    if impl is not None:
        type(proxy)._impl_cls = impl  # type: ignore[attr-defined]

    proxy.connect()
    assert proxy.is_connected()
    print("[TEST] Proxy connected", flush=True)

    ui_meta = {
        "getter": "get_points",
        "start": "start",
        "stop": "stop",
        "interval_ms": 150,
    }
    widget = widgets.SweepPlotWidget(proxy, ui=ui_meta)
    print("[TEST] Widget instantiated", flush=True)
    widgets._ui_clock.ensure_started()
    qtbot.addWidget(widget)
    widget.show()

    try:
        qtbot.mouseClick(widget._start_btn, QtCore.Qt.LeftButton)
        print("[TEST] Start clicked", flush=True)
        qtbot.waitUntil(lambda: call_counts["get_points"] >= 3, timeout=6000)
        print(f"[TEST] call_counts reached {call_counts['get_points']}", flush=True)

        qtbot.mouseClick(widget._stop_btn, QtCore.Qt.LeftButton)
        print("[TEST] Stop clicked", flush=True)

        stopped_at = call_counts["get_points"]
        print(f"[TEST] stopped_at count={stopped_at}", flush=True)
        qtbot.wait(1200)
        post_stop = call_counts["get_points"]
        print(f"[TEST] post_stop count={post_stop}", flush=True)
        assert post_stop <= stopped_at + 1, (
            f"remote sweep continued streaming after stop (delta={post_stop - stopped_at})"
        )
        print("[TEST] Stop assertion passed", flush=True)
    finally:
        print("[TEST] Cleaning up widget", flush=True)
        widget.close()
        with contextlib.suppress(Exception):
            proxy.disconnect()
        print("[TEST] Cleanup done", flush=True)
