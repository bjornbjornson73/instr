from __future__ import annotations

import itertools
import os
from pathlib import Path

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import pytest

pytest.importorskip("pytestqt")

from PySide6 import QtCore, QtWidgets  # type: ignore[import]

from instrctl.gui import widgets


class DummyInstrument:
    kind = "Dummy"
    model = "Demo"

    def __init__(self):
        self.started = False
        self.stopped = False

    def event_getter(self):
        return [(0.0, 1.0), (1.0, 2.0)]

    def start_event(self):
        self.started = True

    def stop_event(self):
        self.stopped = True


class DummyFeedManager:
    def __init__(self):
        self._counter = itertools.count()
        self.started_handles: set[int] = set()
        self.stop_calls: list[int] = []
        self.unsubscribe_calls: list[int] = []
        self.last_callback = None

    def subscribe(self, inst, getter, interval, callback, accumulate):
        handle = next(self._counter)
        self.last_callback = callback
        return handle

    def start(self, handle):
        self.started_handles.add(handle)

    def stop(self, handle):
        self.stop_calls.append(handle)
        self.started_handles.discard(handle)

    def unsubscribe(self, handle):
        self.unsubscribe_calls.append(handle)

    def update_interval(self, handle, interval):
        # No-op for tests; capture if needed later
        pass


@pytest.mark.gui
def test_event_plot_widget_buttons(qtbot, tmp_path, monkeypatch):
    dummy_mgr = DummyFeedManager()
    monkeypatch.setattr(widgets, "_feed_mgr", dummy_mgr)

    save_path = tmp_path / "export.csv"
    monkeypatch.setattr(
        QtWidgets.QFileDialog,
        "getSaveFileName",
        lambda *args, **kwargs: (str(save_path), "CSV Files (*.csv)"),
    )

    inst = DummyInstrument()
    ui = {
        "getter": "event_getter",
        "start": "start_event",
        "stop": "stop_event",
        "interval_ms": 50,
        "markers": False,
    }

    widget = widgets.EventPlotWidget(inst, ui=ui)
    qtbot.addWidget(widget)
    widget.show()

    # Choose file button
    qtbot.mouseClick(widget._file_btn, QtCore.Qt.LeftButton)
    assert widget._file_path == save_path
    assert widget._file_label.text() == save_path.name

    # Start button
    qtbot.mouseClick(widget._start_btn, QtCore.Qt.LeftButton)
    assert inst.started is True
    assert widget._start_btn.isEnabled() is False
    assert widget._stop_btn.isEnabled() is True
    assert dummy_mgr.started_handles
    handle = next(iter(dummy_mgr.started_handles))

    # Autoscale button
    vb = widget._plot.getPlotItem().getViewBox()
    vb.setXRange(0.0, 1.0)
    vb.setYRange(0.0, 1.0)
    widget._buf_x = [10.0, 20.0, 30.0]
    widget._buf_y = [1.0, 2.0, 3.0]
    widget._auto_follow = False
    before_range = vb.viewRange()
    qtbot.mouseClick(widget._fit_btn, QtCore.Qt.LeftButton)
    after_range = vb.viewRange()
    assert widget._auto_follow is True
    assert after_range != before_range

    # Clear button
    widget._buf_x = [5.0]
    widget._buf_y = [6.0]
    widget._status.setText("populated")
    widget._auto_follow = False
    qtbot.mouseClick(widget._clear_btn, QtCore.Qt.LeftButton)
    assert widget._buf_x == []
    assert widget._buf_y == []
    assert widget._status.text() == ""
    assert widget._auto_follow is True

    # Stop button
    qtbot.mouseClick(widget._stop_btn, QtCore.Qt.LeftButton)
    assert inst.stopped is True
    assert widget._start_btn.isEnabled() is True
    assert widget._stop_btn.isEnabled() is False
    assert handle in dummy_mgr.stop_calls or handle not in dummy_mgr.started_handles
    assert handle in dummy_mgr.unsubscribe_calls

    widget.close()

    if save_path.exists():
        contents = save_path.read_text(encoding="utf-8")
        assert "time_s" in contents or contents == ""
