import math

import pytest


def _call_helpers():
    from instrctl.gui.widgets import _select_follow_window, _compute_plot_bounds

    return _select_follow_window, _compute_plot_bounds


def test_select_follow_window_limits_length():
    select, _ = _call_helpers()
    xs = list(range(10))
    ys = [v * 2 for v in xs]
    out_x, out_y = select(xs, ys, follow_pts=3)
    assert out_x == [7, 8, 9]
    assert out_y == [14, 16, 18]


def test_select_follow_window_returns_full_sequence_when_disabled():
    select, _ = _call_helpers()
    xs = [1, 2, 3]
    ys = [10, 20, 30]
    out_x, out_y = select(xs, ys, follow_pts=0)
    assert out_x is xs
    assert out_y is ys


def test_compute_plot_bounds_basic():
    _, compute = _call_helpers()
    bounds = compute([1.0, 5.0, 3.0], [10.0, 5.0, 15.0])
    assert bounds == (1.0, 5.0, 5.0, 15.0)


def test_compute_plot_bounds_expands_degenerate_axes():
    _, compute = _call_helpers()
    xmin, xmax, ymin, ymax = compute([2.0, 2.0], [4.0, 4.0])
    assert math.isclose(xmin, 1.5)
    assert math.isclose(xmax, 2.5)
    assert math.isclose(ymin, 3.5)
    assert math.isclose(ymax, 4.5)


def test_compute_plot_bounds_raises_when_empty():
    _, compute = _call_helpers()
    with pytest.raises(ValueError):
        compute([], [])
