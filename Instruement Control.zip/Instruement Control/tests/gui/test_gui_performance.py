from __future__ import annotations

import os
from dataclasses import replace
from typing import List, Tuple

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import pytest

pytest.importorskip("pytestqt")

from PySide6 import QtCore  # type: ignore[import]

from instrctl.core import EventBus
from instrctl.core.plugins import discover_all
from instrctl.core.remote import RemoteInstrumentProxy
from instrctl.core.registry import InstrumentRegistry
from instrctl.gui import widgets


def _extract_plot(tab: widgets.InstrumentTab, cls) -> QtCore.QObject:
    for w in getattr(tab, "_owned_plot_widgets", []):
        if isinstance(w, cls):
            return w
    raise AssertionError(f"{cls.__name__} not found in InstrumentTab")


def _start_button(plot) -> QtCore.QObject:
    btn = getattr(plot, "_start_btn", None)
    if btn is None:
        raise AssertionError("Plot widget has no _start_btn")
    return btn


def _stop_button(plot) -> QtCore.QObject:
    btn = getattr(plot, "_stop_btn", None)
    if btn is None:
        raise AssertionError("Plot widget has no _stop_btn")
    return btn


def _has_samples(plot) -> bool:
    if isinstance(plot, widgets.MultiTracePlotWidget):
        for curve in getattr(plot, "_curves", {}).values():
            try:
                data = curve.getData()  # type: ignore[call-arg]
            except Exception:
                continue
            if data and data[0] is not None and len(data[0]) > 0:
                return True
        return False
    if isinstance(plot, widgets.EventPlotWidget):
        buf = getattr(plot, "_buf_x", [])
        return bool(buf)
    if isinstance(plot, widgets.SweepPlotWidget):
        xs = getattr(plot, "_last_xs", [])
        return bool(xs)
    raise AssertionError(f"Unsupported plot type {type(plot).__name__}")


@pytest.mark.gui
def test_many_plots_stream_concurrently(qtbot, remote_config):
    discover_all()

    bus = EventBus()
    window = widgets.MainWindow(bus)
    widgets._ui_clock.ensure_started()
    qtbot.addWidget(window)
    with qtbot.waitExposed(window):
        window.show()

    specs: List[Tuple[str, str, type]] = [
        ("NetworkAnalyzer", "NetworkAnalyzerFullDemo", widgets.MultiTracePlotWidget),
        ("SpectrumAnalyzer", "SpectrumAnalyzerFullDemo", widgets.SweepPlotWidget),
        ("VectorSignalGenerator", "VectorSignalGeneratorFullDemo", widgets.EventPlotWidget),
    ]

    plots: List[object] = []
    instruments = []
    replicas = 2
    for _ in range(replicas):
        for kind, model, cls in specs:
            cfg = replace(remote_config)
            inst = RemoteInstrumentProxy(kind=kind, model=model, config=cfg, event_bus=bus)
            impl = InstrumentRegistry.get(kind, model)
            if impl is not None:
                type(inst)._impl_cls = impl  # Ensure GUI metadata resolves to concrete implementation
            inst.connect(type="DEMO")
            window.add_instrument(inst)
            dock = window.docks[-1]
            dock.ensure_built()
            tab = dock.widget()
            assert isinstance(tab, widgets.InstrumentTab)
            plot = _extract_plot(tab, cls)
            plots.append(plot)
            instruments.append(inst)

    # Start all plots nearly simultaneously
    for plot in plots:
        qtbot.mouseClick(_start_button(plot), QtCore.Qt.LeftButton)

    # Wait for each plot to accumulate data within reasonable time
    for plot in plots:
        qtbot.waitUntil(lambda p=plot: _has_samples(p), timeout=5000)

    # Stop all feeds and ensure handles cleared
    for plot in plots:
        qtbot.mouseClick(_stop_button(plot), QtCore.Qt.LeftButton)

    qtbot.waitUntil(
        lambda: all(
            (not getattr(p, "_feed_handles", {}))
            if isinstance(p, widgets.MultiTracePlotWidget)
            else getattr(p, "_feed_handle", None) is None
            for p in plots
        ),
        timeout=3000,
    )

    # Clean up
    for inst in instruments:
        inst.disconnect()
    window.close()
