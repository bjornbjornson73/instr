from __future__ import annotations

import os
from unittest import mock

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import pytest

pytest.importorskip("pytestqt")

from PySide6 import QtCore  # type: ignore[import]

from instrctl.core import EventBus, InstrumentFactory
from instrctl.core.plugins import discover_all
from instrctl.gui import widgets


@pytest.mark.gui
def test_multi_trace_start_stop_invokes_instrument_callbacks(qtbot):
    discover_all()

    bus = EventBus()
    inst = InstrumentFactory.create("NetworkAnalyzer", "NetworkAnalyzerFullDemo", event_bus=bus)
    inst.connect(type="DEMO")

    with mock.patch.object(inst, "start_sweep", wraps=inst.start_sweep) as start_mock, \
         mock.patch.object(inst, "stop_sweep", wraps=inst.stop_sweep) as stop_mock:
        ui_meta = inst.features()["show_network"]["ui"]
        widget = widgets.MultiTracePlotWidget(inst, ui=ui_meta)
        qtbot.addWidget(widget)
        widget.show()
        assert callable(widget._start_fn)
        assert callable(widget._stop_fn)

        qtbot.mouseClick(widget._start_btn, QtCore.Qt.LeftButton)
        qtbot.waitUntil(lambda: start_mock.called, timeout=2000)

        qtbot.mouseClick(widget._stop_btn, QtCore.Qt.LeftButton)
        qtbot.waitUntil(lambda: stop_mock.called, timeout=2000)

        widget.close()

    inst.disconnect()
