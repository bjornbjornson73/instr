import math

import pytest


@pytest.fixture
def normalize():
    from instrctl.gui.widgets import _normalize_plot_points  # noqa: PLC2701 (import inside test)

    return _normalize_plot_points


def test_normalize_pair_sequence(normalize):
    xs, ys, mode = normalize([(1, 2), ("3", "4")])
    assert xs == [1.0, 3.0]
    assert ys == [2.0, 4.0]
    assert mode == "explicit"


def test_normalize_scalar_sequence_with_start(normalize):
    xs, ys, mode = normalize([1, "2.5"], start_index=5)
    assert xs == [5, 6]
    assert ys == [1.0, 2.5]
    assert mode == "index"


def test_normalize_filters_invalid_entries(normalize):
    xs, ys, mode = normalize([float("nan"), float("inf"), -float("inf"), "3.14"])
    assert xs == [0]
    assert ys == [3.14]
    assert mode == "index"


def test_normalize_empty_on_non_iterable(normalize):
    xs, ys, mode = normalize(None)
    assert xs == []
    assert ys == []
    assert mode == "index"


def test_normalize_empty_when_all_invalid(normalize):
    xs, ys, mode = normalize([float("nan"), "not-a-number"])
    assert xs == []
    assert ys == []
    assert mode == "index"
