from __future__ import annotations

from typing import List

import pytest

from instrctl import utils


class _Clock:
    def __init__(self) -> None:
        self._now = 0.0

    def __call__(self) -> float:
        return self._now

    def advance(self, seconds: float) -> None:
        self._now += seconds

    def sleep(self, seconds: float) -> None:
        self.advance(seconds)


class DummyInstrument:
    def __init__(self) -> None:
        self.counter = 0

    def fetch_points(self) -> List[tuple[int, int]]:
        self.counter += 1
        return [(self.counter, self.counter * 10)]

    def fetch_pair(self):
        return ([1, 2, 3], [4, 5, 6])


def test_resolve_getter_accepts_strings():
    inst = DummyInstrument()
    getter = utils.resolve_getter(inst, "fetch_points")
    assert getter() == [(1, 10)]

    with pytest.raises(AttributeError):
        utils.resolve_getter(inst, "missing")


def test_collect_stream_minutes_accumulates_samples():
    inst = DummyInstrument()
    clock = _Clock()

    samples = utils.collect_stream_minutes(
        inst,
        "fetch_points",
        minutes=0.001,
        poll_interval_s=0.05,
        clock=clock,
        sleep_fn=clock.sleep,
    )

    assert len(samples) >= 2
    assert samples[0] == (1, 10)
    assert samples[-1][0] == inst.counter


def test_collect_stream_minutes_with_timestamps_and_tuple_payload():
    inst = DummyInstrument()
    clock = _Clock()

    samples = utils.collect_stream_minutes(
        inst,
        inst.fetch_pair,
        minutes=0.0,
        include_timestamps=True,
        poll_interval_s=0.0,
        clock=clock,
        sleep_fn=clock.sleep,
    )

    assert len(samples) == 3
    ts, value = samples[0]
    assert ts == pytest.approx(0.0)
    assert value == (1, 4)


def test_collect_stream_seconds_alias():
    inst = DummyInstrument()
    clock = _Clock()

    samples = utils.collect_stream_seconds(
        inst,
        "fetch_points",
        seconds=6.0,
        poll_interval_s=3.0,
        clock=clock,
        sleep_fn=clock.sleep,
    )

    assert len(samples) == 2
    assert samples == [(1, 10), (2, 20)]
    assert inst.counter == 2