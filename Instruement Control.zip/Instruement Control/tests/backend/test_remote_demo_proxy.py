import contextlib
import time
from typing import Callable, Sequence

import pytest

from instrctl.core.remote import RemoteInstrumentProxy


def _wait_for(getter: Callable[[], Sequence[float]], condition: Callable[[Sequence[float]], bool], *, timeout: float = 6.0, poll: float = 0.1) -> Sequence[float]:
    """Poll a getter until the provided condition is satisfied or timeout occurs."""

    deadline = time.monotonic() + timeout
    last: Sequence[float] = []
    while time.monotonic() < deadline:
        batch = getter()
        last = batch
        if condition(batch):
            return batch
        time.sleep(poll)
    pytest.fail(f"Condition not satisfied within {timeout}s; last payload size={len(last)}")


def test_remote_demo_proxy_stream(remote_config):
    proxy = RemoteInstrumentProxy(kind="RemoteDemo", model="RemoteDemoFull", config=remote_config)
    proxy.connect()
    try:
        assert proxy.is_connected()

        proxy.start()
        sweep = _wait_for(proxy.get_points, lambda data: len(data) >= 1)
        assert all(isinstance(value, float) for value in sweep)

        proxy.set_sweep_size(256)
        sweep_256 = _wait_for(proxy.get_points, lambda data: len(data) == 256)
        assert len(sweep_256) == 256

        proxy.start_rate()
        rate_samples = _wait_for(proxy.get_data_rate_bps, lambda data: any(value > 0.0 for value in data))
        assert any(value > 0.0 for value in rate_samples)
        proxy.stop_rate()

    finally:
        with contextlib.suppress(Exception):
            proxy.stop()
        proxy.disconnect()
        assert not proxy.is_connected()


def test_remote_demo_proxy_reconnect(remote_config):
    proxy = RemoteInstrumentProxy(kind="RemoteDemo", model="RemoteDemoFull", config=remote_config)

    proxy.connect()
    assert proxy.is_connected()
    proxy.disconnect()
    assert not proxy.is_connected()

    proxy.connect()
    try:
        assert proxy.is_connected()
        proxy.start()
        sweep = _wait_for(proxy.get_points, lambda data: bool(data))
        assert sweep
    finally:
        with contextlib.suppress(Exception):
            proxy.stop()
        proxy.disconnect()
