import json
import sys
import types

import pytest

from instrctl.core.remote import RemoteConfig, RemoteInstrumentProxy


class FakeFlightClient:
    def __init__(self, responses):
        self._responses = responses
        self.actions = []

    def do_action(self, action):
        self.actions.append(action)
        return [types.SimpleNamespace(body=json.dumps(resp).encode("utf-8")) for resp in self._responses]


class FakeFlightModule:
    class Action:
        def __init__(self, name, data):
            self.type = name
            self.body = data


@pytest.fixture
def patched_flight(monkeypatch):
    fake_module = FakeFlightModule()
    pyarrow_ns = types.SimpleNamespace(flight=fake_module)
    monkeypatch.setitem(sys.modules, "pyarrow", pyarrow_ns)
    monkeypatch.setitem(sys.modules, "pyarrow.flight", fake_module)
    return fake_module


def _make_proxy():
    config = RemoteConfig(host="localhost")
    proxy = RemoteInstrumentProxy(kind="demo", model="loopback", config=config)
    proxy._transport = None
    return proxy


def test_invoke_remote_flight_success(patched_flight):
    proxy = _make_proxy()
    client = FakeFlightClient([{"value": 123}])
    proxy._ctl_client = client

    result = proxy._invoke_remote("measure", 1, 2, extra="ok")

    assert result == {"value": 123}
    assert client.actions, "expected invoke action recorded"
    action = client.actions[0]
    assert action.type == "invoke"
    payload = json.loads(action.body.decode("utf-8"))
    assert payload["method"] == "measure"
    assert payload["args"] == [1, 2]
    assert payload["kwargs"] == {"extra": "ok"}


def test_invoke_remote_flight_error(patched_flight):
    proxy = _make_proxy()
    client = FakeFlightClient([{"error": "boom"}])
    proxy._ctl_client = client

    with pytest.raises(RuntimeError):
        proxy._invoke_remote("measure")
