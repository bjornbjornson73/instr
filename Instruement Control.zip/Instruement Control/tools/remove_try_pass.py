"""Utility script to remove try/except blocks with pass-only handlers."""
from __future__ import annotations

import argparse
from pathlib import Path
import sys

import libcst as cst


class RemoveTryPass(cst.CSTTransformer):
    """Transformer that strips try/except blocks whose handlers are no-ops."""

    def _handler_is_noop(self, handler: cst.ExceptHandler) -> bool:
        body = handler.body
        if body is None:
            return True
        statements = list(body.body)
        for stmt in statements:
            if isinstance(stmt, cst.EmptyLine):
                continue
            if isinstance(stmt, cst.SimpleStatementLine):
                if all(isinstance(small, cst.Pass) for small in stmt.body):
                    continue
            return False
        return True

    def leave_Try(self, original_node: cst.Try, updated_node: cst.Try):  # type: ignore[override]
        if updated_node.finalbody is not None:
            return updated_node
        if updated_node.orelse is not None:
            return updated_node
        if not updated_node.handlers:
            return updated_node
        if not all(self._handler_is_noop(handler) for handler in updated_node.handlers):
            return updated_node
        return cst.FlattenSentinel(updated_node.body.body)


def process_file(path: Path) -> bool:
    source = path.read_text(encoding="utf-8")
    try:
        module = cst.parse_module(source)
    except cst.ParserSyntaxError:
        print(f"Skipping unparsable file: {path}", file=sys.stderr)
        return False
    new_module = module.visit(RemoveTryPass())
    if new_module.code != source:
        path.write_text(new_module.code, encoding="utf-8")
        return True
    return False


def main(argv: list[str]) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("paths", nargs="*", type=Path, help="Paths to search for Python files")
    args = parser.parse_args(argv)

    roots = args.paths or [Path.cwd() / "src"]
    total = 0
    modified = 0
    for root in roots:
        if root.is_file() and root.suffix == ".py":
            total += 1
            if process_file(root):
                modified += 1
            continue
        if not root.exists():
            continue
        for path in root.rglob("*.py"):
            if "__pycache__" in path.parts:
                continue
            total += 1
            if process_file(path):
                modified += 1
    print(f"Processed {total} files, modified {modified} files")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
